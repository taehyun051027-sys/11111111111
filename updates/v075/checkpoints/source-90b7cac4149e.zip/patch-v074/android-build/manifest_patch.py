"""Small, guarded binary-AXML delta for the exact shipped v0.7.3 APK.

Existing string indices, resource IDs, element bytes and resource references
are retained. No apktool decode/rebuild or resource-table regeneration occurs.
"""
from dataclasses import dataclass, field
import hashlib, struct, zipfile
from pathlib import Path

BASE_SHA256 = 'fe77f183ae813348ca1cea57596c4528429f08aa5f41792df005f6c1c375ae1d'
PACKAGE = 'com.taehyun.yagu'
GAME_ACTIVITY = 'com.gamevil.bb2013.global.SkeletonLauncher'
APP = 'androidx.multidex.MultiDexApplication'
GATE = 'com.taehyun.yagu.patch.GateActivity'
MANAGER = 'com.taehyun.yagu.patch.PatchManagerActivity'
PROVIDER = 'com.taehyun.yagu.patch.PatchProvider'
AUTHORITY = 'com.taehyun.yagu.bridge'
ANDROID = 'http://schemas.android.com/apk/res/android'
DUMP = 'android.permission.DUMP'
NO_INDEX = 0xffffffff

def u16(data, off): return struct.unpack_from('<H', data, off)[0]
def u32(data, off): return struct.unpack_from('<I', data, off)[0]
def p32(data, off, value): struct.pack_into('<I', data, off, value)

class StringPool:
    def __init__(self, chunk):
        kind, h, size = struct.unpack_from('<HHI', chunk)
        count, styles, flags, start, style_start = struct.unpack_from('<5I', chunk, 8)
        assert kind == 1 and h == 28 and size == len(chunk)
        assert styles == 0 and style_start == 0 and flags == 0, 'Unexpected string-pool format'
        self.flags = flags
        self.offsets = [u32(chunk, h + 4*i) for i in range(count)]
        self.data = bytearray(chunk[start:]) # Includes original padding; indices stay stable.
        self.strings = []
        for offset in self.offsets:
            n = u16(self.data, offset); offset += 2
            if n & 0x8000:
                n = ((n & 0x7fff) << 16) | u16(self.data, offset); offset += 2
            self.strings.append(bytes(self.data[offset:offset+2*n]).decode('utf-16le'))
        self.original_strings = list(self.strings)
    def index(self, text):
        try: return self.strings.index(text)
        except ValueError:
            raw = text.encode('utf-16le'); units = len(raw)//2
            assert units < 0x8000
            self.offsets.append(len(self.data))
            self.data += struct.pack('<H', units) + raw + b'\0\0'
            self.strings.append(text)
            return len(self.strings)-1
    def get(self, index): return None if index == NO_INDEX else self.strings[index]
    def encode(self):
        count = len(self.strings); start = 28 + count*4
        payload = bytes(self.data)
        payload += b'\0' * ((-(start + len(payload))) % 4)
        return (struct.pack('<HHI5I', 1, 28, start+len(payload), count, 0, self.flags, start, 0)
                + struct.pack('<'+'I'*count, *self.offsets) + payload)

@dataclass
class Node:
    start: bytearray
    children: list = field(default_factory=list)
    end: bytes = b''
    def encode(self):
        return bytes(self.start) + b''.join(x.encode() if isinstance(x, Node) else x for x in self.children) + self.end
    @property
    def name_index(self): return u32(self.start, 20)
    def name(self, pool): return pool.get(self.name_index)
    def attributes(self, pool):
        result = {}
        offset = 16 + u16(self.start, 24)
        width, count = u16(self.start, 26), u16(self.start, 28)
        assert width == 20
        for i in range(count):
            a = offset + width*i
            namespace, name, raw = struct.unpack_from('<III', self.start, a)
            size, zero, datatype, value = struct.unpack_from('<HBBI', self.start, a+12)
            assert size == 8 and zero == 0
            result[(pool.get(namespace), pool.get(name))] = {
                'offset': a, 'raw_index': raw, 'type': datatype, 'data': value,
                'value': pool.get(value) if datatype == 3 else value}
        return result
    def get(self, pool, name, namespace=ANDROID):
        return self.attributes(pool)[(namespace, name)]['value']
    def put(self, pool, name, value, datatype=3, namespace=ANDROID):
        attr = self.attributes(pool)[(namespace, name)]
        a = attr['offset']; data = pool.index(value) if datatype == 3 else value
        p32(self.start, a+8, data if datatype == 3 else NO_INDEX)
        self.start[a+15] = datatype; p32(self.start, a+16, data)
    def elements(self, pool, name):
        return [x for x in self.children if isinstance(x, Node) and x.name(pool) == name]

class Manifest:
    def __init__(self, raw):
        kind, header, total = struct.unpack_from('<HHI', raw)
        assert kind == 3 and header == 8 and total == len(raw)
        self.items, stack = [], []
        self.pool = None
        self.resource_map = None
        offset = 8
        while offset < len(raw):
            kind, h, size = struct.unpack_from('<HHI', raw, offset)
            assert size >= h >= 8 and offset+size <= len(raw)
            chunk = bytes(raw[offset:offset+size]); offset += size
            if kind == 1:
                assert self.pool is None
                self.pool = StringPool(chunk); self.items.append(self.pool)
            elif kind == 0x180:
                self.resource_map = chunk; self.items.append(chunk)
            elif kind == 0x102:
                assert h == 16
                node = Node(bytearray(chunk))
                (stack[-1].children if stack else self.items).append(node); stack.append(node)
            elif kind == 0x103:
                assert stack and u32(chunk,20) == stack[-1].name_index
                stack[-1].end = chunk; stack.pop()
            else:
                (stack[-1].children if stack else self.items).append(chunk)
        assert not stack and self.pool and self.resource_map
        roots = [x for x in self.items if isinstance(x, Node)]
        assert len(roots) == 1 and roots[0].name(self.pool) == 'manifest'
        self.root = roots[0]
    def encode(self):
        body = b''.join(x.encode() if isinstance(x,(Node,StringPool)) else x for x in self.items)
        return struct.pack('<HHI', 3, 8, 8+len(body)) + body
    def new_node(self, tag, attrs):
        pool = self.pool; namespace = pool.index(ANDROID)
        resource_ids = list(struct.unpack('<'+'I'*((len(self.resource_map)-8)//4),self.resource_map[8:]))
        encoded_attrs = []
        for name, datatype, value in attrs:
            name_index = pool.index(name)
            assert name_index < len(resource_ids), f'New attribute needs a resource-map entry: {name}'
            data = pool.index(value) if datatype == 3 else value
            raw = data if datatype == 3 else NO_INDEX
            encoded = struct.pack('<IIIHBBI', namespace, name_index, raw, 8, 0, datatype, data)
            encoded_attrs.append((resource_ids[name_index], encoded))
        encoded_attrs.sort(key=lambda x:x[0]) # Android binary XML resource-ID order.
        tag_index = pool.index(tag)
        start = struct.pack('<HHIII',0x102,16,36+20*len(attrs),0,NO_INDEX)
        start += struct.pack('<II6H',NO_INDEX,tag_index,20,20,len(attrs),0,0,0)
        start += b''.join(x[1] for x in encoded_attrs)
        end = struct.pack('<HHIIIII',0x103,16,24,0,NO_INDEX,NO_INDEX,tag_index)
        return Node(bytearray(start),[],end)

def is_launcher(node,pool):
    if node.name(pool) != 'intent-filter': return False
    actions = [x.get(pool,'name') for x in node.elements(pool,'action')]
    categories = [x.get(pool,'name') for x in node.elements(pool,'category')]
    return 'android.intent.action.MAIN' in actions and 'android.intent.category.LAUNCHER' in categories

def patch_manifest(raw):
    m = Manifest(raw); pool = m.pool; root = m.root
    assert root.get(pool,'package',None) == PACKAGE
    assert root.get(pool,'versionName') == '1.2.9'
    assert root.get(pool,'versionCode') == 129002
    app, = root.elements(pool,'application')
    assert app.get(pool,'name') == 'androidx.multidex.MultiDexApplication'
    old_app_label, old_app_icon = app.get(pool,'label'), app.get(pool,'icon')
    activities = app.elements(pool,'activity')
    game, = [x for x in activities if x.get(pool,'name') == GAME_ACTIVITY]
    filters = [x for x in game.elements(pool,'intent-filter') if is_launcher(x,pool)]
    assert len(filters) == 1, 'Expected one original launcher filter'
    launcher = filters[0]
    moved_filters = game.elements(pool,'intent-filter')
    original_filter_bytes = [f.encode() for f in moved_filters]
    untouched = [(x, x.encode() if isinstance(x,Node) else x) for x in app.children if x is not game]
    original_game_start, original_game_end = bytes(game.start), game.end
    original_exported = game.attributes(pool)[(ANDROID, 'exported')]
    assert original_exported['type'] == 0x12 and original_exported['value'] == 0xffffffff
    expected_game_start = bytearray(original_game_start)
    # Only the exported attribute changes. The launcher gate must not be
    # bypassed by an external explicit Intent during a cold-save operation.
    exported_offset = original_exported['offset']
    p32(expected_game_start, exported_offset+8, NO_INDEX)
    p32(expected_game_start, exported_offset+16, 0)
    original_game_children = [x for x in game.children if x not in moved_filters]
    for x in activities:
        assert x.get(pool,'name') not in (GATE,MANAGER)
    root.put(pool,'versionName','v075')
    root.put(pool,'versionCode',129005,0x10)
    # Keep original MultiDexApplication in classes.dex for Android 19/20.
    for f in moved_filters: game.children.remove(f)
    game.put(pool,'exported',0,0x12)
    gate = m.new_node('activity',[
        ('name',3,GATE),('exported',0x12,0xffffffff),
        ('theme',1,game.get(pool,'theme')),('launchMode',0x10,1),
        ('screenOrientation',0x10,game.get(pool,'screenOrientation')),
        ('configChanges',0x11,game.get(pool,'configChanges')),
    ])
    gate.children.extend(moved_filters)
    manager = m.new_node('activity',[
        ('name',3,MANAGER),('exported',0x12,0xffffffff),('permission',3,DUMP),
        ('theme',1,game.get(pool,'theme')),
        ('screenOrientation',0x10,game.get(pool,'screenOrientation')),
        ('configChanges',0x11,game.get(pool,'configChanges')),
    ])
    provider = m.new_node('provider',[
        ('name',3,PROVIDER),('exported',0x12,0xffffffff),('permission',3,DUMP),
        ('authorities',3,AUTHORITY),
    ])
    app.children.extend([gate,manager,provider])
    # Assertions here are preservation checks, not merely re-parsing output.
    assert pool.strings[:len(pool.original_strings)] == pool.original_strings
    assert app.get(pool,'label') == old_app_label and app.get(pool,'icon') == old_app_icon
    assert bytes(game.start) == bytes(expected_game_start) and game.end == original_game_end
    assert game.children == original_game_children
    assert [f.encode() for f in moved_filters] == original_filter_bytes
    for node, before in untouched: assert (node.encode() if isinstance(node,Node) else node) == before
    out = m.encode(); verify_manifest(out)
    report = {
        'version_name':'v075','version_code':129005,'package':PACKAGE,
        'game_activity':GAME_ACTIVITY,'application':APP,'launcher':GATE,
        'manager':MANAGER,'provider':PROVIDER,'provider_authority':AUTHORITY,
        'management_permission':DUMP,'application_label_resource':hex(old_app_label),
        'application_icon_resource':hex(old_app_icon),'original_strings_retained':len(pool.original_strings),
        'new_strings':pool.strings[len(pool.original_strings):],
        'original_game_activity_other_attributes_unchanged':True,
        'original_game_activity_exported_before':True,
        'original_game_activity_exported_after':False,
        'original_other_application_children_unchanged':True,
        'original_launcher_and_deeplink_filters_moved_byte_identically':True,
        'application_class_unchanged_for_legacy_multidex':True,
        'before_sha256':hashlib.sha256(raw).hexdigest(),'after_sha256':hashlib.sha256(out).hexdigest(),
    }
    return out, report

def verify_manifest(raw):
    m = Manifest(raw); p=m.pool; root=m.root
    assert root.get(p,'versionName') == 'v075' and root.get(p,'versionCode') == 129005
    assert root.get(p,'package',None) == PACKAGE
    app,=root.elements(p,'application'); assert app.get(p,'name')==APP
    activities = {x.get(p,'name'):x for x in app.elements(p,'activity')}
    launchers=[name for name,x in activities.items() if any(is_launcher(f,p) for f in x.elements(p,'intent-filter'))]
    assert launchers==[GATE]
    assert activities[GAME_ACTIVITY].get(p,'exported')==0
    assert activities[GAME_ACTIVITY].elements(p,'intent-filter')==[]
    assert activities[GATE].get(p,'exported')==0xffffffff
    assert activities[MANAGER].get(p,'permission')==DUMP and activities[MANAGER].get(p,'exported')==0xffffffff
    providers={x.get(p,'name'):x for x in app.elements(p,'provider')}
    assert providers[PROVIDER].get(p,'permission')==DUMP
    assert providers[PROVIDER].get(p,'exported')==0xffffffff
    assert providers[PROVIDER].get(p,'authorities')==AUTHORITY
    return m

def from_apk(path):
    path=Path(path)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==BASE_SHA256, 'Wrong APK baseline'
    with zipfile.ZipFile(path) as z:return patch_manifest(z.read('AndroidManifest.xml'))
