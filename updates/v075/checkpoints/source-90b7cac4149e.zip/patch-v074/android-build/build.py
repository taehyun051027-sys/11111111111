#!/usr/bin/env python3
"""Prepare/sign v075.apk as a narrow delta over the exact shipped APK.

This script never installs, starts, stops, backs up or otherwise contacts an
Android device. Signing is an explicit --sign operation. Key/password files
are passed directly to apksigner; they are not opened, copied or logged here.
"""
from pathlib import Path
import argparse, hashlib, json, os, re, shutil, struct, subprocess, sys, zipfile, zlib
from manifest_patch import BASE_SHA256, PACKAGE, GATE, GAME_ACTIVITY, from_apk, verify_manifest

HERE=Path(__file__).resolve().parent
PATCH=HERE.parent
PROJECT=PATCH.parent
TOOLS=PATCH/'tools/android-build-tools-35.0.0/android-15'
ANDROID_JAR=PATCH/'tools/android-platforms-android-34/android-34/android.jar'
DEFAULT_APK=PROJECT/'recovery/apk-inspection/yagu-v0.7.3-dev.apk'
DEFAULT_CERT=PROJECT/'recovery/source-v070/source/build-work/android/yagu-local-public-certificate.der'
ABIS=('arm64-v8a','armeabi-v7a')
LIB_NAMES=tuple(f'lib/{abi}/libgameDSO.so' for abi in ABIS)
PUBLIC_ASSET='assets/yagu-v075-public.der'
MANDATORY_CLASSES={f'Lcom/taehyun/yagu/patch/{name};' for name in
    ('GateActivity','PatchManagerActivity','PatchProvider','PatchRuntime','PatchBridge')}

def sha(data):return hashlib.sha256(data).hexdigest()
def sha_file(path):return sha(Path(path).read_bytes())
def run(args, log=None, sensitive=False):
    result=subprocess.run([str(x) for x in args],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    if log:Path(log).write_text(result.stdout)
    if result.returncode:
        # No command line or credentials are printed. apksigner receives file paths.
        if sensitive:raise RuntimeError(f'Signing failed ({result.returncode}); private signing diagnostics were not logged')
        raise RuntimeError(f'{Path(str(args[0])).name} failed ({result.returncode}):\n{result.stdout[-6000:]}')
    return result.stdout
def write_json(path,data):Path(path).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def clean_dir(path):
    path=Path(path).resolve()
    if not path.is_relative_to(HERE):raise ValueError('Build working directories must stay under android-build/')
    if path.exists():shutil.rmtree(path)
    path.mkdir(parents=True)

def dex_classes(data):
    assert data[:4]==b'dex\n' and data[7]==0 and len(data)>=112
    assert struct.unpack_from('<I',data,32)[0]==len(data)
    assert hashlib.sha1(data[32:]).digest()==data[12:32], 'DEX signature mismatch'
    assert zlib.adler32(data[12:])&0xffffffff==struct.unpack_from('<I',data,8)[0], 'DEX checksum mismatch'
    ns,strings=struct.unpack_from('<II',data,56)
    nt,types=struct.unpack_from('<II',data,64)
    nc,classes=struct.unpack_from('<II',data,96)
    def string(index):
        assert index<ns
        p=struct.unpack_from('<I',data,strings+index*4)[0]
        for _ in range(5):
            b=data[p];p+=1
            if not b&0x80:break
        else:raise ValueError('Malformed DEX string length')
        return data[p:data.index(0,p)].decode('utf-8','replace')
    result=[]
    for i in range(nc):
        type_index=struct.unpack_from('<I',data,classes+i*32)[0]
        assert type_index<nt
        result.append(string(struct.unpack_from('<I',data,types+type_index*4)[0]))
    assert len(result)==len(set(result)), 'Duplicate class definition in DEX'
    return set(result)

def compile_dex(source,work):
    source=Path(source).resolve()
    files=sorted(p for p in source.rglob('*.java') if p.name!='SafeApplication.java')
    if not files:raise ValueError('No Java sources found')
    stubs=work/'compile-only-stubs';classes=work/'classes';dex=work/'dex'
    for p in (stubs,classes,dex):clean_dir(p)
    java=stubs/'src/androidx/multidex/MultiDexApplication.java'
    java.parent.mkdir(parents=True)
    java.write_text('package androidx.multidex; public class MultiDexApplication extends android.app.Application {}\n')
    stubclasses=stubs/'classes';stubclasses.mkdir()
    compiler=['java','com.sun.tools.javac.Main','-source','8','-target','8','-encoding','UTF-8',
              '-bootclasspath',ANDROID_JAR]
    run([*compiler,'-d',stubclasses,java],work/'javac-stubs.log')
    stubjar=stubs/'compile-only.jar'
    with zipfile.ZipFile(stubjar,'w') as z:
        for p in sorted(stubclasses.rglob('*.class')):z.write(p,p.relative_to(stubclasses).as_posix())
    argsfile=work/'javac.args'
    # javac response files use their own quoting, not shell quoting.
    allargs=[*map(str,compiler[2:]),'-classpath',str(stubjar),'-d',str(classes),*map(str,files)]
    argsfile.write_text('\n'.join('"'+a.replace('\\','\\\\').replace('"','\\"')+'"' for a in allargs)+'\n')
    run(['java','com.sun.tools.javac.Main','@'+str(argsfile)],work/'javac.log')
    compiled=sorted(classes.rglob('*.class'))
    assert compiled and all(p.relative_to(classes).as_posix().startswith('com/taehyun/yagu/patch/') for p in compiled)
    assert all(p.read_bytes()[:4]==b'\xca\xfe\xba\xbe' and struct.unpack_from('>H',p.read_bytes(),6)[0]==52 for p in compiled)
    run(['java','-cp',TOOLS/'lib/d8.jar','com.android.tools.r8.D8','--release','--min-api','19',
         '--lib',ANDROID_JAR,'--classpath',stubjar,'--output',dex,*compiled],work/'d8.log')
    dexfiles=sorted(dex.glob('*.dex'))
    assert [p.name for p in dexfiles]==['classes.dex'], 'Expected exactly one additive DEX'
    payload=dexfiles[0].read_bytes();names=dex_classes(payload)
    assert MANDATORY_CLASSES<=names, 'Missing entry/bridge classes: '+str(MANDATORY_CLASSES-names)
    assert all(n.startswith('Lcom/taehyun/yagu/patch/') for n in names), 'Compile-only stub leaked into DEX'
    assert 'Lcom/taehyun/yagu/patch/SafeApplication;' not in names
    (work/'classes4.dex').write_bytes(payload)
    return payload,{'classes':sorted(names),'bytes':len(payload),'sha256':sha(payload),
                    'source_sha256':{str(p.relative_to(source)):sha_file(p) for p in files},
                    'min_api':19,'original_dex_files_recompiled':False,
                    'compile_only_stub_packaged':False}

def signature_entry(name):
    name=name.upper()
    return name=='META-INF/MANIFEST.MF' or (name.startswith('META-INF/') and name.endswith(('.SF','.RSA','.DSA','.EC')))

def cert_fingerprints(apk,log):
    out=run([TOOLS/'apksigner','verify','--min-sdk-version','19','--verbose','--print-certs',apk],log)
    fingerprints=re.findall(r'^Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F]+)$',out,re.M)
    if not fingerprints:raise ValueError('No signer certificate fingerprint found')
    return sorted(x.lower() for x in fingerprints)

def make_unsigned(base,manifest,dex,native_overlay,cert,work,test_fixture=False):
    replacements={'AndroidManifest.xml':manifest,'classes4.dex':dex,PUBLIC_ASSET:Path(cert).read_bytes()}
    if native_overlay is not None:
        for abi,name in zip(ABIS,LIB_NAMES):
            lib=Path(native_overlay)/'lib'/abi/'libgameDSO.so'
            if not lib.is_file():
                lib=Path(native_overlay)/abi/'libgameDSO.so'
            data=lib.read_bytes()
            assert data[:4]==b'\x7fELF'
            assert struct.unpack_from('<H',data,18)[0]==(183 if abi=='arm64-v8a' else 40)
            replacements[name]=data
    elif not test_fixture:
        raise ValueError('A final preparation requires both additive native libraries')
    output=work/'v075.unsigned.zip'
    with zipfile.ZipFile(base) as src,zipfile.ZipFile(output,'w',allowZip64=True) as dst:
        names=src.namelist();assert len(names)==len(set(names)), 'Duplicate source ZIP entries'
        assert 'classes4.dex' not in names and PUBLIC_ASSET not in names
        assert sorted(n for n in names if re.fullmatch(r'classes\d*\.dex',n))==['classes.dex','classes2.dex','classes3.dex']
        original_classes=set()
        assert 'Landroidx/multidex/MultiDexApplication;' in dex_classes(src.read('classes.dex'))
        for n in ('classes.dex','classes2.dex','classes3.dex'):original_classes.update(dex_classes(src.read(n)))
        assert not (original_classes & dex_classes(dex)), 'New DEX duplicates an existing class'
        assert 'Landroidx/multidex/MultiDexApplication;' in original_classes
        if not test_fixture:
            for n in LIB_NAMES:assert sha(src.read(n))!=sha(replacements[n]), 'Native overlay is unchanged baseline'
        for info in src.infolist():
            if signature_entry(info.filename):continue
            data=replacements.get(info.filename)
            if data is None:data=src.read(info.filename)
            # Original uncompressed entry bytes/metadata preserved where unchanged.
            dst.writestr(info,data)
        for name in ('classes4.dex',PUBLIC_ASSET):
            info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            dst.writestr(info,replacements[name])
    aligned=work/'v075.aligned.zip'
    run([TOOLS/'zipalign','-P','16','-f','4',output,aligned],work/'zipalign.log')
    run([TOOLS/'zipalign','-c','-P','16','4',aligned],work/'zipalign-check.log')
    verify=verify_package(base,aligned,replacements,work)
    return aligned,replacements,verify

def verify_package(base,result,replacements,work):
    preserved=0;old_dex={};modified={}
    with zipfile.ZipFile(base) as before,zipfile.ZipFile(result) as after:
        assert len(after.namelist())==len(set(after.namelist()))
        assert after.testzip() is None
        for name in before.namelist():
            if signature_entry(name):continue
            a=before.read(name);b=after.read(name)
            if name in replacements:
                assert b==replacements[name]
                modified[name]={'before':sha(a),'after':sha(b)}
            else:
                assert a==b,f'Unexpected modification: {name}'
                preserved+=1
            if re.fullmatch(r'classes\d*\.dex',name):old_dex[name]=sha(b)
        expected_added={'classes4.dex',PUBLIC_ASSET}
        actual_added={n for n in set(after.namelist())-set(before.namelist()) if not signature_entry(n)}
        assert actual_added==expected_added,(actual_added,expected_added)
        assert after.read('classes4.dex')==replacements['classes4.dex']
        assert after.read(PUBLIC_ASSET)==replacements[PUBLIC_ASSET]
        verify_manifest(after.read('AndroidManifest.xml'))
    tree=run([TOOLS/'aapt','dump','xmltree',result,'AndroidManifest.xml'],work/'manifest.aapt.txt')
    badging=run([TOOLS/'aapt','dump','badging',result],work/'badging.txt')
    assert f"package: name='{PACKAGE}' versionCode='129005' versionName='v075'" in badging
    assert "application-label:'야구'" in badging
    assert f"launchable-activity: name='{GATE}'" in badging
    return {'unchanged_entries':preserved,'modified_original_entries':modified,
            'original_dex_sha256':old_dex,'added_entries':sorted(expected_added),
            'resources_and_assets_other_than_new_public_certificate':'byte-identical',
            'aapt_manifest_parse':'pass','application_label':'야구','launcher':GATE,
            'device_contacted':False}

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--base',type=Path,default=DEFAULT_APK)
    p.add_argument('--java-src',type=Path,default=PATCH/'android/src')
    p.add_argument('--native-overlay',type=Path,default=PATCH/'build/overlay')
    p.add_argument('--public-cert',type=Path,default=DEFAULT_CERT)
    p.add_argument('--work',type=Path,default=HERE/'work')
    p.add_argument('--out',type=Path,default=PATCH/'build/v075.apk')
    p.add_argument('--sign',action='store_true',help='Create the final signed v075.apk; never install it')
    p.add_argument('--key',type=Path,help='Already extracted JKS keystore; never extracted by this script')
    p.add_argument('--password-file',type=Path,help='Keystore password file, passed directly to apksigner')
    p.add_argument('--key-password-file',type=Path,help='Optional distinct key password file')
    p.add_argument('--alias',help='Optional JKS key alias')
    p.add_argument('--test-fixture',action='store_true',help='Allow unsigned Java/manifest-only fixture; signing prohibited')
    args=p.parse_args()
    if args.out.name!='v075.apk':p.error('The final filename must be exactly v075.apk')
    if args.sign and args.test_fixture:p.error('Test fixtures cannot be signed')
    if args.java_src.resolve().is_relative_to(HERE/'test-fixture') and not args.test_fixture:
        p.error('The compile-only fixture requires --test-fixture and cannot be signed')
    if args.sign and (not args.key or not args.password_file):p.error('--sign requires --key and --password-file')
    if not args.work.resolve().is_relative_to(HERE):p.error('--work must stay under android-build/')
    args.work.mkdir(parents=True,exist_ok=True)
    assert sha_file(args.base)==BASE_SHA256, 'Wrong APK baseline; refusing downgrade/rebuild'
    assert args.public_cert.is_file(), 'Missing public signing certificate'
    baseline_certs=cert_fingerprints(args.base,args.work/'baseline-signature.txt')
    assert baseline_certs==[sha_file(args.public_cert)], 'Public certificate differs from installed baseline signer'
    manifest,mreport=from_apk(args.base)
    (args.work/'AndroidManifest.xml').write_bytes(manifest)
    write_json(args.work/'manifest-report.json',mreport)
    dex,dreport=compile_dex(args.java_src,args.work)
    write_json(args.work/'dex-report.json',dreport)
    overlay=None if args.test_fixture else args.native_overlay
    aligned,replacements,preport=make_unsigned(args.base,manifest,dex,overlay,args.public_cert,args.work,args.test_fixture)
    report={'version':'v075','version_code':129005,'input_sha256':BASE_SHA256,
            'signer_certificate_sha256':baseline_certs,'manifest':mreport,'dex':dreport,'preservation':preport,
            'test_fixture':args.test_fixture,'signed':False,'device_contacted':False}
    if args.sign:
        assert args.key.is_file() and args.password_file.is_file()
        args.out.parent.mkdir(parents=True,exist_ok=True)
        cmd=[TOOLS/'apksigner','sign','--ks',args.key,'--ks-pass','file:'+str(args.password_file),
             '--key-pass','file:'+str(args.key_password_file or args.password_file),
             '--min-sdk-version','19','--v1-signing-enabled','true','--v2-signing-enabled','true',
             '--v3-signing-enabled','true','--v4-signing-enabled','false','--out',args.out]
        if args.alias:cmd += ['--ks-key-alias',args.alias]
        # Do not persist signing command arguments or stdout to an artifact.
        run([*cmd,aligned],sensitive=True)
        final_certs=cert_fingerprints(args.out,args.work/'final-signature.txt')
        assert final_certs==baseline_certs, 'Final certificate does not match shipped app'
        final_verification=(args.work/'final-signature.txt').read_text()
        for scheme in ('v1','v2','v3'):
            assert re.search(r'^Verified using '+scheme+r' scheme .*: true$',final_verification,re.M), f'Missing {scheme} signature'
        run([TOOLS/'zipalign','-c','-P','16','4',args.out],args.work/'final-zipalign-check.txt')
        report['preservation']=verify_package(args.base,args.out,replacements,args.work)
        report.update(signed=True,output=str(args.out.resolve()),output_sha256=sha_file(args.out),
                      bytes=args.out.stat().st_size,signing_schemes=['v1','v2','v3'])
    else:
        report.update(prepared_archive=str(aligned.resolve()),prepared_sha256=sha_file(aligned))
    write_json(args.work/'build-report.json',report)
    print(json.dumps({'version':'v075','signed':report['signed'],'test_fixture':args.test_fixture,
                      'unchanged_entries':report['preservation']['unchanged_entries'],
                      'report':str(args.work/'build-report.json'),'device_contacted':False},ensure_ascii=False))

if __name__=='__main__':main()
