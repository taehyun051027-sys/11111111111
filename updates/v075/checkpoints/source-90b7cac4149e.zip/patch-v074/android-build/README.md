# v075 Android packaging

`build.py` prepares a narrowly modified APK from the exact shipped
`yagu-v0.7.3-dev.apk` (SHA-256
`fe77f183ae813348ca1cea57596c4528429f08aa5f41792df005f6c1c375ae1d`).
It does not contact an Android device or contain an install command.

The final filename is **v075.apk**, version name **v075**, version code
**129005**, package **com.taehyun.yagu**, application label **야구**.

## Exact manifest delta

The binary XML patch preserves all 158 original string indices and the
original Android attribute resource-ID map. It appends only new strings and
nodes; no resource-table rebuild occurs.

- Keep the original application class
  `androidx.multidex.MultiDexApplication` and its original label/icon/theme
  references. The primary `classes.dex` contains this bootstrap class.
- Change the manifest's version name/code to `v075` / `129005`.
- Move the original MAIN/LAUNCHER and VIEW/gamevil intent filters, with their
  original binary bytes, from
  `com.gamevil.bb2013.global.SkeletonLauncher` to
  `com.taehyun.yagu.patch.GateActivity`.
- Set the original game's Activity to `android:exported="false"`, preserving
  every other attribute byte-for-byte. This prevents an external explicit
  Intent from bypassing Gate while a cold-save operation is in progress.
  Internal same-UID launches still reach the original Activity. Gate copies
  its fullscreen theme, singleTop launch mode, sensorLandscape orientation
  and configuration-change flags. The original game's other components and
  metadata remain unchanged.
- Add `PatchManagerActivity`, exported and protected by
  `android.permission.DUMP`, with the original game's theme/orientation.
- Add `PatchProvider`, exported and protected by
  `android.permission.DUMP`, authority `com.taehyun.yagu.bridge`.

`PatchProvider.onCreate()` must initialize the patch runtime before the game
Activity starts. The original MultiDex application's `attachBaseContext()`
installs secondary DEX files before provider creation on Android 19/20.
A new Application subclass solely in `classes4.dex` would fail that legacy
bootstrap sequence, so `SafeApplication.java` is explicitly excluded.

Gate must forward the original launch intent to the original game Activity
after its save-protection check. This preserves the original deep-link
parameters while both normal and deep-link starts pass through Gate.

## Java, DEX and archive handling

The script uses the available JDK compiler module through
`java com.sun.tools.javac.Main`, targets Java 8, and compiles against the
Android 34 platform stubs. It verifies that each generated class has Java 8
bytecode. A compile-only MultiDexApplication stub is provided on the compiler
and D8 classpath and is never included in the APK.

D8 emits a single additive DEX with min API 19. It becomes **classes4.dex**.
Only classes under `com.taehyun.yagu.patch` may appear there. The builder
requires GateActivity, PatchManagerActivity, PatchProvider, PatchRuntime and
PatchBridge, validates the DEX checksum/signature, and rejects any collision
with a class already defined by the original three DEX files.

The native overlay replaces only the ARM64 and Thumb `libgameDSO.so` entries
that the root's additive native builder produced. All other original entry
contents—including the original three DEX files, resources.arsc, game data,
logos, audio, other native libraries and the existing icon—must compare
byte-for-byte equal with the shipped APK.

The public X.509 certificate is added as
`assets/yagu-v075-public.der`. Its SHA-256 must equal the shipped APK's signer
certificate fingerprint:

`8cd1b65f178f20e33891adc2702ca235b87866cc9235965fa9c8ec63e3d5473f`

Old ZIP signature entries are removed before repackaging. zipalign uses a
16 KB native-library page alignment and ordinary 4-byte entry alignment.
The script verifies the archive, parses its manifest through aapt, and checks
the resolved application label, version and launcher. No graphics or
resource identifiers are regenerated.

## Prepare first, sign only on the root's instruction

With the production Java sources and native overlay available:

```bash
python3 patch-v074/android-build/build.py
```

This writes an unsigned aligned preparation archive and a detailed report
inside `patch-v074/android-build/work/`. It does not produce a final signed
APK or install anything.

After the root authorizes final signing, it supplies an already extracted
JKS and password-file paths:

```bash
python3 patch-v074/android-build/build.py --sign \
  --key /path/to/extracted-signing.jks \
  --password-file /path/to/keystore-password.txt
```

`--alias` is supported if needed. If the private-key password differs from
the keystore password, use `--key-password-file`. The script does not extract
the private archive, read/copy key or password contents, log the signing
command, or retain signing diagnostics. Paths are passed directly to
apksigner's file-password mechanism.

The signed APK must verify with v1, v2 and v3 signatures, match the exact
original certificate, pass zipalign, and retain the full entry-preservation
checks. It is written to `patch-v074/build/v075.apk` by default. An alternative
`--out` path is allowed only if the filename remains exactly `v075.apk`.

## Verification completed so far

The unsigned packaging pipeline was exercised using explicit compile-only
fixtures:

```bash
python3 patch-v074/android-build/build.py --test-fixture \
  --java-src patch-v074/android-build/test-fixture \
  --work patch-v074/android-build/fixture-work
```

That run passed javac, D8, binary manifest parsing, aapt, zipalign, DEX
integrity/no-duplicate-class checks, signer/public-certificate matching and
byte preservation of **4,382 original ZIP entries**. The fixture changes no
native library and is never a deliverable. Signing a fixture is explicitly
rejected.

The report is `fixture-work/build-report.json`. This confirms the packaging
pipeline; it does not claim that the root's in-progress production Java has
passed runtime tests, that the final APK has already been signed, or that an
Android device or the user's three-game save has been modified.
