# 야구 v075 — Mac 연결 도구

Mac에 연결한 갤럭시탭에서 **야구 앱이 허용한 세이브 파일을 조회·백업하고,
변경 초안을 미리 본 뒤 적용하는 전용 도구**입니다. CLI와 stdio MCP 서버를
같이 제공합니다. 현재 진행 중인 선수를 우완으로 바꾸는 작업에는 세이브
바이너리를 직접 편집하는 대신 앱의 `set_hands` 설정을 사용합니다.

## 현재 지원 범위

- 앱 연결 프로토콜 1, 앱 이름/엔진 `v075`, versionCode `129005`를 지원합니다.
- 설치된 앱에 전용 연결 Provider가 없으면 `BRIDGE_UPDATE_REQUIRED`로
  종료합니다. 현재 설치본에 없는 연결 기능이나 신규 UI를 Mac 도구만으로
  추가할 수는 없습니다.
- 이 도구는 APK 설치·덮어설치·삭제, 앱 데이터 초기화, 게임 강제 종료,
  루팅, `run-as`, 임의 셸 명령을 실행하지 않습니다.
- 실제 기기 연결과 현재 3경기 세이브의 검증은 이 패키지 테스트에 포함되지
  않았습니다. 동봉 테스트는 가상 ADB/Provider를 사용하는 자동 테스트입니다.
- 기존 Mac 연결 도구가 `host_exec`를 제공하면 아래 CLI를 실행할 수 있습니다.
  MCP 설정 파일은 MCP 서버 등록을 지원하는 클라이언트에 별도로 등록합니다.
  패키지를 내려받는 것만으로 현재 대화에 새 도구가 자동 등록되지는 않습니다.

## 1. Mac에 설치

압축을 풀고 `Install.command`를 실행합니다. 설치 프로그램은 이 패키지의
파일 해시를 확인한 뒤 다음 전용 폴더에 도구만 복사합니다.

```text
~/Library/Application Support/YaguDeviceBridge/v075/
```

Python 3와 Android SDK Platform-Tools의 `adb`가 필요합니다. 이미 Android
Studio나 기존 Mac 연결 도구가 설치한 `adb`가 있다면 그 실행 파일을 사용할 수
있습니다. `adb` 경로를 자동으로 찾지 못하면 `--adb`로 지정합니다.

공식 안내: [Android Platform-Tools](https://developer.android.com/tools/releases/platform-tools),
[ADB의 USB 연결 절차](https://developer.android.com/tools/adb),
[Python for macOS](https://www.python.org/downloads/macos/).
설치 프로그램은 이 의존성을 자동 다운로드하거나 기존 도구 설정을 수정하지 않습니다.

## 2. 기기를 확인하고 앱에서 연결 승인

갤럭시탭의 USB 디버깅 연결은 기기 화면에서 직접 승인합니다. 다음 예시는
터미널에서 실행하거나 기존 Mac 연결 도구의 `host_exec`에 전달할 수 있습니다.

```sh
YAGU_BRIDGE="$HOME/Library/Application Support/YaguDeviceBridge/v075/yagu_bridge.py"
python3 "$YAGU_BRIDGE" devices
```

출력된 **대상 갤럭시탭의 serial**을 지정합니다. 아래 `TAB_SERIAL`을 실제 값으로
바꾸세요. 도구는 연결된 첫 번째 기기를 자동 선택하지 않습니다.

```sh
YAGU_SERIAL="TAB_SERIAL"
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" inspect
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" status
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" request-session --label "내 Mac 야구 도구" --scope read --scope write
```

마지막 명령은 **앱의 연결 승인 화면을 열기만** 합니다. 갤럭시탭에서 요청 범위를
확인하고 직접 승인하세요. 응답의 `request_id`로 승인 상태를 확인합니다.

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" session-status --request-id "출력된-UUID"
```

승인 토큰은 Mac의 전용 상태 폴더에 현재 사용자만 읽을 수 있는 권한(`0600`)으로
보관합니다. 명령 출력과 MCP 응답에는 토큰을 표시하지 않습니다. 승인 만료 전에는
다음 호출에서 재사용하며, 만료되면 앱에서 다시 승인해야 합니다.

## 3. 기존 선수의 투구 손만 우완으로 변경

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" call --json '{"action":"set_hands","bat":"preserve","pit":"right"}'
```

`bat: preserve`는 현재 타격 손을 유지합니다. `pit: right`는 투구 손을 우완으로
지정합니다. 양쪽을 독립적으로 `preserve`, `right`, `left` 중에서 선택합니다.
앱이 게임 중 변경을 대기시키는 경우 응답의 `queued` 상태를 확인하세요.
이 명령은 패치 설정을 변경하며 세이브 파일 전체를 새 파일로 교체하지 않습니다.

## 4. 저장 파일 조회와 백업

파일 작업에는 `status`의 `game_running: false`, `save_access: ready`가 필요합니다.
게임이 실행 중이면 게임에서 먼저 저장하고 앱의 패치 관리 화면으로 다시 시작하세요.
도구가 게임을 자동으로 강제 종료하지는 않습니다.

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" call --json '{"action":"list_files"}'
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" call --json '{"action":"backup","label":"3경기 진행 보관"}'
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" call --json '{"action":"list_backups"}'
```

허용 파일은 앱의 게임 저장 파일 `bb2013*.sav`와 기존 수상 기록 저널
`yagu_awards_v1_a.sav`, `yagu_awards_v1_b.sav`입니다. 파일명에 경로나 셸 명령을
넣을 수 없습니다. 목록에 나온 정확한 이름을 사용합니다.

Mac으로 사본을 받을 때는 기존 파일과 겹치지 않는 새 경로를 지정합니다.
다운로드 후 전체 SHA-256을 목록의 해시와 비교합니다.

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" download --name "bb2013_실제파일명.sav" --output "$HOME/Desktop/야구-3경기-보관.sav"
```

## 5. 파일 변경은 초안 → 미리보기 → 적용

이 기능은 저장 형식을 이해한 수정 파일이 준비되었을 때 사용합니다. 도구가
세이브의 임의 숫자를 자동으로 바꾸지는 않습니다. 현재 파일의 해시는
`list_files`에서 확인합니다.

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" upload --name "bb2013_실제파일명.sav" --input "$HOME/Desktop/검토한-수정본.sav" --expected-sha256 "현재_원본의_64자리_SHA256"
```

`upload`는 초안에만 전송하고 `committed: false`를 반환합니다. 응답의
`before_sha256`, `after_sha256`, 파일 크기와 변경 요약을 검토한 뒤 적용합니다.

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" call --json '{"action":"write_commit","draft_id":"출력된-초안-ID","expected_sha256":"검토한_after_sha256"}'
```

앱은 적용 직전에 **시작 시점의 원본 해시와 검토한 수정본 해시를 모두 다시
확인하고, 원본을 백업한 후에 교체**해야 합니다. 도구도 해당 초안의 미리보기
해시와 적용 요청이 일치하는지 검사합니다. 초안 파일은 offset 0부터 순서대로
전체를 전송합니다. 완성한 초안을 바꾸려면 기존 초안을 버리고 새 초안을 작성합니다.
중단하거나 초안을 버리려면 다음을 실행합니다.

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" call --json '{"action":"write_abort","draft_id":"초안-ID"}'
```

복원은 앱의 `list_backups`에 실제로 존재하는 백업 ID로만 가능합니다. `status`가
제공한 현재 전체 저장 상태의 해시를 같이 지정합니다. 앱은 복원 전 현재 상태도
별도 백업해야 합니다.

```sh
python3 "$YAGU_BRIDGE" --serial "$YAGU_SERIAL" call --json '{"action":"restore","backup_id":"기존-백업-ID","expected_state_sha256":"현재_전체_상태의_64자리_SHA256"}'
```

## MCP 서버 연결

설치 폴더의 `mcp-server.json`은 설치된 Python과 스크립트의 절대 경로가 들어 있는
설정입니다. 사용하는 MCP 클라이언트의 로컬 stdio 서버 등록 기능에 적용하세요.
기존 WebPro6나 다른 저장소의 설정 파일은 설치 프로그램이 수정하지 않습니다.

서버 실행 형식:

```sh
python3 "$YAGU_BRIDGE" mcp
```

`yagu_devices`, `yagu_inspect`, `yagu_status`, 연결 승인 도구와 각 파일/패치 작업이
별개의 도구로 노출됩니다. 모든 기기 대상 호출에는 `serial`이 필수입니다.
JSON-RPC 메시지만 표준 출력으로 보내며 세션 토큰을 도구 결과로 노출하지 않습니다.
지원하는 MCP 연결 방식은 stdio와 초기화 핸드셰이크를 사용하는
`2024-11-05`, `2025-03-26`, `2025-06-18`, `2025-11-25` 프로토콜입니다.
설계 기준: [MCP stdio 전송](https://modelcontextprotocol.io/specification/2025-11-25/basic/transports),
[초기화와 버전 협상](https://modelcontextprotocol.io/specification/2025-11-25/basic/lifecycle).

## 오류를 읽는 방법

| 코드 | 의미와 다음 단계 |
|---|---|
| `BRIDGE_UPDATE_REQUIRED` | 설치 앱에 필요한 v075 Provider가 없거나 버전이 다릅니다. 자동 설치나 우회는 수행하지 않습니다. |
| `DEVICE_UNAUTHORIZED` | 갤럭시탭에서 이 Mac의 USB 디버깅 연결을 승인해야 합니다. |
| `SESSION_REQUIRED` / `SESSION_EXPIRED` | 앱 내 연결 승인이 필요하거나 만료되었습니다. 새 요청 후 앱에서 승인하세요. |
| `NEEDS_SAVE_AND_RESTART` | 게임이 실행 중입니다. 게임에서 저장하고 패치 관리 화면으로 다시 시작하세요. |
| `SAVE_ACCESS_BLOCKED` | 앱의 백업/접근 준비가 완료되지 않았습니다. 앱 화면에서 원인을 확인하세요. |
| `HASH_MISMATCH` | 파일이나 상태가 확인한 이후 바뀌었습니다. 다시 읽고 검토하세요. |
| `PREVIEW_REQUIRED` | 현재 초안의 미리보기 해시가 필요합니다. `write_preview`를 다시 실행하세요. |
| `COMMIT_VERIFICATION_REQUIRED` | 적용 결과 확인이 불완전합니다. 같은 변경을 재전송하기 전에 앱 상태와 백업을 확인하세요. |

## 자동 테스트

압축을 푼 패키지 폴더에서 실행합니다. 테스트용 가상 ADB만 사용합니다.

```sh
python3 -m unittest discover -s tests -p 'test_*.py' -v
```

검증 범위는 명시적 기기 선택, 앱 내 승인 대기, 토큰 파일 권한과 출력 비노출,
기능 미지원 시 우회 차단, 파일/크기/해시 검증, 게임 실행 중 접근 제한,
초안 미리보기와 적용, 적용 전 백업 및 복원, MCP JSON-RPC 입출력입니다.
물리적 갤럭시탭, Mac의 실제 ADB 연결, 앱 Provider 구현과의 최종 상호운용은
별도로 확인해야 합니다.
