#!/usr/bin/env python3
"""Install only this bridge's own files. No network, ADB, app, or host edits."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile

VERSION = 'v075'
FILES = ('yagu_bridge.py', 'README_ko.md', 'protocol.json')


def install(source, destination):
    source, destination = Path(source), Path(destination)
    manifest = json.loads((source / 'checksums.json').read_text())
    for name in FILES:
        path = source / name
        if not path.is_file() or path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest() != manifest.get(name):
            raise ValueError('패키지 파일 검증 실패: ' + name)
    if destination.exists() and (destination.is_symlink() or not destination.is_dir()):
        raise ValueError('설치 경로는 일반 폴더여야 합니다.')
    marker = destination / 'install-marker.json'
    if destination.exists() and any(destination.iterdir()):
        if marker.is_symlink() or not marker.is_file() or json.loads(marker.read_text()).get('tool') != 'yagu-device-bridge':
            raise ValueError('다른 파일이 있는 폴더에는 설치하지 않습니다.')
    destination.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(destination, 0o700)
    if not marker.exists():
        marker.write_text(json.dumps({'tool': 'yagu-device-bridge', 'version': VERSION}))
    for name in FILES:
        target = destination / name
        if target.is_symlink(): raise ValueError('설치 대상에 심볼릭 링크가 있습니다: ' + name)
        fd, temporary = tempfile.mkstemp(prefix='.install-', dir=destination)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write((source / name).read_bytes())
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, target)
        finally:
            if os.path.exists(temporary): os.unlink(temporary)
    # A concrete standalone config for the user/client to import. No existing
    # WebPro6, MCP client, repository, shell profile, or device is modified.
    config = {'mcpServers': {'yagu-device-bridge': {'command': sys.executable,
              'args': [str(destination / 'yagu_bridge.py'), 'mcp']}}}
    config_path = destination / 'mcp-server.json'
    if config_path.is_symlink(): raise ValueError('MCP 설정 경로가 올바르지 않습니다.')
    fd = os.open(config_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, 'O_NOFOLLOW', 0), 0o600)
    os.fchmod(fd, 0o600)
    with os.fdopen(fd, 'w') as stream:
        json.dump(config, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return {'version': VERSION, 'installed_to': str(destination), 'mcp_config': str(config_path),
            'adb_found_on_path': bool(shutil.which('adb')), 'device_modified': False, 'host_configs_modified': False}


def main():
    parser = argparse.ArgumentParser(description='야구 v075 Mac 도구 설치')
    parser.add_argument('--destination', type=Path)
    args = parser.parse_args()
    source = Path(__file__).resolve().parent
    destination = args.destination or Path.home() / 'Library/Application Support/YaguDeviceBridge' / VERSION
    try:
        result = install(source, destination)
        print('야구 v075 연결 도구를 설치했습니다.')
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print('다음: README_ko.md의 기기 연결·앱 내 승인 절차를 진행하세요.')
        print('앱 설치, 게임 강제 종료, 기존 Mac 연결 도구 설정 변경은 실행하지 않았습니다.')
        if not result['adb_found_on_path']:
            print('adb가 PATH에 없으면 기존 Android SDK의 adb 경로를 --adb로 지정하세요.')
            print('공식 Platform-Tools: https://developer.android.com/tools/releases/platform-tools')
        return 0
    except (OSError, ValueError, KeyError):
        print('설치 파일 또는 설치 경로를 검증하지 못했습니다. 패키지를 다시 확인하세요.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
