#!/usr/bin/env python3
"""Mac CLI / stdio MCP for the explicitly consented 야구 v075 app bridge.

Only fixed ADB commands are exposed. App-private data is accessed exclusively
through the app's permission-checked provider; there is no root/run-as fallback.
Python standard library only. No real device is accessed during the unit tests.
"""
import argparse
import base64
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import time
import uuid

VERSION = 'v075'
VERSION_CODE = 129005
PACKAGE = 'com.taehyun.yagu'
AUTHORITY = 'com.taehyun.yagu.bridge'
ACTIVITY = PACKAGE + '/com.taehyun.yagu.patch.PatchManagerActivity'
MAX_FILE = 16 * 1024 * 1024
CHUNK = 4096
MAX_MESSAGE = 1024 * 1024
SCOPES = ('read', 'write')
PUBLIC = {'status', 'request_session', 'session_status'}
READ = {'list_files', 'read_file', 'backup', 'list_backups', 'patch_info', 'check'}
WRITE = {'write_begin', 'write_chunk', 'write_preview', 'write_commit', 'write_abort', 'restore', 'set_hands'}
COLD = (READ | WRITE) - {'patch_info', 'check', 'set_hands'}
SPECS = {
    'status': ({}, ()),
    'request_session': ({'request_id': 'uuid', 'client_label': 'label', 'scopes': 'scopes'}, ('request_id', 'client_label', 'scopes')),
    'session_status': ({'request_id': 'uuid'}, ('request_id',)),
    'list_files': ({}, ()),
    'read_file': ({'name': 'filename', 'offset': 'offset', 'count': 'count'}, ('name', 'offset', 'count')),
    'backup': ({'label': 'label'}, ('label',)),
    'list_backups': ({}, ()),
    'write_begin': ({'name': 'filename', 'size': 'size', 'expected_sha256': 'sha256'}, ('name', 'size', 'expected_sha256')),
    'write_chunk': ({'draft_id': 'id', 'offset': 'offset', 'data_b64': 'chunk'}, ('draft_id', 'offset', 'data_b64')),
    'write_preview': ({'draft_id': 'id'}, ('draft_id',)),
    'write_commit': ({'draft_id': 'id', 'expected_sha256': 'sha256'}, ('draft_id', 'expected_sha256')),
    'write_abort': ({'draft_id': 'id'}, ('draft_id',)),
    'restore': ({'backup_id': 'id', 'expected_state_sha256': 'sha256'}, ('backup_id', 'expected_state_sha256')),
    'set_hands': ({'bat': 'hand', 'pit': 'hand'}, ('bat', 'pit')),
    'patch_info': ({}, ()),
    'check': ({}, ()),
}


class BridgeError(Exception):
    def __init__(self, code, message):
        self.code, self.message = code, message
        super().__init__(message)

    def as_json(self):
        return {'ok': False, 'error': {'code': self.code, 'message': self.message}}


def require(condition, code, message):
    if not condition:
        raise BridgeError(code, message)


def serial_value(value):
    require(isinstance(value, str) and bool(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,255}', value)),
            'SERIAL_REQUIRED', '대상 기기의 adb serial을 명시해야 합니다. devices 결과에서 선택하세요.')
    return value


def filename(value):
    return isinstance(value, str) and len(value) <= 96 and bool(re.fullmatch(
        r'(?:bb2013[A-Za-z0-9_.-]*|yagu_awards_v1_[ab])\.sav', value))


def valid_hash(value):
    return isinstance(value, str) and bool(re.fullmatch(r'[a-fA-F0-9]{64}', value))


def validate(request):
    require(isinstance(request, dict), 'INVALID_ARGUMENT', '요청은 JSON object여야 합니다.')
    action = request.get('action')
    require(isinstance(action, str) and action in SPECS, 'UNSUPPORTED_ACTION', '허용되지 않은 작업입니다.')
    fields, required = SPECS[action]
    require(set(request) <= set(fields) | {'action', 'protocol'}, 'INVALID_ARGUMENT', '허용되지 않은 요청 필드입니다.')
    require(type(request.get('protocol', 1)) is int and request.get('protocol', 1) == 1, 'PROTOCOL_MISMATCH', '앱 연결 프로토콜은 1이어야 합니다.')
    require(all(k in request for k in required), 'INVALID_ARGUMENT', '필수 요청 필드가 없습니다.')
    result = dict(request, protocol=1)
    for key, kind in fields.items():
        if key not in request: continue
        value = request[key]
        ok = False
        if kind == 'filename': ok = filename(value)
        elif kind == 'sha256':
            ok = valid_hash(value)
            if ok: result[key] = value.lower()
        elif kind == 'uuid':
            try: ok = isinstance(value, str) and str(uuid.UUID(value)) == value.lower()
            except (ValueError, AttributeError): pass
        elif kind == 'id': ok = isinstance(value, str) and bool(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,127}', value)) and '..' not in value
        elif kind == 'label': ok = isinstance(value, str) and 1 <= len(value) <= 80 and not any(ord(c) < 32 for c in value)
        elif kind == 'scopes': ok = isinstance(value, list) and bool(value) and all(x in SCOPES for x in value) and len(set(value)) == len(value)
        elif kind == 'hand': ok = value in ('preserve', 'right', 'left')
        elif kind in ('offset', 'size', 'count'):
            ok = isinstance(value, int) and not isinstance(value, bool) and 0 <= value <= (CHUNK if kind == 'count' else MAX_FILE)
            if kind == 'count': ok = ok and value > 0
        elif kind == 'chunk':
            try: ok = isinstance(value, str) and len(value) <= 5464 and 0 < len(base64.b64decode(value, validate=True)) <= CHUNK
            except (ValueError, TypeError): pass
        require(ok, 'INVALID_ARGUMENT', '요청 필드 형식이 잘못되었습니다: ' + key)
    return result


def redact(value, secrets=()):
    """No session token or encoded request is returned to chat/stdout/logs."""
    if isinstance(value, dict):
        return {key: ('[REDACTED]' if any(x in key.lower() for x in ('token', 'secret', 'credential')) else redact(item, secrets))
                for key, item in value.items()}
    if isinstance(value, list): return [redact(x, secrets) for x in value]
    if isinstance(value, str):
        for secret in secrets:
            if secret: value = value.replace(secret, '[REDACTED]')
    return value


def expiry_seconds(value):
    try:
        if isinstance(value, (int, float)):
            result = float(value)
            if result > 10**12: result /= 1000
        else:
            result = datetime.datetime.fromisoformat(str(value).replace('Z', '+00:00')).timestamp()
        require(time.time() < result < time.time() + 86400, 'SESSION_INVALID', '연결 승인 만료 시간이 올바르지 않습니다.')
        return result
    except (ValueError, TypeError, OverflowError):
        raise BridgeError('SESSION_INVALID', '연결 승인 만료 시간이 올바르지 않습니다.') from None


class StateStore:
    """Private local session/draft receipts, atomically written with mode 0600."""
    def __init__(self, root=None):
        self.root = Path(root) if root else Path.home() / 'Library/Application Support/YaguDeviceBridge/state'
        if self.root.exists():
            require(not self.root.is_symlink() and self.root.is_dir(), 'LOCAL_STATE_UNSAFE', '연결 상태 폴더를 사용할 수 없습니다.')
        else: self.root.mkdir(mode=0o700, parents=True)
        os.chmod(self.root, 0o700)

    def path(self, serial):
        return self.root / (hashlib.sha256(serial_value(serial).encode()).hexdigest() + '.json')

    def load(self, serial):
        path = self.path(serial)
        try:
            fd = os.open(path, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
        except FileNotFoundError: return {'serial': serial, 'drafts': {}, 'pending': {}}
        except OSError: raise BridgeError('LOCAL_STATE_UNSAFE', '연결 상태 파일을 안전하게 열 수 없습니다.') from None
        try:
            info = os.fstat(fd)
            require(stat.S_ISREG(info.st_mode) and info.st_uid == os.getuid() and info.st_mode & 0o077 == 0,
                    'LOCAL_STATE_UNSAFE', '연결 상태 파일은 현재 사용자만 접근할 수 있어야 합니다.')
            require(info.st_size < MAX_MESSAGE, 'LOCAL_STATE_UNSAFE', '연결 상태 파일이 너무 큽니다.')
            with os.fdopen(fd, 'r', encoding='utf-8') as stream:
                fd = None
                data = json.load(stream)
            require(isinstance(data, dict) and data.get('serial') == serial, 'LOCAL_STATE_UNSAFE', '기기별 연결 정보가 일치하지 않습니다.')
            return data
        except (ValueError, TypeError):
            raise BridgeError('LOCAL_STATE_UNSAFE', '연결 상태 파일 형식이 올바르지 않습니다.') from None
        finally:
            if fd is not None: os.close(fd)

    def save(self, serial, data):
        path = self.path(serial)
        require(not path.is_symlink(), 'LOCAL_STATE_UNSAFE', '연결 상태 파일 경로가 올바르지 않습니다.')
        fd, temporary = tempfile.mkstemp(prefix='.session-', dir=self.root)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as stream:
                json.dump(data, stream, ensure_ascii=False, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary): os.unlink(temporary)


def find_adb(explicit=None):
    candidates = [explicit] if explicit else [shutil.which('adb'),
        str(Path.home() / 'Library/Android/sdk/platform-tools/adb'),
        str(Path.home() / 'platform-tools/adb'), '/opt/homebrew/bin/adb', '/usr/local/bin/adb']
    for candidate in candidates:
        if candidate and Path(candidate).is_file() and os.access(candidate, os.X_OK):
            return str(Path(candidate).resolve())
    raise BridgeError('ADB_NOT_FOUND', 'Android SDK Platform-Tools의 adb가 필요합니다. 공식 설치 안내를 확인하세요.')


class Bridge:
    def __init__(self, adb=None, state_dir=None, timeout=20):
        self.adb = find_adb(adb)
        self.store = StateStore(state_dir)
        self.timeout = timeout

    def _run(self, args):
        try:
            completed = subprocess.run([self.adb, *args], stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, encoding='utf-8', errors='replace',
                timeout=self.timeout, check=False)
        except subprocess.TimeoutExpired:
            raise BridgeError('ADB_TIMEOUT', '기기 응답 시간이 초과되었습니다. 연결 상태를 확인하세요.') from None
        except OSError:
            raise BridgeError('ADB_UNAVAILABLE', 'adb를 실행하지 못했습니다.') from None
        # Do not surface raw subprocess stderr: ADB may echo the token-bearing
        # command line. Return only classified, fixed error messages.
        if completed.returncode:
            text = (completed.stdout + completed.stderr).lower()
            if 'unauthorized' in text:
                raise BridgeError('DEVICE_UNAUTHORIZED', '갤럭시탭에서 이 Mac의 USB 디버깅 연결을 승인하세요.')
            if 'offline' in text or 'device not found' in text or 'no devices' in text:
                raise BridgeError('DEVICE_UNAVAILABLE', '선택한 기기가 연결되어 있지 않거나 응답하지 않습니다.')
            if 'permission denial' in text or 'permission denied' in text:
                raise BridgeError('PROVIDER_PERMISSION_DENIED', '앱의 연결 권한이 허용되지 않았습니다.')
            if 'find provider' in text or 'unknown uri' in text or 'not found' in text:
                raise BridgeError('BRIDGE_UPDATE_REQUIRED', '설치된 앱에 v075 연결 기능이 없습니다. 기존 데이터를 보존하는 지원 버전이 필요합니다.')
            raise BridgeError('ADB_COMMAND_FAILED', '허용된 기기 작업을 실행하지 못했습니다. 기기와 앱 상태를 확인하세요.')
        require(len(completed.stdout) <= 2 * MAX_MESSAGE, 'PROVIDER_RESPONSE_INVALID', '기기 응답이 허용 크기를 초과했습니다.')
        return completed.stdout

    def devices(self):
        # Device enumeration is the only ADB command without -s; it never acts
        # on a selected device. Every targeted command below requires serial.
        text = self._run(['devices', '-l'])
        devices = []
        for line in text.splitlines():
            fields = line.strip().split()
            if len(fields) < 2 or fields[0] in ('List', '*'): continue
            if fields[1] not in ('device', 'offline', 'unauthorized', 'recovery', 'sideload', 'bootloader'): continue
            serial_value(fields[0])
            details = dict(x.split(':', 1) for x in fields[2:] if ':' in x)
            devices.append({'serial': fields[0], 'state': fields[1], 'model': details.get('model', '')})
        return {'ok': True, 'devices': devices}

    def inspect(self, serial):
        serial_value(serial)
        package_dump = self._run(['-s', serial, 'shell', 'dumpsys', 'package', PACKAGE])
        names = re.findall(r'\bversionName=([^\s]+)', package_dump)
        codes = re.findall(r'\bversionCode=(\d+)', package_dump)
        model = self._run(['-s', serial, 'shell', 'getprop', 'ro.product.model']).strip()
        sdk = self._run(['-s', serial, 'shell', 'getprop', 'ro.build.version.sdk']).strip()
        return {'ok': True, 'serial': serial, 'package': PACKAGE, 'installed': bool(names or codes),
                'versionName': names[0] if names else None, 'versionCode': int(codes[0]) if codes else None,
                'model': model[:160], 'android_sdk': sdk[:8]}

    def _provider(self, serial, request):
        serial_value(serial)
        raw = json.dumps(request, ensure_ascii=False, separators=(',', ':')).encode()
        require(len(raw) <= 16000, 'INVALID_ARGUMENT', '앱 요청이 너무 큽니다.')
        encoded = base64.b64encode(raw).decode()
        output = self._run(['-s', serial, 'shell', 'content', 'call', '--uri', 'content://' + AUTHORITY,
            '--method', 'request', '--extra', 'payload:s:' + encoded])
        matches = re.findall(r'\bresult_b64=([A-Za-z0-9+/=]+)', output)
        if not matches:
            lower = output.lower()
            if any(x in lower for x in ('find provider', 'no result', 'unknown uri', 'not found')):
                raise BridgeError('BRIDGE_UPDATE_REQUIRED', '설치된 앱에서 v075 연결 기능을 찾지 못했습니다.')
            if 'permission' in lower:
                raise BridgeError('PROVIDER_PERMISSION_DENIED', '앱의 연결 권한이 허용되지 않았습니다.')
            raise BridgeError('PROVIDER_RESPONSE_INVALID', '앱 연결 응답 형식이 올바르지 않습니다.')
        require(len(matches) == 1, 'PROVIDER_RESPONSE_INVALID', '앱 연결 응답이 중복되었습니다.')
        try:
            response = json.loads(base64.b64decode(matches[0], validate=True).decode())
        except (ValueError, UnicodeDecodeError):
            raise BridgeError('PROVIDER_RESPONSE_INVALID', '앱 연결 응답을 읽지 못했습니다.') from None
        require(isinstance(response, dict), 'PROVIDER_RESPONSE_INVALID', '앱 연결 응답 형식이 올바르지 않습니다.')
        if response.get('ok') is False or response.get('error'):
            error = response.get('error', {})
            code = error.get('code', 'APP_ERROR') if isinstance(error, dict) else str(error)
            require(bool(re.fullmatch(r'[A-Z0-9_]{1,80}', code)), 'PROVIDER_RESPONSE_INVALID', '앱 오류 코드가 올바르지 않습니다.')
            safe_messages = {
                'NEEDS_SAVE_AND_RESTART': '게임에서 저장한 뒤 패치 관리 화면으로 다시 시작해야 파일에 접근할 수 있습니다.',
                'HASH_MISMATCH': '파일이 미리보기 이후 변경되었습니다. 다시 읽고 검토하세요.',
                'SESSION_EXPIRED': '연결 승인이 만료되었습니다. 앱에서 다시 승인하세요.',
                'SESSION_REQUIRED': '앱에서 이 Mac의 연결을 승인해야 합니다.',
                'SAVE_ACCESS_BLOCKED': '현재 앱 상태에서는 저장 파일에 접근할 수 없습니다.',
            }
            raise BridgeError(code, safe_messages.get(code, '앱이 작업을 거절했습니다. 앱의 패치 관리 화면을 확인하세요.'))
        return response

    def status(self, serial):
        response = self._provider(serial, {'protocol': 1, 'action': 'status'})
        name = response.get('versionName', response.get('version_name', response.get('engine')))
        code = response.get('versionCode', response.get('version_code'))
        compatible = name == VERSION and code == VERSION_CODE
        response['compatibility'] = {'accept_engine': VERSION, 'version_code': VERSION_CODE, 'compatible': compatible}
        return redact(response)

    def _preflight(self, serial, action):
        response = self.status(serial)
        require(response['compatibility']['compatible'], 'BRIDGE_UPDATE_REQUIRED', '이 도구는 야구 v075(versionCode 129005)의 연결 기능이 필요합니다.')
        access = response.get('save_access')
        if action in COLD:
            require(response.get('game_running') is False, 'NEEDS_SAVE_AND_RESTART', '게임에서 저장한 뒤 패치 관리 화면으로 다시 시작하세요. 게임을 강제 종료하지 않습니다.')
            require(access == 'ready', 'SAVE_ACCESS_BLOCKED', '저장 파일 백업 또는 접근 준비가 완료되지 않았습니다. 앱의 패치 관리 화면을 확인하세요.')
        elif action == 'set_hands':
            require(access in ('ready', 'running'), 'SAVE_ACCESS_BLOCKED', '앱이 변경을 받을 준비가 되지 않았습니다.')
        return response

    def _session(self, serial, scope):
        data = self.store.load(serial)
        session = data.get('session', {})
        require(isinstance(session.get('token'), str) and session.get('expires_at', 0) > time.time(),
                'SESSION_REQUIRED', 'request-session을 실행하고 앱에서 연결을 승인한 뒤 session-status를 확인하세요.')
        require(scope in session.get('scopes', []), 'SCOPE_REQUIRED', '이 작업에 필요한 앱 연결 범위가 승인되지 않았습니다: ' + scope)
        return data, session['token']

    def execute(self, serial, request, open_consent=False):
        serial_value(serial)
        request = validate(request)
        action = request['action']
        if action == 'status': return self.status(serial)
        status = self._preflight(serial, action)
        if action in PUBLIC:
            response = self._provider(serial, request)
            data = self.store.load(serial)
            if action == 'request_session':
                data.setdefault('pending', {})[request['request_id']] = {'scopes': request['scopes'], 'created_at': time.time()}
                self.store.save(serial, data)
                response['request_id'] = request['request_id']
                if open_consent:
                    self._run(['-s', serial, 'shell', 'am', 'start', '-n', ACTIVITY, '--es', 'request_id', request['request_id']])
                    response['consent_screen_opened'] = True
                response['next_step'] = '갤럭시탭 앱 화면에서 직접 연결을 승인한 뒤 session_status를 확인하세요.'
            elif action == 'session_status' and response.get('token'):
                token = response['token']
                require(isinstance(token, str) and 1 <= len(token) <= 4096, 'SESSION_INVALID', '연결 승인 응답이 올바르지 않습니다.')
                pending = data.get('pending', {}).get(request['request_id'])
                require(pending is not None, 'SESSION_INVALID', '이 Mac에서 요청한 연결 승인이 아닙니다.')
                scopes = response.get('scopes', pending['scopes'])
                require(isinstance(scopes, list) and all(x in pending['scopes'] for x in scopes), 'SESSION_INVALID', '연결 승인 범위가 요청과 다릅니다.')
                data['session'] = {'token': token, 'expires_at': expiry_seconds(response.get('expiry', response.get('expires_at'))),
                                   'scopes': scopes, 'request_id': request['request_id']}
                self.store.save(serial, data)
                response['session_saved_locally'] = True
            return redact(response, [response.get('token', '')])
        data, token = self._session(serial, 'write' if action in WRITE else 'read')
        drafts = data.setdefault('drafts', {})
        if action in {'write_chunk', 'write_preview', 'write_commit', 'write_abort'}:
            require(request['draft_id'] in drafts, 'DRAFT_UNKNOWN', '이 Mac에서 시작한 파일 변경 초안이 아닙니다.')
        if action == 'write_commit':
            require(drafts[request['draft_id']].get('preview_sha256') == request['expected_sha256'],
                    'PREVIEW_REQUIRED', '먼저 write_preview로 변경 내용을 확인하고 그 after_sha256으로 적용하세요.')
        if action == 'write_chunk':
            draft = drafts[request['draft_id']]
            length = len(base64.b64decode(request['data_b64']))
            expected_offset = draft.get('received', [[0, 0]])[-1][1] if draft.get('received') else 0
            require(request['offset'] == expected_offset, 'DRAFT_OFFSET_MISMATCH',
                    '초안은 offset 0부터 순서대로 전송해야 합니다. 완성된 초안을 수정하려면 새 초안을 시작하세요.')
            require(request['offset'] + length <= draft['size'], 'INVALID_ARGUMENT', '변경 데이터가 초안 크기를 초과합니다.')
            # Invalidate a prior preview before transport: an interrupted call
            # may have reached the device even when its reply was lost.
            draft.pop('preview_sha256', None)
            self.store.save(serial, data)
        if action == 'write_preview':
            draft = drafts[request['draft_id']]
            require(draft['size'] == 0 or draft.get('received') == [[0, draft['size']]],
                    'DRAFT_INCOMPLETE', '파일 전체를 초안에 전송한 뒤 미리보기를 요청하세요.')
        if action == 'restore':
            require(status.get('current_state_sha256') == request['expected_state_sha256'],
                    'HASH_MISMATCH', '현재 전체 저장 상태 해시와 복원 요청이 일치하지 않습니다.')
            backups = self._provider(serial, {'protocol': 1, 'action': 'list_backups', 'token': token})
            known = [item.get('backup_id', item.get('id')) for item in backups.get('backups', []) if isinstance(item, dict)]
            require(request['backup_id'] in known, 'BACKUP_UNKNOWN', '앱에 존재하는 백업 ID만 복원할 수 있습니다.')
        response = self._provider(serial, dict(request, token=token))
        if action == 'write_begin':
            draft_id = response.get('draft_id')
            validate({'action': 'write_preview', 'draft_id': draft_id})
            drafts[draft_id] = {'name': request['name'], 'size': request['size'], 'before_sha256': request['expected_sha256'], 'received': []}
            self.store.save(serial, data)
        elif action == 'write_chunk':
            draft = drafts[request['draft_id']]
            intervals = sorted(draft.get('received', []) + [[request['offset'], request['offset'] + len(base64.b64decode(request['data_b64']))]])
            merged = []
            for start, end in intervals:
                if merged and start <= merged[-1][1]: merged[-1][1] = max(merged[-1][1], end)
                else: merged.append([start, end])
            draft['received'] = merged
            self.store.save(serial, data)
        elif action == 'write_preview':
            after = response.get('after_sha256')
            require(valid_hash(after), 'PROVIDER_RESPONSE_INVALID', '변경 미리보기의 해시가 올바르지 않습니다.')
            require(response.get('before_sha256') == drafts[request['draft_id']]['before_sha256'],
                    'HASH_MISMATCH', '파일이 초안 작성 이후 변경되었습니다.')
            require(response.get('size') == drafts[request['draft_id']]['size'],
                    'PROVIDER_RESPONSE_INVALID', '변경 미리보기의 파일 크기가 초안과 다릅니다.')
            drafts[request['draft_id']]['preview_sha256'] = after.lower()
            self.store.save(serial, data)
        elif action in ('write_commit', 'write_abort'):
            if action == 'write_commit':
                require(response.get('newsha', response.get('new_sha256')) == request['expected_sha256'] and
                        isinstance(response.get('backup_id'), str), 'COMMIT_VERIFICATION_REQUIRED',
                        '적용 응답의 해시 또는 백업 ID를 확인하지 못했습니다. 다시 적용하지 말고 앱 상태와 백업을 확인하세요.')
            drafts.pop(request['draft_id'], None)
            self.store.save(serial, data)
        elif action == 'list_files':
            require(isinstance(response.get('files'), list) and
                    all(isinstance(item, dict) and filename(item.get('name')) and
                        type(item.get('size')) is int and 0 <= item['size'] <= MAX_FILE and valid_hash(item.get('sha256'))
                        for item in response['files']),
                    'PROVIDER_RESPONSE_INVALID', '앱이 허용되지 않은 파일 또는 잘못된 파일 정보를 반환했습니다.')
        elif action == 'read_file':
            try: binary = base64.b64decode(response['data_b64'], validate=True)
            except (ValueError, KeyError, TypeError):
                raise BridgeError('PROVIDER_RESPONSE_INVALID', '파일 읽기 응답이 올바르지 않습니다.') from None
            require(len(binary) <= request['count'], 'PROVIDER_RESPONSE_INVALID', '파일 응답 크기가 요청을 초과했습니다.')
        return redact(response, [token])

    def request_session(self, serial, label='Mac 야구 도구', scopes=None):
        return self.execute(serial, {'action': 'request_session', 'request_id': str(uuid.uuid4()),
            'client_label': label, 'scopes': scopes or ['read', 'write']}, open_consent=True)

    def upload(self, serial, name, source, expected):
        source = Path(source)
        require(source.is_file() and not source.is_symlink(), 'LOCAL_FILE_INVALID', '읽을 일반 세이브 파일을 지정하세요.')
        require(source.stat().st_size <= MAX_FILE, 'LOCAL_FILE_INVALID', '파일은 16 MiB 이하여야 합니다.')
        binary = source.read_bytes()
        begin = self.execute(serial, {'action': 'write_begin', 'name': name, 'size': len(binary), 'expected_sha256': expected})
        draft = begin['draft_id']
        try:
            for offset in range(0, len(binary), CHUNK):
                self.execute(serial, {'action': 'write_chunk', 'draft_id': draft, 'offset': offset,
                    'data_b64': base64.b64encode(binary[offset:offset + CHUNK]).decode()})
            preview = self.execute(serial, {'action': 'write_preview', 'draft_id': draft})
            require(preview['after_sha256'] == hashlib.sha256(binary).hexdigest(), 'HASH_MISMATCH', '전송한 파일과 앱의 변경 초안 해시가 다릅니다.')
            return dict(preview, draft_id=draft, committed=False)
        except BridgeError as error:
            # Keep draft and original untouched for explicit abort/resume.
            raise BridgeError(error.code, error.message + ' 초안 ID: ' + draft) from None

    def download(self, serial, name, destination):
        validate({'action': 'read_file', 'name': name, 'offset': 0, 'count': CHUNK})
        target = Path(destination)
        require(not target.exists() and not target.is_symlink(), 'LOCAL_FILE_EXISTS', '기존 파일을 덮어쓰지 않습니다. 새 저장 경로를 지정하세요.')
        listing = self.execute(serial, {'action': 'list_files'})
        found = next((item for item in listing.get('files', []) if item.get('name') == name), None)
        require(found and isinstance(found.get('size'), int) and 0 <= found['size'] <= MAX_FILE and valid_hash(found.get('sha256')),
                'FILE_NOT_FOUND', '앱 파일 목록에서 크기와 해시가 확인된 세이브 파일을 선택하세요.')
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix='.yagu-download-', dir=target.parent)
        digest = hashlib.sha256()
        try:
            with os.fdopen(fd, 'wb') as stream:
                for offset in range(0, found['size'], CHUNK):
                    count = min(CHUNK, found['size'] - offset)
                    response = self.execute(serial, {'action': 'read_file', 'name': name, 'offset': offset, 'count': count})
                    chunk = base64.b64decode(response['data_b64'])
                    require(len(chunk) == count, 'FILE_CHANGED', '파일 크기가 읽기 도중 변경되었습니다.')
                    stream.write(chunk)
                    digest.update(chunk)
                stream.flush()
                os.fsync(stream.fileno())
            require(digest.hexdigest() == found['sha256'], 'HASH_MISMATCH', '읽은 파일의 해시가 원본 목록과 다릅니다.')
            # Atomic, no overwrite even if another process created target.
            os.link(temporary, target)
            return {'ok': True, 'name': name, 'path': str(target.absolute()), 'size': found['size'], 'sha256': digest.hexdigest()}
        finally:
            if os.path.exists(temporary): os.unlink(temporary)


def json_schema(fields, required):
    definitions = {
        'filename': {'type': 'string', 'pattern': r'^(bb2013[A-Za-z0-9_.-]*|yagu_awards_v1_[ab])\.sav$'},
        'sha256': {'type': 'string', 'pattern': '^[a-fA-F0-9]{64}$'},
        'uuid': {'type': 'string', 'format': 'uuid'}, 'id': {'type': 'string', 'maxLength': 128},
        'label': {'type': 'string', 'minLength': 1, 'maxLength': 80},
        'scopes': {'type': 'array', 'items': {'type': 'string', 'enum': list(SCOPES)}, 'minItems': 1, 'uniqueItems': True},
        'hand': {'type': 'string', 'enum': ['preserve', 'right', 'left']},
        'offset': {'type': 'integer', 'minimum': 0, 'maximum': MAX_FILE},
        'size': {'type': 'integer', 'minimum': 0, 'maximum': MAX_FILE},
        'count': {'type': 'integer', 'minimum': 1, 'maximum': CHUNK},
        'chunk': {'type': 'string', 'maxLength': 5464, 'description': 'Base64 of at most 4096 bytes.'},
    }
    properties = {'serial': {'type': 'string', 'description': 'Exact serial from yagu_devices. Never auto-selected.'}}
    properties.update({key: definitions[kind] for key, kind in fields.items()})
    return {'type': 'object', 'properties': properties, 'required': ['serial', *required], 'additionalProperties': False}


DESCRIPTIONS = {
    'status': 'Read app version, save access, running state and current state hash. No save data or token is disclosed.',
    'request_session': 'Ask the app to show a short-lived read/write consent request. The user approves on the tablet; this tool never approves it.',
    'session_status': 'Check an existing consent request. Approved tokens are stored locally with mode 0600 and are never returned.',
    'list_files': 'List only allowed game save files with size and SHA-256. Requires a read session and cold maintenance mode.',
    'read_file': 'Read at most 4096 bytes of an allowed game save file. Requires read consent and cold maintenance mode.',
    'backup': 'Ask the app to make a verified backup of its current game saves. Does not overwrite the originals.',
    'list_backups': 'List existing app backups and the current state hash; needed before a restore.',
    'write_begin': 'Start a staged save-file edit. expected_sha256 is the CURRENT original file hash; original remains unchanged.',
    'write_chunk': 'Write at most 4096 bytes into an existing staged draft. Invalidates any previous preview.',
    'write_preview': 'Inspect draft before/after SHA-256, size and diff summary. Does not replace a save.',
    'write_commit': 'Apply a reviewed draft using its exact preview after_sha256. App rechecks old hash and makes a backup before replacing the file.',
    'write_abort': 'Discard a staged draft without changing the original save.',
    'restore': 'Restore an existing app backup ID only, guarded by current_state_sha256; app snapshots current data first.',
    'set_hands': 'Set batting/pitching handedness independently in the patch sidecar. Preserve keeps that hand. May queue while game is running.',
    'patch_info': 'Read the app patch revision and supported settings. Available while a game is running.',
    'check': 'Run the app-provided patch integrity check without changing game progress.',
}


def mcp_tools():
    result = [{'name': 'yagu_devices', 'description': 'List ADB device serials and connection states. No device is selected automatically.',
               'inputSchema': {'type': 'object', 'properties': {}, 'additionalProperties': False},
               'annotations': {'readOnlyHint': True, 'destructiveHint': False, 'openWorldHint': False}},
              {'name': 'yagu_inspect', 'description': 'Read only the 야구 package version and device model/SDK. No private files.',
               'inputSchema': json_schema({}, ()),
               'annotations': {'readOnlyHint': True, 'destructiveHint': False, 'openWorldHint': False}}]
    for action, (fields, required) in SPECS.items():
        if action == 'request_session':
            fields, required = {'client_label': 'label', 'scopes': 'scopes'}, ('client_label', 'scopes')
        result.append({'name': 'yagu_' + action, 'description': DESCRIPTIONS[action],
                       'inputSchema': json_schema(fields, required),
                       'annotations': {'readOnlyHint': action in (READ - {'backup'}) | {'status', 'session_status'},
                                       'destructiveHint': action in {'write_commit', 'restore'}, 'openWorldHint': False}})
    return result


class MCPServer:
    def __init__(self, bridge_factory):
        self.bridge_factory, self.bridge, self.initialized = bridge_factory, None, False

    def handle(self, message):
        ident = message.get('id') if isinstance(message, dict) else None
        try:
            require(isinstance(message, dict) and message.get('jsonrpc') == '2.0' and isinstance(message.get('method'), str),
                    'INVALID_REQUEST', 'Invalid JSON-RPC request')
            method, params = message['method'], message.get('params', {})
            if method.startswith('notifications/'):
                return None
            if method == 'initialize':
                offered = params.get('protocolVersion')
                supported = ['2024-11-05', '2025-03-26', '2025-06-18', '2025-11-25']
                version = offered if offered in supported else supported[-1]
                self.initialized = True
                result = {'protocolVersion': version, 'capabilities': {'tools': {'listChanged': False}},
                          'serverInfo': {'name': 'yagu-device-bridge', 'version': VERSION},
                          'instructions': 'Select a serial explicitly. Use the app consent flow. File edits require ready maintenance mode, original hash, preview, and backup-backed commit.'}
            elif method == 'ping': result = {}
            else:
                require(self.initialized, 'NOT_INITIALIZED', 'initialize is required')
                if method == 'tools/list': result = {'tools': mcp_tools()}
                elif method == 'tools/call':
                    name, args = params.get('name'), params.get('arguments', {})
                    require(name in {x['name'] for x in mcp_tools()} and isinstance(args, dict), 'INVALID_ARGUMENT', 'Unknown tool or invalid arguments')
                    try:
                        if self.bridge is None: self.bridge = self.bridge_factory()
                        if name == 'yagu_devices':
                            require(not args, 'INVALID_ARGUMENT', 'devices takes no arguments')
                            value = self.bridge.devices()
                        else:
                            args = dict(args)
                            serial = args.pop('serial', None)
                            serial_value(serial)
                            if name == 'yagu_inspect':
                                require(not args, 'INVALID_ARGUMENT', 'inspect accepts serial only')
                                value = self.bridge.inspect(serial)
                            elif name == 'yagu_request_session':
                                require(set(args) == {'client_label', 'scopes'}, 'INVALID_ARGUMENT', 'request_session accepts client_label and scopes')
                                value = self.bridge.request_session(serial, args['client_label'], args['scopes'])
                            else: value = self.bridge.execute(serial, dict(args, action=name[len('yagu_'):]))
                        result = {'content': [{'type': 'text', 'text': json.dumps(value, ensure_ascii=False)}], 'isError': False}
                    except BridgeError as error:
                        result = {'content': [{'type': 'text', 'text': json.dumps(error.as_json(), ensure_ascii=False)}], 'isError': True}
                else: raise BridgeError('METHOD_NOT_FOUND', 'Unknown JSON-RPC method')
            return {'jsonrpc': '2.0', 'id': ident, 'result': result}
        except BridgeError as error:
            code = -32601 if error.code == 'METHOD_NOT_FOUND' else -32602
            return {'jsonrpc': '2.0', 'id': ident, 'error': {'code': code, 'message': error.message}}

    def serve(self, stdin=None, stdout=None):
        stdin, stdout = stdin or sys.stdin, stdout or sys.stdout
        while True:
            line = stdin.readline(MAX_MESSAGE + 1)
            if not line: break
            try:
                require(len(line) <= MAX_MESSAGE, 'INVALID_REQUEST', 'JSON-RPC line is too large')
                reply = self.handle(json.loads(line))
            except (ValueError, BridgeError):
                reply = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32700, 'message': 'Invalid JSON-RPC message'}}
            except Exception:
                # Unexpected local exceptions never dump credentials or argv.
                reply = {'jsonrpc': '2.0', 'id': None, 'error': {'code': -32603, 'message': 'Local bridge error'}}
            if reply is not None:
                stdout.write(json.dumps(reply, ensure_ascii=False, separators=(',', ':')) + '\n')
                stdout.flush()


def main(argv=None):
    parser = argparse.ArgumentParser(description='야구 v075 Mac 연결 도구')
    parser.add_argument('--adb', help='공식 platform-tools/adb 실행 파일 경로')
    parser.add_argument('--state-dir', help='연결 토큰/초안 상태를 저장할 전용 로컬 폴더')
    parser.add_argument('--serial', help='devices에서 확인한 대상 serial; 자동 선택하지 않음')
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('devices', 'inspect', 'status', 'mcp'): commands.add_parser(name)
    consent = commands.add_parser('request-session')
    consent.add_argument('--label', default='Mac 야구 도구')
    consent.add_argument('--scope', action='append', choices=SCOPES)
    session = commands.add_parser('session-status')
    session.add_argument('--request-id', required=True)
    call = commands.add_parser('call')
    call.add_argument('--json', required=True, help='허용된 action JSON; token은 받지 않음')
    upload = commands.add_parser('upload')
    upload.add_argument('--name', required=True)
    upload.add_argument('--input', required=True)
    upload.add_argument('--expected-sha256', required=True)
    download = commands.add_parser('download')
    download.add_argument('--name', required=True)
    download.add_argument('--output', required=True)
    args = parser.parse_args(argv)
    factory = lambda: Bridge(args.adb, args.state_dir)
    if args.command == 'mcp':
        MCPServer(factory).serve()
        return 0
    try:
        bridge = factory()
        if args.command == 'devices': result = bridge.devices()
        else:
            serial_value(args.serial)
            if args.command == 'inspect': result = bridge.inspect(args.serial)
            elif args.command == 'status': result = bridge.status(args.serial)
            elif args.command == 'request-session': result = bridge.request_session(args.serial, args.label, args.scope)
            elif args.command == 'session-status': result = bridge.execute(args.serial, {'action': 'session_status', 'request_id': args.request_id})
            elif args.command == 'call':
                try: request = json.loads(args.json)
                except ValueError: raise BridgeError('INVALID_ARGUMENT', '요청 JSON을 읽지 못했습니다.') from None
                result = bridge.execute(args.serial, request)
            elif args.command == 'upload': result = bridge.upload(args.serial, args.name, args.input, args.expected_sha256)
            else: result = bridge.download(args.serial, args.name, args.output)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except BridgeError as error:
        print(json.dumps(error.as_json(), ensure_ascii=False, indent=2))
        return 2
    except (OSError, ValueError, TypeError):
        print(json.dumps(BridgeError('LOCAL_ERROR', '로컬 파일 또는 연결 상태를 처리하지 못했습니다.').as_json(), ensure_ascii=False))
        return 2


if __name__ == '__main__':
    sys.exit(main())
