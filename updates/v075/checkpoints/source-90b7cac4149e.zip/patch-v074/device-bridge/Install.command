#!/bin/bash
set -eu
if ! command -v python3 >/dev/null 2>&1; then
  printf '%s\n' 'Python 3가 필요합니다: https://www.python.org/downloads/macos/'
  exit 1
fi
yagu_package_dir="${0%/*}"
if [ "$yagu_package_dir" = "$0" ]; then yagu_package_dir='.'; fi
exec python3 "$yagu_package_dir/install_bridge.py"
