#!/usr/bin/env python3
"""Test fixture only. It never connects to ADB or a physical device."""
import base64
import hashlib
import json
import os
from pathlib import Path
import sys
import time
import uuid

path = Path(os.environ['YAGU_FAKE_ADB_STATE'])
state = json.loads(path.read_text())
args = sys.argv[1:]


def save():
    path.write_text(json.dumps(state))


def finish(value):
    save()
    encoded = base64.b64encode(json.dumps(value).encode()).decode()
    print('Result: Bundle[{result_b64=' + encoded + '}]')
    raise SystemExit(0)


def fail(code):
    finish({'ok': False, 'error': {'code': code}})


def data(name):
    return base64.b64decode(state['files'][name])


def sha(blob):
    return hashlib.sha256(blob).hexdigest()


def state_sha():
    return sha(json.dumps(state['files'], sort_keys=True).encode())


def backup():
    ident = 'backup-' + str(uuid.uuid4())
    state.setdefault('backups', {})[ident] = dict(state['files'])
    return ident


if args == ['devices', '-l']:
    print('List of devices attached\nTAB123\tdevice product:test model:Galaxy_Tab transport_id:1\nOTHER42\tunauthorized')
    raise SystemExit(0)
assert args[:2] == ['-s', 'TAB123'], args
if args[2:] == ['shell', 'dumpsys', 'package', 'com.taehyun.yagu']:
    print('Package [com.taehyun.yagu]\n  versionCode=129005 minSdk=21\n  versionName=v075')
    raise SystemExit(0)
if args[2:5] == ['shell', 'getprop', 'ro.product.model']:
    print('Galaxy Tab test fixture')
    raise SystemExit(0)
if args[2:5] == ['shell', 'getprop', 'ro.build.version.sdk']:
    print('35')
    raise SystemExit(0)
if args[2:6] == ['shell', 'am', 'start', '-n']:
    assert args[6] == 'com.taehyun.yagu/com.taehyun.yagu.patch.PatchManagerActivity'
    assert args[7:9] == ['--es', 'request_id']
    state['consent_screen_opened'] = args[9]
    save()
    print('Starting: Intent')
    raise SystemExit(0)
assert args[2:10] == ['shell', 'content', 'call', '--uri', 'content://com.taehyun.yagu.bridge', '--method', 'request', '--extra'], args
assert args[10].startswith('payload:s:') and len(args) == 11
request = json.loads(base64.b64decode(args[10][len('payload:s:'):]))
action = request['action']
state.setdefault('calls', []).append({'serial': args[1], 'action': action,
    'fields': sorted(request), 'token_present': bool(request.get('token'))})
if state.get('echo_error') and action != 'status':
    save()
    print('failed command ' + ' '.join(args), file=sys.stderr)
    raise SystemExit(1)
if state.get('provider_missing'):
    save()
    print('Error while accessing provider: Could not find provider')
    raise SystemExit(0)
if action == 'status':
    finish({'ok': True, 'versionName': state.get('versionName', 'v075'), 'versionCode': state.get('versionCode', 129005),
            'game_running': state.get('game_running', False), 'save_access': state.get('save_access', 'ready'),
            'current_state_sha256': state_sha()})
if action == 'request_session':
    state.setdefault('requests', {})[request['request_id']] = request
    finish({'ok': True, 'state': 'pending', 'request_id': request['request_id']})
if action == 'session_status':
    pending = state.get('requests', {}).get(request['request_id'])
    if not pending: fail('REQUEST_UNKNOWN')
    if not state.get('user_approved'): finish({'ok': True, 'state': 'pending'})
    state['active_scopes'] = state.get('approved_scopes', pending['scopes'])
    finish({'ok': True, 'state': 'approved', 'token': state['test_token'],
            'expiry': time.time() + 300, 'scopes': state['active_scopes']})
if request.get('token') != state['test_token']: fail('SESSION_REQUIRED')
if action not in ('patch_info', 'check', 'set_hands'):
    if state.get('game_running'): fail('NEEDS_SAVE_AND_RESTART')
    if state.get('save_access', 'ready') != 'ready': fail('SAVE_ACCESS_BLOCKED')
if action == 'list_files':
    finish({'ok': True, 'files': [{'name': name, 'size': len(data(name)), 'sha256': sha(data(name))} for name in sorted(state['files'])]})
if action == 'read_file':
    raw = data(request['name'])
    finish({'ok': True, 'data_b64': base64.b64encode(raw[request['offset']:request['offset'] + request['count']]).decode()})
if action == 'backup': finish({'ok': True, 'backup_id': backup(), 'current_state_sha256': state_sha()})
if action == 'list_backups':
    finish({'ok': True, 'backups': [{'backup_id': ident} for ident in state.get('backups', {})], 'current_state_sha256': state_sha()})
if action == 'write_begin':
    if sha(data(request['name'])) != request['expected_sha256']: fail('HASH_MISMATCH')
    ident = 'draft-' + str(uuid.uuid4())
    state.setdefault('drafts', {})[ident] = {'name': request['name'], 'old_hash': request['expected_sha256'],
        'data_b64': base64.b64encode(bytes(request['size'])).decode(), 'size': request['size'], 'received': 0}
    finish({'ok': True, 'draft_id': ident})
if action in ('write_chunk', 'write_preview', 'write_commit', 'write_abort'):
    draft = state.get('drafts', {}).get(request['draft_id'])
    if not draft: fail('DRAFT_UNKNOWN')
    binary = bytearray(base64.b64decode(draft['data_b64']))
    if action == 'write_chunk':
        part = base64.b64decode(request['data_b64'])
        if request['offset'] != draft['received']: fail('DRAFT_OFFSET_MISMATCH')
        binary[request['offset']:request['offset'] + len(part)] = part
        draft['data_b64'] = base64.b64encode(binary).decode()
        draft['received'] += len(part)
        finish({'ok': True, 'received': len(part)})
    if action == 'write_preview':
        if draft['received'] != draft['size']: fail('DRAFT_INCOMPLETE')
        finish({'ok': True, 'draft_id': request['draft_id'], 'before_sha256': sha(data(draft['name'])),
                'after_sha256': sha(binary), 'size': len(binary), 'diffsummary': 'test byte changes'})
    if action == 'write_commit':
        if sha(data(draft['name'])) != draft['old_hash'] or sha(binary) != request['expected_sha256']: fail('HASH_MISMATCH')
        ident = backup()
        state['files'][draft['name']] = draft['data_b64']
        del state['drafts'][request['draft_id']]
        finish({'ok': True, 'backup_id': ident, 'newsha': sha(binary)})
    del state['drafts'][request['draft_id']]
    finish({'ok': True, 'aborted': True})
if action == 'restore':
    if request['expected_state_sha256'] != state_sha(): fail('HASH_MISMATCH')
    if request['backup_id'] not in state.get('backups', {}): fail('BACKUP_UNKNOWN')
    ident = backup()
    state['files'] = dict(state['backups'][request['backup_id']])
    finish({'ok': True, 'before_backup_id': ident, 'current_state_sha256': state_sha()})
if action == 'set_hands':
    state['hands'] = {key: request[key] for key in ('bat', 'pit')}
    finish({'ok': True, 'hands': state['hands'], 'queued': bool(state.get('game_running'))})
if action in ('patch_info', 'check'): finish({'ok': True, 'engine': 'v075', 'verified': True})
fail('UNSUPPORTED_ACTION')
