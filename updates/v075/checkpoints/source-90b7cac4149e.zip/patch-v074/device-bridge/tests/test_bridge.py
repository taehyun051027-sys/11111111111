"""No real ADB/device access. Executes a controlled fake provider subprocess."""
import base64
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tempfile
import time
import unittest
import uuid

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('bridge', HERE.parent / 'yagu_bridge.py')
bridge = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bridge)


class BridgeTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.state = self.root / 'fake.json'
        self.original = b'Three games and custom club remain preserved\0' * 150
        self.secret = 'TEST-ONLY-CONSENT-TOKEN-' + str(uuid.uuid4())
        self.state.write_text(json.dumps({'files': {'bb2013_3.sav': base64.b64encode(self.original).decode()},
                                        'test_token': self.secret, 'game_running': False, 'save_access': 'ready'}))
        self.previous = os.environ.get('YAGU_FAKE_ADB_STATE')
        os.environ['YAGU_FAKE_ADB_STATE'] = str(self.state)
        self.adb = HERE / 'fake_adb.py'
        self.adb.chmod(0o755)
        self.client = bridge.Bridge(str(self.adb), self.root / 'local')

    def tearDown(self):
        if self.previous is None: os.environ.pop('YAGU_FAKE_ADB_STATE', None)
        else: os.environ['YAGU_FAKE_ADB_STATE'] = self.previous
        self.temp.cleanup()

    def data(self): return json.loads(self.state.read_text())

    def modify(self, **changes):
        data = self.data()
        data.update(changes)
        self.state.write_text(json.dumps(data))

    def error(self, code, function, *args, **kwargs):
        with self.assertRaises(bridge.BridgeError) as caught: function(*args, **kwargs)
        self.assertEqual(code, caught.exception.code)
        self.assertNotIn(self.secret, str(caught.exception))

    def approve(self, scopes=None):
        request = self.client.request_session('TAB123', scopes=scopes)
        pending = self.client.execute('TAB123', {'action': 'session_status', 'request_id': request['request_id']})
        self.assertEqual('pending', pending['state'])
        self.assertNotIn('session', self.client.store.load('TAB123'))
        # This fixture change represents a human pressing Approve in the app.
        # No bridge/ADB operation can change it.
        self.modify(user_approved=True)
        response = self.client.execute('TAB123', {'action': 'session_status', 'request_id': request['request_id']})
        self.assertNotIn(self.secret, json.dumps(response))
        return response

    def request(self, action, **fields): return self.client.execute('TAB123', dict(fields, action=action))

    def test_enumeration_and_package_inspection(self):
        self.assertEqual(['TAB123', 'OTHER42'], [d['serial'] for d in self.client.devices()['devices']])
        result = self.client.inspect('TAB123')
        self.assertEqual('v075', result['versionName'])
        self.assertEqual(129005, result['versionCode'])

    def test_explicit_serial_and_injection_are_rejected_before_adb(self):
        for serial in (None, '', '-d', 'TAB123;id', 'TAB123 $(id)', 'TAB123\nroot'):
            self.error('SERIAL_REQUIRED', self.client.status, serial)
        for request in ({'action': 'shell', 'command': 'id'}, {'action': 'status', 'token': 'inject'},
                        {'action': 'read_file', 'name': '../prefs.xml', 'offset': 0, 'count': 1},
                        {'action': 'read_file', 'name': 'bb2013.sav;id', 'offset': 0, 'count': 1},
                        {'action': 'read_file', 'name': 'bb2013.sav', 'offset': -1, 'count': 1},
                        {'action': 'read_file', 'name': 'bb2013.sav', 'offset': 0, 'count': 4097},
                        {'action': 'write_begin', 'name': 'bb2013.sav', 'size': 2**30, 'expected_sha256': '0' * 64}):
            with self.assertRaises(bridge.BridgeError): self.client.execute('TAB123', request)
        self.assertEqual([], self.data().get('calls', []))

    def test_absent_provider_does_not_try_any_access_fallback(self):
        self.modify(provider_missing=True)
        self.error('BRIDGE_UPDATE_REQUIRED', self.request, 'list_files')
        self.assertEqual(['status'], [c['action'] for c in self.data()['calls']])

    def test_wrong_version_stops_before_consent_or_file_calls(self):
        self.modify(versionName='0.7.3', versionCode=129003)
        self.error('BRIDGE_UPDATE_REQUIRED', self.client.request_session, 'TAB123')
        self.assertEqual(['status'], [c['action'] for c in self.data()['calls']])

    def test_consent_is_manual_token_private_and_reused_until_expiry(self):
        response = self.approve()
        self.assertTrue(response['session_saved_locally'])
        path = self.client.store.path('TAB123')
        self.assertEqual(0o600, stat.S_IMODE(path.stat().st_mode))
        self.assertEqual(0o700, stat.S_IMODE(path.parent.stat().st_mode))
        self.assertTrue(self.request('list_files')['files'])
        state = self.client.store.load('TAB123')
        state['session']['expires_at'] = time.time() - 1
        self.client.store.save('TAB123', state)
        self.error('SESSION_REQUIRED', self.request, 'list_files')

    def test_scope_and_running_or_blocked_guards(self):
        self.approve(['read'])
        self.error('SCOPE_REQUIRED', self.request, 'set_hands', bat='preserve', pit='right')
        self.modify(game_running=True, save_access='running')
        self.error('NEEDS_SAVE_AND_RESTART', self.request, 'read_file', name='bb2013_3.sav', offset=0, count=1)
        self.assertTrue(self.request('patch_info')['ok'])
        self.modify(game_running=False, save_access='blocked')
        before = len(self.data()['calls'])
        self.error('SAVE_ACCESS_BLOCKED', self.request, 'write_begin', name='bb2013_3.sav', size=1, expected_sha256='0' * 64)
        self.assertEqual(['status'], [c['action'] for c in self.data()['calls'][before:]])

    def test_set_hands_uses_sidecar_while_running_and_keeps_save(self):
        self.approve()
        self.modify(game_running=True, save_access='running')
        result = self.request('set_hands', bat='preserve', pit='right')
        self.assertTrue(result['queued'])
        self.assertEqual(self.original, base64.b64decode(self.data()['files']['bb2013_3.sav']))
        self.error('INVALID_ARGUMENT', self.request, 'set_hands', bat='both', pit='right')

    def test_draft_preview_commit_backup_and_restore(self):
        self.approve()
        original_hash = hashlib.sha256(self.original).hexdigest()
        new = b'Reviewed modified save\0' * 400
        source = self.root / 'edited.sav'
        source.write_bytes(new)
        preview = self.client.upload('TAB123', 'bb2013_3.sav', source, original_hash)
        self.assertFalse(preview['committed'])
        self.assertEqual(self.original, base64.b64decode(self.data()['files']['bb2013_3.sav']))
        self.error('PREVIEW_REQUIRED', self.request, 'write_commit', draft_id=preview['draft_id'], expected_sha256='0' * 64)
        result = self.request('write_commit', draft_id=preview['draft_id'], expected_sha256=preview['after_sha256'])
        self.assertEqual(new, base64.b64decode(self.data()['files']['bb2013_3.sav']))
        self.assertEqual(self.original, base64.b64decode(self.data()['backups'][result['backup_id']]['bb2013_3.sav']))
        current_hash = self.client.status('TAB123')['current_state_sha256']
        self.error('HASH_MISMATCH', self.request, 'restore', backup_id=result['backup_id'], expected_state_sha256='0' * 64)
        self.error('BACKUP_UNKNOWN', self.request, 'restore', backup_id='unknown-backup', expected_state_sha256=current_hash)
        restored = self.request('restore', backup_id=result['backup_id'], expected_state_sha256=current_hash)
        self.assertEqual(self.original, base64.b64decode(self.data()['files']['bb2013_3.sav']))
        self.assertEqual(new, base64.b64decode(self.data()['backups'][restored['before_backup_id']]['bb2013_3.sav']))

    def test_completed_draft_is_not_rewritten_and_old_hash_is_rechecked(self):
        self.approve()
        old = hashlib.sha256(self.original).hexdigest()
        draft = self.request('write_begin', name='bb2013_3.sav', size=4, expected_sha256=old)['draft_id']
        self.request('write_chunk', draft_id=draft, offset=0, data_b64=base64.b64encode(b'aaaa').decode())
        preview = self.request('write_preview', draft_id=draft)
        self.error('DRAFT_OFFSET_MISMATCH', self.request, 'write_chunk', draft_id=draft, offset=0, data_b64=base64.b64encode(b'bbbb').decode())
        updated = self.request('write_preview', draft_id=draft)
        self.modify(files={'bb2013_3.sav': base64.b64encode(b'changed by game').decode()})
        self.error('HASH_MISMATCH', self.request, 'write_commit', draft_id=draft, expected_sha256=updated['after_sha256'])
        self.assertEqual(b'changed by game', base64.b64decode(self.data()['files']['bb2013_3.sav']))

    def test_unknown_draft_and_bad_hash_do_not_mutate_files(self):
        self.approve()
        self.error('DRAFT_UNKNOWN', self.request, 'write_chunk', draft_id='not-created-here', offset=0, data_b64='YQ==')
        self.error('HASH_MISMATCH', self.request, 'write_begin', name='bb2013_3.sav', size=1, expected_sha256='0' * 64)
        self.assertEqual(self.original, base64.b64decode(self.data()['files']['bb2013_3.sav']))

    def test_incomplete_draft_needs_full_coverage_before_preview(self):
        self.approve()
        draft = self.request('write_begin', name='bb2013_3.sav', size=8,
                             expected_sha256=hashlib.sha256(self.original).hexdigest())['draft_id']
        self.error('DRAFT_OFFSET_MISMATCH', self.request, 'write_chunk', draft_id=draft, offset=4, data_b64=base64.b64encode(b'bbbb').decode())
        self.request('write_chunk', draft_id=draft, offset=0, data_b64=base64.b64encode(b'aaaa').decode())
        self.error('DRAFT_INCOMPLETE', self.request, 'write_preview', draft_id=draft)
        self.request('write_chunk', draft_id=draft, offset=4, data_b64=base64.b64encode(b'bbbb').decode())
        preview = self.request('write_preview', draft_id=draft)
        self.assertEqual(hashlib.sha256(b'aaaabbbb').hexdigest(), preview['after_sha256'])
        self.request('write_abort', draft_id=draft)
        self.assertEqual(self.original, base64.b64decode(self.data()['files']['bb2013_3.sav']))

    def test_download_verified_and_never_overwrites(self):
        self.approve()
        target = self.root / 'download.sav'
        result = self.client.download('TAB123', 'bb2013_3.sav', target)
        self.assertEqual(self.original, target.read_bytes())
        self.assertEqual(hashlib.sha256(self.original).hexdigest(), result['sha256'])
        self.assertEqual(0o600, stat.S_IMODE(target.stat().st_mode))
        self.error('LOCAL_FILE_EXISTS', self.client.download, 'TAB123', 'bb2013_3.sav', target)

    def test_error_output_never_echoes_token_or_encoded_request(self):
        self.approve()
        self.modify(echo_error=True)
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = bridge.main(['--adb', str(self.adb), '--state-dir', str(self.root / 'local'), '--serial', 'TAB123',
                                'call', '--json', '{"action":"patch_info"}'])
        self.assertEqual(2, code)
        self.assertNotIn(self.secret, output.getvalue())
        self.assertNotIn('payload:s:', output.getvalue())
        self.assertNotIn(base64.b64encode(self.secret.encode()).decode(), output.getvalue())

    def test_state_file_symlink_and_world_readable_rejected(self):
        self.approve()
        path = self.client.store.path('TAB123')
        path.chmod(0o644)
        self.error('LOCAL_STATE_UNSAFE', self.client.store.load, 'TAB123')
        path.chmod(0o600)
        other = self.root / 'private-copy.json'
        path.rename(other)
        path.symlink_to(other)
        self.error('LOCAL_STATE_UNSAFE', self.client.store.load, 'TAB123')

    def test_mcp_stdio_json_only_and_no_command_escape(self):
        messages = [
            {'jsonrpc': '2.0', 'id': 1, 'method': 'initialize', 'params': {'protocolVersion': '2025-11-25'}},
            {'jsonrpc': '2.0', 'method': 'notifications/initialized'},
            {'jsonrpc': '2.0', 'id': 2, 'method': 'tools/list'},
            {'jsonrpc': '2.0', 'id': 3, 'method': 'tools/call', 'params': {'name': 'yagu_status', 'arguments': {'serial': 'TAB123'}}},
            {'jsonrpc': '2.0', 'id': 4, 'method': 'tools/call', 'params': {'name': 'yagu_shell', 'arguments': {'serial': 'TAB123', 'command': 'id'}}},
        ]
        result = subprocess.run([sys.executable, str(HERE.parent / 'yagu_bridge.py'), '--adb', str(self.adb),
            '--state-dir', str(self.root / 'local'), 'mcp'], input='\n'.join(json.dumps(x) for x in messages) + '\n',
            capture_output=True, text=True, check=True)
        replies = [json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual([1, 2, 3, 4], [r['id'] for r in replies])
        self.assertEqual('2025-11-25', replies[0]['result']['protocolVersion'])
        names = [t['name'] for t in replies[1]['result']['tools']]
        self.assertIn('yagu_write_preview', names)
        self.assertNotIn('yagu_shell', names)
        self.assertIn('error', replies[-1])
        self.assertNotIn(self.secret, result.stdout + result.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
