import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('installer', HERE.parent / 'install_bridge.py')
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)


class InstallerTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.source = self.root / 'source'
        self.source.mkdir()
        for name in installer.FILES: (self.source / name).write_text('test contents: ' + name)
        hashes = {name: hashlib.sha256((self.source / name).read_bytes()).hexdigest() for name in installer.FILES}
        (self.source / 'checksums.json').write_text(json.dumps(hashes))

    def tearDown(self): self.temp.cleanup()

    def test_installs_only_owned_files_and_concrete_mcp_config(self):
        destination = self.root / 'installed'
        result = installer.install(self.source, destination)
        self.assertFalse(result['device_modified'])
        self.assertFalse(result['host_configs_modified'])
        self.assertEqual(set(installer.FILES) | {'mcp-server.json', 'install-marker.json'}, {p.name for p in destination.iterdir()})
        config = json.loads((destination / 'mcp-server.json').read_text())
        self.assertEqual([str(destination / 'yagu_bridge.py'), 'mcp'], config['mcpServers']['yagu-device-bridge']['args'])
        installer.install(self.source, destination)

    def test_hash_failure_stops_before_copy(self):
        (self.source / 'yagu_bridge.py').write_text('tampered')
        destination = self.root / 'installed'
        with self.assertRaises(ValueError): installer.install(self.source, destination)
        self.assertFalse(destination.exists())

    def test_existing_other_repository_or_symlink_is_not_modified(self):
        destination = self.root / 'other-repository'
        destination.mkdir()
        (destination / 'README_ko.md').write_text('keep this')
        with self.assertRaises(ValueError): installer.install(self.source, destination)
        self.assertEqual('keep this', (destination / 'README_ko.md').read_text())
        link = self.root / 'link'
        link.symlink_to(destination)
        with self.assertRaises(ValueError): installer.install(self.source, link)
