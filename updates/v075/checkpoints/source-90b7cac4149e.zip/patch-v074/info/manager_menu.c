/* Original-menu entry points for the Android patch/save manager.
 * The controls are children of the original Cocos panels, using those panels'
 * existing atlases and bitmap font. They never save, resume, alter a match
 * phase, or write a player. Touch state belongs to these two transient views.
 */
typedef unsigned char u8;
typedef __SIZE_TYPE__ usize;
#define API __attribute__((visibility("hidden")))
typedef struct { float x, y; } Point;
typedef struct { float x, y, width, height; } Rect;
typedef struct { long x, y; } PointerPos;
#if __SIZEOF_POINTER__ == 8
#define CONFIG_FRAMES 0x20
#define CONFIG_TAB 0x68
#define CONFIG_INTRO 0x78
#define PAUSE_STATE 0x124
#else
#define CONFIG_FRAMES 0x10
#define CONFIG_TAB 0x34
#define CONFIG_INTRO 0x40
#define PAUSE_STATE 0xfc
#endif
#define CONFIG_BUTTON_TAG 0x07405001
#define PAUSE_BUTTON_TAG 0x07405002
#define BUTTON_TEXT_TAG 0x07405003
API extern void old_v074_config_table(u8 *, int);
API extern void old_v074_config_draw(u8 *, int, int);
API extern void old_v074_config_cleanup(u8 *);
API extern void old_v074_config_press(u8 *, PointerPos *);
API extern void old_v074_config_release(u8 *, PointerPos *);
API extern void old_v074_config_move(u8 *, PointerPos *);
API extern void old_v074_pause_enter(u8 *);
API extern void old_v074_pause_exit(u8 *);
API extern void old_v074_pause_visit(u8 *);
API extern u8 old_v074_pause_press(u8 *, PointerPos *);
API extern u8 old_v074_pause_release(u8 *, PointerPos *);
API extern u8 old_v074_pause_move(u8 *, PointerPos *);
API extern void v074_open_patch_manager(void);
API extern u8 *info_resource_manager(void);
API extern u8 *info_pzc_manager(u8 *, int);
API extern u8 *info_load_frame_auto(u8 *, int);
API extern u8 *info_graphics(void);
API extern int info_screen_width(u8 *);
API extern int info_screen_height(u8 *);
API extern void info_text(u8 *, const char *, int, int, Rect *, int, int, int, u8, u8, u8);
API extern void manager_remove_child(u8 *, int, u8);
API extern u8 *manager_get_child(u8 *, int);
API extern u8 *manager_global_child(int);
API extern u8 *manager_pause_resources(void);
API extern u8 *manager_pause_pzc(u8 *, int);

/* The only stored object pointer is the owner. Child nodes are looked up on
 * a currently executing/validated owner, never cached across reconstruction.
 */
typedef struct {
    u8 *owner;
    Rect bounds;
    int tab;
    u8 captured;
    u8 inside;
    u8 ready;
} MenuState;
static MenuState config;
static MenuState pause_menu;

static void position(u8 *node, float x, float y) {
    Point p = {x, y};
    void (**v)(void) = *(void (***)(void))node;
    ((void (*)(u8 *, Point *))v[19])(node, &p);
}
static void child(u8 *node, u8 *c, int z, int tag) {
    void (**v)(void) = *(void (***)(void))node;
    ((void (*)(u8 *, u8 *, int, int))v[55])(node, c, z, tag);
}
static void visible(u8 *node, u8 show) {
    void (**v)(void) = *(void (***)(void))node;
    ((void (*)(u8 *, u8))v[31])(node, show);
}
static u8 *config_frame(u8 *ui, int index) {
    if (!ui || (unsigned)index > 3u) return 0;
    return *(u8 **)(ui + CONFIG_FRAMES + index * sizeof(void *));
}
static int hit(MenuState *s, const PointerPos *p) {
    return p && (float)p->x >= s->bounds.x && (float)p->y >= s->bounds.y &&
        (float)p->x < s->bounds.x + s->bounds.width &&
        (float)p->y < s->bounds.y + s->bounds.height;
}
static void cancel(MenuState *s) { s->captured = 0; s->inside = 0; }
static void forget(MenuState *s) {
    cancel(s); s->owner = 0; s->ready = 0; s->tab = -1;
}
static void add_button(u8 *parent, u8 *pzc, int frame, int tag,
                       float x, float y, float w, float h, const char *color) {
    u8 *button = info_load_frame_auto(pzc, frame);
    Rect text = {0.0f, 0.0f, w, h};
    child(parent, button, 9, tag);
    position(button, x, -y);
    info_text(button, color, 1, BUTTON_TEXT_TAG, &text, 0x22, 0, 0, 1, 0, 1);
}

API void v074_config_cleanup(u8 *ui) {
    int i;
    /* The destructor calls RemoveMenuConfigUnit BEFORE this cleanup, leaving
     * stale frame fields. Resolve live scene children by original tags, never
     * dereference the cached fields during cleanup. Language rebuild is safe
     * for the same reason. Missing/already-freed frame tags return null.
     */
    for (i = 0; i != 4; ++i) {
        u8 *frame = manager_global_child(0x49833041 + i);
        if (frame) manager_remove_child(frame, CONFIG_BUTTON_TAG, 1);
    }
    if (config.owner == ui) forget(&config);
    old_v074_config_cleanup(ui);
}
API void v074_config_table(u8 *ui, int tab) {
    u8 *frame, *pzc;
    if (config.owner == ui) forget(&config);
    old_v074_config_table(ui, tab);
    tab = *(int *)(ui + CONFIG_TAB);
    frame = config_frame(ui, tab);
    if (!frame) return;
    pzc = info_pzc_manager(info_resource_manager(), 3);
    if (!pzc) return;
    manager_remove_child(frame, CONFIG_BUTTON_TAG, 1);
    /* Empty strip below the four existing tabs: native x124,y364,121x40. */
    add_button(frame, pzc, 188, CONFIG_BUTTON_TAG, -276.0f, 124.0f,
               121.0f, 40.0f, "!S16!x132746ff패치·저장");
    config.owner = ui;
    config.tab = tab;
}
API void v074_config_draw(u8 *ui, int x, int y) {
    old_v074_config_draw(ui, x, y);
    if (config.owner != ui) return;
    if (ui[CONFIG_INTRO] || *(int *)(ui + CONFIG_TAB) != config.tab) {
        config.ready = 0; cancel(&config); return;
    }
    config.bounds.x = (float)(info_screen_width(info_graphics()) / 2 + x - 276);
    config.bounds.y = (float)(info_screen_height(info_graphics()) / 2 + y + 124);
    config.bounds.width = 121.0f; config.bounds.height = 40.0f;
    config.ready = 1;
}
static int config_active(u8 *ui) {
    return config.owner == ui && config.ready && !ui[CONFIG_INTRO] &&
        *(int *)(ui + CONFIG_TAB) == config.tab;
}
API void v074_config_press(u8 *ui, PointerPos *p) {
    if (config_active(ui) && hit(&config, p)) {
        config.captured = 1; config.inside = 1; return;
    }
    if (config.owner == ui) cancel(&config);
    old_v074_config_press(ui, p);
}
API void v074_config_move(u8 *ui, PointerPos *p) {
    if (config.owner == ui && config.captured) {
        config.inside = (u8)(config_active(ui) && hit(&config, p)); return;
    }
    old_v074_config_move(ui, p);
}
API void v074_config_release(u8 *ui, PointerPos *p) {
    if (config.owner == ui && config.captured) {
        int open = config_active(ui) && config.inside && hit(&config, p);
        cancel(&config); /* Clear before crossing the JNI/activity boundary. */
        if (open) v074_open_patch_manager();
        return;
    }
    old_v074_config_release(ui, p);
}

static int pause_active(u8 *ui) {
    unsigned state;
    if (pause_menu.owner != ui || !pause_menu.ready) return 0;
    state = *(unsigned *)(ui + PAUSE_STATE);
    /* Normal pause and its sound/settings page only. Hide during D-pad
     * calibration and the return-to-main-menu confirmation popup. */
    return state <= 1u;
}
API void v074_pause_enter(u8 *ui) {
    u8 *pzc;
    int cx, cy;
    forget(&pause_menu);
    old_v074_pause_enter(ui);
    /* This exact original resource is used by visit_none/visit_config. */
    pzc = manager_pause_pzc(manager_pause_resources(), 1);
    if (!pzc) return;
    cx = info_screen_width(info_graphics()) / 2;
    cy = info_screen_height(info_graphics()) / 2;
    manager_remove_child(ui, PAUSE_BUTTON_TAG, 1);
    /* Below the native pause panel, whose last row ends at centerY+120. */
    add_button(ui, pzc, 5, PAUSE_BUTTON_TAG, (float)(cx - 136),
               (float)(154 - cy), 272.0f, 56.0f, "!S18!xffffffff패치·저장");
    pause_menu.owner = ui;
    pause_menu.bounds.x = (float)(cx - 136);
    pause_menu.bounds.y = (float)(cy + 154);
    pause_menu.bounds.width = 272.0f;
    pause_menu.bounds.height = 56.0f;
    pause_menu.ready = 1;
    {
        u8 *button = manager_get_child(ui, PAUSE_BUTTON_TAG);
        if (button) visible(button, (u8)pause_active(ui));
    }
}
API void v074_pause_exit(u8 *ui) {
    if (pause_menu.owner == ui) forget(&pause_menu);
    manager_remove_child(ui, PAUSE_BUTTON_TAG, 1);
    old_v074_pause_exit(ui);
}
API void v074_pause_visit(u8 *ui) {
    if (pause_menu.owner == ui) {
        int active = pause_active(ui);
        u8 *button = manager_get_child(ui, PAUSE_BUTTON_TAG);
        if (button) visible(button, (u8)active);
        if (!active) cancel(&pause_menu);
    }
    old_v074_pause_visit(ui);
}
API u8 v074_pause_press(u8 *ui, PointerPos *p) {
    if (pause_active(ui) && hit(&pause_menu, p)) {
        pause_menu.captured = 1; pause_menu.inside = 1; return 1;
    }
    if (pause_menu.owner == ui) cancel(&pause_menu);
    return old_v074_pause_press(ui, p);
}
API u8 v074_pause_move(u8 *ui, PointerPos *p) {
    if (pause_menu.owner == ui && pause_menu.captured) {
        pause_menu.inside = (u8)(pause_active(ui) && hit(&pause_menu, p)); return 1;
    }
    return old_v074_pause_move(ui, p);
}
API u8 v074_pause_release(u8 *ui, PointerPos *p) {
    if (pause_menu.owner == ui && pause_menu.captured) {
        int open = pause_active(ui) && pause_menu.inside && hit(&pause_menu, p);
        cancel(&pause_menu);
        if (open) v074_open_patch_manager();
        return 1;
    }
    return old_v074_pause_release(ui, p);
}
