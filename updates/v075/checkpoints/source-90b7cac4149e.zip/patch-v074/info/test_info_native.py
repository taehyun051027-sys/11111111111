#!/usr/bin/env python3
"""Execute the compiled info patch and original touch-dispatch code in Unicorn.

This is a native-code regression harness, not a claim of Android/GPU testing.
The original APK's Run, OnTouchRun and ProcTouchFunc execute. Renderer/allocation
boundaries are instrumented; saved career bytes are real guarded emulator RAM.
"""
from pathlib import Path
import hashlib
import io
import json
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "patch-v074/tools/python"))
sys.path.insert(0, str(HERE))
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_ARCH_ARM, UC_MODE_ARM, UC_MODE_THUMB, UC_HOOK_CODE, UC_HOOK_MEM_WRITE
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_X3, UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_X6, UC_ARM64_REG_X7, UC_ARM64_REG_LR, UC_ARM64_REG_SP, UC_ARM64_REG_PC, UC_ARM64_REG_CPACR_EL1, UC_ARM64_REG_S0
from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3, UC_ARM_REG_LR, UC_ARM_REG_SP, UC_ARM_REG_PC, UC_ARM_REG_C1_C0_2, UC_ARM_REG_FPEXC
from elf_inspect import Inspect
from module import BINDINGS, HOOKS, HOOK_EVIDENCE, CALLS

ZIG = ROOT / "patch-v074/tools/python/ziglang/zig"
CODE = 0x1000000
STUB = 0x1800000
DATA = 0x2000000
STACK = 0x3000000
END = STUB + 0xF000


def build(abi):
    out = HERE / ("test-" + abi)
    out.mkdir(exist_ok=True)
    is64 = abi == "arm64-v8a"
    game = Inspect(abi)
    for alias, (address, expected) in HOOK_EVIDENCE[abi].items():
        assert game.functions[HOOKS[alias]]["address"] == address
        assert game.read(address, 4).hex() == expected
    for address, expected, symbol in CALLS[abi]:
        assert game.read(address, 4).hex() == expected
    names = [n for n in BINDINGS if n != "info_add_table" and not n.startswith("manager_")]
    names += ["v074_my_batter", "v074_my_pitcher", "v074_batter_label", "v074_pitcher_label", "test_before_main", "old_v074_info_touch", "test_before_table", "test_node_position", "test_node_child"]
    stubs = {n: STUB + i * 16 for i, n in enumerate(names)}
    aliases = dict(stubs)
    aliases["old_v074_info_run"] = game.functions[HOOKS["v074_info_run"]]["address"]
    asm = [".text"]
    if not is64:
        asm += [".syntax unified", ".thumb"]
    for n, a in aliases.items():
        asm += [f".global {n}", f".hidden {n}", f".type {n}, %function", f".set {n}, {a | (not is64)}"]
    (out / "bind.S").write_text("\n".join(asm) + "\n")
    (out / "driver.c").write_text("""
typedef unsigned char u8;
extern void v074_info_touch(u8 *, int);
extern void v074_info_main(u8 *);
extern void test_before_table(u8 *, int);
extern void test_before_main(u8 *);
extern const char *v074_info_position_label(u8 *, int);
const char *test_position_label;
void old_v074_info_main(u8 *ui) {
    test_before_main(ui);
    test_position_label = v074_info_position_label(ui, 36);
}
void test_callback(u8 *touch, int index) {
    v074_info_touch(touch - sizeof(void *), index);
}
void info_add_table(u8 *ui, int page) {
    test_before_table(ui, page);
    v074_info_main(ui);
}
""")
    (out / "link.ld").write_text(f"""SECTIONS {{
 . = {CODE};
 .text : {{ *(.text*) }}
 .rodata : {{ *(.rodata*) }}
 .data : {{ *(.data*) }}
 .bss : {{ *(.bss*) *(COMMON) }}
 /DISCARD/ : {{ *(.comment) *(.eh_frame*) *(.ARM.exidx*) }}
}}""")
    target = ["-target", "aarch64-freestanding-none"] if is64 else ["-target", "thumb-freestanding-eabi", "-mcpu=cortex_a7", "-mfloat-abi=softfp"]
    cmd = [str(ZIG), "cc", *target, "-Oz", "-g", "-fPIC", "-ffreestanding", "-fno-builtin", "-fno-lto", "-fno-stack-protector", "-fno-unwind-tables", "-fno-asynchronous-unwind-tables", "-fvisibility=hidden", "-nostdlib", "-static", str(HERE / "info_payload.c"), str(out / "driver.c"), str(out / "bind.S"), "-Wl,-T," + str(out / "link.ld"), "-Wl,-e,v074_info_main", "-o", str(out / "info-test.elf")]
    subprocess.run(cmd, check=True, capture_output=True)
    raw = (out / "info-test.elf").read_bytes()
    elf = ELFFile(io.BytesIO(raw))
    symbols = {s.name: s["st_value"] for s in elf.get_section_by_name(".symtab").iter_symbols()}
    return game, raw, elf, symbols, stubs


class Harness:
    def __init__(self, abi):
        self.abi = abi
        self.is64 = abi == "arm64-v8a"
        self.word = 8 if self.is64 else 4
        self.mask = (1 << (self.word * 8)) - 1
        self.game, self.raw, self.elf, self.symbols, self.stubs = build(abi)
        self.uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM) if self.is64 else Uc(UC_ARCH_ARM, UC_MODE_THUMB)
        self.args = [UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_X3, UC_ARM64_REG_X4, UC_ARM64_REG_X5, UC_ARM64_REG_X6, UC_ARM64_REG_X7] if self.is64 else [UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_R3]
        self.pc = UC_ARM64_REG_PC if self.is64 else UC_ARM_REG_PC
        self.sp = UC_ARM64_REG_SP if self.is64 else UC_ARM_REG_SP
        self.lr = UC_ARM64_REG_LR if self.is64 else UC_ARM_REG_LR
        self.uc.mem_map(0, CODE)
        for seg in self.game.elf.iter_segments():
            if seg["p_type"] == "PT_LOAD":
                self.uc.mem_write(seg["p_vaddr"], seg.data())
        self.uc.mem_map(CODE, 0x10000)
        for seg in self.elf.iter_segments():
            if seg["p_type"] == "PT_LOAD":
                self.uc.mem_write(seg["p_vaddr"], seg.data())
        self.uc.mem_map(STUB, 0x10000)
        self.uc.mem_map(DATA, 0x100000)
        self.uc.mem_map(STACK, 0x100000)
        if self.is64:
            self.uc.reg_write(UC_ARM64_REG_CPACR_EL1, 3 << 20)
        else:
            self.uc.reg_write(UC_ARM_REG_C1_C0_2, 0xF << 20)
            self.uc.reg_write(UC_ARM_REG_FPEXC, 0x40000000)
        self.ui = DATA
        self.root = DATA + 0x1000
        self.vtable = DATA + 0x2000
        self.touch_vtable = DATA + 0x3000
        self.array_slots = DATA + 0x4000
        self.career = DATA + 0x10000
        self.career_size = 0x20000
        self.bat, self.pit, self.npc = self.career + 0x1000, self.career + 0x3000, self.career + 0x5000
        self.fixture = bytearray((i * 31 + 47) % 256 for i in range(self.career_size))
        # Deliberately nonzero club edits and exactly three played games remain.
        self.fixture[0x120:0x124] = struct.pack("<I", 3)
        self.fixture[0x180:0x180+24] = b"custom-club-edit-preserve"
        self.uc.mem_write(self.career, bytes(self.fixture))
        self.put16(self.bat, 1000)
        self.put16(self.pit, 1100)
        self.put16(self.npc, 1000)  # A same-ID copy must still be rejected.
        self.career_before = bytes(self.uc.mem_read(self.career, self.career_size))
        self.off = {"actor": 0x30 if self.is64 else 0x20, "root": 0x40 if self.is64 else 0x28, "ready": 0xB1 if self.is64 else 0x69, "exit": 0xB2 if self.is64 else 0x6A, "page": 0xB8 if self.is64 else 0x70, "touch_index": 0x20 if self.is64 else 0x14}
        self.touch = self.ui + self.word
        self.putptr(self.ui + self.off["actor"], self.bat)
        self.putptr(self.ui + self.off["root"], self.root)
        self.putptr(self.root, self.vtable)
        self.putptr(self.touch, self.touch_vtable)
        self.putptr(self.vtable + 19 * self.word, self.stubs["test_node_position"] | (not self.is64))
        self.putptr(self.vtable + 55 * self.word, self.stubs["test_node_child"] | (not self.is64))
        self.putptr(self.touch_vtable + 2 * self.word, self.symbols["test_callback"])
        self.put32(self.touch + self.off["touch_index"], -1)
        self.put8(self.ui + self.off["ready"], 1)
        self.heap = DATA + 0x40000
        self.units = []
        self.count = 5
        self.events = []
        self.labels = []
        self.nodes = []
        self.constructors = []
        self.members = {"bat": self.bat, "pit": self.pit}
        self.writes = []
        self.pending_stock_unit = None
        self.stock_remove_count = 0
        self.old_main_calls = 0
        self.old_touch_indices = []
        self.table_actors = []
        self.player_actors = []
        self.native_dispatch_entries = 0
        self.stub_by_address = {a: n for n, a in self.stubs.items()}
        self.native_names = {n: self.game.functions[n]["address"] | (not self.is64) for n in ["CBBGTouchMgrUI::OnTouchRun()", "CBBGTouchMgrUI::ProcTouchFunc()"]}
        self.native_plt = {}
        for a, n in self.game.plt.items():
            if n in self.native_names:
                self.native_plt[a] = self.native_names[n]
            if n in ["CGsArray<CBBGTouchUnit*>::Size()", "CGsArray<CBBGTouchUnit*>::Get(int)", "CBBGTouchUnit::IsDelayLastFrm()", "CBBGTouchUnit::Remove(eTOUCH_UNIT, bool)", "CGsSingleton<CBBGSoundMgr>::GetInstPtr()", "CBBGSoundMgr::PlayEffect(int, bool)"]:
                self.stub_by_address[a] = n
        self.uc.hook_add(UC_HOOK_CODE, self.dispatch)
        self.uc.hook_add(UC_HOOK_MEM_WRITE, self.track_write, begin=self.career, end=self.career+self.career_size-1)
        self.label_ptrs = [self.alloc_text("타자"), self.alloc_text("투수")]
        self.stock_position = self.alloc_text("선발")

    def put8(self, address, value): self.uc.mem_write(address, bytes([value & 255]))
    def put16(self, address, value): self.uc.mem_write(address, struct.pack("<H", value))
    def put32(self, address, value): self.uc.mem_write(address, struct.pack("<I", value & 0xFFFFFFFF))
    def putptr(self, address, value): self.uc.mem_write(address, value.to_bytes(self.word, "little"))
    def getptr(self, address): return int.from_bytes(self.uc.mem_read(address, self.word), "little")
    def getarg(self, index):
        if index < len(self.args): return self.uc.reg_read(self.args[index])
        return self.getptr(self.uc.reg_read(self.sp) + (index-len(self.args)) * self.word)
    def alloc(self, size=0x100):
        a = self.heap
        self.heap += (size + 15) & ~15
        return a
    def alloc_text(self, text):
        raw = text.encode() + b"\0"
        a = self.alloc(len(raw)); self.uc.mem_write(a, raw); return a
    def read_text(self, address):
        raw = bytearray()
        while self.uc.mem_read(address + len(raw), 1) != b"\0": raw += self.uc.mem_read(address + len(raw), 1)
        return raw.decode()
    def track_write(self, uc, access, address, size, value, user):
        self.writes.append((address, size, value))
        raise AssertionError(f"career write {self.abi}: {address:#x}")
    def ret(self, value=0):
        self.uc.reg_write(self.args[0], value & self.mask)
        self.uc.reg_write(self.pc, self.uc.reg_read(self.lr))
    def actor(self): return self.getptr(self.ui + self.off["actor"])
    def run(self, name, *args):
        self.uc.reg_write(self.sp, STACK + 0xF0000)
        self.uc.reg_write(self.lr, END | (not self.is64))
        for reg, value in zip(self.args, args): self.uc.reg_write(reg, value & self.mask)
        self.uc.emu_start(self.symbols[name], END, count=1000000)
        return self.uc.reg_read(self.args[0])

    def dispatch(self, uc, address, size, user):
        if address == END:
            uc.emu_stop(); return
        if address in self.native_plt:
            uc.reg_write(self.pc, self.native_plt[address]); return
        if address == (self.native_names["CBBGTouchMgrUI::ProcTouchFunc()"] & ~1):
            self.native_dispatch_entries += 1
        name = self.stub_by_address.get(address)
        if name is None: return
        a = [self.getarg(i) for i in range(4)]
        result = 0
        if name == "v074_my_batter": result = self.members["bat"]
        elif name == "v074_my_pitcher": result = self.members["pit"]
        elif name == "v074_batter_label": result = self.label_ptrs[0]
        elif name == "v074_pitcher_label": result = self.label_ptrs[1]
        elif name == "test_before_main":
            self.old_main_calls += 1
            self.count = 5
            self.units = [DATA + 0x5000 + i * 0x100 for i in range(5)]
            self.labels.clear(); self.nodes.clear(); self.constructors.clear()
            for i, unit in enumerate(self.units): self.putptr(self.array_slots + i * self.word, unit)
        elif name == "info_common_string": result = self.stock_position
        elif name == "old_v074_info_touch": self.old_touch_indices.append(a[1])
        elif name in ["info_touch_array_size", "CGsArray<CBBGTouchUnit*>::Size()"]: result = self.count
        elif name == "CGsArray<CBBGTouchUnit*>::Get(int)": result = self.array_slots + a[1] * self.word
        elif name == "CBBGTouchUnit::IsDelayLastFrm()":
            self.pending_stock_unit = a[0]
            result = 1
        elif name == "CBBGTouchUnit::Remove(eTOUCH_UNIT, bool)":
            assert a[0] in self.units, "stock dispatcher touched a freed TouchUnit"
            assert self.pending_stock_unit == a[0]
            self.pending_stock_unit = None
            self.stock_remove_count += 1
        elif name == "test_before_table":
            assert self.pending_stock_unit is None, "UI was rebuilt before original touch callback finished"
            assert a[1] == 0
            self.table_actors.append(self.actor())
        elif name == "info_add_player": self.player_actors.append(self.actor())
        elif name in ["info_resource_manager", "info_graphics", "CGsSingleton<CBBGSoundMgr>::GetInstPtr()"]: result = DATA + 0x8000
        elif name == "info_pzc_manager":
            assert a[1] == 8
            result = DATA + 0x9000
        elif name in ["info_load_frame_auto", "info_load_frame", "info_load_animation"]:
            expected = {"info_load_frame_auto": 86, "info_load_frame": 87, "info_load_animation": 5}[name]
            assert a[1] == expected
            result = self.alloc(); self.putptr(result, self.vtable)
        elif name == "info_screen_width": result = 800
        elif name == "info_screen_height": result = 480
        elif name == "info_alloc":
            assert a[0] == (0x48 if self.is64 else 0x38)
            result = self.alloc(a[0])
        elif name == "test_node_child":
            assert a[0] == self.root and a[2] == 2
            self.nodes.append(a[1])
        elif name == "test_node_position":
            x, y = struct.unpack("<2f", self.uc.mem_read(a[1], 8))
            assert x in [-350.0, -260.0] and y == 132.0
        elif name == "info_text":
            assert a[0] == self.root
            text = self.read_text(a[1]); self.labels.append(text)
            rect = self.getarg(4)
            x, y, w, h = struct.unpack("<4f", self.uc.mem_read(rect, 16))
            if text.endswith("양투양타"):
                assert (x, y, w, h) == (-350.0, -87.0, 165.0, 26.0)
            else:
                assert x in [-350.0, -260.0] and (y, w, h) == (-132.0, 75.0, 42.0)
        elif name == "info_touch_ctor":
            if self.is64:
                coords = [struct.unpack("<f", struct.pack("<I", self.uc.reg_read(UC_ARM64_REG_S0+i)))[0] for i in range(8)]
                z, parented, parent = self.getarg(3), self.getarg(4), self.getarg(5)
            else:
                words = [a[3]] + [self.getarg(i) for i in range(4, 11)]
                coords = list(struct.unpack("<8f", struct.pack("<8I", *words)))
                z, parented, parent = self.getarg(11), self.getarg(12), self.getarg(13)
            assert tuple(coords[:4]) in [(50.0, 108.0, 75.0, 42.0), (140.0, 108.0, 75.0, 42.0)], coords
            assert coords[:4] == coords[4:]
            assert (z, parented, parent) == (3, 0, 0)
            self.constructors.append(coords)
        elif name == "info_add_touch":
            assert a[0] == self.touch
            self.units.append(a[1]); self.putptr(self.array_slots + self.count * self.word, a[1]); self.count += 1
        elif name in ["info_create_clip", "info_init_animation", "CBBGSoundMgr::PlayEffect(int, bool)"]: pass
        else: raise AssertionError("unhandled boundary " + name)
        self.ret(result)

    def click(self, index):
        self.put32(self.touch + self.off["touch_index"], index)
        self.run("v074_info_run", self.ui)
        assert self.getptr(self.touch + self.off["touch_index"]) & 0xFFFFFFFF == 0xFFFFFFFF


def suite(abi):
    h = Harness(abi)
    h.run("v074_info_main", h.ui)
    assert h.count == 7 and len(h.constructors) == 2
    assert h.labels == ["!S18!xffff00ff타자", "!S18!xffffffff투수", "!S16!xffffffff양투양타"]
    assert h.read_text(h.getptr(h.symbols["test_position_label"])) == "야구신"
    for i in range(12):
        target = h.pit if i % 2 == 0 else h.bat
        h.click(6 if i % 2 == 0 else 5)
        assert h.actor() == target
        assert h.table_actors[-1] == target and h.player_actors[-1] == target
        assert h.count == 7
        assert h.read_text(h.getptr(h.symbols["test_position_label"])) == "야구신"
    assert h.stock_remove_count == 12
    assert len(h.table_actors) == 12
    h.click(5)  # Selected batter: no redundant rebuild.
    assert len(h.table_actors) == 12
    for index in range(5):
        h.run("v074_info_touch", h.ui, index)
    assert h.old_touch_indices == list(range(5))
    # Deferred switch must not survive a close, a changed page, or a new modal.
    for invalid in ["exit", "page", "replacement", "rebuild"]:
        h.run("v074_info_touch", h.ui, 6)
        if invalid == "exit": h.put8(h.ui + h.off["exit"], 1)
        if invalid == "page": h.put32(h.ui + h.off["page"], 1)
        if invalid == "replacement": h.putptr(h.ui + h.off["actor"], h.npc)
        if invalid == "rebuild": h.run("v074_info_main", h.ui)
        h.run("v074_info_run", h.ui)
        assert len(h.table_actors) == 12
        h.put8(h.ui + h.off["exit"], 0); h.put32(h.ui + h.off["page"], 0)
        h.putptr(h.ui + h.off["actor"], h.bat)
    # Same-ID NPC copies, absent pitcher data, wrong identity, role ID mismatch.
    for invalid in ["npc", "missing", "wrong_id", "same_actor"]:
        h.putptr(h.ui + h.off["actor"], h.npc if invalid == "npc" else h.bat)
        h.members["pit"] = 0 if invalid == "missing" else (h.bat if invalid == "same_actor" else h.pit)
        if invalid == "wrong_id": h.members["pit"] = h.npc
        h.run("v074_info_main", h.ui)
        assert h.count == 5
        if invalid == "npc": assert h.getptr(h.symbols["test_position_label"]) == h.stock_position
        h.run("v074_info_touch", h.ui, 6)
        assert h.old_touch_indices[-1] == 6
    # Config labels use the same original bitmap renderer/style.
    h.members["pit"] = h.pit
    h.putptr(h.ui + h.off["actor"], h.bat)
    h.label_ptrs = [h.alloc_text("타격"), h.alloc_text("투구")]
    h.run("v074_info_main", h.ui)
    assert h.labels == ["!S18!xffff00ff타격", "!S18!xffffffff투구", "!S16!xffffffff양투양타"]
    assert h.run("v074_info_position_label", h.ui, 36) == h.stock_position
    after = bytes(h.uc.mem_read(h.career, h.career_size))
    assert after == h.career_before and not h.writes
    assert struct.unpack_from("<I", after, 0x120)[0] == 3
    return {
        "abi": abi,
        "result": "pass",
        "original_native_touch_dispatches": h.native_dispatch_entries,
        "alternating_role_switches": 12,
        "stock_detail_indices_preserved": list(range(5)),
        "career_fixture_bytes_unchanged": len(after),
        "career_sha256": hashlib.sha256(after).hexdigest(),
        "career_write_count": len(h.writes),
        "display_only_labels": "My BAT/PIT position 야구신; hands 양투양타; NPC and out-of-scope label unchanged",
        "layout": "stock frames 86/87, animation 5, original TouchUnit/bitmap text; geometry and ABI checked",
        "limitations": "No Android GL rendering, physical touch, save migration or live-device end-to-end run in this harness.",
    }


if __name__ == "__main__":
    result = [suite(abi) for abi in ["arm64-v8a", "armeabi-v7a"]]
    (HERE / "native-test-results.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps(result, indent=2, ensure_ascii=False))
