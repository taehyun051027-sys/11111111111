/* v0.7.4: original CBBGPlayerInfoUI, switchable two-way ability inspection.
 *
 * The viewed actor is UI-local. This file never calls a save function, a mode
 * setter, a player setter, SearchRaisePlayer, or the v0.7.3 mirroring getter.
 * It uses the verified, read-only v074_my_* API supplied by the common patch.
 *
 * The original renderer supplies both ability panels and the original v0.7.3
 * infinity formatter remains in its original call path. New controls reuse
 * Raise UI frames 86/87, animation 5, the stock TouchUnit, and bitmap text.
 */
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef __SIZE_TYPE__ usize;
#define API __attribute__((visibility("hidden")))

typedef struct { float x, y; } Point;
typedef struct { float x, y, width, height; } Rect;

#if __SIZEOF_POINTER__ == 8
#define UI_PLAYER 0x30
#define UI_ROOT 0x40
#define UI_TOUCH 0x08
#define UI_READY 0xb1
#define UI_EXIT 0xb2
#define UI_PAGE 0xb8
#define TOUCH_UNIT_BYTES 0x48
#else
#define UI_PLAYER 0x20
#define UI_ROOT 0x28
#define UI_TOUCH 0x04
#define UI_READY 0x69
#define UI_EXIT 0x6a
#define UI_PAGE 0x70
#define TOUCH_UNIT_BYTES 0x38
#endif

API extern u8 *v074_my_batter(void);
API extern u8 *v074_my_pitcher(void);
API extern const char *v074_batter_label(void);
API extern const char *v074_pitcher_label(void);
API extern void old_v074_info_main(u8 *ui);
API extern const char *info_common_string(u8 *resources, int index);
API extern void old_v074_info_touch(u8 *ui, int index);
API extern int old_v074_info_run(u8 *ui);
API extern void info_add_table(u8 *ui, int page);
API extern void info_add_player(u8 *ui);
API extern u8 *info_resource_manager(void);
API extern u8 *info_pzc_manager(u8 *resources, int resource_id);
API extern u8 *info_load_frame_auto(u8 *pzc, int frame);
API extern u8 *info_load_frame(u8 *pzc, int frame);
API extern u8 *info_load_animation(u8 *pzc, int animation);
API extern void info_create_clip(u8 *animation);
API extern void info_init_animation(u8 *animation, u8 loop, u8 run);
API extern u8 *info_alloc(usize bytes);
API extern void info_touch_ctor(u8 *unit, u8 *frame, u8 *animation,
                               Rect collision, Rect draw, int z, u8 parented,
                               u8 *parent);
API extern void info_add_touch(u8 *touch_manager, u8 *unit);
API extern int info_touch_array_size(u8 *array);
API extern u8 *info_graphics(void);
API extern int info_screen_width(u8 *graphics);
API extern int info_screen_height(u8 *graphics);
API extern void info_text(u8 *parent, const char *text, int z, int tag,
                          Rect *rect, int align, int x, int y,
                          u8 visible, u8 wipi, u8 utf8);

/* At most one player-information modal is active. The reservation is consumed
 * only after stock Run/ProcTouchFunc returns. ProcTouchFunc uses its TouchUnit
 * after invoking ProcTouchResult; rebuilding the unit array in that callback
 * would free the active unit. UI construction clears an old reservation before
 * any reused UI address can consume it. No reservation is serialized.
 */
static u8 *pending_ui;
static u8 *pending_actor;
static int pending_role;
static u8 *profile_actor;

static u8 *ptr(u8 *base, usize offset) {
    return *(u8 **)(base + offset);
}

/* v074_my_* validate career ownership; additionally require the exact viewed
 * pointer and the original role ID. An NPC/copy with a matching ID is excluded.
 * Role result: 1 = batter, 2 = pitcher, 0 = non-owned/incomplete career.
 */
static int owned_role(u8 *ui, u8 **bat_out, u8 **pit_out) {
    u8 *bat = v074_my_batter();
    u8 *pit = v074_my_pitcher();
    u8 *view;
    if (!ui || !bat || !pit || bat == pit) return 0;
    if (*(u16 *)bat != 1000 || *(u16 *)pit != 1100) return 0;
    view = ptr(ui, UI_PLAYER);
    if (bat_out) *bat_out = bat;
    if (pit_out) *pit_out = pit;
    return view == bat ? 1 : (view == pit ? 2 : 0);
}

/* These two slots are the existing CCNode ABI, verified at the stock
 * AddMainInfo call sites on both architectures: setPosition index 19;
 * addChild(node,z,tag) index 55. Calling virtually preserves the Cocos object.
 */
static void node_position(u8 *node, float x, float y) {
    Point point = {x, y};
    void (**vt)(void) = *(void (***)(void))node;
    ((void (*)(u8 *, Point *))vt[19])(node, &point);
}

static void node_child(u8 *node, u8 *child, int z, int tag) {
    void (**vt)(void) = *(void (***)(void))node;
    ((void (*)(u8 *, u8 *, int, int))vt[55])(node, child, z, tag);
}

/* Language matches this Korean build. The !S / !x prefix is the original
 * CBBGStatic::GetChangeFont format; requested 20-pixel text emits !S18.
 * Yellow is the game's current-choice color; the unselected role stays white.
 */
static void role_label(char *output, int role, int selected) {
    const char *style = selected ? "!S18!xffff00ff" : "!S18!xffffffff";
    const char *text = role == 1 ? v074_batter_label() : v074_pitcher_label();
    unsigned int n = 0, i = 0;
    while (*style) output[n++] = *style++;
    /* The signed-data patch loader validates short UTF-8 labels. This guard
     * also prevents any malformed provider from overflowing the stack buffer.
     */
    if (!text || !*text) text = role == 1 ? "\xed\x83\x80\xec\x9e\x90" : "\xed\x88\xac\xec\x88\x98";
    while (text[i] && i < 64) output[n++] = text[i++];
    if (text[i] && i == 64) {
        while (i && (((unsigned char)text[i] & 0xc0u) == 0x80u)) { --n; --i; }
    }
    output[n] = 0;
}

static void add_role_controls(u8 *ui, int selected) {
    u8 *root = ptr(ui, UI_ROOT);
    u8 *touch = ui + UI_TOUCH;
    u8 *pzc;
    int cx, cy, role;
    if (!root || *(int *)(ui + UI_PAGE) != 0) return;
    /* Preserve the five original detail controls and their numeric indices. */
    if (info_touch_array_size(touch + sizeof(void *)) != 5) return;
    pzc = info_pzc_manager(info_resource_manager(), 8);
    if (!pzc) return;
    cx = info_screen_width(info_graphics()) / 2;
    cy = info_screen_height(info_graphics()) / 2;
    for (role = 1; role <= 2; ++role) {
        /* Coordinates are center-relative, like the original PZC. At the
         * native 800x480 layout these are x50/140,y108, below equipment level.
         */
        Rect relative = {(float)(-350 + 90 * (role - 1)), -132.0f, 75.0f, 42.0f};
        Rect absolute = relative;
        u8 *base = info_load_frame_auto(pzc, 86);
        u8 *press = info_load_frame(pzc, 87);
        u8 *animation = info_load_animation(pzc, 5);
        u8 *unit = info_alloc(TOUCH_UNIT_BYTES);
        char label[96];
        role_label(label, role, selected == role);
        /* Original Cocos loaders/new are non-null-or-fail allocation APIs. */
        node_child(root, base, 2, 0x07404000 + role);
        node_position(base, relative.x, -relative.y);
        info_text(root, label, 4, 0x07404010 + role,
                  &relative, 0x22, 0, 0, 1, 0, 1);
        info_create_clip(animation);
        info_init_animation(animation, 0, 0);
        absolute.x += (float)cx;
        absolute.y += (float)cy;
        info_touch_ctor(unit, press, animation, absolute, absolute, 3, 0, 0);
        info_add_touch(touch, unit);
    }
}

/* Only the specific AddMainInfo GetCommonStr(position) callsite uses this
 * helper. The underlying position field/getter stays available to the roster.
 */
API const char *v074_info_position_label(u8 *resources, int index) {
    u8 *bat = v074_my_batter(), *pit = v074_my_pitcher();
    if (profile_actor && ((profile_actor == bat && *(u16 *)bat == 1000) ||
                          (profile_actor == pit && *(u16 *)pit == 1100)))
        return "야구신";
    return info_common_string(resources, index);
}

API void v074_info_main(u8 *ui) {
    int role;
    u8 *previous = profile_actor;
    if (pending_ui == ui) {
        pending_ui = 0;
        pending_actor = 0;
        pending_role = 0;
    }
    profile_actor = ui ? ptr(ui, UI_PLAYER) : 0;
    old_v074_info_main(ui);
    profile_actor = previous;
    role = owned_role(ui, 0, 0);
    if (role) {
        Rect hands = {-350.0f, -87.0f, 165.0f, 26.0f};
        add_role_controls(ui, role);
        if (ptr(ui, UI_ROOT))
            info_text(ptr(ui, UI_ROOT), "!S16!xffffffff양투양타", 4,
                      0x07404020, &hands, 0x22, 0, 0, 1, 0, 1);
    }
}

API void v074_info_touch(u8 *ui, int index) {
    int role, target;
    if ((unsigned)index - 5u > 1u) {
        old_v074_info_touch(ui, index);
        return;
    }
    role = owned_role(ui, 0, 0);
    if (!role) {
        old_v074_info_touch(ui, index);
        return;
    }
    if (*(int *)(ui + UI_PAGE) != 0 || !ui[UI_READY] || ui[UI_EXIT]) return;
    target = index - 4;
    if (target == role) return;
    pending_ui = ui;
    pending_actor = ptr(ui, UI_PLAYER);
    pending_role = target;
}

API int v074_info_run(u8 *ui) {
    int result = old_v074_info_run(ui);
    if (pending_ui == ui) {
        u8 *expected = pending_actor;
        int target = pending_role;
        u8 *bat = 0, *pit = 0;
        pending_ui = 0;
        pending_actor = 0;
        pending_role = 0;
        if (result != -1 || ui[UI_EXIT] || *(int *)(ui + UI_PAGE) != 0) return result;
        if (ptr(ui, UI_PLAYER) != expected || !owned_role(ui, &bat, &pit)) return result;
        if (target != 1 && target != 2) return result;
        *(u8 **)(ui + UI_PLAYER) = target == 1 ? bat : pit;
        /* The original methods dispose and rebuild their own visual resources.
         * New main-info controls are added through v074_info_main above.
         */
        info_add_table(ui, 0);
        info_add_player(ui);
    }
    return result;
}
