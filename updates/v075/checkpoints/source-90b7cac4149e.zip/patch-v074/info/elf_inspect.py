"""Read-only inspection of the installed-version ELF; no save/game execution."""
from pathlib import Path
import io,sys,subprocess,re,json,struct
sys.path.insert(0,str(Path(__file__).resolve().parents[2]/'recovery/apk-inspection/deps'))
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_ARCH_ARM,CS_MODE_ARM,CS_MODE_THUMB
ROOT=Path(__file__).resolve().parents[2]
class Inspect:
 def __init__(self,abi='arm64-v8a',path=None):
  self.abi=abi; self.is64=abi=='arm64-v8a'
  self.path=Path(path) if path else ROOT/'recovery/apk-inspection/lib'/abi/'libgameDSO.so'
  self.raw=self.path.read_bytes(); self.elf=ELFFile(io.BytesIO(self.raw))
  syms=list(self.elf.get_section_by_name('.dynsym').iter_symbols())
  names=subprocess.run(['c++filt'],input='\n'.join(s.name for s in syms),capture_output=True,text=True,check=True).stdout.splitlines()
  self.functions={n:{'address':s['st_value']&~int(not self.is64),'size':s['st_size'],'mangled':s.name} for s,n in zip(syms,names) if s['st_value'] and s['st_info']['type']=='STT_FUNC'}
  self.labels={s['st_value']&~int(not self.is64):n for s,n in zip(syms,names) if s['st_value']}
  self.plt={}
  section=self.elf.get_section_by_name('.plt')
  rels=self.elf.get_section_by_name('.rela.plt' if self.is64 else '.rel.plt')
  for i,r in enumerate(rels.iter_relocations()):
   address=section['sh_addr']+32+i*16; self.labels[address]='[PLT] '+names[r['r_info_sym']]; self.plt[address]=names[r['r_info_sym']]
  self.cs=Cs(CS_ARCH_ARM64,CS_MODE_ARM) if self.is64 else Cs(CS_ARCH_ARM,CS_MODE_THUMB)
 def read(self,address,size):
  for s in self.elf.iter_segments():
   if s['p_type']=='PT_LOAD' and s['p_vaddr']<=address and address+size<=s['p_vaddr']+s['p_filesz']:
    o=s['p_offset']+address-s['p_vaddr']; return self.raw[o:o+size]
  raise ValueError(hex(address))
 def dump(self,name):
  f=self.functions[name]; lines=['\n### '+name+' '+hex(f['address'])+' '+str(f['size'])]
  for i in self.cs.disasm(self.read(f['address'],f['size']),f['address']):
   note=''
   if i.mnemonic in ('b','bl','b.w','blx') and i.op_str.startswith('#'):
    t=int(i.op_str[1:],16)
    if t in self.labels:note=' ; '+self.labels[t]
   lines.append(f'{i.address:08x}: {i.bytes.hex():8s} {i.mnemonic:7s} {i.op_str}{note}')
  return '\n'.join(lines)
if __name__=='__main__':
 abi=sys.argv[1] if len(sys.argv)>1 else 'arm64-v8a'
 exp=sys.argv[2] if len(sys.argv)>2 else 'CBBGPlayerInfoUI::'
 a=Inspect(abi)
 print('\n'.join(a.dump(n) for n in a.functions if re.search(exp,n)))
