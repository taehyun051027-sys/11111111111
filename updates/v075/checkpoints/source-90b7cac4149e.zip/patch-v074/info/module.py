"""Bindings for the additive v0.7.4 original player-info UI extension."""

HOOKS = {
    "v074_info_main": "CBBGPlayerInfoUI::AddMainInfo()",
    "v074_info_touch": "CBBGPlayerInfoUI::ProcTouchResult(int)",
    "v074_info_run": "CBBGPlayerInfoUI::Run()",
}

BINDINGS = {
    "info_common_string": "CBBGCcMgrRes::GetCommonStr(int)",
    "info_add_table": "CBBGPlayerInfoUI::AddTable(int)",
    "info_add_player": "CBBGPlayerInfoUI::AddPlayer()",
    "info_resource_manager": "CGsSingleton<CBBGCcMgrRes>::GetInstPtr()",
    "info_pzc_manager": "CBBGCcMgrRes::GetPZCMgr(BBG_CC_RES_ID)",
    "info_load_frame_auto": "ccpzx::CCPZXMgr::LoadFrame_Autorelease(int)",
    "info_load_frame": "ccpzx::CCPZXMgr::LoadFrame_Unmanaged(int)",
    "info_load_animation": "ccpzx::CCPZXMgr::LoadAnimation_Unmanaged(int)",
    "info_create_clip": "ccpzx::CCPZXAnimation::CreateAniClip()",
    "info_init_animation": "BB_InitCCAnimation(ccpzx::CCPZXAnimation*, bool, bool)",
    "info_alloc": {
        "arm64-v8a": "operator new(unsigned long)",
        "armeabi-v7a": "operator new(unsigned int)",
    },
    "info_touch_ctor": "CBBGTouchUnit::CBBGTouchUnit(ccpzx::CCPZXFrame*, ccpzx::CCPZXAnimation*, cocos2d::CCRect, cocos2d::CCRect, int, bool, cocos2d::CCNode*)",
    "info_add_touch": "CBBGTouchMgrUI::AddTouchUnit(CBBGTouchUnit*)",
    "info_touch_array_size": "CGsArray<CBBGTouchUnit*>::Size()",
    "info_graphics": "CGsSingleton<CGsGraphics>::GetInstPtr()",
    "info_screen_width": "CGsGraphics::GetWidth()",
    "info_screen_height": "CGsGraphics::GetHeight()",
    "info_text": "AddChildFitFontToNode(cocos2d::CCNode*, char const*, int, int, cocos2d::CCRect&, int, int, int, bool, bool, bool)",
}

HOOK_EVIDENCE = {
    "arm64-v8a": {
        "v074_info_main": (0x4CC8F8, "fd7bbea9"),
        "v074_info_touch": (0x4CC4CC, "ffc300d1"),
        "v074_info_run": (0x4CA640, "ffc300d1"),
    },
    "armeabi-v7a": {
        "v074_info_main": (0x2FF708, "f0b503af"),
        "v074_info_touch": (0x2FF4B8, "80b56f46"),
        "v074_info_run": (0x2FE068, "80b56f46"),
    },
}


MANAGER_HOOKS = {
    "v074_config_table": "CBBGUIMenuConfig::AddConfigTable(int)",
    "v074_config_draw": "CBBGUIMenuConfig::OnDraw(int, int)",
    "v074_config_cleanup": "CBBGUIMenuConfig::RemoveMenuConfigAll()",
    "v074_config_press": "CBBGUIMenuConfig::OnPointerPress(GxPointerPos*)",
    "v074_config_release": "CBBGUIMenuConfig::OnPointerRelease(GxPointerPos*)",
    "v074_config_move": "CBBGUIMenuConfig::OnPointerMove(GxPointerPos*)",
    "v074_pause_enter": "CBBGGameRun_Pause::onEnter()",
    "v074_pause_exit": "CBBGGameRun_Pause::onExit()",
    "v074_pause_visit": "CBBGGameRun_Pause::visit()",
    "v074_pause_press": "CBBGGameRun_Pause::OnPointerPress(GxPointerPos*)",
    "v074_pause_release": "CBBGGameRun_Pause::OnPointerRelease(GxPointerPos*)",
    "v074_pause_move": "CBBGGameRun_Pause::OnPointerMove(GxPointerPos*)",
}
HOOKS.update(MANAGER_HOOKS)
BINDINGS.update({
    "manager_remove_child": "cocos2d::CCNode::removeChildByTag(int, bool)",
    "manager_global_child": "GetChildNodeByTag(int)",
    "manager_get_child": "cocos2d::CCNode::getChildByTag(int)",
    "manager_pause_resources": "CBBGGameRun_PZXMgr::GetInstPtr()",
    "manager_pause_pzc": "CBBGGameRun_PZXMgr::GetPZXMgr(BBG_RES_PZC_ID)",
})

CALLS = {
    "arm64-v8a": [(0x4CD388, "2e800994", "v074_info_position_label")],
    "armeabi-v7a": [(0x2FFDD0, "70f126e8", "v074_info_position_label")],
}

def install(builder, symbols):
    for address, expected, symbol in CALLS[builder.abi]:
        code = builder.branch(address, symbols[symbol] & ~1, True)
        assert len(code) == 4
        builder.patch(address, code, "My player position display: 야구신", expected)

from pathlib import Path
SOURCES = [Path(__file__).resolve().parent / name for name in ("info_payload.c", "manager_menu.c")]
