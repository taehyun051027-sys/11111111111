import struct

def parse(blob):
 u=lambda p:struct.unpack_from("<I",blob,p)[0]
 ioff,fo,ao=struct.unpack_from("<3I",blob,12)
 ni=u(ioff+12); start=fo-ni*28
 images=[struct.unpack_from("<4H",blob,start+i*28) for i in range(ni)]
 frames=[]; p=fo+16
 for i in range(u(fo+12)):
  n=u(p);p+=4;parts=[]
  for j in range(n):
   part=struct.unpack_from("<Ihh4BI5f",blob,p);p+=36+part[7]*8;parts.append(part)
  n=u(p);p+=4;boxes=[]
  for j in range((n&65535)+(n>>16)):
   boxes.append(struct.unpack_from("<6h",blob,p));p+=12
  if u(p)==0x21544f58:
   p+=8+max(1,u(p+4))*28
  frames.append((parts,boxes))
 assert p==ao,(hex(p),hex(ao))
 return images,frames
