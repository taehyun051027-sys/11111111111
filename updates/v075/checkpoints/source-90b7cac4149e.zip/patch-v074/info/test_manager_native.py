#!/usr/bin/env python3
"""Compiled A64/Thumb menu hooks with original native menu event dispatch.

Renderer/JNI boundaries are instrumented. Original CBBGMenuRun pointer dispatch
executes from the shipped ELF, while view lifetimes and absent scene tags model
both language-page replacement and the destructor's already-freed frame fields.
This is not an Android/GPU or physical-device claim.
"""
from pathlib import Path
import io, json, struct, subprocess, sys, hashlib
import test_info_native as base
from test_info_native import HERE, ROOT, ZIG, CODE, STUB, DATA, STACK, END, Harness, Inspect, ELFFile, UC_HOOK_MEM_WRITE
from module import MANAGER_HOOKS, BINDINGS

def build(abi):
    is64 = abi == 'arm64-v8a'
    game = Inspect(abi)
    out = HERE / ('manager-test-' + abi)
    out.mkdir(exist_ok=True)
    names = list(BINDINGS) + ['old_' + n for n in MANAGER_HOOKS]
    names += ['v074_open_patch_manager', 'test_node_position', 'test_node_child',
              'test_node_visible', 'test_callback']
    stubs = {n: STUB + i * 16 for i, n in enumerate(dict.fromkeys(names))}
    aliases = dict(stubs)
    for event in ['press', 'release', 'move']:
        symbol = 'CBBGMenuRun::OnPointer' + event.title() + '(GxPointerPos*)'
        aliases['native_menu_' + event] = game.functions[symbol]['address']
    asm = ['.text'] + ([] if is64 else ['.syntax unified', '.thumb'])
    for name, address in aliases.items():
        asm += [f'.global {name}', f'.hidden {name}', f'.type {name}, %function',
                f'.set {name}, {address | (not is64)}']
    (out / 'bind.S').write_text('\n'.join(asm) + '\n')
    (out / 'link.ld').write_text(f'''SECTIONS {{
 . = {CODE}; .text : {{ *(.text*) }} .rodata : {{ *(.rodata*) }}
 .data : {{ *(.data*) }} .bss : {{ *(.bss*) *(COMMON) }}
 /DISCARD/ : {{ *(.comment) *(.eh_frame*) *(.ARM.exidx*) }}
}}''')
    target = ['-target', 'aarch64-freestanding-none'] if is64 else ['-target', 'thumb-freestanding-eabi', '-mcpu=cortex_a7', '-mfloat-abi=softfp']
    subprocess.run([str(ZIG), 'cc', *target, '-Oz', '-g', '-fPIC', '-ffreestanding',
        '-fno-builtin', '-fno-lto', '-fno-stack-protector', '-fno-unwind-tables',
        '-fno-asynchronous-unwind-tables', '-fvisibility=hidden', '-Wall', '-Wextra',
        '-Werror', '-nostdlib', '-static', str(HERE / 'manager_menu.c'),
        str(out / 'bind.S'), '-Wl,-T,' + str(out / 'link.ld'),
        '-Wl,-e,v074_config_table', '-o', str(out / 'menu-test.elf')],
        check=True, capture_output=True)
    raw = (out / 'menu-test.elf').read_bytes()
    elf = ELFFile(io.BytesIO(raw))
    syms = {s.name: s['st_value'] for s in elf.get_section_by_name('.symtab').iter_symbols()}
    return game, raw, elf, syms, stubs

class MenuHarness(Harness):
    def __init__(self, abi):
        saved = base.build
        base.build = build
        try: super().__init__(abi)
        finally: base.build = saved
        self.config = DATA
        self.pause = DATA + 0x1000
        self.pos = DATA + 0x8000
        self.menurun = DATA + 0x60000
        self.config_vtable = DATA + 0x61000
        self.cf = 0x20 if self.is64 else 0x10
        self.ct = 0x68 if self.is64 else 0x34
        self.ci = 0x78 if self.is64 else 0x40
        self.ps = 0x124 if self.is64 else 0xfc
        self.uc.mem_write(self.config, bytes(0x500))
        self.uc.mem_write(self.pause, bytes(0x500))
        self.putptr(self.config, self.config_vtable)
        self.putptr(self.pause, self.vtable)
        self.putptr(self.vtable + 31*self.word, self.stubs['test_node_visible'] | (not self.is64))
        for i, e in enumerate(['press', 'release', 'move']):
            self.putptr(self.config_vtable + (3+i)*self.word, self.symbols['v074_config_' + e])
        self.putptr(self.menurun + (0xd8 if self.is64 else 0xac), self.config)
        self.frames = [DATA + 0x50000 + i*0x400 for i in range(4)]
        self.live = set(self.frames + [self.pause])
        self.children = {}
        self.global_frames = {}
        self.node_info = {}
        self.forwarded = []
        self.open_count = 0
        self.original_dispatch = 0
        self.pause_writes = []
        self.install_frames()
        self.uc.hook_add(UC_HOOK_MEM_WRITE, self.track_pause_write,
                         begin=self.pause, end=self.pause+0x4ff)

    def install_frames(self):
        for i, frame in enumerate(self.frames):
            self.live.add(frame)
            self.putptr(frame, self.vtable)
            self.putptr(self.config+self.cf+i*self.word, frame)
            self.global_frames[0x49833041+i] = frame

    def track_pause_write(self, uc, access, address, size, value, user):
        self.pause_writes.append((address, size, value))
        raise AssertionError('pause/match object write by menu patch')

    def point(self, x, y):
        self.putptr(self.pos, x & self.mask)
        self.putptr(self.pos+self.word, y & self.mask)
        return self.pos

    def event(self, menu, action, x, y):
        pos = self.point(x,y)
        if menu == 'config':
            self.original_dispatch += 1
            return self.run('native_menu_' + action, self.menurun, pos)
        return self.run('v074_pause_' + action, self.pause, pos)

    def dispatch(self, uc, address, size, user):
        if address == END: uc.emu_stop(); return
        name = self.stub_by_address.get(address)
        if name is None: return
        a = [self.getarg(i) for i in range(4)]
        result = 0
        if name == 'old_v074_config_table':
            self.put32(a[0]+self.ct, a[1]); self.put8(a[0]+self.ci, 0)
        elif name.startswith('old_v074_'):
            self.forwarded.append((name, a[0], a[1]))
            if name in ['old_v074_pause_press','old_v074_pause_release','old_v074_pause_move']: result = 1
        elif name in ['info_resource_manager','info_graphics','manager_pause_resources']: result = DATA+0x9000
        elif name == 'info_pzc_manager':
            assert a[1] == 3; result = DATA+0xa000
        elif name == 'manager_pause_pzc':
            assert a[1] == 1; result = DATA+0xb000
        elif name == 'info_screen_width': result = 800
        elif name == 'info_screen_height': result = 480
        elif name == 'info_load_frame_auto':
            assert (a[0],a[1]) in [(DATA+0xa000,188),(DATA+0xb000,5)]
            result = self.alloc(); self.putptr(result,self.vtable); self.live.add(result)
            self.node_info[result] = {'frame':a[1], 'visible':True}
        elif name == 'test_node_child':
            assert a[0] in self.live and a[1] in self.live
            assert a[2] == 9 and a[3] in [0x07405001,0x07405002]
            assert (a[0],a[3]) not in self.children
            self.children[a[0],a[3]] = a[1]
        elif name == 'test_node_position':
            assert a[0] in self.live
            self.node_info[a[0]]['position'] = struct.unpack('<2f', self.uc.mem_read(a[1],8))
        elif name == 'test_node_visible':
            assert a[0] in self.live
            self.node_info[a[0]]['visible'] = bool(a[1])
        elif name == 'manager_remove_child':
            assert a[0] in self.live, f'stale Cocos frame dereference {a[0]:x}'
            assert a[1] in [0x07405001,0x07405002] and a[2] == 1
            removed = self.children.pop((a[0],a[1]),None)
            if removed: self.live.remove(removed)
        elif name == 'manager_global_child': result = self.global_frames.get(a[0],0)
        elif name == 'manager_get_child':
            assert a[0] in self.live
            result = self.children.get((a[0],a[1]),0)
        elif name == 'info_text':
            assert a[0] in self.live
            t = self.read_text(a[1]); assert t.endswith('패치·저장')
            rect = struct.unpack('<4f',self.uc.mem_read(self.getarg(4),16))
            assert rect in [(0.,0.,121.,40.),(0.,0.,272.,56.)]
            assert (a[2],a[3]) == (1,0x07405003)
            self.node_info[a[0]]['text'] = t
        elif name == 'v074_open_patch_manager': self.open_count += 1
        else: raise AssertionError('unexpected menu dependency: '+name)
        self.ret(result)

def suite(abi):
    h = MenuHarness(abi)
    for tab in range(4):
        h.run('v074_config_table',h.config,tab)
        h.run('v074_config_draw',h.config,0,0)
        b=h.children[h.frames[tab],0x07405001]
        assert h.node_info[b]['position'] == (-276.,-124.)
        assert h.node_info[b]['frame'] == 188
        before=h.open_count
        h.event('config','press',150,380)
        h.event('config','release',150,380)
        assert h.open_count == before+1
        # A duplicate release never opens the manager a second time.
        h.event('config','release',150,380)
        assert h.open_count == before+1
        # Original settings remain reachable through native MenuRun dispatch.
        for action in ['press','move','release']:
            h.event('config',action,450,200)
            assert h.forwarded[-1][0] == 'old_v074_config_'+action
        # A drag off the small button cancels it.
        h.event('config','press',150,380)
        h.event('config','move',400,300)
        h.event('config','release',150,380)
        assert h.open_count == before+1
    # Overlay follows native OnDraw offsets while the panel slides.
    h.run('v074_config_draw',h.config,20,-10)
    before=h.open_count
    h.event('config','press',260,355)
    h.event('config','release',260,355)
    assert h.open_count == before+1
    h.event('config','press',150,380)
    h.put32(h.config+h.ct,0)
    h.event('config','release',150,380)
    assert h.open_count == before+1
    # Original destructor first removes all frame nodes without clearing fields.
    # The patch must look up live scene tags, not touch those dangling fields.
    for frame in h.frames:
        h.live.remove(frame)
        for key in list(h.children):
            if key[0]==frame:
                h.live.discard(h.children.pop(key))
    h.global_frames.clear()
    h.run('v074_config_cleanup',h.config)
    h.event('config','release',150,380)
    assert h.open_count == before+1
    # Reuse owner address after scene teardown/language replacement.
    h.install_frames()
    h.run('v074_config_table',h.config,1)
    h.run('v074_config_draw',h.config,0,0)
    h.event('config','press',150,380)
    h.run('v074_config_cleanup',h.config)
    h.event('config','release',150,380)
    assert h.open_count == before+1
    # Pause: preserve every byte of the live match/pause object.
    h.put32(h.pause+h.ps,0)
    pause_before=bytes(h.uc.mem_read(h.pause,0x500))
    h.run('v074_pause_enter',h.pause)
    b=h.children[h.pause,0x07405002]
    assert h.node_info[b]['position']==(264.,86.)
    assert h.node_info[b]['frame']==5
    for state in range(6):
        h.put32(h.pause+h.ps,state)
        h.run('v074_pause_visit',h.pause)
        assert h.node_info[b]['visible']==(state<=1)
        before=h.open_count
        h.event('pause','press',400,420)
        h.event('pause','release',400,420)
        assert h.open_count==before+(state<=1)
        for action in ['press','move','release']:
            assert h.event('pause',action,100,200)==1
            assert h.forwarded[-1][0]=='old_v074_pause_'+action
        assert int.from_bytes(h.uc.mem_read(h.pause+h.ps,4),'little')==state
    h.put32(h.pause+h.ps,0)
    before=h.open_count
    h.event('pause','press',400,420)
    h.event('pause','move',100,100)
    h.event('pause','release',400,420)
    assert h.open_count==before
    h.event('pause','press',400,420)
    h.put32(h.pause+h.ps,5)
    h.event('pause','release',400,420)
    assert h.open_count==before
    h.put32(h.pause+h.ps,0)
    h.event('pause','press',400,420)
    h.run('v074_pause_exit',h.pause)
    h.event('pause','release',400,420)
    assert h.open_count==before and (h.pause,0x07405002) not in h.children
    h.run('v074_pause_enter',h.pause)
    h.event('pause','release',400,420)
    assert h.open_count==before
    assert bytes(h.uc.mem_read(h.pause,0x500)) == pause_before
    after=bytes(h.uc.mem_read(h.career,h.career_size))
    assert after==h.career_before and not h.writes and not h.pause_writes
    bss=h.elf.get_section_by_name('.bss')['sh_size']
    return {'abi':abi,'result':'pass','menu_bss_bytes':bss,
        'original_menu_native_pointer_dispatches':h.original_dispatch,
        'all_four_original_config_tabs':True,
        'other_pointer_inputs_forwarded':True,
        'pause_states_unchanged':list(range(6)),
        'stale_config_frame_cleanup':'passed destructor-order and owner-reuse checks',
        'career_fixture_bytes_unchanged':len(after), 'career_write_count':0,
        'pause_object_write_count':0,
        'career_sha256':hashlib.sha256(after).hexdigest(),
        'limitations':'No Android GPU rendering, physical touch, JNI activity or live device E2E executed here.'}

if __name__=='__main__':
    result=[suite(a) for a in ['arm64-v8a','armeabi-v7a']]
    (HERE/'manager-native-test-results.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))
