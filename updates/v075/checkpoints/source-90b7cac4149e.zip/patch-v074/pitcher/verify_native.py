"""Execute compiled patch + exact v0.7.3 handedness instructions on both ABIs.

Requires test-{a64,thumb}.elf built by build_tests.py. No Android device is used.
The only substituted native calls are PLT dispatches to the same original
IsAce/GetStyle function bodies, because the ELF loader is not running here.
"""
from pathlib import Path
import io, json, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "patch-v074/tools/python"))
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM64, UC_ARCH_ARM, UC_MODE_ARM, UC_MODE_THUMB, UC_HOOK_CODE
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2, UC_ARM64_REG_SP, UC_ARM64_REG_LR, UC_ARM64_REG_PC
from unicorn.arm_const import UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2, UC_ARM_REG_SP, UC_ARM_REG_LR, UC_ARM_REG_PC
from inspect_native import Native
import module

def load_elf(uc, elf, bias):
    segments = [s for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
    lo = min(s['p_vaddr'] for s in segments) & ~4095
    hi = (max(s['p_vaddr'] + s['p_memsz'] for s in segments) + 4095) & ~4095
    uc.mem_map(bias + lo, hi - lo)
    for s in segments:
        if s['p_filesz']: uc.mem_write(bias + s['p_vaddr'], s.data())

def verify(abi, patch_bias):
    is64 = abi == 'arm64-v8a'
    native = Native(abi)
    uc = Uc(UC_ARCH_ARM64 if is64 else UC_ARCH_ARM, UC_MODE_ARM if is64 else UC_MODE_THUMB)
    original_bias = 0x20000000
    load_elf(uc, native.elf, original_bias)
    patch_path = HERE / ('test-a64.elf' if is64 else 'test-thumb.elf')
    patch_elf = ELFFile(io.BytesIO(patch_path.read_bytes()))
    load_elf(uc, patch_elf, patch_bias)
    exports = {s.name: s['st_value'] for s in patch_elf.get_section_by_name('.symtab').iter_symbols()}
    arg = UC_ARM64_REG_X0 if is64 else UC_ARM_REG_R0
    sp = UC_ARM64_REG_SP if is64 else UC_ARM_REG_SP
    lr = UC_ARM64_REG_LR if is64 else UC_ARM_REG_LR
    pc = UC_ARM64_REG_PC if is64 else UC_ARM_REG_PC
    stop, memory, stack = 0x7f000000, 0x71000000, 0x72000000
    uc.mem_map(stop, 4096); uc.mem_map(memory, 4096); uc.mem_map(stack, 0x20000)
    redirect = {}
    for plt, name in native.plt.items():
        if name in ('CBBGPlayerData::IsAce()', 'CBBGPlayerData::GetStyle()'):
            redirect[original_bias + plt] = original_bias + native.functions[name]['address'] + (not is64)
    def dispatch(uc, address, _size, _user):
        if address in redirect: uc.reg_write(pc, redirect[address])
    uc.hook_add(UC_HOOK_CODE, dispatch)
    argregs = (UC_ARM64_REG_X0, UC_ARM64_REG_X1, UC_ARM64_REG_X2) if is64 else (UC_ARM_REG_R0, UC_ARM_REG_R1, UC_ARM_REG_R2)
    def call(address, *args):
        for reg, val in zip(argregs, args): uc.reg_write(reg, val & (0xffffffffffffffff if is64 else 0xffffffff))
        uc.reg_write(sp, stack + 0x10000)
        uc.reg_write(lr, stop | (not is64))
        uc.emu_start(address, stop, count=1000)
        assert uc.reg_read(pc) == stop, hex(uc.reg_read(pc))
        return uc.reg_read(arg)
    original_left = original_bias + native.functions['CBBGPlayerData::IsLeft()']['address'] + (not is64)
    original_style = original_bias + native.functions['CBBGPlayerData::GetStyle()']['address'] + (not is64)
    patch = patch_bias + exports['v074_pitcher_make_right']
    actor = memory + 0x700
    total = 0
    for byte in range(256):
        initial = bytearray(((i * 71 + 17) & 255) for i in range(4096))
        initial[0x700:0x702] = (1100).to_bytes(2, 'little')
        initial[0x722] = byte
        # A separate BAT has deliberately different handedness/appearance.
        initial[0x200:0x202] = (1000).to_bytes(2, 'little')
        initial[0x222] = 0x3d
        uc.mem_write(memory, bytes(initial))
        assert call(original_style, actor) == byte >> 4
        assert call(original_left, actor) == int((byte >> 4) in (1, 3, 5))
        expected = bytearray(initial)
        changed = (byte >> 4) <= 5 and bool(byte & 0x10)
        if changed: expected[0x722] &= ~0x10
        assert call(patch, actor) == int(changed)
        assert bytes(uc.mem_read(memory, 4096)) == bytes(expected)
        assert call(original_left, actor) == 0
        assert call(original_style, actor) == expected[0x722] >> 4
        assert call(original_left, memory + 0x200) == 1
        assert call(patch, actor) == 0
        assert bytes(uc.mem_read(memory, 4096)) == bytes(expected)
        total += 1
    assert call(patch, 0) == 0
    hand_patch = patch_bias + exports['v075_set_player_hand']
    hand_cases = 0
    for role in (0, 1):
        offset = 0x200 if role == 0 else 0x700
        for byte in range(256):
            for left in (0, 1):
                initial = bytearray(((i * 71 + 17) & 255) for i in range(4096))
                initial[offset:offset+2] = (1000 if role == 0 else 1100).to_bytes(2, 'little')
                initial[offset+0x22] = byte
                expected = bytearray(initial)
                if (byte >> 4) <= 5: expected[offset+0x22] = (byte & ~0x10) | (left << 4)
                uc.mem_write(memory, bytes(initial))
                assert call(hand_patch, memory + offset, role, left) == int(byte != expected[offset+0x22])
                assert bytes(uc.mem_read(memory, 4096)) == bytes(expected)
                assert call(original_left, memory + offset) == (left if (byte >> 4) <= 5 else 0)
                assert call(original_style, memory + offset) == expected[offset+0x22] >> 4
                assert call(hand_patch, memory + offset, role, -1) == 0
                assert bytes(uc.mem_read(memory, 4096)) == bytes(expected)
                hand_cases += 1
    return {'abi': abi, 'patch_load_bias': hex(patch_bias), 'style_cases': total,
            'v075_both_hand_cases': hand_cases,
            'exact_original_IsLeft_GetStyle': 'pass', 'all_other_4095_bytes': 'preserved'}

def main():
    sites = []
    for abi in module.CALLSITES:
        n = Native(abi)
        for address, alias, original, expected in module.CALLSITES[abi]:
            assert n.read(address, 4).hex() == expected, (abi, hex(address))
            instruction = next(n.cs.disasm(n.read(address, 4), address))
            assert n.plt[int(instruction.op_str[1:], 16)] == original
            sites.append({'abi': abi, 'address': hex(address), 'target': original, 'patch': alias})
    runs = [verify(abi, bias) for abi in ('arm64-v8a', 'armeabi-v7a') for bias in (0x10000000, 0x50000000)]
    report = {'status': 'pass', 'native_execution': runs, 'validated_callsites': sites,
              'device_e2e': 'not performed; no user device/save available'}
    (HERE / 'native-verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': 'pass', 'instruction_cases': sum(x['style_cases'] for x in runs),
                      'v075_both_hand_cases': sum(x['v075_both_hand_cases'] for x in runs),
                      'validated_callsites': len(sites), 'abis': 2, 'ASLR_biases_per_abi': 2}))

if __name__ == '__main__': main()
