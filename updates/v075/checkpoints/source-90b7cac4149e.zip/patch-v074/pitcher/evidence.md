# Pitcher customization and independent hands — additive v0.7.5 module

## Baseline and integration

The authoritative baseline is `recovery/apk-inspection/yagu-v0.7.3-dev.apk`,
SHA-256 `fe77f183ae813348ca1cea57596c4528429f08aa5f41792df005f6c1c375ae1d`.
All function addresses, instructions and object layouts in this folder were
read from that APK's two native libraries. The old v0.7.0 source was consulted
only to understand its two-way roster policy; it is not a replacement build.

Production sources: `pitcher.c`, `hands.c`. Builder contract: `module.py`.
There are six entry hooks and six narrowly selected callsite patches per ABI.
The complete module uses 56 bytes of zero-initialized BSS on ARM64 and 48 bytes
on Thumb, with no file I/O, heap allocation, saved-game schema or relocation
requirements introduced by these C sources. Original UI constructors perform
their normal allocation internally.

`BINDINGS` intentionally uses the mangled D1 destructor name. A demangled
destructor lookup is ambiguous: D0 deletes the allocation and would leave the
PageMgr pointing at freed memory. D1 tears down the original UI in place; its
allocation and PageMgr address remain unchanged.

The parent builder should implement
`patch_call(address, target, expected=original_instruction_bytes)` and bind
`old_<hook>` to the exact original v0.7.3 implementation/trampoline. The
callsite patcher must turn Thumb BLX-to-ARM-PLT into BL-to-Thumb-payload, not
retain BLX. `verify_native.py` verifies the exact expected instruction bytes
and their original PLT targets on both ABIs.

## Hand representation: one bit, two independent roles

Normal My Player identities are BAT RFID 1000 and PIT RFID 1100. Both original
`GetStyle()` implementations read the high nibble of byte `actor + 0x22`.
Both original `IsLeft()` implementations return true for styles 1, 3 or 5.
The even styles 0, 2 and 4 are right-handed, and the adjacent odd styles are
the same original style families with the opposite hand.

Changing bit `0x10` therefore changes only hand. It preserves the style
family, skin bits, low ACE bits, form, name, uniform, appearance, levels,
abilities, RFID, batting order, all records and every other actor byte.
`SetLeft()` is **not** the appropriate method: it modifies the low two bits,
which the normal My Player `IsLeft()` path does not inspect.

`v075_set_player_hand(actor, role, left)` checks the exact role RFID and a
supported style before writing. Role 0 means BAT, role 1 means PIT. `left=0`
means right, `left=1` means left, and other values, including -1 (preserve),
make no change. It returns 1 only when a bit changed.

The older `v074_pitcher_make_right()` helper remains available for isolated
compatibility tests. The final v0.7.5 policy does not force that helper from
every getter. The parent's default preference can request right pitching
while retaining the current batting hand; either hand can then be selected
independently in the parent settings UI.

## Safe switching boundaries

An `IsLeft()` getter override would be insufficient and unsafe for visual
consistency. The engine separately caches batter style, pitcher style,
pitch-origin data, camera handedness and player sprites. A changing getter
while a ball is in flight could make those components disagree.

The module changes the stored style only at two existing preparation points:

| Boundary | ARM64 | Thumb | Reason |
|---|---:|---:|---|
| `SET_PLAYER` call to `LoadResPlayer()` | `0x38a024` | `0x22c1fe` | Both `UpdatePlayer()` calls have already completed; the original renderer and motion setup follow. |
| `INIT_HANDLER_GSTATE_SLT_BALL_TYPE()` | `0x38c1bc` | `0x22d6c8` | The previous pitch is complete; the original function resets motion before the next pitch selection. |

At either point the module first checks that the core's backup is ready and
that the active mode is the original BAT career (4). It obtains the two
preferences, applies the one-bit setter to current actors and the persistent
own roster, and ORs only the changed roles into the original load flags.

Current actors are processed before persistent roster actors, because these
pointers may alias. Otherwise the first mutation could hide the need to
refresh a sprite. Opponent RFIDs are rejected by the pure setter. Existing
load flags are retained.

At the at-bat callsite, the original `LoadResPlayer()` runs exactly once; the
rest of `SET_PLAYER` executes its original motion, pitcher-style and
statistics setup. At the pitch boundary, a changed preference causes the
original `LoadResPlayer()` to refresh sprites, camera hand and CCLPitch data,
then the original `GetPitchingStyle()` and `SetPitcherStyle()` refresh the
pitcher physics object's cached style. The original pitch preparation's
`ResetMotion()` then runs. Unchanged preferences cause no extra reload.

No new call to `AtBatterIn()`, `ResetSB()`, statistics initialization, inning
progression or record writing is introduced. UI setting changes are pending
until these boundaries. A pitch already underway is not rebuilt.

The root implements `v075_bat_hand()` / `v075_pitch_hand()` as sidecar
preferences (-1 preserve / 0 right / 1 left), and must not flip actor bits
from general getters when those settings change.

## Unified original creation UI

Original creation remains the start flow. Once BAT choices and name are
complete, the same `CBBGCreatePlayerUI` allocation is reconstructed using its
original PIT constructor. Parallel BAT and PIT UI instances are deliberately
avoided: they use global scene tag IDs and would collide.

The module saves the five BAT choices in its small state. The player name is
kept in the original run's existing name buffer, with no separate player or
career. Original PIT controls supply pitcher style family, throwing hand,
skin, motion and pitch groups. Pitcher position remains starter (0), matching
the requested two-way starter policy. Shared appearance changes are reflected
back into the BAT choices. The throwing and batting hand choices are separate.

The original first-frame name-initialized flag is restored with the name.
Without that flag, the reconstructed page would see the already consumed
empty IME buffer and ask for the same name again. Original name editing,
choice controls, error popups and pitch selection remain active.

Back from pitch selection hides the original pitch popup. Back again returns
to BAT choices without losing either role's choices. Re-entering the PIT
page restores chosen pitch groups via the original selection-animation
method. Cancel/delete clears only transient module state. State re-entry
while the original UI is retained also retains the current BAT/PIT step.

Only four original global mode checks inside the creation display/process
path are redirected to a phase-aware query; the actual global game mode
remains 4. There is no separate pitcher career.

After PIT choices complete, the module reconstructs the original BAT UI and
lets the original BAT `MAKER_DONE` create the career. Its `InitModeData(true)`
already saves before returning. Consequently, applying PIT choices after
`MAKER_DONE` would miss the first save. The module instead patches only the
creation-specific `SaveObjects(1,1)` callsite (`0x4a085c` / `0x2e1900`).

The guarded save wrapper requires a pending creation transaction, mode 4,
valid original PIT choices, RFID 1000/1100 actors, and the expected new BAT
name. It invokes the existing v0.7.3 pitcher getter to realize the two-way
roster, applies PIT style/form/pitch mask, and invokes original save. It then
calls `v074_new_career_created()` and
`v075_set_creation_hands(bat_left, pit_left)` once. Existing careers never arm
this transaction. The root's actor lookup APIs must inspect the roster,
because original `InitModeData` invalidates cached-object state immediately
before the save call. Precisely, `ClearObjects()` zeroes the validity mask at
DM + `0x514`; it does not itself zero the cache pointers.

The original `SaveObjects()` always returns zero and discards the downstream
save result. The wrapper therefore cannot claim independent durable disk
success from that return value. The parent's first-launch snapshot and
sidecar implementation remain responsible for recovery. No forced extra
save or full rewrite of an existing career is introduced here.

## Verification performed

Run `python3 patch-v074/pitcher/build_tests.py` from the repository root.

The host tests compile the production C sources with AddressSanitizer and
UndefinedBehaviorSanitizer. Leak detection is disabled because this execution
environment uses ptrace, which LeakSanitizer cannot support; the modules do
not themselves allocate heap memory. The tests cover:

- All 256 packed style bytes, both roles and both hands, invalid settings,
  null pointers and every one of the 65,536 possible RFID values.
- Exact byte preservation around actor data, including independent batting
  hand, appearance, mock team edits, record regions and pitch fields.
- Unified BAT/PIT creation, default RHP, explicit future LHP selection,
  original pitch-group requirement, starter role, shared name/skin, and saved
  pitching choices before the original save.
- Back, cancel, state re-entry, partial choices, restored pitch selection,
  foreign mode, invalid actor identity and no sidecar initialization on a
  rejected commit.
- Independent hand settings, delayed application, current/roster aliases,
  no repeat reload for unchanged preferences, opponent preservation,
  backup/mode guards, and sprite-camera-physics-before-motion ordering.

The same production sources compile as freestanding ARM64 and Thumb PIC
objects. Unicorn executes their actual machine instructions together with
the exact baseline APK's original `IsLeft()` and `GetStyle()` implementations.
The only substituted original dispatches route PLT calls directly to their
same original method bodies. Both ABIs run at two nonzero ASLR load biases:
1,024 legacy handedness cases and 4,096 independent-role hand cases pass,
including comparison of every byte in the surrounding 4 KB memory region.
All twelve callsites match their expected baseline instruction bytes and
original PLT targets. The machine-readable report is
`native-verification.json`.

**Not performed:** visual full-game Android E2E, rendering on the Galaxy Tab,
or a migration of the user's actual three-game save. No device or user save
was accessed. These tests establish native field semantics, memory
preservation, state-machine ordering and exact patch targets; they are not a
substitute for a signed integrated APK/device test.
