"""Reproducibly compile the production C module and its isolated ABI tests."""
from pathlib import Path
import os, subprocess, sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEPS = ROOT / 'patch-v074/tools/python'
sys.path.insert(0, str(DEPS))
from elftools.elf.elffile import ELFFile
ZIG = DEPS / 'ziglang/zig'

def run(args, **kw): subprocess.run([str(x) for x in args], check=True, **kw)

def main():
    env = dict(os.environ, ASAN_OPTIONS='detect_leaks=0') # LSan cannot run under ptrace.
    for name in ('test_creation', 'test_hands'):
        run(['cc', '-std=c11', '-O1', '-g', '-fsanitize=address,undefined',
             '-fno-omit-frame-pointer', HERE / f'{name}.c', '-o', HERE / name])
        run([HERE / name], env=env)
    sizes = {}
    for kind, compile_target, link_target in (
        ('a64', 'aarch64-linux-android', 'aarch64-freestanding-none'),
        ('thumb', 'thumb-linux-android', 'thumb-freestanding-none')):
        cpu = ['-mcpu=cortex_a9', '-mfloat-abi=softfp'] if kind == 'thumb' else []
        objects, und = [], []
        sizes[kind] = 0
        for source in ('pitcher', 'hands'):
            obj = HERE / f'{source}-{kind}.o'; objects.append(obj)
            run([ZIG, 'cc', '-target', compile_target, *cpu,
                 '-ffreestanding', '-fPIC', '-fno-stack-protector', '-fno-builtin', '-O2',
                 '-c', HERE / f'{source}.c', '-o', obj])
            with obj.open('rb') as f:
                e = ELFFile(f)
                und += [s.name for s in e.get_section_by_name('.symtab').iter_symbols()
                        if s['st_shndx'] == 'SHN_UNDEF' and s.name]
                bss = e.get_section_by_name('.bss')
                if bss: sizes[kind] += bss['sh_size']
        und = list(dict.fromkeys(und))
        defs = '\n'.join(f'{name} = 0x{0x300000 + i*32 + (kind == "thumb"):x};' for i, name in enumerate(und))
        script = HERE / f'test-{kind}.ld'
        script.write_text(defs + '\nSECTIONS { . = 0x100000; .text : { *(.text*) } '
            '.rodata : { *(.rodata*) } . = 0x200000; .bss (NOLOAD) : { *(.bss*) } '
            '/DISCARD/ : { *(.comment) *(.eh_frame*) *(.note*) } }\n')
        run([ZIG, 'cc', '-target', link_target, *cpu, '-nostdlib',
             '-Wl,-e,v074_pitcher_make_right', f'-Wl,-T,{script}', *objects, '-o', HERE / f'test-{kind}.elf'])
    print('PASS: native compile BSS', sizes)
    run([sys.executable, HERE / 'verify_native.py'])

if __name__ == '__main__': main()
