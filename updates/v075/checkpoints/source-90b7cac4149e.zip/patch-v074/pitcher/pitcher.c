/* Additive v0.7.5 changes over the exact v0.7.3 library.
 * No saved-game format changes. No file I/O. Existing-career hand migration
 * is exposed as a one-bit pure mutation; the core owns backup/sidecar gating.
 * Creation serially reuses the original UI object because its scene tags are
 * global. It never creates a separate pitcher career or changes game mode.
 */
#include "../core/api.h"

typedef v074_u8 u8;
typedef v074_u16 u16;
typedef v074_u32 u32;
#define API V074_API

#if __SIZEOF_POINTER__ == 8
#define RUN_UI 0xe8
#define RUN_NAME 0x260
#define RUN_KEY 0x90
#define RUN_UI_CREATED 0x238
#define UI_IS_BAT 0x39
#define UI_TABLE 0x3c
#define UI_ROW 0x54
#define UI_NAME 0x64
#define UI_BALL 0xa8
#define UI_NAME_INITIALIZED 0x104
#else
#define RUN_UI 0xb4
#define RUN_NAME 0x180
#define RUN_KEY 0x70
#define RUN_UI_CREATED 0x15c
#define UI_IS_BAT 0x25
#define UI_TABLE 0x28
#define UI_ROW 0x40
#define UI_NAME 0x50
#define UI_BALL 0x90
#define UI_NAME_INITIALIZED 0xc0
#endif

API extern void old_v074_creation_init(void *run);
API extern void old_v074_creation_delete(void *run);
API extern void old_v074_creation_process(void *run);
API extern void old_v074_creation_event(void *run);
API extern void old_v074_creation_adjust(void *ui, int value);
API extern void v074_creation_ui_ctor(void *ui, int is_bat);
/* D1, never D0: the PageMgr and run retain the same allocated address. */
API extern void v074_creation_ui_dtor(void *ui);
API extern void v074_creation_ui_start(void *ui);
API extern int v074_creation_name_ready(void *ui);
API extern int v074_creation_choices_ready(void *run);
API extern int v074_creation_ball_show(void *ui);
API extern int v074_creation_ball_ready(void *ui);
API extern int v074_creation_table_open(void *ui);
API extern int v074_creation_ball_choice(void *ball_ui, int group);
API extern void v074_creation_ball_toggle(void *ball_ui, int group);
API extern int v074_creation_mode(void);
API extern int v074_creation_original_is_bat(void);
API extern int v074_creation_original_is_pit(void);
API extern void *v074_creation_get_pitcher(void *data_mgr);
API extern int v074_creation_save_original(void *data_mgr, u8 a, u8 b);
API extern int v075_set_creation_hands(int bat_left, int pit_left);

enum { NONE, BAT, PIT, COMMIT, SAVED };
typedef struct {
    u8 *run;
    int bat[5];
    int pit[5];
    u8 phase;
    u8 pit_initialized;
    u8 ball_groups;
    u8 committed;
} CreationState;
/* 56 B on ARM64, 48 B on ARM32. Zero-initialized, no pointers in rodata. */
static CreationState creation;
_Static_assert(sizeof(CreationState) <= 96, "creation state exceeds budget");

static u8 *ui_for(void *run) {
    return run ? *(u8 **)((u8 *)run + RUN_UI) : (u8 *)0;
}
static int *table_for(u8 *ui) { return (int *)(ui + UI_TABLE); }
static int active(void *run) {
    return run && creation.run == (u8 *)run && v074_creation_mode() == 4;
}
static void copy_name(u8 *to, const u8 *from) {
    int end = 0;
    for (unsigned i = 0; i < 63; ++i) {
        u8 c = end ? 0 : from[i];
        if (!c) end = 1;
        to[i] = c;
    }
    to[63] = 0;
}
static void snapshot_table(int *to, u8 *ui) {
    for (unsigned i = 0; i < 5; ++i) to[i] = table_for(ui)[i];
}
static void snapshot_balls(u8 *ui) {
    u8 *ball = *(u8 **)(ui + UI_BALL);
    if (!ball) return;
    creation.ball_groups = 0;
    for (int i = 0; i < 4; ++i)
        if (v074_creation_ball_choice(ball, i) > 0)
            creation.ball_groups |= (u8)(1u << i);
}
static void rebuild_ui(u8 *ui, int is_bat, const int *table) {
    /* Name lives in the original run's name buffer across the destructor. */
    v074_creation_ui_dtor(ui);
    v074_creation_ui_ctor(ui, is_bat);
    copy_name(ui + UI_NAME, creation.run + RUN_NAME);
    /* Original Run consumes and clears IME text. A reconstructed page already
     * has a valid name; bypass only its first-frame "enter a name" prompt. */
    ui[UI_NAME_INITIALIZED] = 1;
    v074_creation_ui_start(ui);
    /* Use the original selection/preview path, rather than raw table writes. */
    for (int i = 0; i < 5; ++i) {
        *(int *)(ui + UI_ROW) = i;
        old_v074_creation_adjust(ui, table[i]);
    }
    *(int *)(ui + UI_ROW) = 0;
}

API int v074_pitcher_make_right(void *actor) {
    u8 *pit = (u8 *)actor;
    if (!pit || *(u16 *)pit != 1100 || (pit[0x22] >> 4) > 5) return 0;
    if (!(pit[0x22] & 0x10)) return 0;
    pit[0x22] &= (u8)~0x10;
    return 1;
}

/* The core skips legacy RHP migration during this fresh-player transaction. */
API int v074_creation_committing(void) { return creation.phase == COMMIT; }

API void v074_creation_init(void *run) {
    u8 *before = ui_for(run);
    int continuing = run && creation.run == (u8 *)run && before &&
        ((u8 *)run)[RUN_UI_CREATED] &&
        (creation.phase == BAT || creation.phase == PIT);
    if (!continuing) {
        creation.run = (u8 *)0;
        creation.phase = NONE;
        creation.pit_initialized = creation.ball_groups = creation.committed = 0;
    }
    old_v074_creation_init(run);
    u8 *ui = ui_for(run);
    if (continuing && ui == before && v074_creation_mode() == 4) {
        /* The original state init clears the run-name buffer even when it
         * keeps an existing UI. Preserve a live BAT/PIT creation step. */
        copy_name((u8 *)run + RUN_NAME, ui + UI_NAME);
        return;
    }
    if (run && ui && v074_creation_mode() == 4 && ui[UI_IS_BAT]) {
        creation.run = (u8 *)run;
        creation.phase = BAT;
    }
}

API void v074_creation_delete(void *run) {
    if (creation.run == (u8 *)run) {
        creation.run = (u8 *)0;
        creation.phase = NONE;
        creation.pit_initialized = creation.ball_groups = creation.committed = 0;
    }
    old_v074_creation_delete(run);
}

API void v074_creation_process(void *run) {
    u8 *ui = ui_for(run);
    if (!active(run) || !ui ||
        !v074_creation_name_ready(ui) ||
        !v074_creation_choices_ready(run)) {
        old_v074_creation_process(run);
        return;
    }
    if (creation.phase == BAT) {
        snapshot_table(creation.bat, ui);
        copy_name(creation.run + RUN_NAME, ui + UI_NAME);
        if (!creation.pit_initialized) {
            creation.pit[0] = 0; /* Original pitcher style family. */
            creation.pit[1] = 1; /* Original UI: 1 = right, 0 = left. */
            creation.pit[3] = 0; /* Original pitching motion. */
            creation.pit[4] = 0; /* Two-way starter, every game. */
            creation.pit_initialized = 1;
        }
        creation.pit[2] = creation.bat[2]; /* One shared player appearance. */
        creation.phase = PIT;
        rebuild_ui(ui, 0, creation.pit);
        return;
    }
    if (creation.phase == PIT) {
        if (v074_creation_ball_show(ui) && v074_creation_ball_ready(ui)) {
            snapshot_table(creation.pit, ui);
            snapshot_balls(ui);
            creation.bat[2] = creation.pit[2];
            copy_name(creation.run + RUN_NAME, ui + UI_NAME);
            creation.phase = COMMIT;
            rebuild_ui(ui, 1, creation.bat);
            /* Original BAT completion creates exactly one BAT career. */
            old_v074_creation_process(run);
            return;
        }
        void *before = *(void **)(ui + UI_BALL);
        /* Only this callsite sees PIT mode; global game mode remains BAT. */
        old_v074_creation_process(run);
        void *ball = *(void **)(ui + UI_BALL);
        if (!before && ball && creation.ball_groups) {
            for (int i = 0; i < 4; ++i)
                if (creation.ball_groups & (1u << i))
                    v074_creation_ball_toggle(ball, i);
        }
        return;
    }
    old_v074_creation_process(run);
}

API void v074_creation_event(void *run) {
    u8 *ui = ui_for(run);
    if (active(run) && ui && creation.phase == PIT &&
        *(int *)((u8 *)run + RUN_KEY) == -16 &&
        !v074_creation_ball_show(ui) && !v074_creation_table_open(ui)) {
        snapshot_table(creation.pit, ui);
        snapshot_balls(ui);
        creation.bat[2] = creation.pit[2];
        copy_name(creation.run + RUN_NAME, ui + UI_NAME);
        creation.phase = BAT;
        rebuild_ui(ui, 1, creation.bat);
        *(int *)((u8 *)run + RUN_KEY) = 0;
        return;
    }
    old_v074_creation_event(run);
}

API void v074_creation_adjust(void *obj, int value) {
    u8 *ui = (u8 *)obj;
    if (creation.phase == PIT && ui == ui_for(creation.run) &&
        *(int *)(ui + UI_ROW) == 4) value = 0;
    old_v074_creation_adjust(obj, value);
}

/* Redirect only the four documented UI callsites, never global mode state. */
API int v074_creation_is_bat(void) {
    return creation.phase == PIT ? 0 : v074_creation_original_is_bat();
}
API int v074_creation_is_pit(void) {
    return creation.phase == PIT ? 1 : v074_creation_original_is_pit();
}

static int same_created_name(const u8 *bat, const u8 *name) {
    /* SetName's original actor field is 17 bytes including the terminator. */
    for (unsigned i = 0; i < 16; ++i) {
        if (bat[2 + i] != name[i]) return 0;
        if (!name[i]) return 1;
    }
    return 1;
}
static int valid_pitcher_choices(void) {
    return creation.pit[0] >= 0 && creation.pit[0] <= 2 &&
        creation.pit[1] >= 0 && creation.pit[1] <= 1 &&
        creation.pit[3] >= 0 && creation.pit[3] <= 2 &&
        creation.pit[4] == 0;
}

API int v074_creation_save(void *data_mgr, u8 a, u8 b) {
    int committed = 0;
    if (creation.phase == COMMIT && !creation.committed && creation.run &&
        v074_creation_mode() == 4 && valid_pitcher_choices()) {
        u8 *bat = (u8 *)v074_my_batter();
        /* Existing v0.7.3 getter realizes its two-way roster before save. */
        u8 *pit = (u8 *)v074_creation_get_pitcher(data_mgr);
        if (bat && pit && *(u16 *)bat == 1000 && *(u16 *)pit == 1100 &&
            same_created_name(bat, creation.run + RUN_NAME)) {
            unsigned style = (unsigned)creation.pit[0] * 2u +
                             (creation.pit[1] == 0);
            pit[0x22] = (u8)((pit[0x22] & 0x0f) | (style << 4));
            pit[0x21] = (u8)((pit[0x21] & 0x0f) |
                            ((unsigned)creation.pit[3] << 4));
            /* Original four selectable groups have base types 2,7,12,17. */
            u32 mask = 1u; /* Original fastball type 1. */
            for (unsigned i = 0; i < 4; ++i)
                if (creation.ball_groups & (1u << i)) mask |= 1u << (1u + 5u*i);
            *(u32 *)(pit + 0x2c) = mask;
            committed = 1;
        }
    }
    int result = v074_creation_save_original(data_mgr, a, b);
    if (committed) {
        creation.committed = 1;
        /* Original SaveObjects returns 0 unconditionally; see evidence.md. */
        (void)v074_new_career_created();
        (void)v075_set_creation_hands(creation.bat[1] == 0, creation.pit[1] == 0);
        creation.phase = SAVED;
    }
    return result;
}
