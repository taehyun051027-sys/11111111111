"""Exact v0.7.3 native hook contract for the additive v0.7.5 builder."""
from pathlib import Path

SOURCES = [str(Path(__file__).with_name(name)) for name in ("pitcher.c", "hands.c")]
HOOKS = {
    "v074_creation_init": "CBBGRaisePlayerRun::INIT_HANDLER_MSTATE_RAISE_PLAYER_SLT_TEAM()",
    "v074_creation_delete": "CBBGRaisePlayerRun::DeleteMakerUI()",
    "v074_creation_process": "CBBGRaisePlayerRun::DoProcessMakePlayerComplete()",
    "v074_creation_event": "CBBGRaisePlayerRun::EVENT_HANDLER_MSTATE_RAISE_PLAYER_SLT_TEAM()",
    "v074_creation_adjust": "CBBGCreatePlayerUI::DoChangeAdjustPlayer(int)",
    "v075_hand_prepare_pitch": "CBBGGameRun::INIT_HANDLER_GSTATE_SLT_BALL_TYPE()",
}
BINDINGS = {
    "v074_creation_ui_ctor": "_ZN18CBBGCreatePlayerUIC1Eb",
    "v074_creation_ui_dtor": "_ZN18CBBGCreatePlayerUID1Ev",
    "v074_creation_ui_start": "CBBGCreatePlayerUI::DoStartScrollPage()",
    "v074_creation_name_ready": "CBBGCreatePlayerUI::IsInputPlayerName()",
    "v074_creation_choices_ready": "CBBGRaisePlayerRun::IsCreatePlayerComplete()",
    "v074_creation_ball_show": "CBBGCreatePlayerUI::IsBallTypeShow()",
    "v074_creation_ball_ready": "CBBGCreatePlayerUI::IsPitSltBallTypeComplete()",
    "v074_creation_table_open": "CBBGCreatePlayerUI::IsOpenSltTableList()",
    "v074_creation_ball_choice": "CBBGCreateBallTypeUI::GetSltBallType(int)",
    "v074_creation_ball_toggle": "CBBGCreateBallTypeUI::AddBallTypeSelectAni(int)",
    "v074_creation_mode": "CBBGStatic::GetCurGameMode()",
    "v074_creation_original_is_bat": "CBBGStatic::IsBatMode()",
    "v074_creation_original_is_pit": "CBBGStatic::IsPitMode()",
    "v074_creation_get_pitcher": "CBBGDataMgr::GetRaisePitcher()",
    "v074_creation_save_original": "CBBGDataMgr::SaveObjects(unsigned char, unsigned char)",
    "v075_hand_mode": "CBBGStatic::GetCurGameMode()",
    "v075_hand_entry_batter": "CBBGEntryMgr::GetCurBatter()",
    "v075_hand_entry_pitcher": "CBBGEntryMgr::GetCurPitcher()",
    "v075_hand_get_load_type": "CBBGGameRun::GetLoadPlayerType()",
    "v075_hand_set_load_type": "CBBGGameRun::SetLoadPlayerType(int)",
    "v075_hand_load_players": "CBBGGameRun::LoadResPlayer()",
    "v075_hand_runtime_pitcher": "CBBGGameRun::GetPitcher() const",
    "v075_hand_pitching_style": "CBBGGameRun::GetPitchingStyle(int, int)",
    "v075_hand_set_pitching_style": "CBBGPitcher::SetPitcherStyle(ePitcherStyle)",
}

# Each site must still contain the original BL/BLX to the listed symbol.
# Patching should reject an unexpected instruction instead of guessing.
CALLSITES = {
    "arm64-v8a": [
        (0x44f0ec, "v074_creation_is_bat", "CBBGStatic::IsBatMode()", "a97a0b94"),
        (0x44db2c, "v074_creation_is_bat", "CBBGStatic::IsBatMode()", "19800b94"),
        (0x4a1108, "v074_creation_is_bat", "CBBGStatic::IsBatMode()", "a2320a94"),
        (0x4a137c, "v074_creation_is_pit", "CBBGStatic::IsPitMode()", "ad320a94"),
        (0x4a085c, "v074_creation_save", "CBBGDataMgr::SaveObjects(unsigned char, unsigned char)", "fd370a94"),
        (0x38a024, "v075_hand_load_at_bat", "CBBGGameRun::LoadResPlayer()", "5b9e0e94"),
    ],
    "armeabi-v7a": [
        (0x2ab6c8, "v074_creation_is_bat", "CBBGStatic::IsBatMode()", "c4f152ef"),
        (0x2aa5d8, "v074_creation_is_bat", "CBBGStatic::IsBatMode()", "c5f1caef"),
        (0x2e1e42, "v074_creation_is_bat", "CBBGStatic::IsBatMode()", "8ef196eb"),
        (0x2e1fcc, "v074_creation_is_pit", "CBBGStatic::IsPitMode()", "8ef120ec"),
        (0x2e1900, "v074_creation_save", "CBBGDataMgr::SaveObjects(unsigned char, unsigned char)", "8ff19eec"),
        (0x22c1fe, "v075_hand_load_at_bat", "CBBGGameRun::LoadResPlayer()", "48f268e8"),
    ],
}

def install(builder, symbols):
    """The parent builder exposes patch_call(address, target, expected=bytes)."""
    for address, alias, _original, expected in CALLSITES[builder.abi]:
        builder.patch_call(address, symbols[alias], expected=bytes.fromhex(expected))
