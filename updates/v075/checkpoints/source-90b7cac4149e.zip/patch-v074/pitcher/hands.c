/* v0.7.5: independent throwing/batting hand selection.
 * Read sidecar preferences only at original preparation states. Never override
 * IsLeft/GetStyle on demand: doing so mid-pitch can desynchronize sprites,
 * ball origin, and the physics objects' cached styles.
 */
#include "../core/api.h"
#define API V074_API
typedef v074_u8 u8;
typedef v074_u16 u16;

#if __SIZEOF_POINTER__ == 8
#define GAME_ATT_ENTRY 0x410
#define GAME_DEF_ENTRY 0x418
#else
#define GAME_ATT_ENTRY 0x2c8
#define GAME_DEF_ENTRY 0x2cc
#endif

API extern int v075_bat_hand(void);
API extern int v075_pitch_hand(void);
API extern int v075_hand_mode(void);
API extern void old_v075_hand_prepare_pitch(void *game);
API extern void *v075_hand_entry_batter(void *entry);
API extern void *v075_hand_entry_pitcher(void *entry);
API extern int v075_hand_get_load_type(void *game);
API extern void v075_hand_set_load_type(void *game, int type);
API extern void v075_hand_load_players(void *game);
API extern void *v075_hand_runtime_pitcher(void *game);
API extern int v075_hand_pitching_style(void *game, int style, int form);
API extern void v075_hand_set_pitching_style(void *pitcher, int style);

/* role 0 = BAT (RFID 1000), role 1 = PIT (RFID 1100).
 * left -1 / any invalid value means no mutation. Return 1 only if changed.
 * Bit 0x10 selects handedness within the original style family, preserving
 * skin/ACE bits, form, uniform, name, abilities, records, and roster identity.
 */
API int v075_set_player_hand(void *actor, int role, int left) {
    u8 *p = (u8 *)actor;
    if (!p || (role != 0 && role != 1) || (left != 0 && left != 1)) return 0;
    if (*(u16 *)p != (role ? 1100 : 1000) || (p[0x22] >> 4) > 5) return 0;
    u8 desired = (u8)((p[0x22] & (u8)~0x10) | ((unsigned)left << 4));
    if (desired == p[0x22]) return 0;
    p[0x22] = desired;
    return 1;
}

static void *current(void *game, int role) {
    void *entry = *(void **)((u8 *)game + (role ? GAME_DEF_ENTRY : GAME_ATT_ENTRY));
    if (!entry) return (void *)0;
    return role ? v075_hand_entry_pitcher(entry) : v075_hand_entry_batter(entry);
}

static int apply_at_boundary(void *game) {
    if (!game || !v074_backup_ready() || v075_hand_mode() != 4) return 0;
    int bat_left = v075_bat_hand();
    int pit_left = v075_pitch_hand();
    /* Current actors can be copies of the persistent roster or aliases to it.
     * Apply them first so an alias still yields a resource-reload signal. */
    int bat_changed = v075_set_player_hand(current(game, 0), 0, bat_left);
    int pit_changed = v075_set_player_hand(current(game, 1), 1, pit_left);
    bat_changed |= v075_set_player_hand(v074_my_batter(), 0, bat_left);
    pit_changed |= v075_set_player_hand(v074_my_pitcher(), 1, pit_left);
    return bat_changed | (pit_changed << 1);
}

API void v075_hand_load_at_bat(void *game) {
    int changed = apply_at_boundary(game);
    if (changed)
        v075_hand_set_load_type(game, v075_hand_get_load_type(game) | changed);
    /* The single SET_PLAYER callsite comes after both UpdatePlayer calls.
     * Its remaining original sequence is LoadResPlayer -> ResetMotion ->
     * SetPitcherStyle, with no duplicate player/statistics initialization. */
    v075_hand_load_players(game);
}

API void v075_hand_prepare_pitch(void *game) {
    int changed = apply_at_boundary(game);
    if (changed) {
        v075_hand_set_load_type(game, v075_hand_get_load_type(game) | changed);
        /* Original loader updates sprites, camera handedness and CCLPitch
         * ball-origin data. It does not write a record or start a new at-bat. */
        v075_hand_load_players(game);
        if (changed & 2) {
            u8 *p = (u8 *)current(game, 1);
            void *runtime = v075_hand_runtime_pitcher(game);
            if (p && runtime) {
                int style = v075_hand_pitching_style(game, p[0x22] >> 4, p[0x21] >> 4);
                v075_hand_set_pitching_style(runtime, style);
            }
        }
    }
    /* This entry is reached between pitches. Its original ResetMotion now
     * uses the chosen hand; a ball already in flight is never rebuilt. */
    old_v075_hand_prepare_pitch(game);
}
