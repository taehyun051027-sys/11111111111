/* Native host harness for the actual freestanding production module.
 * UI services are explicit mocks; this does not claim a rendered-device E2E.
 */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "pitcher.c"

static u8 run_mem[0x400], ui_mem[0x108], ball_mem[64];
static u8 team_mem[0x1000], before_team[0x1000], saved_team[0x1000];
static u8 *bat = team_mem + 0x200, *pit = team_mem + 0x700;
static int ball_values[4], ball_shown, table_open, mode = 4;
static int reserved, saves, sidecar_calls, deletes, ctor_bat, ctor_pit;
static int old_process_calls, old_event_calls, initialize_calls;
static int selected_bat = -1, selected_pit = 0;
static int legacy_force = 1;

int v074_backup_ready(void) { return 1; }
void *v074_my_batter(void) { return bat; }
void *v074_my_pitcher(void) { return pit; }
int v074_god_selected(void) { return 0; }
int v074_set_god_selected(int x) { return x; }
int v074_legacy_rhp_active(void) { return legacy_force; }
int v074_new_career_created(void) {
    assert(saves > sidecar_calls);
    assert(v074_creation_committing());
    ++sidecar_calls;
    legacy_force = 0;
    return 1;
}
int v075_set_creation_hands(int bat_left, int pit_left) {
    assert(saves && sidecar_calls);
    selected_bat = bat_left; selected_pit = pit_left; return 1;
}
void v074_open_patch_manager(void) {}

void old_v074_creation_init(void *run) {
    assert(run == run_mem); ++initialize_calls;
    memset(run_mem + RUN_NAME, 0, 64); run_mem[RUN_UI_CREATED] = 1;
}
void old_v074_creation_delete(void *run) { assert(run == run_mem); ++deletes; }
void old_v074_creation_adjust(void *obj, int value) {
    u8 *u = obj;
    assert(*(int *)(u + UI_ROW) >= 0 && *(int *)(u + UI_ROW) <= 4);
    table_for(u)[*(int *)(u + UI_ROW)] = value;
}
void v074_creation_ui_ctor(void *obj, int is_bat) {
    memset(obj, 0, sizeof ui_mem);
    u8 *u = obj; u[UI_IS_BAT] = is_bat;
    for (unsigned i = 0; i < 5; ++i) table_for(u)[i] = -1;
    if (is_bat) ++ctor_bat; else ++ctor_pit;
    ball_shown = table_open = 0;
    memset(ball_values, 0, sizeof ball_values);
}
void v074_creation_ui_dtor(void *obj) { assert(obj == ui_mem); }
void v074_creation_ui_start(void *obj) {
    assert(obj == ui_mem);
    assert(v074_creation_is_bat() == ((u8 *)obj)[UI_IS_BAT]);
}
int v074_creation_name_ready(void *obj) { return ((u8 *)obj)[UI_NAME] != 0; }
int v074_creation_choices_ready(void *run) {
    u8 *ui = ui_for(run);
    if (!ui) return 0;
    for (int i = 0; i < 5; ++i) if (table_for(ui)[i] < 0) return 0;
    return 1;
}
int v074_creation_ball_show(void *obj) { assert(obj == ui_mem); return ball_shown; }
int v074_creation_ball_ready(void *obj) {
    assert(obj == ui_mem);
    int count = 0;
    for (int i = 0; i < 4; ++i) count += ball_values[i] > 0;
    return count >= 3;
}
int v074_creation_table_open(void *obj) { assert(obj == ui_mem); return table_open; }
int v074_creation_ball_choice(void *obj, int group) {
    assert(obj == ball_mem && group >= 0 && group < 4); return ball_values[group];
}
void v074_creation_ball_toggle(void *obj, int group) {
    assert(obj == ball_mem && group >= 0 && group < 4);
    ball_values[group] = !ball_values[group];
}
int v074_creation_mode(void) { return mode; }
int v074_creation_original_is_bat(void) { return mode == 4; }
int v074_creation_original_is_pit(void) { return mode == 3; }
void *v074_creation_get_pitcher(void *dm) {
    (void)dm;
    /* Simulate the parent's legacy-migration getter guard. */
    if (v074_legacy_rhp_active() && !v074_creation_committing())
        v074_pitcher_make_right(pit);
    return pit;
}
int v074_creation_save_original(void *dm, u8 a, u8 b) {
    assert(dm == team_mem && a == 1 && b == 1);
    (void)v074_creation_get_pitcher(dm);
    memcpy(saved_team, team_mem, sizeof saved_team);
    ++saves;
    return 0;
}
void old_v074_creation_process(void *run) {
    ++old_process_calls;
    u8 *u = ui_for(run);
    if (!u || !v074_creation_name_ready(u) || !v074_creation_choices_ready(run)) return;
    if (v074_creation_is_bat()) { reserved = 0x49; return; }
    if (ball_shown) { if (v074_creation_ball_ready(u)) reserved = 0x49; return; }
    *(void **)(u + UI_BALL) = ball_mem; ball_shown = 1;
}
void old_v074_creation_event(void *run) {
    ++old_event_calls;
    if (*(int *)((u8 *)run + RUN_KEY) == -16) {
        if (table_open) table_open = 0;
        else if (ball_shown) ball_shown = 0;
    }
}

static void reset_case(void) {
    memset(&creation, 0, sizeof creation);
    memset(run_mem, 0, sizeof run_mem);
    for (unsigned i = 0; i < sizeof team_mem; ++i) team_mem[i] = (u8)(i * 71 + 17);
    *(u16 *)bat = 1000; *(u16 *)pit = 1100;
    memcpy(before_team, team_mem, sizeof team_mem);
    reserved = saves = sidecar_calls = deletes = ctor_bat = ctor_pit = 0;
    old_process_calls = old_event_calls = initialize_calls = 0;
    legacy_force = 1;
    mode = 4;
    v074_creation_ui_ctor(ui_mem, 1);
    *(void **)(run_mem + RUN_UI) = ui_mem;
    strcpy((char *)ui_mem + UI_NAME, "MY HERO");
    int initial[] = {2, 0, 1, 7, 5};
    for (int i = 0; i < 5; ++i) table_for(ui_mem)[i] = initial[i];
    memcpy(bat + 2, "MY HERO", 8);
    memcpy(before_team, team_mem, sizeof team_mem);
}
static void key_back(void) {
    *(int *)(run_mem + RUN_KEY) = -16;
    v074_creation_event(run_mem);
}
static void assert_team_unchanged(void) {
    assert(!memcmp(before_team, team_mem, sizeof team_mem));
}

static void test_existing_preservation(void) {
    reset_case();
    for (unsigned style_byte = 0; style_byte < 256; ++style_byte) {
        memcpy(team_mem, before_team, sizeof team_mem);
        pit[0x22] = (u8)style_byte;
        u8 expected[sizeof team_mem]; memcpy(expected, team_mem, sizeof expected);
        int change = (style_byte >> 4) <= 5 && (style_byte & 0x10);
        if (change) expected[0x700 + 0x22] &= (u8)~0x10;
        assert(v074_pitcher_make_right(pit) == !!change);
        assert(!memcmp(expected, team_mem, sizeof expected));
        assert(!v074_pitcher_make_right(pit)); /* Idempotent. */
    }
    for (unsigned id = 0; id < 65536; ++id) {
        *(u16 *)pit = id; pit[0x22] = 0x3d;
        assert(v074_pitcher_make_right(pit) == (id == 1100));
        assert(pit[0x22] == (id == 1100 ? 0x2d : 0x3d));
    }
    assert(!v074_pitcher_make_right(0));
    reset_case();
    /* Save hook is inert during resume: no creation transaction armed. */
    v074_creation_save(team_mem, 1, 1);
    assert(sidecar_calls == 0);
    assert((pit[0x22] >> 4) > 5); /* Deliberately invalid style unchanged. */
    assert_team_unchanged();
}

static void test_complete_creation(void) {
    reset_case();
    v074_creation_init(run_mem);
    assert(creation.phase == BAT);
    v074_creation_process(run_mem);
    assert(creation.phase == PIT && !ui_mem[UI_IS_BAT]);
    assert(ui_for(run_mem) == ui_mem && reserved == 0 && mode == 4);
    assert(!strcmp((char *)ui_mem + UI_NAME, "MY HERO"));
    assert(ui_mem[UI_NAME_INITIALIZED] == 1);
    assert(table_for(ui_mem)[1] == 1); /* default right hand */
    v074_creation_init(run_mem); /* State re-entry must retain the PIT page. */
    assert(creation.phase == PIT && !ui_mem[UI_IS_BAT]);
    assert(!strcmp((char *)run_mem + RUN_NAME, "MY HERO"));
    assert_team_unchanged();
    /* A left-handed future selection must survive legacy-RHP migration. */
    table_for(ui_mem)[0] = 2; table_for(ui_mem)[1] = 0;
    table_for(ui_mem)[2] = 3; table_for(ui_mem)[3] = 2;
    *(int *)(ui_mem + UI_ROW) = 4;
    v074_creation_adjust(ui_mem, 2);
    assert(table_for(ui_mem)[4] == 0);
    v074_creation_process(run_mem);
    assert(ball_shown && reserved == 0 && creation.phase == PIT);
    ball_values[0] = ball_values[1] = 1;
    v074_creation_process(run_mem);
    assert(reserved == 0); /* Original requires three groups. */
    ball_values[3] = 1;
    v074_creation_process(run_mem);
    assert(creation.phase == COMMIT && ui_mem[UI_IS_BAT] && reserved == 0x49);
    assert(table_for(ui_mem)[0] == 2 && table_for(ui_mem)[1] == 0);
    assert(table_for(ui_mem)[2] == 3 && table_for(ui_mem)[3] == 7 && table_for(ui_mem)[4] == 5);
    assert_team_unchanged();
    v074_creation_save(team_mem, 1, 1);
    assert(creation.phase == SAVED && sidecar_calls == 1 && saves == 1);
    assert(pit[0x22] >> 4 == 5 && pit[0x21] >> 4 == 2);
    assert(selected_bat == 1 && selected_pit == 1);
    assert(*(u32 *)(pit + 0x2c) == (1u | 2u | 64u | 65536u));
    assert(!memcmp(team_mem, saved_team, sizeof team_mem));
    /* The commit may touch only pitch style/form and the pitch-type mask. */
    for (unsigned i = 0; i < sizeof team_mem; ++i) {
        if (i == 0x721 || i == 0x722 || (i >= 0x72c && i < 0x730)) continue;
        assert(team_mem[i] == before_team[i]);
    }
    v074_creation_save(team_mem, 1, 1);
    assert(sidecar_calls == 1); /* One initialization per successful creation. */
    assert(pit[0x22] >> 4 == 5); /* Later saves retain explicit LHP selection. */
}

static void test_back_and_cancel(void) {
    reset_case(); v074_creation_init(run_mem); v074_creation_process(run_mem);
    table_for(ui_mem)[0] = 1; table_for(ui_mem)[1] = 0; table_for(ui_mem)[3] = 1;
    v074_creation_process(run_mem);
    ball_values[0] = ball_values[2] = ball_values[3] = 1;
    key_back(); assert(!ball_shown && creation.phase == PIT);
    table_open = 1; key_back(); assert(!table_open && creation.phase == PIT);
    key_back(); assert(creation.phase == BAT && ui_mem[UI_IS_BAT]);
    assert(table_for(ui_mem)[1] == 0 && table_for(ui_mem)[3] == 7);
    strcpy((char *)ui_mem + UI_NAME, "EDITED");
    v074_creation_process(run_mem);
    assert(creation.phase == PIT && table_for(ui_mem)[0] == 1);
    assert(table_for(ui_mem)[1] == 0 && table_for(ui_mem)[3] == 1);
    assert(!strcmp((char *)ui_mem + UI_NAME, "EDITED"));
    v074_creation_process(run_mem);
    assert(ball_shown && ball_values[0] && !ball_values[1] && ball_values[2] && ball_values[3]);
    assert(sidecar_calls == 0 && saves == 0);
    v074_creation_delete(run_mem);
    assert(creation.phase == NONE && creation.run == 0 && deletes == 1);
    assert_team_unchanged();
}

static void test_incomplete_foreign_and_failed_commit(void) {
    reset_case(); v074_creation_init(run_mem);
    ui_mem[UI_NAME] = 0; v074_creation_process(run_mem);
    assert(creation.phase == BAT && ctor_pit == 0);
    strcpy((char *)ui_mem + UI_NAME, "MY HERO");
    table_for(ui_mem)[2] = -1; v074_creation_process(run_mem);
    assert(creation.phase == BAT && ctor_pit == 0);
    assert_team_unchanged();
    reset_case(); mode = 3; v074_creation_init(run_mem);
    assert(creation.phase == NONE); v074_creation_process(run_mem);
    assert(ctor_pit == 0); assert_team_unchanged();
    reset_case(); v074_creation_init(run_mem); v074_creation_process(run_mem);
    v074_creation_process(run_mem);
    ball_values[0] = ball_values[1] = ball_values[2] = 1;
    v074_creation_process(run_mem);
    *(u16 *)pit = 1101; memcpy(before_team, team_mem, sizeof team_mem);
    v074_creation_save(team_mem, 1, 1);
    assert(sidecar_calls == 0 && creation.phase == COMMIT); assert_team_unchanged();
}

int main(void) {
    test_existing_preservation();
    test_complete_creation();
    test_back_and_cancel();
    test_incomplete_foreign_and_failed_commit();
    printf("PASS: hand bit / all 65,536 IDs / career preservation / unified creation / left choice / save ordering / back / cancel / invalid commit. BSS=%zu bytes.\n", sizeof creation);
    return 0;
}
