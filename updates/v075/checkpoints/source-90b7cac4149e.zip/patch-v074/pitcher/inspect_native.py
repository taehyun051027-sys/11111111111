"""Read-only inspection of the exact installed v0.7.3 library."""
from pathlib import Path
import io,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'recovery/apk-inspection/deps'))
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_ARCH_ARM,CS_MODE_ARM,CS_MODE_THUMB
class Native:
 def __init__(self,abi='arm64-v8a',original=False):
  self.abi=abi; self.is64=abi=='arm64-v8a'
  self.path=ROOT/'recovery/apk-inspection/lib'/abi/'libgameDSO.so'
  self.raw=self.path.read_bytes();self.elf=ELFFile(io.BytesIO(self.raw))
  syms=list(self.elf.get_section_by_name('.dynsym').iter_symbols())
  names=subprocess.run(['c++filt'],input='\n'.join(x.name for x in syms),text=True,capture_output=True,check=True).stdout.splitlines()
  self.functions={n:{'address':s['st_value']&~int(not self.is64),'size':s['st_size'],'mangled':s.name} for s,n in zip(syms,names) if s['st_value'] and s['st_info']['type']=='STT_FUNC'}
  self.labels={s['st_value']&~int(not self.is64):n for s,n in zip(syms,names) if s['st_value']}
  self.plt={}
  start=self.elf.get_section_by_name('.plt')['sh_addr']
  for i,r in enumerate(self.elf.get_section_by_name('.rela.plt' if self.is64 else '.rel.plt').iter_relocations()):
   at=start+32+i*16;self.plt[at]=names[r['r_info_sym']];self.labels[at]='[PLT] '+names[r['r_info_sym']]
  self.cs=Cs(CS_ARCH_ARM64,CS_MODE_ARM) if self.is64 else Cs(CS_ARCH_ARM,CS_MODE_THUMB)
 def read(self,a,n):
  for s in self.elf.iter_segments():
   if s['p_type']=='PT_LOAD' and s['p_vaddr']<=a and a+n<=s['p_vaddr']+s['p_filesz']:
    o=s['p_offset']+a-s['p_vaddr'];return self.raw[o:o+n]
  raise ValueError(hex(a))
 def dump(self,name):
  f=self.functions[name];return self.dump_addr(f['address'],f['size'],name)
 def dump_addr(self,a,n,name=''):
  lines=['### '+name+' '+hex(a)+' '+str(n)]
  for i in self.cs.disasm(self.read(a,n),a):
   comment=''
   if i.mnemonic in ('bl','b','b.w','blx') and i.op_str.startswith('#'):
    t=int(i.op_str[1:],16);comment=' ; '+self.labels.get(t,'')
   lines.append(f'{i.address:08x}: {i.bytes.hex():8s} {i.mnemonic:7s} {i.op_str}{comment}')
  return '\n'.join(lines)
if __name__=='__main__':
 n=Native(sys.argv[1] if len(sys.argv)>1 else 'arm64-v8a');pattern=sys.argv[2] if len(sys.argv)>2 else 'CBBGPlayerData::(SetLeft|IsLeft|GetForm|SetForm)'
 print('\n\n'.join(n.dump(x) for x in n.functions if re.search(pattern,x)))
