/* Actual v0.7.5 hand module, native host verification with engine mocks.
 * Tests guard/ordering/resource refresh without invoking any Android device.
 */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "hands.c"

static u8 world[4096], saved_world[4096], game[0x1200], runtime[128];
static u8 *roster_bat = world + 0x100, *roster_pit = world + 0x200;
static u8 *current_bat = world + 0x300, *current_pit = world + 0x400;
static int backup = 1, mode = 4, bat_hand = -1, pit_hand = -1;
static int flags, reloads, prepared, new_style, style_set;
static int timeline[32], timeline_n;
static void logstep(int x) { timeline[timeline_n++] = x; }

int v074_backup_ready(void) { return backup; }
void *v074_my_batter(void) { return roster_bat; }
void *v074_my_pitcher(void) { return roster_pit; }
int v075_bat_hand(void) { return bat_hand; }
int v075_pitch_hand(void) { return pit_hand; }
int v075_hand_mode(void) { return mode; }
void *v075_hand_entry_batter(void *entry) { assert(entry == game + 8); return current_bat; }
void *v075_hand_entry_pitcher(void *entry) { assert(entry == game + 16); return current_pit; }
int v075_hand_get_load_type(void *g) { assert(g == game); return flags; }
void v075_hand_set_load_type(void *g, int value) { assert(g == game); flags = value; logstep(1); }
void v075_hand_load_players(void *g) { assert(g == game); ++reloads; logstep(2); }
void *v075_hand_runtime_pitcher(void *g) { assert(g == game); return runtime; }
int v075_hand_pitching_style(void *g, int style, int form) {
    assert(g == game); logstep(3); return 2 * form + (style & 1);
}
void v075_hand_set_pitching_style(void *p, int style) {
    assert(p == runtime); new_style = style; ++style_set; logstep(4);
}
void old_v075_hand_prepare_pitch(void *g) { assert(g == game); ++prepared; logstep(6); }

static void reset_case(void) {
    roster_bat = world + 0x100; roster_pit = world + 0x200;
    current_bat = world + 0x300; current_pit = world + 0x400;
    for (unsigned i = 0; i < sizeof world; ++i) world[i] = (u8)(i * 39 + 11);
    *(u16 *)roster_bat = *(u16 *)current_bat = 1000;
    *(u16 *)roster_pit = *(u16 *)current_pit = 1100;
    roster_bat[0x22] = current_bat[0x22] = 0x2b; /* RHB, family 1. */
    roster_pit[0x22] = current_pit[0x22] = 0x3e; /* LHP, family 1. */
    roster_pit[0x21] = current_pit[0x21] = 0x20; /* Original form 2, SP. */
    memset(game, 0, sizeof game);
    *(void **)(game + GAME_ATT_ENTRY) = game + 8;
    *(void **)(game + GAME_DEF_ENTRY) = game + 16;
    backup = 1; mode = 4; bat_hand = pit_hand = -1;
    flags = 8; reloads = prepared = new_style = style_set = timeline_n = 0;
    memcpy(saved_world, world, sizeof world);
}
static void only_style_bits_changed(void) {
    for (unsigned i = 0; i < sizeof world; ++i) {
        int allowed = i == 0x122 || i == 0x222 || i == 0x322 || i == 0x422;
        assert((world[i] ^ saved_world[i]) == 0 ||
               (allowed && (world[i] ^ saved_world[i]) == 0x10));
    }
}
static void no_changes(void) { assert(!memcmp(world, saved_world, sizeof world)); }

static void test_setter(void) {
    reset_case();
    for (int role = 0; role < 2; ++role) for (unsigned byte = 0; byte < 256; ++byte) {
        u8 *p = role ? roster_pit : roster_bat;
        for (int left = -2; left < 4; ++left) {
            p[0x22] = byte;
            u8 copy[52]; memcpy(copy, p, 52);
            int valid = (byte >> 4) <= 5 && (left == 0 || left == 1);
            unsigned want = valid ? (byte & ~0x10u) | ((unsigned)left << 4) : byte;
            assert(v075_set_player_hand(p, role, left) == (byte != want));
            copy[0x22] = want;
            assert(!memcmp(copy, p, 52));
            assert(!v075_set_player_hand(p, role, left));
        }
    }
    assert(!v075_set_player_hand(0, 0, 0));
    assert(!v075_set_player_hand(roster_bat, 9, 0));
    for (unsigned id = 0; id < 65536; ++id) for (int role = 0; role < 2; ++role) {
        *(u16 *)roster_bat = id; roster_bat[0x22] = 0x3d;
        unsigned correct = role ? 1100 : 1000;
        assert(v075_set_player_hand(roster_bat, role, 0) == (id == correct));
        assert(roster_bat[0x22] == (id == correct ? 0x2d : 0x3d));
    }
}
static void test_independent_pre_pitch(void) {
    reset_case(); bat_hand = 1; pit_hand = 0;
    no_changes(); /* Setting a preference alone must not touch a live pitch. */
    v075_hand_prepare_pitch(game);
    assert(flags == 11 && reloads == 1 && prepared == 1 && style_set == 1);
    assert(new_style == 4 && current_pit[0x22] == 0x2e && current_bat[0x22] == 0x3b);
    assert(roster_pit[0x22] == 0x2e && roster_bat[0x22] == 0x3b);
    int order[] = {1, 2, 3, 4, 6};
    assert(timeline_n == 5 && !memcmp(timeline, order, sizeof order));
    only_style_bits_changed();
    timeline_n = 0; v075_hand_prepare_pitch(game);
    assert(reloads == 1 && style_set == 1 && prepared == 2);
    assert(timeline_n == 1 && timeline[0] == 6); /* No per-pitch redundant reload. */
    bat_hand = 0; pit_hand = 1; v075_hand_prepare_pitch(game);
    assert(current_pit[0x22] == 0x3e && current_bat[0x22] == 0x2b && new_style == 5);
    no_changes(); /* Both can be switched back independently. */
}
static void test_aliases_and_at_bat(void) {
    reset_case(); current_bat = roster_bat; current_pit = roster_pit;
    bat_hand = 1; pit_hand = 0; v075_hand_prepare_pitch(game);
    assert(flags == 11 && reloads == 1); only_style_bits_changed();
    reset_case(); bat_hand = 1; v075_hand_load_at_bat(game);
    assert(flags == 9 && reloads == 1 && prepared == 0);
    assert(timeline_n == 2 && timeline[0] == 1 && timeline[1] == 2);
    assert(roster_pit[0x22] == 0x3e && current_pit[0x22] == 0x3e);
    only_style_bits_changed();
}
static void test_guards_and_opponents(void) {
    reset_case(); bat_hand = 1; pit_hand = 0; backup = 0;
    v075_hand_prepare_pitch(game); no_changes(); assert(!reloads && prepared == 1);
    reset_case(); bat_hand = 1; pit_hand = 0; mode = 2;
    v075_hand_load_at_bat(game); no_changes(); assert(reloads == 1 && flags == 8);
    reset_case(); v075_hand_prepare_pitch(game); no_changes(); assert(!reloads);
    reset_case(); *(u16 *)current_bat = 123; *(u16 *)current_pit = 456;
    memcpy(saved_world, world, sizeof world); bat_hand = 1; pit_hand = 0;
    v075_hand_prepare_pitch(game);
    assert(current_bat[0x22] == 0x2b && current_pit[0x22] == 0x3e);
    assert(roster_bat[0x22] == 0x3b && roster_pit[0x22] == 0x2e);
    only_style_bits_changed();
}
int main(void) {
    test_setter(); test_independent_pre_pitch(); test_aliases_and_at_bat(); test_guards_and_opponents();
    puts("PASS: v0.7.5 independent hands / all RFID and style values / deferred boundaries / sprite-camera-physics ordering / alias safety / backup-mode guards / opponents unchanged.");
    return 0;
}
