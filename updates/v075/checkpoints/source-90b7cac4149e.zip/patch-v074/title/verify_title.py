"""Compile/execute the actual title C on both ABIs at nonzero load biases.

Original v0.7.3 count stubs and ChangeNickName execute natively in Unicorn.
Filesystem, UI services, and old journal operations have explicit callbacks.
This is not a substitute for Android rendering or a physical save migration.
"""
from pathlib import Path
import hashlib
import io
import json
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / "patch-v074/tools/python"))
from elftools.elf.elffile import ELFFile
from keystone import Ks, KS_ARCH_ARM, KS_ARCH_ARM64, KS_MODE_THUMB, KS_MODE_LITTLE_ENDIAN
from unicorn import Uc, UC_ARCH_ARM, UC_ARCH_ARM64, UC_MODE_THUMB, UC_MODE_ARM, UC_HOOK_CODE
from unicorn import arm_const as ar, arm64_const as a64
from module import HOOKS, BINDINGS, RAW_BINDINGS, CALLS, install

ZIG = ROOT / "patch-v074/tools/python/ziglang/zig"
HEAP, STACK, STOP = 0x60000000, 0x61000000, 0x62000000
SP = STACK + 0x80000
BAT, PIT, NPC, CONTEXT, UI = [HEAP + x for x in (0x100, 0x200, 0x300, 0x1000, 0x3000)]
MGR, TABLE, ROW = [HEAP + x for x in (0x5000, 0x6000, 0x7000)]
NAME, DESC, OLD_TEXT = [HEAP + x for x in (0x8000, 0x8100, 0x8200)]


def align(value, size=4096):
    return (value + size - 1) // size * size


class Build:
    def __init__(self, abi):
        self.abi, self.is64 = abi, abi == "arm64-v8a"
        self.original = (ROOT / "recovery/apk-inspection/lib" / abi / "libgameDSO.so").read_bytes()
        self.image = bytearray(self.original)
        self.elf = ELFFile(io.BytesIO(self.original))
        self.defs = json.loads((ROOT / "patch-v074/core" / (abi + "-symbols.json")).read_text())
        self.base = align(max(s['p_vaddr'] + s['p_memsz'] for s in self.elf.iter_segments() if s['p_type'] == 'PT_LOAD'))
        self.ks = Ks(KS_ARCH_ARM64, KS_MODE_LITTLE_ENDIAN) if self.is64 else Ks(KS_ARCH_ARM, KS_MODE_THUMB)
        self.patches = []
        self.plt = {}
        symbols = self.elf.get_section_by_name('.dynsym')
        names = {d['mangled']: n for n, d in self.defs.items()}
        section = self.elf.get_section_by_name('.plt')
        rels = self.elf.get_section_by_name('.rela.plt' if self.is64 else '.rel.plt')
        for i, rel in enumerate(rels.iter_relocations()):
            name = names.get(symbols.get_symbol(rel['r_info_sym']).name)
            if name:
                self.plt[name] = section['sh_addr'] + 32 + 16 * i
        self.bindings = {n: addresses[abi] for n, addresses in RAW_BINDINGS.items()}
        self.bindings.update({n: self.sym(s) | int(not self.is64) for n, s in BINDINGS.items()})
        self.bindings['old_v074_title_change'] = self.sym(HOOKS['v074_title_change']) | int(not self.is64)
        stub_names = ['v074_backup_ready', 'v074_my_batter', 'v074_my_pitcher', 'v074_god_selected',
                      'v074_set_god_selected', 'v074_god_name', 'v074_god_description',
                      'old_v074_title_name', 'old_v074_title_effect', 'old_v074_title_description']
        self.bindings.update({name: (self.base + 0x10000 + i * 16) | int(not self.is64)
                              for i, name in enumerate(stub_names)})
        work = HERE / 'compiled' / abi
        work.mkdir(parents=True, exist_ok=True)
        asm = ['.text']
        for name, address in self.bindings.items():
            asm += [f'.global {name}', f'.hidden {name}', f'.type {name}, %function', f'.set {name}, {address}']
        (work / 'bindings.S').write_text('\n'.join(asm) + '\n')
        script = f'''PHDRS {{ payload PT_LOAD FLAGS(5); }}
SECTIONS {{ . = {self.base};
 .payload : {{ *(.text .text.*) *(.rodata .rodata.*) }} :payload
 .data : {{ *(.data .data.*) *(.bss .bss.*) *(COMMON) }} :payload
 /DISCARD/ : {{ *(.eh_frame*) *(.ARM.exidx*) *(.ARM.extab*) *(.comment) *(.note*) }} }}'''
        (work / 'payload.ld').write_text(script)
        target = ['-target', 'aarch64-freestanding-none'] if self.is64 else ['-target', 'thumb-freestanding-eabi', '-mcpu=cortex_a7']
        cmd = [str(ZIG), 'cc', *target, '-Oz', '-fPIC', '-ffreestanding', '-fno-builtin', '-fno-lto',
               '-fno-stack-protector', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables',
               '-fvisibility=hidden', '-fno-ident', '-nostdlib', '-static', '-g',
               '-Wl,--no-undefined', '-Wl,--no-gc-sections', '-Wl,-no-pie',
               '-Wl,-e,v074_title_count', '-Wl,--build-id=none', '-Wl,-T,' + str(work / 'payload.ld'),
               str(HERE / 'title_payload.c'), str(work / 'bindings.S'), '-o', str(work / 'payload.elf')]
        result = subprocess.run(cmd, capture_output=True, text=True)
        (work / 'compiler.log').write_text(result.stdout + result.stderr)
        assert result.returncode == 0, result.stderr
        elf = ELFFile(io.BytesIO((work / 'payload.elf').read_bytes()))
        for section in elf.iter_sections():
            assert not (section['sh_type'] in ('SHT_REL', 'SHT_RELA') and section['sh_size'])
        data = elf.get_section_by_name('.data')
        assert not data or data['sh_size'] == 0, 'Title module must have no mutable global state'
        self.payload = elf.get_section_by_name('.payload').data()
        self.symbols = {s.name: s['st_value'] & ~int(not self.is64)
                        for s in elf.get_section_by_name('.symtab').iter_symbols() if s['st_value']}
        install(self, self.symbols)
        # Guard the raw calculation/mask entrypoints and all untouched v0.7.3
        # gameplay paths; only the exact seven reviewed 4-byte sites may change.
        changed = {i for i, (x, y) in enumerate(zip(self.original, self.image)) if x != y}
        allowed = set().union(*(set(range(self.offset(a), self.offset(a) + 4)) for a, *_ in CALLS[abi]))
        assert changed <= allowed
        for name in ['CBBGPlayerData::GetNickName()', 'CBBGPlayerData::SetNickName(int)',
                     'CBBGRaiseMode::IsNickName(int)', 'CBBGRaiseMode::SetNickName(int, bool)',
                     'CBBGPlayerData::GetStatus(EnumBodyPart, unsigned char, unsigned char)']:
            address, size = self.sym(name), self.defs[name]['size']
            offset = self.offset(address)
            assert self.image[offset:offset + size] == self.original[offset:offset + size], name

    def sym(self, name):
        return self.defs[name]['value'] & ~int(not self.is64)

    def offset(self, address):
        for s in self.elf.iter_segments():
            if s['p_type'] == 'PT_LOAD' and s['p_vaddr'] <= address < s['p_vaddr'] + s['p_filesz']:
                return s['p_offset'] + address - s['p_vaddr']
        raise ValueError(hex(address))

    def branch(self, source, target, link=False):
        opcode = 'bl' if link else ('b' if self.is64 else 'b.w')
        return bytes(self.ks.asm(f'{opcode} #{target}', source)[0])

    def patch(self, address, data, why, expected):
        off = self.offset(address)
        assert self.image[off:off + len(data)].hex() == expected, (self.abi, hex(address), why)
        self.image[off:off + len(data)] = data
        self.patches.append((address, why))


class Case:
    def __init__(self, build, slide):
        self.b, self.slide, self.is64 = build, slide, build.is64
        self.uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM) if self.is64 else Uc(UC_ARCH_ARM, UC_MODE_THUMB)
        self.regs = [getattr(a64, f'UC_ARM64_REG_X{i}') for i in range(31)] if self.is64 else [getattr(ar, f'UC_ARM_REG_R{i}') for i in range(13)]
        self.pc = a64.UC_ARM64_REG_PC if self.is64 else ar.UC_ARM_REG_PC
        self.sp = a64.UC_ARM64_REG_SP if self.is64 else ar.UC_ARM_REG_SP
        self.lr = a64.UC_ARM64_REG_X30 if self.is64 else ar.UC_ARM_REG_LR
        self.uc.mem_map(slide, align(build.base + 0x20000))
        for s in build.elf.iter_segments():
            if s['p_type'] == 'PT_LOAD':
                self.uc.mem_write(slide + s['p_vaddr'], bytes(build.image[s['p_offset']:s['p_offset'] + s['p_filesz']]))
        self.uc.mem_write(slide + build.base, build.payload)
        for address in [HEAP, STACK]: self.uc.mem_map(address, 0x100000)
        self.uc.mem_map(STOP, 4096)
        if not self.is64:
            self.uc.reg_write(ar.UC_ARM_REG_C1_C0_2, 0xf00000)
            self.uc.reg_write(ar.UC_ARM_REG_FPEXC, 0x40000000)
        self.uc.mem_write(HEAP, bytes((i * 11 + 5) % 256 for i in range(0x2800)))
        self.uc.mem_write(BAT + 0x23, b'\x11')
        self.uc.mem_write(PIT + 0x23, b'\x25')
        self.uc.mem_write(NPC + 0x23, b'\x05')
        self.uc.mem_write(NAME, '야구신'.encode() + b'\0')
        self.uc.mem_write(DESC, '투타겸업의 정점. 모든 능력치 ∞'.encode() + b'\0')
        self.uc.mem_write(OLD_TEXT, b'original-title\0')
        self.ready, self.bat, self.pit, self.context, self.selected = 1, BAT, PIT, CONTEXT, 1
        self.persist_ok, self.old_equipped = True, 65
        self.events, self.callbacks, self.count = [], {}, 0
        self.cb('v074_backup_ready', lambda: self.ret(self.ready))
        self.cb('v074_my_batter', lambda: self.ret(self.bat))
        self.cb('v074_my_pitcher', lambda: self.ret(self.pit))
        self.cb('v074_god_selected', lambda: self.ret(self.selected))
        self.cb('v074_set_god_selected', self.persist)
        self.cb('v074_god_name', lambda: self.ret(NAME))
        self.cb('v074_god_description', lambda: self.ret(DESC))
        self.cb('v073_title_context', lambda: self.ret(self.context))
        self.cb('v073_title_get', lambda: self.event_ret('old-get', self.old_equipped))
        self.cb('v073_title_set', lambda: self.event_ret('old-set', 0, 2))
        self.cb('v073_title_owned', self.old_owned)
        self.cb('v074_title_popup', lambda: self.event_ret('popup', 0, 4))
        for suffix in ['name', 'effect', 'description']:
            self.cb('old_v074_title_' + suffix, lambda s=suffix: self.event_ret('old-' + s, OLD_TEXT, 2))
        for name, callback in {
            'CGsSingleton<CBBGDataMgr>::GetInstPtr()': lambda: self.ret(MGR),
            'CBBGStatic::GetCurGameMode()': lambda: self.ret(4),
            'CBBGDataMgr::GetRaisePlayer(eGameMode)': lambda: self.ret(BAT),
            'CBBGDataMgr::SaveObjects(unsigned char, unsigned char)': lambda: self.event_ret('save-objects', 0, 3),
            'CBBGNickNameItemBox::SetEquipNickNameIdx(int)': lambda: self.event_ret('equip-badge', 0, 2),
            'CBBGUIListMgr::GetSltList()': lambda: self.ret(ROW),
        }.items():
            self.callbacks[slide + build.plt[name]] = callback
        # Template spelling differs by ABI; identify the exact table service.
        addresses = [a for n, a in build.plt.items() if 'GetSltUnit()' in n]
        for address in addresses: self.callbacks[slide + address] = lambda: self.ret(ROW)
        self.ptr(UI + (0x50 if self.is64 else 0x30), TABLE)
        self.uc.hook_add(UC_HOOK_CODE, self.oncode)

    def cb(self, name, callback):
        self.callbacks[(self.b.bindings[name] & ~1) + self.slide] = callback

    def ptr(self, address, value):
        self.uc.mem_write(address, struct.pack('<Q' if self.is64 else '<I', value))

    def r(self, index, value=None):
        if value is not None: self.uc.reg_write(self.regs[index], value)
        return self.uc.reg_read(self.regs[index])

    def ret(self, value):
        destination = self.uc.reg_read(self.lr)
        self.r(0, value)
        self.uc.reg_write(self.pc, destination)

    def event_ret(self, name, value, argc=1):
        self.events.append((name, *(self.r(i) for i in range(argc))))
        self.ret(value)

    def persist(self):
        value = self.r(0)
        self.events.append(('persist', value))
        if self.persist_ok: self.selected = value
        self.ret(int(self.persist_ok))

    def old_owned(self):
        raise_pointer, index = self.r(0), self.r(1) & 0xffffffff
        self.events.append(('old-owned', raise_pointer, index))
        self.ret(int(raise_pointer == CONTEXT and index < 83 and index != 8))

    def oncode(self, uc, address, size, data):
        if address == self.until: uc.emu_stop()
        elif address in self.callbacks: self.callbacks[address]()

    def run(self, address, args=(), until=STOP):
        self.until = until
        self.uc.reg_write(self.sp, SP)
        self.uc.reg_write(self.lr, STOP | int(not self.is64))
        for i, value in enumerate(args): self.r(i, value & (0xffffffffffffffff if self.is64 else 0xffffffff))
        try:
            self.uc.emu_start(address | int(not self.is64), 0, count=20000)
        except Exception as exc:
            raise AssertionError((self.b.abi, hex(self.uc.reg_read(self.pc)),
                                  hex(self.uc.reg_read(self.lr)), self.events[-8:])) from exc
        assert self.uc.reg_read(self.pc) == until, (self.b.abi, hex(self.uc.reg_read(self.pc)))
        assert self.uc.reg_read(self.sp) == SP, 'stack imbalance'
        self.count += 1
        return self.r(0)

    def call(self, name, *args):
        return self.run(self.slide + self.b.symbols[name], args)

    def text(self, address):
        return bytes(self.uc.mem_read(address, 256)).split(b'\0', 1)[0].decode()

    def memory(self):
        return hashlib.sha256(self.uc.mem_read(HEAP, 0x2800)).hexdigest()


def verify(build, slide):
    c = Case(build, slide)
    before = c.memory()
    assert c.call('v074_title_count') == 84
    c.ready = 0
    assert c.call('v074_title_count') == 83
    assert c.call('v074_title_owned', CONTEXT, 83) == 0
    c.ready = 1
    c.context = 0
    assert c.call('v074_title_count') == 55
    assert c.call('v074_title_owned', CONTEXT, 83) == 0
    c.context = CONTEXT
    assert c.call('v074_title_owned', CONTEXT, 83) == 1
    assert c.call('v074_title_owned', CONTEXT + 4, 83) == 0
    c.pit = 0
    assert c.call('v074_title_owned', CONTEXT, 83) == 0
    c.pit = PIT
    # Original 83 entries stay at the same indices and argument ABI.
    for index in range(83):
        assert c.call('v074_title_owned', CONTEXT, index) == int(index != 8)
        for role in [0, 1]:
            for suffix in ['name', 'effect', 'description']:
                assert c.call('v074_title_' + suffix, index, role) == OLD_TEXT
                assert c.events[-1] == ('old-' + suffix, index, role)
    assert c.text(c.call('v074_title_name', 83, 1)) == '야구신'
    assert c.text(c.call('v074_title_effect', 83, 0)) == '모든 능력치 ∞'
    assert '모든 능력치 ∞' in c.text(c.call('v074_title_description', 83, 1))
    # Patched name/description API is consulted, not a stale embedded title.
    c.uc.mem_write(NAME, '새 야구신'.encode() + b'\0')
    assert c.text(c.call('v074_title_name', 83, 1)) == '새 야구신'
    for actor in [BAT, PIT]:
        assert c.call('v074_title_get', actor) == 83
        assert c.call('v074_title_display_get', actor) == 83
    assert c.call('v074_title_display_get', NPC) == 5
    c.selected = 0
    assert c.call('v074_title_get', BAT) == 65
    assert c.call('v074_title_display_get', BAT) == 17
    assert c.call('v074_title_display_get', PIT) == 37
    c.events.clear()
    c.call('v074_title_set', BAT, 83)
    assert c.selected == 1 and c.events == [('persist', 1)]
    c.events.clear()
    c.call('v074_title_set', PIT, 83)
    c.call('v074_title_set', NPC, 83)
    assert c.events == [], 'ID83 escaped to an original setter'
    c.call('v074_title_set', BAT, 65)
    assert c.selected == 0 and c.events[-1] == ('old-set', BAT, 65)
    c.selected, c.persist_ok = 1, False
    c.events.clear()
    c.call('v074_title_set', BAT, 17)
    assert c.selected == 1 and not any(e[0] == 'old-set' for e in c.events)
    assert c.memory() == before, 'An existing save/player/mask/record byte changed'

    # Run original native ChangeNickName with the new sidecar preflight and
    # actual patched inner call. Native UI updates, old table/journal services
    # and SaveObjects remain behind explicit external service callbacks.
    selection, equipped, redraw = (0x5c, 0x64, 0x68) if build.is64 else (0x38, 0x40, 0x44)
    c.uc.mem_write(UI + selection, struct.pack('<I', 83))
    c.uc.mem_write(UI + equipped, struct.pack('<I', 17))
    c.selected = 0
    c.events.clear()
    c.call('v074_title_change', UI)
    assert struct.unpack('<I', c.uc.mem_read(UI + equipped, 4))[0] == 17
    assert [e[0] for e in c.events] == ['persist', 'popup']
    assert c.events[-1][2:] == (2, 1, 1)
    c.persist_ok = True
    c.events.clear()
    c.call('v074_title_change', UI)
    assert c.selected == 1
    assert struct.unpack('<I', c.uc.mem_read(UI + equipped, 4))[0] == 83
    assert c.uc.mem_read(UI + redraw, 1) == b'\x01'
    assert sum(e[0] == 'persist' for e in c.events) == 1
    assert sum(e[0] == 'save-objects' for e in c.events) == 1
    assert not any(e[0] == 'old-set' for e in c.events)
    assert c.memory() == before

    c.uc.mem_write(UI + selection, struct.pack('<I', 65))
    c.events.clear()
    c.call('v074_title_change', UI)
    assert c.selected == 0
    assert ('old-set', BAT, 65) in c.events
    assert c.events.index(('persist', 0)) < c.events.index(('old-set', BAT, 65))
    assert struct.unpack('<I', c.uc.mem_read(UI + equipped, 4))[0] == 65
    assert c.memory() == before

    # The actual Player Info callsite routes through the display-only getter.
    display_site = 0x4cd68c if build.is64 else 0x2fffd8
    for actor, selected, expected in [(BAT, 1, 83), (PIT, 1, 83),
                                     (NPC, 1, 5), (BAT, 0, 17), (PIT, 0, 37)]:
        c.selected = selected
        assert c.run(slide + display_site, (actor,), until=slide + display_site + 4) == expected

    # Execute v0.7.3's register-preserving table-count stub through the real
    # patched BL, and inspect the original loop's count register/stack slot.
    source, resume = (0x4feec4, 0x4feec8) if build.is64 else (0x321480, 0x321484)
    for ready, expected in [(1, 84), (0, 83)]:
        c.ready = ready
        c.run(slide + source, until=slide + resume)
        actual = c.r(8) if build.is64 else struct.unpack('<I', c.uc.mem_read(SP + 0x128, 4))[0]
        assert actual == expected
    assert c.memory() == before
    return {'load_bias': hex(slide), 'native_calls': c.count,
            'original_83_title_indices_preserved': True,
            'native_change_and_count_stub_executed': True,
            'existing_memory_sha256_unchanged': before,
            'sidecar_failure_keeps_ui_and_selection': True,
            'android_rendering_verified': False}


def main():
    report = {'scope': 'instruction-level title verification; original UI/services at documented boundaries',
              'abis': []}
    for abi in ['arm64-v8a', 'armeabi-v7a']:
        build = Build(abi)
        entry = {'abi': abi, 'payload_bytes': len(build.payload), 'callsite_patches': len(build.patches),
                 'input_sha256': hashlib.sha256(build.original).hexdigest(),
                 'results': [verify(build, bias) for bias in [0x10000000, 0x38000000]]}
        report['abis'].append(entry)
    (HERE / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
