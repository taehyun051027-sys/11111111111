# 야구신 title addition

This module adds a distinct 84th selectable title, **야구신**, to the shipped
v0.7.3 two-way player's title inventory. Internal symbol names use `v074`; the
parent package owns the released version name.

## Save preservation contract

- The existing 83 UI titles keep their indices, ownership logic, and role
  mapping. ID 83 is the new **UI-only** title. It is never stored in the original
  one-byte `CBBGPlayerData` nickname or either original 55-bit nickname mask.
- Parent APIs resolve the existing batter and pitcher without creating or
  mirroring either player. The new title becomes owned only after the parent
  reports a successful save backup and both owned role objects exist.
- Selection is an independent parent-managed sidecar flag. The parent grants
  default selection after a successful first migration. The old raw title
  selections remain available beneath that flag.
- Selecting any old owned title clears the sidecar flag and calls the same
  v0.7.3 setter with the same original UI ID. Selecting 야구신 calls no original
  nickname setter. If sidecar persistence fails, the original UI change does
  not run; the game displays its usual popup with an explanatory message.
- No team edits, stats, progress, achievements, old title masks, saved record
  order, or compatibility ability fields are rewritten by this module.

## Original UI and ability behavior

The new row uses the original title list, item renderer, owned/equipped badge,
confirmation, font formatting, and description panel. The two Player Info
views use a display-only getter so both roles show the selected title. Ordinary
players and other title selections keep their original Player Info fallback.
The original calculation-facing `GetNickName` and `SetNickName` stay intact;
the rest-menu recovery bonus and table-indexed stat formulas never receive 83.

The displayed effect is `모든 능력치 ∞`. Both owned roles already receive the
v0.7.3 tagged unbounded ability semantics and existing safe gameplay adapters;
this addition preserves those implementations. It does not replace infinity
with a larger serialized number. Name and detailed description come from the
parent's validated patch APIs, `v074_god_name` and `v074_god_description`.

No image/font assets are replaced. Text follows the existing Korean system
font pipeline. The new title is present in the selectable title inventory;
the separate historical 110-cell BAT/PIT title record-book grid is unchanged.

## Integration

Compile `title_payload.c` with the parent payload. `module.py` supplies four
original entry hooks, six v0.7.3 raw function bindings, two symbolic bindings,
and seven byte-checked callsite patches for each ABI. Addresses are locked to
the libraries in the authoritative recovered v0.7.3 APK. Every Thumb raw
binding includes its function-state bit.

Run:

```sh
python patch-v074/title/verify_title.py
```

`verification.json` records the compiled native verification. It covers both
ABIs at two nonzero load biases, every original title's forwarding arguments,
ownership gates, selection/failure paths, raw memory preservation, actual
original `ChangeNickName` execution, actual Player Info callsites, and the
original register-preserving table-count stubs. Service callbacks represent
filesystem/UI/journal boundaries explicitly. No real Android save or device
is accessed by these tests. Android glyph pixels, final APK integration,
parent sidecar persistence, and physical device gameplay need independent
verification; this report does not claim those were performed.
