"""Add one new title to the exact v0.7.3 title inventory, preserving its journal.

The original calculation-facing GetNickName/SetNickName and all bitmask/save
functions are intentionally absent from HOOKS. Every callsite below is checked
against the shipped v0.7.3 bytes before any patch is accepted.
"""

HOOKS = {
    "v074_title_name": "CBBGStatic::GetRaiseNickName(int, bool)",
    "v074_title_effect": "CBBGStatic::GetRaiseNickNameEffect(int, bool)",
    "v074_title_description": "CBBGStatic::GetRaiseNickNameTxt(int, bool)",
    "v074_title_change": "CBBGNickNameUI::ChangeNickName()",
}

BINDINGS = {
    "v074_title_raw_get": "CBBGPlayerData::GetNickName()",
    "v074_title_popup": "CBBGStatic::CreateDefaultCCPopup(char const*, int, int, bool)",
}

# These v0.7.3 helpers have no ELF symbols. Addresses include Thumb state bit.
RAW_BINDINGS = {
    "v073_title_context": {"arm64-v8a": 0x9D5A60, "armeabi-v7a": 0x6EA1D9},
    "v073_title_count": {"arm64-v8a": 0x9D5CB4, "armeabi-v7a": 0x6EA38D},
    "v073_title_owned": {"arm64-v8a": 0x9D5CD4, "armeabi-v7a": 0x6EA39F},
    "v073_title_get": {"arm64-v8a": 0x9D5E98, "armeabi-v7a": 0x6EA4C5},
    "v073_title_set": {"arm64-v8a": 0x9D5F48, "armeabi-v7a": 0x6EA54B},
}

# (address, expected current bytes, exported payload function, purpose)
CALLS = {
    "arm64-v8a": [
        (0x9DFC4C, "1ad8ff97", "v074_title_count", "title table count 83 -> 84 after backup"),
        (0x4FE6AC, "fb5d1394", "v074_title_get", "title chooser equipped ID"),
        (0x4FEF40, "655b1394", "v074_title_owned", "title table ownership pass 1"),
        (0x4FEFAC, "4a5b1394", "v074_title_owned", "title table ownership pass 2"),
        (0x4FFC44, "24581394", "v074_title_owned", "title equip confirmation ownership"),
        (0x4FFBB0, "e6581394", "v074_title_set", "title equip selection sidecar"),
        (0x4CD68C, "59930994", "v074_title_display_get", "Player Info title display only"),
    ],
    "armeabi-v7a": [
        (0x6EEE98, "fbf778fa", "v074_title_count", "title table count 83 -> 84 after backup"),
        (0x320F16, "c9f3d5fa", "v074_title_get", "title chooser equipped ID"),
        (0x3214CC, "c8f367ff", "v074_title_owned", "title table ownership pass 1"),
        (0x321514, "c8f343ff", "v074_title_owned", "title table ownership pass 2"),
        (0x321CE6, "c8f35afb", "v074_title_owned", "title equip confirmation ownership"),
        (0x321C88, "c8f35ffc", "v074_title_set", "title equip selection sidecar"),
        (0x2FFFD8, "74f1aaee", "v074_title_display_get", "Player Info title display only"),
    ],
}


def install(builder, symbols):
    for address, expected, symbol, purpose in CALLS[builder.abi]:
        code = builder.branch(address, symbols[symbol] & ~1, True)
        assert len(code) == 4, (builder.abi, hex(address), symbol)
        builder.patch(address, code, "야구신: " + purpose, expected)

