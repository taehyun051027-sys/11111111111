/* Additive v0.7.4 title. No original nickname ID or save layout is changed.
 *
 * v0.7.3 exposes 83 UI titles, backed by two original 55-bit role masks and
 * its existing title journal. 83 is a UI-only ID here, NEVER a serialized
 * CBBGPlayerData nickname. All ability math continues through v0.7.3's
 * unbounded-player implementation; finite compatibility fields stay intact.
 */
#include "../core/api.h"

enum { V074_GOD_TITLE = 83, V074_OLD_TITLE_COUNT = 83 };

V074_API extern void *v073_title_context(void);
V074_API extern int v073_title_count(void);
V074_API extern int v073_title_owned(void *, int);
V074_API extern int v073_title_get(void *);
V074_API extern void v073_title_set(void *, int);
V074_API extern int v074_title_raw_get(void *);
V074_API extern const char *old_v074_title_name(int, v074_u8);
V074_API extern const char *old_v074_title_effect(int, v074_u8);
V074_API extern const char *old_v074_title_description(int, v074_u8);
V074_API extern void old_v074_title_change(void *);
V074_API extern void v074_title_popup(const char *, int, int, v074_u8);
V074_API extern const char *v074_god_name(void);
V074_API extern const char *v074_god_description(void);

/* Plain char arrays use PC-relative addressing and need no ASLR relocation. */
static const char god_effect[] = "모든 능력치 ∞";
static const char save_error[] = "칭호를 저장하지 못했습니다. 다시 시도해 주세요.";

/* All getters below are read-only. In particular, do not call the original
 * GetRaisePitcher() here: its v0.7.3 hook can mirror/create player state. */
static int god_owned(void) {
    return v074_backup_ready() && v074_my_batter() && v074_my_pitcher();
}

static int god_player(void *player) {
    if (!player || !god_owned()) return 0;
    return player == v074_my_batter() || player == v074_my_pitcher();
}

static void *god_title_context(void) {
    return god_owned() ? v073_title_context() : (void *)0;
}

/* The original table loop uses this runtime bound; its 83 original entries,
 * ordering, frames, ownership and equipped badges are retained verbatim. */
V074_API int v074_title_count(void) {
    int count = v073_title_count();
    return count == V074_OLD_TITLE_COUNT && god_owned() ? count + 1 : count;
}

V074_API int v074_title_owned(void *raise, int id) {
    if (id == V074_GOD_TITLE) {
        void *context = god_title_context();
        return context && raise == context;
    }
    return v073_title_owned(raise, id);
}

/* Existing v0.7.3 list wrappers route 55..82 to the PIT title texts. They
 * eventually call these original static methods, so only ID83 is intercepted. */
V074_API const char *v074_title_name(int id, v074_u8 is_batter) {
    return id == V074_GOD_TITLE ? v074_god_name() : old_v074_title_name(id, is_batter);
}

V074_API const char *v074_title_effect(int id, v074_u8 is_batter) {
    return id == V074_GOD_TITLE ? god_effect : old_v074_title_effect(id, is_batter);
}

V074_API const char *v074_title_description(int id, v074_u8 is_batter) {
    return id == V074_GOD_TITLE ? v074_god_description() : old_v074_title_description(id, is_batter);
}

/* Title chooser getter retains v0.7.3's virtual PIT ID translation. */
V074_API int v074_title_get(void *player) {
    if (god_player(player) && v074_god_selected()) return V074_GOD_TITLE;
    return v073_title_get(player);
}

/* Player Info's display-only getter must retain its original raw-ID fallback.
 * Do not replace CBBGPlayerData::GetNickName() globally: other callers use it
 * for table indexing and recovery/stat bonuses rather than text display. */
V074_API int v074_title_display_get(void *player) {
    if (god_player(player) && v074_god_selected()) return V074_GOD_TITLE;
    return v074_title_raw_get(player);
}

static int persist_selection(int selected) {
    return !!v074_god_selected() == !!selected || v074_set_god_selected(selected);
}

V074_API void v074_title_set(void *player, int id) {
    void *context;
    if (id == V074_GOD_TITLE) {
        if (god_player(player) && god_title_context()) persist_selection(1);
        return;  /* ID83 can never escape into an original serialized byte. */
    }
    context = god_player(player) ? god_title_context() : (void *)0;
    if (context && id >= 0 && id < V074_OLD_TITLE_COUNT &&
        v073_title_owned(context, id) && !persist_selection(0)) return;
    v073_title_set(player, id);
}

/* Original ChangeNickName updates its visible equipped row BEFORE invoking
 * its setter. Commit our sidecar flag first; on failure do not run any of the
 * old UI/save changes, and display the existing game's normal error popup. */
V074_API void v074_title_change(void *ui) {
    void *context;
    int id;
    if (!ui) return;
#if __SIZEOF_POINTER__ == 8
    id = *(int *)((v074_u8 *)ui + 0x5c);
#else
    id = *(int *)((v074_u8 *)ui + 0x38);
#endif
    context = god_title_context();
    if (id == V074_GOD_TITLE) {
        if (!context) return;
        if (!persist_selection(1)) {
            v074_title_popup(save_error, 2, 1, 1);
            return;
        }
    } else if (context && id >= 0 && id < V074_OLD_TITLE_COUNT &&
               v073_title_owned(context, id)) {
        if (!persist_selection(0)) {
            v074_title_popup(save_error, 2, 1, 1);
            return;
        }
    }
    old_v074_title_change(ui);
}
