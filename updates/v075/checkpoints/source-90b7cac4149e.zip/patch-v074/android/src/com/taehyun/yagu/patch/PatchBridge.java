package com.taehyun.yagu.patch;

/** Kept public: native code resolves these exact JNI signatures. */
public final class PatchBridge {
    private PatchBridge(){}
    public static int getFlags(){return PatchRuntime.ready()?PatchRuntime.state.flags():0;}
    public static int getHands(){return PatchRuntime.ready()?PatchRuntime.state.hands():10;}
    public static int setHands(int bat,int pit){synchronized(PatchRuntime.operationLock){try{PatchRuntime.requireReady();PatchRuntime.state.hands(bat,pit);return 1;}catch(Exception e){return 0;}}}
    public static int setGodSelected(int value){synchronized(PatchRuntime.operationLock){try{PatchRuntime.requireReady();PatchRuntime.state.god(value!=0);return 1;}catch(Exception e){return 0;}}}
    public static int newCareerCreated(){synchronized(PatchRuntime.operationLock){try{PatchRuntime.requireReady();PatchRuntime.state.newCareer();return 1;}catch(Exception e){return 0;}}}
    public static String getText(int index){return PatchRuntime.ready()?PatchRuntime.state.text(index):"";}
    public static void openManager(){PatchRuntime.openManager();}
}
