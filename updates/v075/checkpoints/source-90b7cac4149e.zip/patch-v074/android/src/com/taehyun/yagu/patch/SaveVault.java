package com.taehyun.yagu.patch;

import java.io.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** File-only core. Android UI and transport never write a save directly.
 * The caller must quiesce the game before write/restore; optimistic hashes
 * detect intervening changes but cannot lock an unrelated native file writer.
 */
final class SaveVault {
    static final String PACKAGE = "com.taehyun.yagu";
    static final String STATE = "yagu_v075_state.json";
    static final long MAX_FILE = 16L * 1024 * 1024;
    static final long MAX_TOTAL = 96L * 1024 * 1024;
    static final int MAX_FILES = 128;
    final File files, vault, snapshots, drafts;
    private boolean ready;
    private String initialBackup;
    private Fault fault;
    interface Fault { void point(String name) throws IOException; }
    static final class Entry {
        final String name, sha256; final long size;
        Entry(String n, long s, String h) { name=n; size=s; sha256=h; }
    }
    SaveVault(File files, File vault) throws IOException {
        this.files=files.getCanonicalFile(); this.vault=vault.getCanonicalFile();
        snapshots=new File(this.vault,"snapshots"); drafts=new File(this.vault,"drafts");
        mkdir(this.files); mkdir(this.vault); mkdir(snapshots); mkdir(drafts);
    }
    void fault(Fault f) { fault=f; }
    private void point(String n) throws IOException { if(fault!=null) fault.point(n); }
    static boolean isGameFile(String n) {
        return n!=null && n.length()<100 &&
            (n.matches("bb2013[a-zA-Z0-9_.-]*\\.sav") || n.matches("yagu_awards_v1_[ab]\\.sav"));
    }
    static boolean allowed(String n) { return isGameFile(n) || STATE.equals(n); }
    static void mkdir(File f) throws IOException { if(!f.isDirectory() && !f.mkdirs()) throw new IOException("DIRECTORY_UNAVAILABLE"); }
    private static File child(File parent, String name) throws IOException {
        if(!allowed(name)) throw new IOException("FILE_NOT_ALLOWED");
        File f=new File(parent,name);
        if(!f.getCanonicalFile().getParentFile().equals(parent.getCanonicalFile())) throw new IOException("UNSAFE_PATH");
        return f;
    }
    static String hex(byte[] b) { StringBuilder s=new StringBuilder(b.length*2); for(byte v:b)s.append(String.format(Locale.US,"%02x",v&255)); return s.toString(); }
    static MessageDigest digest() { try{return MessageDigest.getInstance("SHA-256");}catch(Exception e){throw new IllegalStateException(e);} }
    static String sha(File f) throws IOException {
        MessageDigest d=digest(); try(InputStream in=new FileInputStream(f)){ byte[] b=new byte[16384]; int n; while((n=in.read(b))!=-1)d.update(b,0,n); } return hex(d.digest());
    }
    static byte[] readBounded(InputStream in, long limit) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] b=new byte[8192]; int n; long count=0;
        while((n=in.read(b))!=-1){count+=n;if(count>limit)throw new IOException("SIZE_LIMIT");out.write(b,0,n);}return out.toByteArray();
    }
    static void atomic(File file, byte[] data) throws IOException {
        mkdir(file.getParentFile()); File temp=new File(file.getParentFile(),".new-"+UUID.randomUUID());
        try { try(FileOutputStream out=new FileOutputStream(temp)){out.write(data);out.getFD().sync();}
            if(!temp.renameTo(file))throw new IOException("ATOMIC_RENAME_FAILED");
        } finally { if(temp.exists()&&!temp.delete())temp.deleteOnExit(); }
    }
    static void copy(File from, File to) throws IOException {
        try(InputStream in=new FileInputStream(from)){atomic(to,readBounded(in,MAX_FILE));}
    }
    static Properties properties(File f) throws IOException {
        Properties p=new Properties(); try(InputStream in=new FileInputStream(f)){p.load(new ByteArrayInputStream(readBounded(in,1024*1024)));}return p;
    }
    static void properties(File f, Properties p) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();p.store(b,"Yagu v075 verified save archive");atomic(f,b.toByteArray());
    }
    synchronized List<Entry> entries() throws IOException { return scan(files); }
    private static List<Entry> scan(File dir) throws IOException {
        File[] all=dir.listFiles();if(all==null)throw new IOException("SAVE_DIRECTORY_UNREADABLE");
        List<Entry> result=new ArrayList<>();long total=0;
        for(File f:all)if(allowed(f.getName())){
            child(dir,f.getName());if(!f.isFile())throw new IOException("UNSAFE_SAVE_ENTRY");
            if(f.length()>MAX_FILE)throw new IOException("SIZE_LIMIT"); total+=f.length();
            result.add(new Entry(f.getName(),f.length(),sha(f)));
        }
        if(result.size()>MAX_FILES||total>MAX_TOTAL)throw new IOException("SIZE_LIMIT");
        Collections.sort(result,new Comparator<Entry>(){public int compare(Entry a,Entry b){return a.name.compareTo(b.name);}});
        return result;
    }
    synchronized String stateHash() throws IOException {return stateHash(entries());}
    static String stateHash(List<Entry> list) throws IOException {
        MessageDigest d=digest();for(Entry e:list)d.update((e.name+"\0"+e.size+"\0"+e.sha256+"\n").getBytes("UTF-8"));return hex(d.digest());
    }
    private void requireReady() throws IOException {
        if(!ready)throw new IOException("VAULT_NOT_READY");
    }
    synchronized boolean ready(){return ready;}
    synchronized String initialBackup(){return initialBackup;}
    synchronized List<Entry> initialEntries() throws IOException {
        if(!ready)throw new IOException("BACKUP_NOT_READY");return verify(backupDir(initialBackup));
    }
    synchronized void initialize() throws IOException {
        ready=false; recover();
        File marker=new File(vault,"initial.properties");
        if(marker.exists()){
            Properties p=properties(marker);initialBackup=p.getProperty("backup_id");
            File dir=backupDir(initialBackup); verify(dir);
            if(!sha(new File(dir,"manifest.properties")).equals(p.getProperty("manifest_sha256")))throw new IOException("INITIAL_BACKUP_CHANGED");
        } else {
            initialBackup=snapshot("pre-v075");
            Properties p=new Properties();p.setProperty("backup_id",initialBackup);
            p.setProperty("manifest_sha256",sha(new File(backupDir(initialBackup),"manifest.properties")));properties(marker,p);
        }
        ready=true;
    }
    private static Properties manifest(List<Entry> list,String label) throws IOException {
        Properties p=new Properties();p.setProperty("format","yagu-save-v1");p.setProperty("package",PACKAGE);p.setProperty("engine","v075");
        p.setProperty("created_ms",Long.toString(System.currentTimeMillis()));p.setProperty("label",label);p.setProperty("count",Integer.toString(list.size()));
        p.setProperty("state_sha256",stateHash(list));
        for(int i=0;i<list.size();i++){Entry e=list.get(i);String k="file."+i+".";p.setProperty(k+"name",e.name);p.setProperty(k+"size",Long.toString(e.size));p.setProperty(k+"sha256",e.sha256);}
        return p;
    }
    private static List<Entry> verify(File dir) throws IOException {
        Properties p=properties(new File(dir,"manifest.properties"));
        if(!"yagu-save-v1".equals(p.getProperty("format"))||!PACKAGE.equals(p.getProperty("package"))||!"v075".equals(p.getProperty("engine")))throw new IOException("INCOMPATIBLE_ARCHIVE");
        int n;try{n=Integer.parseInt(p.getProperty("count"));}catch(Exception e){throw new IOException("BAD_MANIFEST");}
        if(n<0||n>MAX_FILES)throw new IOException("SIZE_LIMIT");
        List<Entry> list=new ArrayList<>();Set<String> names=new HashSet<>();long total=0;
        for(int i=0;i<n;i++){
            String k="file."+i+".",name=p.getProperty(k+"name"),hash=p.getProperty(k+"sha256");long size;
            try{size=Long.parseLong(p.getProperty(k+"size"));}catch(Exception e){throw new IOException("BAD_MANIFEST");}
            File f=child(dir,name);
            if(!names.add(name)||size<0||size>MAX_FILE||hash==null||!hash.matches("[0-9a-f]{64}"))throw new IOException("BAD_MANIFEST");
            total+=size;if(total>MAX_TOTAL||!f.isFile()||f.length()!=size||!sha(f).equals(hash))throw new IOException("ARCHIVE_HASH_MISMATCH");
            list.add(new Entry(name,size,hash));
        }
        Collections.sort(list,new Comparator<Entry>(){public int compare(Entry a,Entry b){return a.name.compareTo(b.name);}});
        if(!stateHash(list).equals(p.getProperty("state_sha256")))throw new IOException("ARCHIVE_STATE_MISMATCH");
        for(File f:dir.listFiles())if(!"manifest.properties".equals(f.getName())&&!names.contains(f.getName()))throw new IOException("UNLISTED_ARCHIVE_ENTRY");
        return list;
    }
    synchronized String snapshot(String label) throws IOException {
        if(label==null||label.length()>120)throw new IOException("INVALID_LABEL");
        List<Entry> before=entries();String beforeHash=stateHash(before);
        String id="backup-"+System.currentTimeMillis()+"-"+UUID.randomUUID().toString();
        File stage=new File(vault,"stage-"+UUID.randomUUID());mkdir(stage);
        try {
            for(Entry e:before)copy(child(files,e.name),child(stage,e.name));
            properties(new File(stage,"manifest.properties"),manifest(before,label));verify(stage);
            if(!stateHash().equals(beforeHash))throw new IOException("SAVE_CHANGED_DURING_BACKUP");
            point("backup-before-commit");
            if(!stateHash().equals(beforeHash))throw new IOException("SAVE_CHANGED_DURING_BACKUP");
            File dest=new File(snapshots,id);
            if(!stage.renameTo(dest))throw new IOException("BACKUP_COMMIT_FAILED");return id;
        }finally{if(stage.exists())removeTree(stage);}
    }
    File backupDir(String id) throws IOException {
        if(id==null||!id.matches("backup-[0-9]+-[a-f0-9-]{36}"))throw new IOException("INVALID_BACKUP_ID");
        File d=new File(snapshots,id);if(!d.getCanonicalFile().getParentFile().equals(snapshots))throw new IOException("UNSAFE_PATH");return d;
    }
    synchronized List<Properties> backups() throws IOException {
        List<Properties> list=new ArrayList<>();File[] dirs=snapshots.listFiles();if(dirs==null)throw new IOException("BACKUP_DIRECTORY_UNREADABLE");
        Arrays.sort(dirs,Collections.reverseOrder());for(File d:dirs)if(d.isDirectory()){
            try {verify(d);Properties p=properties(new File(d,"manifest.properties"));p.setProperty("backup_id",d.getName());list.add(p);}catch(IOException ignored){}
        }return list;
    }
    synchronized void exportArchive(String id,OutputStream destination) throws IOException {
        File dir=backupDir(id);List<Entry> es=verify(dir);
        ZipOutputStream zip=new ZipOutputStream(destination);
        List<String> names=new ArrayList<>();names.add("manifest.properties");for(Entry e:es)names.add(e.name);
        for(String n:names){zip.putNextEntry(new ZipEntry(n));try(InputStream in=new FileInputStream(new File(dir,n))){byte[] b=new byte[16384];int count;while((count=in.read(b))!=-1)zip.write(b,0,count);}zip.closeEntry();}
        zip.finish();zip.flush();
    }
    synchronized String importArchive(InputStream source) throws IOException {
        File stage=new File(vault,"import-"+UUID.randomUUID());mkdir(stage);long total=0;Set<String> seen=new HashSet<>();
        try {
            ZipInputStream zip=new ZipInputStream(source);ZipEntry z;
            while((z=zip.getNextEntry())!=null){String n=z.getName();
                if(z.isDirectory()||(!"manifest.properties".equals(n)&&!allowed(n))||!seen.add(n)||seen.size()>MAX_FILES+1)throw new IOException("UNSAFE_ARCHIVE_ENTRY");
                File f="manifest.properties".equals(n)?new File(stage,n):child(stage,n);
                byte[] data=readBounded(zip,"manifest.properties".equals(n)?1024*1024:MAX_FILE);total+=data.length;
                if(total>MAX_TOTAL+1024*1024)throw new IOException("SIZE_LIMIT");atomic(f,data);zip.closeEntry();
            }
            verify(stage);String id="backup-"+System.currentTimeMillis()+"-"+UUID.randomUUID();
            if(!stage.renameTo(new File(snapshots,id)))throw new IOException("IMPORT_COMMIT_FAILED");return id;
        } finally {if(stage.exists())removeTree(stage);}
    }
    private void replaceState(File source) throws IOException {
        List<Entry> es=verify(source);Set<String> names=new HashSet<>();for(Entry e:es)names.add(e.name);
        for(Entry e:es){copy(child(source,e.name),child(files,e.name));point("restore-file-"+e.name);}
        for(Entry e:entries())if(!names.contains(e.name)&&!child(files,e.name).delete())throw new IOException("RESTORE_REMOVE_FAILED");
        if(!stateHash().equals(stateHash(es)))throw new IOException("RESTORE_VERIFY_FAILED");
    }
    synchronized void recover() throws IOException {
        File journal=new File(vault,"transaction.properties");if(!journal.exists())return;
        Properties p=properties(journal);File old=backupDir(p.getProperty("backup_id"));
        Fault saved=fault;fault=null;try{replaceState(old);}finally{fault=saved;}
        if(!journal.delete())throw new IOException("RECOVERY_JOURNAL_FAILED");
    }
    private String transact(File stage, String expected, String label) throws IOException {
        requireReady();
        if(expected==null||!stateHash().equals(expected))throw new IOException("STALE_STATE");verify(stage);
        String backup=snapshot(label);point("transaction-backup-created");
        if(!stateHash().equals(expected))throw new IOException("STALE_STATE");
        Properties p=new Properties();p.setProperty("backup_id",backup);
        File journal=new File(vault,"transaction.properties");properties(journal,p);
        try {point("transaction-started");replaceState(stage);point("transaction-complete");if(!journal.delete())throw new IOException("JOURNAL_REMOVE_FAILED");return backup;}
        catch(IOException e){try{recover();}catch(IOException recovery){ready=false;throw new IOException("RECOVERY_REQUIRED",recovery);}throw e;}
    }
    synchronized String restore(String id,String expected) throws IOException {requireReady();File dir=backupDir(id);verify(dir);return transact(dir,expected,"before-restore");}
    synchronized String write(String name,byte[] bytes,String expectedOld,String expectedNew) throws IOException {
        requireReady();
        if(!isGameFile(name)||bytes.length>MAX_FILE)throw new IOException("FILE_NOT_ALLOWED");File dest=child(files,name);
        if(!dest.isFile()||!sha(dest).equals(expectedOld))throw new IOException("STALE_FILE");
        if(!hex(digest().digest(bytes)).equals(expectedNew))throw new IOException("PREVIEW_HASH_MISMATCH");
        point("write-before-state-check");String expected=stateHash();File stage=new File(vault,"write-"+UUID.randomUUID());mkdir(stage);
        try{
            for(Entry e:entries())copy(child(files,e.name),child(stage,e.name));
            File staged=child(stage,name);
            if(!staged.isFile()||!sha(staged).equals(expectedOld))throw new IOException("STALE_FILE");
            atomic(staged,bytes);
            properties(new File(stage,"manifest.properties"),manifest(scan(stage),"file-edit"));verify(stage);
            return transact(stage,expected,"before-file-edit");
        }finally{removeTree(stage);}
    }
    synchronized byte[] read(String name,long offset,int count) throws IOException {
        if(!isGameFile(name)||offset<0||count<0||count>4096)throw new IOException("INVALID_READ");
        try(RandomAccessFile f=new RandomAccessFile(child(files,name),"r")){if(offset>f.length())throw new IOException("INVALID_OFFSET");f.seek(offset);byte[] b=new byte[(int)Math.min(count,f.length()-offset)];f.readFully(b);return b;}
    }
    static void removeTree(File f) throws IOException {
        if(f.isDirectory()){File[] children=f.listFiles();if(children==null)throw new IOException("CLEANUP_FAILED");for(File c:children)removeTree(c);}
        if(f.exists()&&!f.delete())throw new IOException("CLEANUP_FAILED");
    }
}
