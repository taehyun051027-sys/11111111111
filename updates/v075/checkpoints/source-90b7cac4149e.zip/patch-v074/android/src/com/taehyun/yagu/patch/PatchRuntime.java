package com.taehyun.yagu.patch;

import android.app.*;
import android.content.*;
import android.os.*;
import org.json.*;
import java.io.*;
import java.lang.ref.WeakReference;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import javax.net.ssl.HttpsURLConnection;

final class PatchRuntime {
    static Context context;
    static SaveVault vault;
    static PatchState state;
    static volatile boolean initialized,gameLoaded;
    static volatile String failure;
    static final Object operationLock=new Object();
    static WeakReference<Activity> current=new WeakReference<>(null);
    static final ExecutorService worker=Executors.newSingleThreadExecutor();
    static final String GAME="com.gamevil.bb2013.global.SkeletonLauncher";
    static final String PATCH_URL="https://raw.githubusercontent.com/taehyun051027-sys/11111111111/main/patches/v075/latest.yagupatch";
    static synchronized void initialize(Context c){
        if(initialized)return;initialized=true;context=c.getApplicationContext();
        if(context instanceof Application)((Application)context).registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks(){
            public void onActivityCreated(Activity a,Bundle b){if(GAME.equals(a.getClass().getName()))gameLoaded=true;}
            public void onActivityStarted(Activity a){}
            public void onActivityResumed(Activity a){current=new WeakReference<>(a);}
            public void onActivityPaused(Activity a){}
            public void onActivityStopped(Activity a){}
            public void onActivitySaveInstanceState(Activity a,Bundle b){}
            public void onActivityDestroyed(Activity a){if(current.get()==a)current.clear();}
        });
        try{
            File base=Build.VERSION.SDK_INT>=21?context.getNoBackupFilesDir():context.getDir("yagu_no_backup",0);
            vault=new SaveVault(context.getFilesDir(),new File(base,"yagu-v075"));vault.initialize();
            try(InputStream cert=context.getAssets().open("yagu-v075-public.der")){state=new PatchState(context.getFilesDir(),vault.vault,cert);}
        }catch(Exception e){failure=code(e);}
    }
    static boolean ready(){return failure==null&&vault!=null&&vault.ready()&&state!=null;}
    static String access(){return !ready()?"backup_failed":gameLoaded?"running":"ready";}
    static void requireFiles() throws IOException {
        if(!ready())throw new IOException("BACKUP_FAILED");if(gameLoaded)throw new IOException("NEEDS_SAVE_AND_RESTART");
    }
    static void requireReady() throws IOException {if(!ready())throw new IOException("BACKUP_FAILED");}
    static String backup(String label) throws Exception {synchronized(operationLock){requireFiles();return vault.snapshot(label);}}
    static String restore(String id,String expected) throws Exception {
        synchronized(operationLock){
            requireFiles();File stateFile=new File(vault.backupDir(id),SaveVault.STATE);
            if(stateFile.isFile())try(InputStream in=new FileInputStream(stateFile)){
                PatchState.validateState(new JSONObject(new String(SaveVault.readBounded(in,16384),"UTF-8")));
            }
            String backup=vault.restore(id,expected);state.reload();return backup;
        }
    }
    static String code(Throwable e){String s=e.getMessage();return s!=null&&s.matches("[A-Z][A-Z0-9_]{2,80}")?s:"OPERATION_FAILED";}
    static JSONObject error(Throwable e){JSONObject r=new JSONObject(),err=new JSONObject();try{err.put("code",code(e));r.put("ok",false);r.put("error",err);}catch(JSONException ignored){}return r;}
    static JSONObject ok(){JSONObject r=new JSONObject();try{r.put("ok",true);r.put("protocol",1);}catch(JSONException ignored){}return r;}
    static JSONObject status() throws Exception {
        JSONObject o=ok();o.put("versionName",PatchState.ENGINE);o.put("versionCode",PatchState.VERSION);o.put("package",SaveVault.PACKAGE);o.put("game_running",gameLoaded);o.put("save_access",access());
        o.put("current_state_sha256",!gameLoaded&&ready()?vault.stateHash():JSONObject.NULL);
        if(ready()){
            List<SaveVault.Entry> baseline=new ArrayList<>();for(SaveVault.Entry e:vault.initialEntries())if(SaveVault.isGameFile(e.name))baseline.add(e);
            JSONObject first=new JSONObject();first.put("file_count",baseline.size());first.put("game_state_sha256",SaveVault.stateHash(baseline));o.put("initial_backup",first);
            if(!gameLoaded){List<SaveVault.Entry> now=new ArrayList<>();for(SaveVault.Entry e:vault.entries())if(SaveVault.isGameFile(e.name))now.add(e);
                o.put("game_save_state_sha256",SaveVault.stateHash(now));o.put("initial_save_bytes_unchanged",SaveVault.stateHash(baseline).equals(SaveVault.stateHash(now)));
            }
        }
        o.put("capabilities",new JSONArray(new String[]{"save_export","save_restore","verified_file_edit","signed_data_patch","independent_hands"}));
        if(failure!=null)o.put("failure",failure);return o;
    }
    static byte[] downloadPatch() throws Exception {
        HttpsURLConnection c=(HttpsURLConnection)new URL(PATCH_URL).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(10000);c.setInstanceFollowRedirects(false);c.setUseCaches(false);
        try {int status=c.getResponseCode();if(status==404)throw new IOException("PATCH_NOT_PUBLISHED");if(status!=200)throw new IOException("PATCH_SERVER_UNAVAILABLE");
            try(InputStream in=c.getInputStream()){return SaveVault.readBounded(in,65536);}
        }finally{c.disconnect();}
    }
    static void openManager(){
        if(context==null)return;new Handler(Looper.getMainLooper()).post(new Runnable(){public void run(){Activity a=current.get();Intent i=new Intent(context,PatchManagerActivity.class);if(a!=null&&!a.isFinishing())a.startActivity(i);else{i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);context.startActivity(i);}}});
    }
}
