package com.taehyun.yagu.patch;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.util.*;

/** Separate maintenance screen; the original game and editor remain intact. */
public final class PatchManagerActivity extends Activity {
    private static final int EXPORT=41,IMPORT=42,PATCH=43;
    private LinearLayout body;
    private TextView status;
    private RadioGroup bat,pit;
    private String exportId;
    private boolean busy;
    private final Handler main=new Handler(Looper.getMainLooper());
    interface Work { String run() throws Exception; }
    @Override public void onCreate(Bundle b){super.onCreate(b);PatchRuntime.initialize(this);render();consent(getIntent());}
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);consent(i);}
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+0.5f);}
    private TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.WHITE);t.setPadding(0,dp(6),0,dp(6));body.addView(t);return t;}
    private void heading(String s){TextView t=text(s,20);t.setTypeface(null,1);}
    private Button button(String label,View.OnClickListener action){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(42,48,56));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(48));p.setMargins(0,dp(5),0,dp(5));body.addView(b,p);b.setOnClickListener(action);return b;}
    private void render(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(Color.rgb(15,19,25));body=new LinearLayout(this);body.setOrientation(1);body.setPadding(dp(24),dp(14),dp(24),dp(24));scroll.addView(body);setContentView(scroll);
        heading("야구 · v075");text("보직  야구신     |     양투양타",17);
        status=text(PatchRuntime.ready()?"기존 선수와 시즌은 그대로 유지됩니다.":"보호 사본을 준비하지 못했습니다. 게임 시작과 저장 파일 변경을 막았습니다. 오류: "+PatchRuntime.failure,15);
        button(PatchRuntime.gameLoaded?"게임으로 돌아가기":"기존 선수·시즌 계속하기",new View.OnClickListener(){public void onClick(View v){if(busy)return;if(PatchRuntime.gameLoaded)finish();else GateActivity.openGame(PatchManagerActivity.this);}}).setEnabled(PatchRuntime.ready());
        if(!PatchRuntime.ready())return;
        heading("양투양타 설정");text("타격 손과 투구 손을 각각 선택하세요. 경기 중 변경하면 다음 타석·투구 준비부터 적용됩니다.",14);
        int hands=PatchRuntime.state.hands();bat=handGroup("타격",hands&3);pit=handGroup("투구",(hands>>2)&3);
        button("투구·타격 손 적용",new View.OnClickListener(){public void onClick(View v){final int b=bat.getCheckedRadioButtonId()-100,p=pit.getCheckedRadioButtonId()-200;work(new Work(){public String run() throws Exception{PatchRuntime.state.hands(b,p);return PatchRuntime.gameLoaded?"선택을 저장했습니다. 다음 타석·투구 준비부터 적용됩니다.":"양투양타 선택을 저장했습니다.";}});}});
        button("야구신 칭호 장착",new View.OnClickListener(){public void onClick(View v){work(new Work(){public String run() throws Exception{PatchRuntime.state.god(true);return "야구신 칭호를 장착했습니다. 선수 정보 화면을 다시 열어 확인하세요.";}});}});
        heading("작은 패치");text("게임 안에서 지원하는 설정·문구 패치를 확인하고 적용합니다. 새 경기 기능을 추가하는 엔진 변경은 별도 버전이 필요할 수 있습니다.",14);
        button("패치 확인",new View.OnClickListener(){public void onClick(View v){if(busy)return;busy=true;status.setText("패치를 확인하고 있습니다…");PatchRuntime.worker.execute(new Runnable(){public void run(){try{final byte[] bytes=PatchRuntime.downloadPatch();final JSONObject p=PatchRuntime.state.inspect(bytes);main.post(new Runnable(){public void run(){busy=false;previewPatch(bytes,p);}});}catch(final Exception e){failed(e);}}});}});
        button("패치 파일 열기",new View.OnClickListener(){public void onClick(View v){pick(PATCH,"*/*");}});
        heading("세이브 보호");
        text(PatchRuntime.gameLoaded?"저장 파일은 관리 모드에서만 다룹니다. 게임으로 돌아가 저장을 마친 후 아래 버튼으로 앱을 닫고 다시 열어 주세요.":"게임이 아직 실행되지 않은 관리 모드입니다. 백업·내보내기·복원을 사용할 수 있습니다.",14);
        if(PatchRuntime.gameLoaded){
            button("저장 완료 후 앱 닫기 · 다음 실행은 관리 모드",new View.OnClickListener(){public void onClick(View v){new AlertDialog.Builder(PatchManagerActivity.this).setTitle("게임에서 저장을 마쳤나요?").setMessage("저장하지 않은 플레이는 보관할 수 없습니다. 저장을 마쳤다면 앱을 닫은 뒤 야구 아이콘을 다시 누르세요. 기존 기록을 불러오기 전에 관리 화면이 열립니다.")
                .setNegativeButton("게임으로 돌아가기",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int n){finish();}})
                .setPositiveButton("저장 완료 · 앱 닫기",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int n){
                    if(!getSharedPreferences("yagu-v075-launch",0).edit().putBoolean("maintenance",true).commit()){status.setText("관리 모드 설정을 저장하지 못했습니다.");return;}
                    BridgeSessions.revokeAll();finishAffinity();main.postDelayed(new Runnable(){public void run(){android.os.Process.killProcess(android.os.Process.myPid());}},200);
                }}).show();}});
        }
        button("현재 세이브 백업",new View.OnClickListener(){public void onClick(View v){work(new Work(){public String run() throws Exception{PatchRuntime.requireFiles();PatchRuntime.vault.snapshot("in-game manual backup");return "현재 세이브를 별도 사본으로 보관하고 파일 해시를 확인했습니다.";}});}}).setEnabled(!PatchRuntime.gameLoaded);
        button("세이브 파일로 내보내기",new View.OnClickListener(){public void onClick(View v){if(busy)return;busy=true;PatchRuntime.worker.execute(new Runnable(){public void run(){try{final String id=PatchRuntime.backup("before-export");main.post(new Runnable(){public void run(){busy=false;exportId=id;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/zip");i.putExtra(Intent.EXTRA_TITLE,"yagu-v075-save-"+System.currentTimeMillis()+".zip");startActivityForResult(i,EXPORT);}});}catch(Exception e){failed(e);}}});}}).setEnabled(!PatchRuntime.gameLoaded);
        button("저장된 보호 사본 복원",new View.OnClickListener(){public void onClick(View v){chooseBackup();}}).setEnabled(!PatchRuntime.gameLoaded);
        button("내보낸 세이브 파일 가져오기",new View.OnClickListener(){public void onClick(View v){pick(IMPORT,"*/*");}}).setEnabled(!PatchRuntime.gameLoaded);
        heading("맥 연결");text("맥에서 연결을 요청하면 이 화면에서 범위를 확인한 뒤 10분간 허용할 수 있습니다. 연결 승인은 세이브 변경을 자동 실행하지 않습니다.",14);
        button("맥 연결 승인 모두 해제",new View.OnClickListener(){public void onClick(View v){BridgeSessions.revokeAll();status.setText("모든 맥 연결 승인을 해제했습니다.");}});
    }
    private RadioGroup handGroup(String name,int selected){
        text(name+" 손",16);RadioGroup group=new RadioGroup(this);group.setOrientation(LinearLayout.HORIZONTAL);int base="타격".equals(name)?100:200;String[] labels={"오른손","왼손","현재 유지"};
        for(int i=0;i<3;i++){RadioButton b=new RadioButton(this);b.setId(base+i);b.setText(labels[i]);b.setTextColor(Color.WHITE);group.addView(b,new RadioGroup.LayoutParams(0,dp(46),1));}
        group.check(base+(selected<3?selected:2));body.addView(group);return group;
    }
    private void work(final Work w){if(busy)return;busy=true;status.setText("처리하고 있습니다…");PatchRuntime.worker.execute(new Runnable(){public void run(){try{final String result;synchronized(PatchRuntime.operationLock){result=w.run();}main.post(new Runnable(){public void run(){busy=false;if(!isFinishing())status.setText(result);}});}catch(Exception e){failed(e);}}});}
    private void failed(final Exception e){main.post(new Runnable(){public void run(){busy=false;if(!isFinishing())status.setText(message(PatchRuntime.code(e)));}});}
    private String message(String code){
        if("NEEDS_SAVE_AND_RESTART".equals(code))return "게임에서 저장을 마친 뒤 관리 모드로 다시 열어 주세요.";
        if("PATCH_NOT_PUBLISHED".equals(code))return "아직 게시된 작은 패치가 없습니다. 현재 게임은 계속 사용할 수 있습니다.";
        if("PATCH_NOT_NEWER".equals(code))return "이미 적용한 패치입니다.";
        if("STALE_STATE".equals(code)||"STALE_FILE".equals(code))return "확인한 뒤 저장 상태가 바뀌었습니다. 목록을 새로 열어 다시 확인하세요.";
        return "완료하지 못했습니다. 기존 기록을 확인 없이 덮어쓰지 않습니다. 오류: "+code;
    }
    private void pick(int request,String mime){if(busy)return;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);startActivityForResult(i,request);}
    private void consent(Intent intent){
        final String id=intent.getStringExtra("request_id");if(id==null)return;final BridgeSessions.Session s=BridgeSessions.pending(id);
        if(s==null){status.setText("이 연결 요청은 없거나 만료됐습니다.");return;}
        String scope=s.scopes.contains("write")?"저장 파일 조회·백업 및 검토한 변경 적용, 투구·타격 손 설정":"저장 파일 조회·백업과 패치 확인";
        new AlertDialog.Builder(this).setTitle("이 맥의 연결을 허용할까요?").setMessage(s.label+"\n\n허용 범위: "+scope+"\n유효 시간: 10분\n파일 변경은 게임을 실행하지 않은 관리 모드에서만 가능합니다.")
            .setNegativeButton("거절",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){try{BridgeSessions.approve(id,false);}catch(Exception ignored){}}})
            .setPositiveButton("10분간 허용",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int which){try{BridgeSessions.approve(id,true);status.setText("맥 연결을 10분간 허용했습니다.");}catch(Exception e){status.setText(message(PatchRuntime.code(e)));}}}).show();
    }
    private void previewPatch(final byte[] bytes,final JSONObject p){
        if(isFinishing())return;status.setText("패치 서명과 호환 버전을 확인했습니다.");new AlertDialog.Builder(this).setTitle("패치 "+p.optInt("revision"))
            .setMessage(p.optString("summary")+"\n\n선수·시즌 기록은 그대로 두고 지원하는 설정을 적용합니다. 문구 변경은 게임을 저장한 후 앱을 다시 열면 반영됩니다.")
            .setNegativeButton("취소",null).setPositiveButton("패치 적용",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int n){work(new Work(){public String run() throws Exception{PatchRuntime.requireReady();PatchRuntime.state.apply(bytes);return "패치를 적용했습니다. 변경된 문구는 저장 후 앱을 다시 열면 표시됩니다.";}});}}).show();
    }
    private void chooseBackup(){
        if(busy)return;busy=true;PatchRuntime.worker.execute(new Runnable(){public void run(){try{
            PatchRuntime.requireFiles();final List<Properties> list=PatchRuntime.vault.backups();final String hash=PatchRuntime.vault.stateHash();
            final String[] labels=new String[list.size()];for(int i=0;i<labels.length;i++){Properties p=list.get(i);labels[i]=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date(Long.parseLong(p.getProperty("created_ms"))))+" · "+p.getProperty("count")+"개 파일";}
            main.post(new Runnable(){public void run(){busy=false;if(isFinishing())return;if(labels.length==0){status.setText("보관한 사본이 없습니다.");return;}new AlertDialog.Builder(PatchManagerActivity.this).setTitle("복원할 보호 사본").setItems(labels,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int n){confirmRestore(list.get(n).getProperty("backup_id"),hash,labels[n]);}}).setNegativeButton("취소",null).show();}});
        }catch(Exception e){failed(e);}}});
    }
    private void confirmRestore(final String id,final String hash,String label){
        new AlertDialog.Builder(this).setTitle("이 사본으로 복원할까요?").setMessage(label+"\n\n현재 진행도도 먼저 별도 백업합니다. 복원하면 선택한 사본 시점의 선수·구단·시즌으로 돌아갑니다.").setNegativeButton("취소",null)
            .setPositiveButton("현재 진행 백업 후 복원",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int n){work(new Work(){public String run() throws Exception{PatchRuntime.restore(id,hash);return "복원을 완료했습니다. 현재 진행의 이전 사본도 보관했습니다. 게임 계속하기로 확인하세요.";}});}}).show();
    }
    @Override protected void onActivityResult(final int request,int result,final Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;final Uri uri=data.getData();
        if(request==EXPORT){final String id=exportId;if(id==null){status.setText("내보낼 사본을 다시 선택하세요.");return;}work(new Work(){public String run() throws Exception{PatchRuntime.requireFiles();try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("EXPORT_FAILED");PatchRuntime.vault.exportArchive(id,out);}return "세이브 파일을 내보냈습니다.";}});}
        else if(request==IMPORT){if(busy)return;busy=true;PatchRuntime.worker.execute(new Runnable(){public void run(){try{PatchRuntime.requireFiles();final String id;try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("IMPORT_FAILED");id=PatchRuntime.vault.importArchive(in);}final String hash=PatchRuntime.vault.stateHash();main.post(new Runnable(){public void run(){busy=false;confirmRestore(id,hash,"가져온 세이브 파일 · 무결성 확인 완료");}});}catch(Exception e){failed(e);}}});}
        else if(request==PATCH){if(busy)return;busy=true;PatchRuntime.worker.execute(new Runnable(){public void run(){try{final byte[] bytes;try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)throw new IOException("PATCH_READ_FAILED");bytes=SaveVault.readBounded(in,65536);}final JSONObject p=PatchRuntime.state.inspect(bytes);main.post(new Runnable(){public void run(){busy=false;previewPatch(bytes,p);}});}catch(Exception e){failed(e);}}});}
    }
}
