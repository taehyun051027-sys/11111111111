package com.taehyun.yagu.patch;

import android.content.*;
import android.database.Cursor;
import android.net.Uri;
import android.os.*;
import android.util.Base64;
import org.json.*;
import java.io.*;
import java.util.*;

/** DUMP permission in manifest plus device-side, short-lived explicit consent. */
public final class PatchProvider extends ContentProvider {
    private static final class Draft {
        String id,name,owner,oldHash,preview;long size,written;File file;
    }
    private final Map<String,Draft> drafts=new HashMap<>();
    @Override public boolean onCreate(){PatchRuntime.initialize(getContext());return true;}
    @Override public synchronized Bundle call(String method,String argument,Bundle extras){
        JSONObject result;
        try {
            if(Binder.getCallingUid()!=android.os.Process.myUid() && getContext().checkCallingPermission("android.permission.DUMP")!=android.content.pm.PackageManager.PERMISSION_GRANTED)throw new IOException("CALLER_NOT_ALLOWED");
            if(!"request".equals(method)||extras==null)throw new IOException("INVALID_METHOD");
            String encoded=extras.getString("payload");if(encoded==null||encoded.length()>24000)throw new IOException("REQUEST_TOO_LARGE");
            byte[] raw=Base64.decode(encoded,Base64.DEFAULT);if(raw.length>16384)throw new IOException("REQUEST_TOO_LARGE");
            JSONObject request=new JSONObject(new String(raw,"UTF-8"));if(request.getInt("protocol")!=1)throw new IOException("PROTOCOL_MISMATCH");
            synchronized(PatchRuntime.operationLock){result=handle(request,Binder.getCallingUid());}
        }catch(Exception e){result=PatchRuntime.error(e);}
        Bundle b=new Bundle();try{b.putString("result_b64",Base64.encodeToString(result.toString().getBytes("UTF-8"),Base64.NO_WRAP));}catch(Exception ignored){}return b;
    }
    private JSONObject handle(JSONObject r,int uid) throws Exception {
        String a=r.getString("action");
        if("status".equals(a))return PatchRuntime.status();
        if("request_session".equals(a))return BridgeSessions.request(r,uid);
        if("session_status".equals(a))return BridgeSessions.status(r.getString("request_id"),uid);
        boolean write=a.startsWith("write_")||"restore".equals(a)||"set_hands".equals(a);
        BridgeSessions.Session s=BridgeSessions.authorize(r,uid,write?"write":"read");PatchRuntime.requireReady();
        JSONObject o=PatchRuntime.ok();
        if("set_hands".equals(a)){
            PatchRuntime.state.hands(PatchState.handValue(r.getString("bat")),PatchState.handValue(r.getString("pit")));
            o.put("queued",PatchRuntime.gameLoaded);o.put("applies_at","next_at_bat_or_pitch");o.put("bat",r.getString("bat"));o.put("pit",r.getString("pit"));return o;
        }
        if("patch_info".equals(a)){o.put("patch",PatchRuntime.state.info());return o;}
        if("check".equals(a)){byte[] patch=PatchRuntime.downloadPatch();o.put("patch",PatchRuntime.state.inspect(patch));o.put("applied",false);return o;}
        PatchRuntime.requireFiles();SaveVault v=PatchRuntime.vault;
        if("list_files".equals(a)){
            JSONArray files=new JSONArray();for(SaveVault.Entry e:v.entries())if(SaveVault.isGameFile(e.name)){JSONObject f=new JSONObject();f.put("name",e.name);f.put("size",e.size);f.put("sha256",e.sha256);files.put(f);}
            o.put("files",files);o.put("current_state_sha256",v.stateHash());return o;
        }
        if("read_file".equals(a)){o.put("data_b64",Base64.encodeToString(v.read(r.getString("name"),r.getLong("offset"),r.getInt("count")),Base64.NO_WRAP));return o;}
        if("backup".equals(a)){String id=v.snapshot(r.optString("label","Mac backup"));o.put("backup_id",id);o.put("current_state_sha256",v.stateHash());return o;}
        if("list_backups".equals(a)){
            JSONArray backups=new JSONArray();for(Properties p:v.backups()){JSONObject b=new JSONObject();for(String k:new String[]{"backup_id","created_ms","label","state_sha256","count"})b.put(k,p.getProperty(k));backups.put(b);}
            o.put("backups",backups);o.put("current_state_sha256",v.stateHash());return o;
        }
        if("restore".equals(a)){String backup=PatchRuntime.restore(r.getString("backup_id"),r.getString("expected_state_sha256"));o.put("backup_id",backup);o.put("current_state_sha256",v.stateHash());return o;}
        if("write_begin".equals(a)){
            if(drafts.size()>=4)throw new IOException("DRAFT_LIMIT");String name=r.getString("name"),expected=r.getString("expected_sha256");long size=r.getLong("size");
            if(!SaveVault.isGameFile(name)||size<0||size>SaveVault.MAX_FILE)throw new IOException("FILE_NOT_ALLOWED");
            File current=new File(v.files,name);if(!current.isFile()||!SaveVault.sha(current).equals(expected))throw new IOException("STALE_FILE");
            Draft d=new Draft();d.id=UUID.randomUUID().toString();d.name=name;d.owner=s.id;d.oldHash=expected;d.size=size;d.file=new File(v.drafts,d.id+".draft");
            if(!d.file.createNewFile())throw new IOException("DRAFT_CREATE_FAILED");drafts.put(d.id,d);o.put("draft_id",d.id);return o;
        }
        if(a.startsWith("write_")){
            Draft d=drafts.get(r.getString("draft_id"));if(d==null||!d.owner.equals(s.id))throw new IOException("DRAFT_NOT_FOUND");
            if("write_abort".equals(a)){if(!d.file.delete())throw new IOException("DRAFT_DELETE_FAILED");drafts.remove(d.id);o.put("aborted",true);return o;}
            if("write_chunk".equals(a)){
                if(d.preview!=null)throw new IOException("DRAFT_ALREADY_PREVIEWED");byte[] data=Base64.decode(r.getString("data_b64"),Base64.DEFAULT);
                if(data.length<1||data.length>4096||r.getLong("offset")!=d.written||d.written+data.length>d.size)throw new IOException("INVALID_CHUNK");
                try(FileOutputStream out=new FileOutputStream(d.file,true)){out.write(data);out.getFD().sync();}d.written+=data.length;o.put("written",d.written);return o;
            }
            if(d.written!=d.size||d.file.length()!=d.size)throw new IOException("DRAFT_INCOMPLETE");
            File old=new File(v.files,d.name);if(!old.isFile()||!SaveVault.sha(old).equals(d.oldHash))throw new IOException("STALE_FILE");
            if("write_preview".equals(a)){
                d.preview=SaveVault.sha(d.file);long changes=0;JSONArray offsets=new JSONArray();
                try(InputStream before=new BufferedInputStream(new FileInputStream(old));InputStream after=new BufferedInputStream(new FileInputStream(d.file))){
                    long at=0;int x,y;while(true){x=before.read();y=after.read();if(x<0&&y<0)break;if(x!=y){changes++;if(offsets.length()<16)offsets.put(at);}at++;}
                }
                o.put("draft_id",d.id);o.put("before_sha256",d.oldHash);o.put("after_sha256",d.preview);o.put("size",d.size);o.put("changed_bytes",changes);o.put("first_changed_offsets",offsets);o.put("committed",false);return o;
            }
            if("write_commit".equals(a)){
                if(d.preview==null||!d.preview.equals(r.getString("expected_sha256")))throw new IOException("PREVIEW_REQUIRED");
                byte[] content;try(InputStream in=new FileInputStream(d.file)){content=SaveVault.readBounded(in,SaveVault.MAX_FILE);}
                String backup=v.write(d.name,content,d.oldHash,d.preview);o.put("backup_id",backup);o.put("newsha",SaveVault.sha(new File(v.files,d.name)));o.put("current_state_sha256",v.stateHash());
                if(d.file.delete())drafts.remove(d.id);return o;
            }
        }
        throw new IOException("UNKNOWN_ACTION");
    }
    @Override public Cursor query(Uri u,String[] p,String s,String[] a,String o){throw new UnsupportedOperationException();}
    @Override public String getType(Uri u){return null;}
    @Override public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
    @Override public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
    @Override public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
