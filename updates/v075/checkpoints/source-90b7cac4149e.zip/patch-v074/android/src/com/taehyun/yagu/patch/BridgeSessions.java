package com.taehyun.yagu.patch;

import android.util.Base64;
import org.json.*;
import java.io.IOException;
import java.security.SecureRandom;
import java.util.*;

final class BridgeSessions {
    static final class Session {
        String id,label,token,status="pending";long expires;int uid;
        final Set<String> scopes=new HashSet<>();
    }
    private static final Map<String,Session> sessions=new HashMap<>();
    static synchronized JSONObject request(JSONObject request,int uid) throws Exception {
        prune();String id=request.getString("request_id");
        if(!id.matches("[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}"))throw new IOException("INVALID_REQUEST_ID");
        if(sessions.containsKey(id))throw new IOException("REQUEST_EXISTS");if(sessions.size()>=8)throw new IOException("SESSION_LIMIT");
        Session s=new Session();s.id=id;s.uid=uid;s.label=PatchState.bounded(request.getString("client_label"),120);
        JSONArray scopes=request.getJSONArray("scopes");if(scopes.length()<1||scopes.length()>2)throw new IOException("INVALID_SCOPE");
        for(int i=0;i<scopes.length();i++){String v=scopes.getString(i);if(!"read".equals(v)&&!"write".equals(v))throw new IOException("INVALID_SCOPE");s.scopes.add(v);}
        s.expires=System.currentTimeMillis()+10*60*1000;sessions.put(id,s);return describe(s,false);
    }
    private static void prune(){long now=System.currentTimeMillis();Iterator<Session> it=sessions.values().iterator();while(it.hasNext())if(it.next().expires<=now)it.remove();}
    static synchronized Session pending(String id){prune();Session s=sessions.get(id);return s!=null&&"pending".equals(s.status)?s:null;}
    static synchronized void approve(String id,boolean approve) throws Exception {
        Session s=pending(id);if(s==null)throw new IOException("SESSION_EXPIRED");
        if(!approve){s.status="denied";return;}
        byte[] b=new byte[32];new SecureRandom().nextBytes(b);s.token=Base64.encodeToString(b,Base64.URL_SAFE|Base64.NO_WRAP|Base64.NO_PADDING);
        s.status="approved";s.expires=System.currentTimeMillis()+10*60*1000;
    }
    private static JSONObject describe(Session s,boolean token) throws Exception {
        JSONObject o=PatchRuntime.ok();o.put("request_id",s.id);o.put("status",s.status);o.put("expiry",s.expires);o.put("scopes",new JSONArray(s.scopes));
        if(token&&"approved".equals(s.status))o.put("token",s.token);return o;
    }
    static synchronized JSONObject status(String id,int uid) throws Exception {
        prune();Session s=sessions.get(id);if(s==null||s.uid!=uid)throw new IOException("SESSION_EXPIRED");return describe(s,true);
    }
    static synchronized Session authorize(JSONObject r,int uid,String scope) throws Exception {
        prune();String t=r.optString("token","");if(t.length()<32)throw new IOException("SESSION_REQUIRED");
        for(Session s:sessions.values())if(s.uid==uid&&"approved".equals(s.status)&&s.token.equals(t)){
            if(!s.scopes.contains(scope))throw new IOException("SCOPE_REQUIRED");return s;
        }throw new IOException("SESSION_EXPIRED");
    }
    static synchronized void revokeAll(){sessions.clear();}
}
