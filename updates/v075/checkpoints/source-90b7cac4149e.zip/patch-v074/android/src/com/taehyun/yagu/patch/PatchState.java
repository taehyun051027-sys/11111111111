package com.taehyun.yagu.patch;

import android.util.Base64;
import org.json.*;
import java.io.*;
import java.security.*;
import java.security.cert.CertificateFactory;
import java.util.*;

final class PatchState {
    static final String ENGINE="v075";
    static final int VERSION=129005;
    private final File file,history;
    private final PublicKey publicKey;
    private JSONObject state;
    PatchState(File files,File vault,InputStream certificate) throws Exception {
        file=new File(files,SaveVault.STATE);history=new File(vault,"state-history");SaveVault.mkdir(history);
        publicKey=CertificateFactory.getInstance("X.509").generateCertificate(certificate).getPublicKey();reload();
    }
    synchronized void reload() throws Exception {
        if(file.isFile()){try(InputStream in=new FileInputStream(file)){state=new JSONObject(new String(SaveVault.readBounded(in,16384),"UTF-8"));}validateState(state);}
        else {state=defaults();save(state);}
    }
    private static JSONObject defaults() throws JSONException {
        JSONObject o=new JSONObject();o.put("schema",1);o.put("engine",ENGINE);o.put("godSelected",true);o.put("batHand",2);o.put("pitHand",0);o.put("revision",0);
        o.put("godTitleName","야구신");o.put("godTitleDescription","양투양타의 야구신. 모든 능력치 ∞");o.put("batterLabel","타자");o.put("pitcherLabel","투수");return o;
    }
    static void validateState(JSONObject o) throws Exception {
        if(o.getInt("schema")!=1||!ENGINE.equals(o.getString("engine")))throw new IOException("STATE_SCHEMA_MISMATCH");
        if(o.getInt("batHand")<0||o.getInt("batHand")>2||o.getInt("pitHand")<0||o.getInt("pitHand")>2||o.getInt("revision")<0)throw new IOException("INVALID_STATE");
        o.getBoolean("godSelected");bounded(o.getString("godTitleName"),60);bounded(o.getString("godTitleDescription"),180);bounded(o.getString("batterLabel"),28);bounded(o.getString("pitcherLabel"),28);
    }
    static String bounded(String s,int bytes) throws IOException {
        if(s==null||s.length()==0||s.getBytes("UTF-8").length>bytes||s.indexOf('\0')>=0||s.indexOf('\r')>=0||s.indexOf('\n')>=0)throw new IOException("INVALID_TEXT");return s;
    }
    private void save(JSONObject next) throws Exception {
        validateState(next);
        if(file.isFile())SaveVault.copy(file,new File(history,"state-"+System.currentTimeMillis()+"-"+UUID.randomUUID()+".json"));
        SaveVault.atomic(file,next.toString().getBytes("UTF-8"));state=next;
    }
    private JSONObject copy() throws JSONException{return new JSONObject(state.toString());}
    synchronized int flags(){return 1|(state.optBoolean("godSelected",true)?2:0);}
    synchronized int hands(){return state.optInt("batHand",2)|(state.optInt("pitHand",0)<<2);}
    synchronized String text(int i){String[] keys={"godTitleName","godTitleDescription","batterLabel","pitcherLabel"};return i>=0&&i<keys.length?state.optString(keys[i]):"";}
    synchronized void god(boolean enabled) throws Exception {JSONObject n=copy();n.put("godSelected",enabled);save(n);}
    synchronized void hands(int bat,int pit) throws Exception {
        if(bat<0||bat>2||pit<0||pit>2)throw new IOException("INVALID_HAND");JSONObject n=copy();n.put("batHand",bat);n.put("pitHand",pit);save(n);
    }
    synchronized void newCareer() throws Exception {JSONObject n=copy();n.put("godSelected",true);save(n);}
    synchronized JSONObject info() throws JSONException {
        JSONObject o=new JSONObject();o.put("engine",ENGINE);o.put("versionCode",VERSION);o.put("revision",state.optInt("revision"));o.put("godTitleName",text(0));o.put("bat",handName(hands()&3));o.put("pit",handName((hands()>>2)&3));return o;
    }
    static String handName(int value){return value==0?"right":value==1?"left":"preserve";}
    static int handValue(String value) throws IOException {if("right".equals(value))return 0;if("left".equals(value))return 1;if("preserve".equals(value))return 2;throw new IOException("INVALID_HAND");}
    private static void keys(JSONObject object,String... allowed) throws IOException {
        Set<String> set=new HashSet<>(Arrays.asList(allowed));Iterator<String> it=object.keys();while(it.hasNext())if(!set.contains(it.next()))throw new IOException("UNSUPPORTED_PATCH_FIELD");
    }
    synchronized JSONObject inspect(byte[] envelope) throws Exception {
        if(envelope.length>65536)throw new IOException("PATCH_TOO_LARGE");
        JSONObject outer=new JSONObject(new String(envelope,"UTF-8"));keys(outer,"format","payload","signature");
        if(!"yagu-patch-v1".equals(outer.getString("format")))throw new IOException("PATCH_FORMAT");
        byte[] payload=Base64.decode(outer.getString("payload"),Base64.DEFAULT),signature=Base64.decode(outer.getString("signature"),Base64.DEFAULT);
        if(payload.length>16384||signature.length>1024)throw new IOException("PATCH_TOO_LARGE");
        Signature verifier=Signature.getInstance("SHA256withRSA");verifier.initVerify(publicKey);verifier.update(payload);
        if(!verifier.verify(signature))throw new IOException("PATCH_SIGNATURE_INVALID");
        JSONObject p=new JSONObject(new String(payload,"UTF-8"));keys(p,"schema","applicationId","engine","minVersionCode","maxVersionCode","revision","summary","changes");
        if(p.getInt("schema")!=1||!SaveVault.PACKAGE.equals(p.getString("applicationId"))||!ENGINE.equals(p.getString("engine"))||p.getInt("minVersionCode")>VERSION||p.getInt("maxVersionCode")<VERSION)throw new IOException("PATCH_INCOMPATIBLE");
        int revision=p.getInt("revision");if(revision<=state.optInt("revision"))throw new IOException("PATCH_NOT_NEWER");
        bounded(p.getString("summary"),600);JSONObject c=p.getJSONObject("changes");
        keys(c,"godTitleName","godTitleDescription","batterLabel","pitcherLabel","battingHand","pitchingHand");
        if(c.has("godTitleName"))bounded(c.getString("godTitleName"),60);if(c.has("godTitleDescription"))bounded(c.getString("godTitleDescription"),180);
        if(c.has("batterLabel"))bounded(c.getString("batterLabel"),28);if(c.has("pitcherLabel"))bounded(c.getString("pitcherLabel"),28);
        if(c.has("battingHand"))handValue(c.getString("battingHand"));if(c.has("pitchingHand"))handValue(c.getString("pitchingHand"));
        return p;
    }
    synchronized JSONObject apply(byte[] envelope) throws Exception {
        JSONObject p=inspect(envelope),c=p.getJSONObject("changes"),next=copy();
        for(String k:new String[]{"godTitleName","godTitleDescription","batterLabel","pitcherLabel"})if(c.has(k))next.put(k,c.getString(k));
        if(c.has("battingHand"))next.put("batHand",handValue(c.getString("battingHand")));if(c.has("pitchingHand"))next.put("pitHand",handValue(c.getString("pitchingHand")));
        next.put("revision",p.getInt("revision"));save(next);JSONObject result=info();result.put("restart_required",true);return result;
    }
}
