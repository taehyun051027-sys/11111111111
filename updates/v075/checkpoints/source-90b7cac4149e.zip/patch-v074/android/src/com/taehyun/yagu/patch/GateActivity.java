package com.taehyun.yagu.patch;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;

public final class GateActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);PatchRuntime.initialize(this);
        boolean maintenance=getSharedPreferences("yagu-v075-launch",0).getBoolean("maintenance",false);
        if(!PatchRuntime.ready()||maintenance){startActivity(new Intent(this,PatchManagerActivity.class));finish();return;}
        openGame(this);
    }
    static void openGame(Activity a){
        synchronized(PatchRuntime.operationLock){
            if(!PatchRuntime.ready()){PatchRuntime.openManager();return;}
            if(!a.getSharedPreferences("yagu-v075-launch",0).edit().putBoolean("maintenance",false).commit()){PatchRuntime.openManager();return;}
            Intent i=a instanceof GateActivity?new Intent(a.getIntent()):new Intent();i.setClassName(a,PatchRuntime.GAME);i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
            PatchRuntime.gameLoaded=true;a.startActivity(i);a.finish();
        }
    }
}
