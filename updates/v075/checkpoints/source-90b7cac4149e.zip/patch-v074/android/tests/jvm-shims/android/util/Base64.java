package android.util;

/** JVM-only shim for the used android.util.Base64 flags.
 * Never packaged in the APK. Android's decoder permits ASCII whitespace,
 * URL_SAFE selects the alternate alphabet, and NO_PADDING affects encoding.
 */
public final class Base64 {
    public static final int DEFAULT=0,NO_PADDING=1,NO_WRAP=2,CRLF=4,URL_SAFE=8,NO_CLOSE=16;
    private Base64(){}
    public static byte[] decode(String text,int flags){
        String clean=text.replace("\r", "").replace("\n", "").replace("\t", "").replace(" ", "");
        return ((flags&URL_SAFE)!=0?java.util.Base64.getUrlDecoder():java.util.Base64.getDecoder()).decode(clean);
    }
    public static String encodeToString(byte[] data,int flags){
        java.util.Base64.Encoder encoder=(flags&URL_SAFE)!=0?java.util.Base64.getUrlEncoder():java.util.Base64.getEncoder();
        if((flags&NO_PADDING)!=0)encoder=encoder.withoutPadding();String text=encoder.encodeToString(data);
        if((flags&NO_WRAP)!=0||text.length()==0)return text;
        String newline=(flags&CRLF)!=0?"\r\n":"\n";StringBuilder result=new StringBuilder();
        for(int at=0;at<text.length();at+=76)result.append(text,at,Math.min(at+76,text.length())).append(newline);
        return result.toString();
    }
}
