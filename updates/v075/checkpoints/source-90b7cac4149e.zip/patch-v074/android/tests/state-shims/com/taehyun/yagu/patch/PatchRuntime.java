package com.taehyun.yagu.patch;
import org.json.JSONObject;
/** Minimal JVM boundary for isolated BridgeSessions tests; not APK code. */
final class PatchRuntime {
    static JSONObject ok(){return new JSONObject().put("ok",true).put("protocol",1);}
}
