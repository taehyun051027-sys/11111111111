package com.taehyun.yagu.patch;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Pure JVM regression/fault-injection tests. All saves are synthetic fixtures.
 * No APK, Android app sandbox, tablet or real user save is accessed.
 */
public final class SaveVaultTest {
    static final String BAT="bb2013batter.sav", PIT="bb2013pitcher.sav", TEAM="bb2013team.sav";
    interface Task { void run() throws Exception; }
    static int assertions;
    static final List<String[]> results=new ArrayList<>();
    static void check(boolean value,String message) { assertions++;if(!value)throw new AssertionError(message); }
    static void same(byte[] expected,byte[] actual,String message){check(Arrays.equals(expected,actual),message);}
    static String hash(byte[] b){try{return SaveVault.hex(MessageDigest.getInstance("SHA-256").digest(b));}catch(Exception e){throw new AssertionError(e);}}
    static byte[] bytes(String s){return s.getBytes(StandardCharsets.UTF_8);}
    static void fail(String code,Task task) throws Exception {
        try{task.run();throw new AssertionError("Expected rejection "+code);}
        catch(IOException e){check(code==null||code.equals(e.getMessage()),"Expected "+code+"; got "+e.getMessage());}
    }
    static void execute(String name,Task task){
        int before=assertions;
        try{task.run();results.add(new String[]{name,"pass",Integer.toString(assertions-before)});}
        catch(Throwable t){results.add(new String[]{name,"FAIL",t.toString()});}
    }
    static Map<String,byte[]> directory(File dir) throws IOException {
        Map<String,byte[]> values=new TreeMap<>();Path base=dir.toPath();
        try(java.util.stream.Stream<Path> paths=Files.walk(base)){
            for(Path p:(Iterable<Path>)paths.filter(Files::isRegularFile)::iterator)
                values.put(base.relativize(p).toString(),Files.readAllBytes(p));
        }return values;
    }
    static void sameDirectory(Map<String,byte[]> before,File after,String message) throws IOException {
        Map<String,byte[]> actual=directory(after);check(before.keySet().equals(actual.keySet()),message+" file set");
        for(String n:before.keySet())same(before.get(n),actual.get(n),message+" "+n);
    }
    static final class Fixture implements AutoCloseable {
        final File root,files,vaultDir;final SaveVault vault;final Map<String,byte[]> initial;
        Fixture() throws Exception {
            root=Files.createTempDirectory("yagu-synthetic-vault-").toFile();files=new File(root,"files");vaultDir=new File(root,"vault");files.mkdirs();
            String[] game={BAT,PIT,TEAM,"yagu_awards_v1_a.sav","yagu_awards_v1_b.sav"};
            for(int i=0;i<game.length;i++){
                byte[] b=new byte[4096+i*613];new Random(71308+i).nextBytes(b);
                b[0x24]=3;b[0x25]=0;b[0x26]=0;b[0x27]=0;
                byte[] club=bytes("EDITED-CLUB-SYNTHETIC-FIXTURE");System.arraycopy(club,0,b,0x80,club.length);
                Files.write(new File(files,game[i]).toPath(),b);
            }
            Files.write(new File(files,SaveVault.STATE).toPath(),bytes("{\"syntheticFixture\":true,\"games\":3,\"clubEdited\":true}"));
            Files.write(new File(files,"sdk-analytics.bin").toPath(),bytes("SDK-DATA-MUST-STAY-UNCHANGED"));
            File sdk=new File(files,"vendor/cache");sdk.mkdirs();Files.write(new File(sdk,"blob.bin").toPath(),bytes("UNKNOWN-NESTED-FILE"));
            vault=new SaveVault(files,vaultDir);initial=directory(files);
        }
        void init() throws IOException {vault.initialize();check(vault.ready(),"ready after verified initial backup");}
        byte[] current(String n) throws IOException{return Files.readAllBytes(new File(files,n).toPath());}
        byte[] edited(String n) throws IOException {byte[] b=current(n);b[0x310]^=0x57;return b;}
        void replace(String n,byte[] b) throws IOException {Files.write(new File(files,n).toPath(),b);}
        void noUnknownChanges() throws IOException {
            same(initial.get("sdk-analytics.bin"),current("sdk-analytics.bin"),"SDK root file preserved");
            same(initial.get("vendor/cache/blob.bin"),current("vendor/cache/blob.bin"),"SDK nested file preserved");
        }
        public void close() throws Exception {
            try(java.util.stream.Stream<Path> paths=Files.walk(root.toPath())){
                for(Path p:(Iterable<Path>)paths.sorted(Comparator.reverseOrder())::iterator)Files.deleteIfExists(p);
            }
        }
    }
    static byte[] export(SaveVault v,String id) throws IOException {ByteArrayOutputStream b=new ByteArrayOutputStream();v.exportArchive(id,b);return b.toByteArray();}
    static Map<String,byte[]> unzip(byte[] archive) throws IOException {
        Map<String,byte[]> out=new LinkedHashMap<>();try(ZipInputStream z=new ZipInputStream(new ByteArrayInputStream(archive))){ZipEntry e;while((e=z.getNextEntry())!=null){out.put(e.getName(),z.readAllBytes());z.closeEntry();}}return out;
    }
    static byte[] zip(Map<String,byte[]> data) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();try(ZipOutputStream z=new ZipOutputStream(b)){for(Map.Entry<String,byte[]> e:data.entrySet()){z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}}return b.toByteArray();
    }
    static Properties prop(byte[] raw) throws IOException {Properties p=new Properties();p.load(new ByteArrayInputStream(raw));return p;}
    static byte[] prop(Properties p) throws IOException {ByteArrayOutputStream b=new ByteArrayOutputStream();p.store(b,"synthetic test archive");return b.toByteArray();}
    static Map<String,byte[]> manifestChange(Map<String,byte[]> original,String key,String value) throws IOException {
        Map<String,byte[]> m=new LinkedHashMap<>(original);Properties p=prop(m.get("manifest.properties"));p.setProperty(key,value);m.put("manifest.properties",prop(p));return m;
    }
    static void importRejected(Fixture f,byte[] data,String code) throws Exception {
        Map<String,byte[]> before=directory(f.files);int count=f.vault.backups().size();
        fail(code,()->f.vault.importArchive(new ByteArrayInputStream(data)));
        sameDirectory(before,f.files,"failed import leaves current files");check(f.vault.backups().size()==count,"failed import commits no archive");
        File[] dirs=f.vaultDir.listFiles();for(File d:dirs)check(!d.getName().startsWith("import-"),"failed import removes stage");
    }
    static void le(ByteArrayOutputStream b,long v,int n){for(int i=0;i<n;i++){b.write((int)v&255);v>>>=8;}}
    static byte[] duplicateZip() throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream();String name="manifest.properties";byte[] n=bytes(name),data=bytes("duplicate entry fixture");CRC32 crc=new CRC32();crc.update(data);
        for(int i=0;i<2;i++){le(out,0x04034b50,4);le(out,20,2);le(out,0,2);le(out,0,2);le(out,0,2);le(out,0,2);le(out,crc.getValue(),4);le(out,data.length,4);le(out,data.length,4);le(out,n.length,2);le(out,0,2);out.write(n);out.write(data);}
        le(out,0x06054b50,4);for(int i=0;i<18;i++)out.write(0);return out.toByteArray();
    }
    static byte[] largeZip(int entries,long each) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] block=new byte[16384];try(ZipOutputStream z=new ZipOutputStream(b)){
            for(int i=0;i<entries;i++){z.putNextEntry(new ZipEntry("bb2013large"+i+".sav"));for(long at=0;at<each;at+=block.length)z.write(block,0,(int)Math.min(block.length,each-at));z.closeEntry();}
        }return b.toByteArray();
    }
    static void initialPreserved() throws Exception {try(Fixture f=new Fixture()){
        f.init();sameDirectory(f.initial,f.files,"initial backup is read only");String id=f.vault.initialBackup();check(id!=null,"initial backup ID");
        String state=f.vault.stateHash();SaveVault second=new SaveVault(f.files,f.vaultDir);second.initialize();check(id.equals(second.initialBackup()),"initial backup not replaced on restart");check(state.equals(second.stateHash()),"restart preserves state hash");
        Map<String,byte[]> archived=unzip(export(f.vault,id));for(SaveVault.Entry e:f.vault.entries())same(f.current(e.name),archived.get(e.name),"archive exact bytes "+e.name);
        check(!archived.containsKey("sdk-analytics.bin")&&!archived.containsKey("vendor/cache/blob.bin"),"unknown SDK files excluded from archive");
        check(f.current(BAT)[0x24]==3,"three-game marker preserved");f.noUnknownChanges();
    }}
    static void initialFailureClosed() throws Exception {try(Fixture f=new Fixture()){
        f.vault.fault(n->{if("backup-before-commit".equals(n))throw new IOException("INJECTED_BACKUP_FAILURE");});
        fail("INJECTED_BACKUP_FAILURE",()->f.vault.initialize());check(!f.vault.ready(),"failed initial backup is not ready");
        sameDirectory(f.initial,f.files,"initial backup failure preserves all files");
        f.vault.fault(null);String id=f.vault.snapshot("manual-test-snapshot");byte[] edited=f.edited(BAT);
        fail("VAULT_NOT_READY",()->f.vault.write(BAT,edited,hash(f.current(BAT)),hash(edited)));
        fail("VAULT_NOT_READY",()->f.vault.restore(id,f.vault.stateHash()));sameDirectory(f.initial,f.files,"unready writes rejected");
    }}
    static void initialCorruptionClosed() throws Exception {try(Fixture f=new Fixture()){
        f.init();File backup=f.vault.backupDir(f.vault.initialBackup());Files.write(new File(backup,BAT).toPath(),bytes("damaged backup"));
        SaveVault second=new SaveVault(f.files,f.vaultDir);fail("ARCHIVE_HASH_MISMATCH",()->second.initialize());check(!second.ready(),"corrupt initial backup fails closed");byte[] b=f.edited(BAT);
        fail("VAULT_NOT_READY",()->second.write(BAT,b,hash(f.current(BAT)),hash(b)));sameDirectory(f.initial,f.files,"corrupt backup blocks original writes");
    }}
    static void archiveRoundTrip() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] archive=export(f.vault,f.vault.initialBackup());String old=f.vault.stateHash();String imported=f.vault.importArchive(new ByteArrayInputStream(archive));check(old.equals(f.vault.stateHash()),"import alone does not restore");
        f.replace(BAT,f.edited(BAT));f.replace("bb2013temporary.sav",bytes("new save slot fixture"));String undo=f.vault.restore(imported,f.vault.stateHash());
        sameDirectory(f.initial,f.files,"full archive restore exact bytes");check(f.vault.backupDir(undo).isDirectory(),"restore produces verified undo snapshot");
        f.vault.restore(undo,f.vault.stateHash());check(new File(f.files,"bb2013temporary.sav").isFile(),"undo restores previously present slot");f.noUnknownChanges();
    }}
    static void archiveTraversalDuplicates() throws Exception {try(Fixture f=new Fixture()){
        f.init();for(String n:new String[]{"../bb2013outside.sav","/tmp/bb2013outside.sav","child/bb2013inside.sav","..\\bb2013outside.sav"}){
            Map<String,byte[]> m=new LinkedHashMap<>();m.put(n,bytes("must not escape"));importRejected(f,zip(m),"UNSAFE_ARCHIVE_ENTRY");
        }importRejected(f,duplicateZip(),"UNSAFE_ARCHIVE_ENTRY");check(!new File(f.root,"bb2013outside.sav").exists(),"no archive traversal output");
    }}
    static void archiveIntegrity() throws Exception {try(Fixture f=new Fixture()){
        f.init();Map<String,byte[]> original=unzip(export(f.vault,f.vault.initialBackup()));
        Map<String,byte[]> bad=new LinkedHashMap<>(original);byte[] changed=bad.get(BAT).clone();changed[7]^=1;bad.put(BAT,changed);importRejected(f,zip(bad),"ARCHIVE_HASH_MISMATCH");
        importRejected(f,zip(manifestChange(original,"file.0.size","1")),"ARCHIVE_HASH_MISMATCH");
        importRejected(f,zip(manifestChange(original,"file.0.sha256","xyz")),"BAD_MANIFEST");
        importRejected(f,zip(manifestChange(original,"state_sha256","0".repeat(64))),"ARCHIVE_STATE_MISMATCH");
        importRejected(f,zip(manifestChange(original,"package","different.package")),"INCOMPATIBLE_ARCHIVE");
        importRejected(f,zip(manifestChange(original,"engine","unknown-engine")),"INCOMPATIBLE_ARCHIVE");
        importRejected(f,zip(manifestChange(original,"file.0.name","../bb2013outside.sav")),"FILE_NOT_ALLOWED");
        Properties p=prop(original.get("manifest.properties"));bad=new LinkedHashMap<>(original);p.setProperty("file.1.name",p.getProperty("file.0.name"));bad.put("manifest.properties",prop(p));importRejected(f,zip(bad),"BAD_MANIFEST");
        bad=new LinkedHashMap<>(original);bad.put("bb2013unlisted.sav",bytes("not in manifest"));importRejected(f,zip(bad),"UNLISTED_ARCHIVE_ENTRY");
        bad=new LinkedHashMap<>(original);bad.put("sdk-private.bin",bytes("not allowed"));importRejected(f,zip(bad),"UNSAFE_ARCHIVE_ENTRY");
        importRejected(f,zip(manifestChange(original,"count","129")),"SIZE_LIMIT");
    }}
    static void archiveSizeLimits() throws Exception {try(Fixture f=new Fixture()){
        f.init();importRejected(f,largeZip(1,SaveVault.MAX_FILE+1),"SIZE_LIMIT");
        importRejected(f,largeZip(7,SaveVault.MAX_FILE),"SIZE_LIMIT");
        Map<String,byte[]> tooMany=new LinkedHashMap<>();for(int i=0;i<130;i++)tooMany.put("bb2013entry"+i+".sav",new byte[0]);importRejected(f,zip(tooMany),"UNSAFE_ARCHIVE_ENTRY");
        Map<String,byte[]> manifest=new LinkedHashMap<>();manifest.put("manifest.properties",new byte[1024*1024+1]);importRejected(f,zip(manifest),"SIZE_LIMIT");
    }}
    static void staleWrites() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] old=f.current(BAT),edit=f.edited(BAT);String initial=f.vault.stateHash();
        fail("STALE_FILE",()->f.vault.write(BAT,edit,"0".repeat(64),hash(edit)));
        fail("PREVIEW_HASH_MISMATCH",()->f.vault.write(BAT,edit,hash(old),"0".repeat(64)));
        fail("FILE_NOT_ALLOWED",()->f.vault.write("sdk-analytics.bin",edit,hash(old),hash(edit)));
        sameDirectory(f.initial,f.files,"rejected edits leave all files");String undo=f.vault.write(BAT,edit,hash(old),hash(edit));same(edit,f.current(BAT),"verified edit bytes applied");
        fail("STALE_FILE",()->f.vault.write(BAT,edit,hash(old),hash(edit)));
        fail("STALE_STATE",()->f.vault.restore(f.vault.initialBackup(),initial));same(edit,f.current(BAT),"stale restore leaves latest edit");
        f.vault.restore(undo,f.vault.stateHash());sameDirectory(f.initial,f.files,"verified edit undo exact");
    }}
    static void snapshotRace() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] externallyChanged=f.edited(TEAM);f.vault.fault(n->{if("backup-before-commit".equals(n))f.replace(TEAM,externallyChanged);});
        fail("SAVE_CHANGED_DURING_BACKUP",()->f.vault.snapshot("racing-game-write"));same(externallyChanged,f.current(TEAM),"racing game write not overwritten");
        same(f.initial.get(BAT),f.current(BAT),"unrelated batter preserved");f.noUnknownChanges();
    }}
    static void transactionRace() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] edit=f.edited(BAT),external=f.edited(TEAM);
        f.vault.fault(n->{if("transaction-backup-created".equals(n))f.replace(TEAM,external);});
        fail("STALE_STATE",()->f.vault.write(BAT,edit,hash(f.current(BAT)),hash(edit)));
        same(f.initial.get(BAT),f.current(BAT),"stale transaction does not apply edit");same(external,f.current(TEAM),"newer team write preserved");check(!new File(f.vaultDir,"transaction.properties").exists(),"stale transaction creates no journal");
    }}
    static void targetHashRace() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] old=f.current(BAT),edit=f.edited(BAT),external=old.clone();external[0x350]^=0x23;
        f.vault.fault(n->{if("write-before-state-check".equals(n))f.replace(BAT,external);});
        fail("STALE_FILE",()->f.vault.write(BAT,edit,hash(old),hash(edit)));same(external,f.current(BAT),"concurrent target write retained");
    }}
    static void midWriteRollback() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] edit=f.edited(BAT);Map<String,byte[]> before=directory(f.files);
        f.vault.fault(n->{if(("restore-file-"+BAT).equals(n))throw new IOException("INJECTED_MID_WRITE");});
        fail("INJECTED_MID_WRITE",()->f.vault.write(BAT,edit,hash(f.current(BAT)),hash(edit)));sameDirectory(before,f.files,"mid-write rollback exact");
        check(f.vault.ready(),"successful rollback retains ready");check(!new File(f.vaultDir,"transaction.properties").exists(),"rollback consumes journal");f.noUnknownChanges();
    }}
    static void completeWriteRollback() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] edit=f.edited(BAT);f.vault.fault(n->{if("transaction-complete".equals(n))throw new IOException("INJECTED_COMMIT_FAILURE");});
        fail("INJECTED_COMMIT_FAILURE",()->f.vault.write(BAT,edit,hash(f.current(BAT)),hash(edit)));sameDirectory(f.initial,f.files,"post-write pre-commit rollback exact");
    }}
    static void recoveryFailureClosed() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] edit=f.edited(BAT);File held=new File(f.root,"held-backup-bytefile");final File[] missing={null};
        f.vault.fault(n->{if(("restore-file-"+BAT).equals(n)){
            Properties journal=SaveVault.properties(new File(f.vaultDir,"transaction.properties"));File backup=f.vault.backupDir(journal.getProperty("backup_id"));missing[0]=new File(backup,BAT);Files.move(missing[0].toPath(),held.toPath());throw new IOException("INJECTED_IO_FAILURE");
        }});
        fail("RECOVERY_REQUIRED",()->f.vault.write(BAT,edit,hash(f.current(BAT)),hash(edit)));check(!f.vault.ready(),"rollback IO failure disables vault");check(new File(f.vaultDir,"transaction.properties").isFile(),"recovery journal retained");
        fail("VAULT_NOT_READY",()->f.vault.write(BAT,edit,hash(f.current(BAT)),hash(edit)));
        Files.move(held.toPath(),missing[0].toPath());SaveVault retry=new SaveVault(f.files,f.vaultDir);retry.initialize();check(retry.ready(),"startup retries repaired recovery");sameDirectory(f.initial,f.files,"recovery retry restores exact original");
    }}
    static void crashChild(String[] args) throws Exception {
        SaveVault v=new SaveVault(new File(args[1]),new File(args[2]));v.initialize();String point=args[3];
        v.fault(n->{if(point.equals(n))Runtime.getRuntime().halt(73);});
        byte[] old=Files.readAllBytes(new File(v.files,BAT).toPath()),edit=old.clone();edit[0x310]^=0x39;
        v.write(BAT,edit,hash(old),hash(edit));throw new AssertionError("crash point not reached");
    }
    static void processCrashRecovery(String point) throws Exception {try(Fixture f=new Fixture()){
        f.init();Process p=new ProcessBuilder(new File(System.getProperty("java.home"),"bin/java").getPath(),"-cp",System.getProperty("java.class.path"),SaveVaultTest.class.getName(),"--crash-child",f.files.getAbsolutePath(),f.vaultDir.getAbsolutePath(),point).redirectErrorStream(true).start();
        byte[] output=p.getInputStream().readAllBytes();int exit=p.waitFor();check(exit==73,"child genuinely halted at "+point+"; exit="+exit+" "+new String(output,StandardCharsets.UTF_8));
        check(new File(f.vaultDir,"transaction.properties").isFile(),"halt leaves recovery journal");SaveVault reopened=new SaveVault(f.files,f.vaultDir);reopened.initialize();
        check(reopened.ready(),"startup recovery succeeds after process halt");sameDirectory(f.initial,f.files,"process crash recovers exact files");check(!new File(f.vaultDir,"transaction.properties").exists(),"startup clears completed journal");f.noUnknownChanges();
    }}
    static void fileEntryLimits() throws Exception {try(Fixture f=new Fixture()){
        try(RandomAccessFile out=new RandomAccessFile(new File(f.files,"bb2013oversize.sav"),"rw")){out.setLength(SaveVault.MAX_FILE+1);}
        fail("SIZE_LIMIT",()->f.vault.initialize());check(!f.vault.ready(),"oversize live entry blocks initial backup");f.noUnknownChanges();
    }try(Fixture f=new Fixture()){
        Path external=new File(f.root,"outside.sav").toPath();Files.write(external,bytes("external fixture"));Files.createSymbolicLink(new File(f.files,"bb2013link.sav").toPath(),external);
        fail("UNSAFE_PATH",()->f.vault.initialize());same(bytes("external fixture"),Files.readAllBytes(external),"external symlink target untouched");
    }}
    static void boundedRead() throws Exception {try(Fixture f=new Fixture()){
        f.init();byte[] b=f.current(BAT);same(Arrays.copyOfRange(b,0x20,0x40),f.vault.read(BAT,0x20,32),"offset read exact");same(new byte[0],f.vault.read(BAT,b.length,10),"EOF bounded read");
        fail("INVALID_READ",()->f.vault.read(BAT,-1,20));fail("INVALID_READ",()->f.vault.read(BAT,0,4097));fail("INVALID_OFFSET",()->f.vault.read(BAT,b.length+1,1));fail("INVALID_READ",()->f.vault.read("sdk-analytics.bin",0,1));
    }}
    static String escape(String s){return s.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r");}
    public static void main(String[] args) throws Exception {
        if(args.length>0&&"--crash-child".equals(args[0])){crashChild(args);return;}
        execute("initial_backup_exact_fixture_preservation",SaveVaultTest::initialPreserved);
        execute("initial_backup_failure_blocks_mutations",SaveVaultTest::initialFailureClosed);
        execute("initial_backup_corruption_blocks_mutations",SaveVaultTest::initialCorruptionClosed);
        execute("archive_round_trip_and_restore_undo",SaveVaultTest::archiveRoundTrip);
        execute("zip_traversal_and_duplicate_entry_rejection",SaveVaultTest::archiveTraversalDuplicates);
        execute("archive_hash_size_manifest_integrity",SaveVaultTest::archiveIntegrity);
        execute("archive_decompression_size_and_count_limits",SaveVaultTest::archiveSizeLimits);
        execute("stale_file_state_and_preview_hash_rejection",SaveVaultTest::staleWrites);
        execute("snapshot_detects_game_write_before_commit",SaveVaultTest::snapshotRace);
        execute("transaction_rechecks_state_after_backup",SaveVaultTest::transactionRace);
        execute("file_edit_rechecks_staged_expected_hash",SaveVaultTest::targetHashRace);
        execute("mid_write_failure_exact_rollback",SaveVaultTest::midWriteRollback);
        execute("pre_commit_failure_exact_rollback",SaveVaultTest::completeWriteRollback);
        execute("rollback_failure_blocks_edits_then_startup_recovers",SaveVaultTest::recoveryFailureClosed);
        execute("process_halt_after_journal_start",()->processCrashRecovery("transaction-started"));
        execute("process_halt_after_first_file",()->processCrashRecovery("restore-file-"+BAT));
        execute("process_halt_after_all_files",()->processCrashRecovery("transaction-complete"));
        execute("live_file_size_and_external_symlink_rejection",SaveVaultTest::fileEntryLimits);
        execute("bounded_save_read_preserves_unknown_files",SaveVaultTest::boundedRead);
        int failed=0;StringBuilder json=new StringBuilder("{\n  \"suite\": \"SaveVault pure JVM fault injection\",\n  \"fixture\": \"Synthetic arbitrary binary files with three-game and edited-club markers; no user saves\",\n  \"real_android_device_tested\": false,\n  \"tests\": [\n");
        for(int i=0;i<results.size();i++){String[] r=results.get(i);if(!"pass".equals(r[1]))failed++;json.append("    {\"name\":\"").append(escape(r[0])).append("\",\"result\":\"").append(r[1]).append("\",\"detail\":\"").append(escape(r[2])).append("\"}");if(i+1<results.size())json.append(',');json.append('\n');}
        json.append("  ],\n  \"test_count\": ").append(results.size()).append(",\n  \"assertions\": ").append(assertions).append(",\n  \"failed\": ").append(failed).append("\n}\n");
        if(args.length>0)Files.write(Path.of(args[0]),bytes(json.toString()));System.out.print(json);if(failed>0)System.exit(1);
    }
}
