#include "api.h"
typedef v074_u8 u8;
typedef v074_u16 u16;
typedef v074_u32 u32;
typedef v074_uptr uptr;
extern u8 *v075_data_manager(void);
extern int v075_game_mode(void);
extern void *v075_jni_env(void);
extern void *v075_jni_find(void *,const char *);
extern void *v075_jni_method(void *,void *,const char *,const char *);
extern int v075_jni_int(void *,void *,void *,...);
extern void v075_jni_void(void *,void *,void *,...);
extern void *v075_jni_object(void *,void *,void *,...);
static char name_buf[64],description_buf[192],bat_label[32],pit_label[32];
static int texts_ready;
static int good_env(void *env) {
 if(!env)return 0;
 void **t=*(void ***)env;
 void *exception=((void *(*)(void *))t[15])(env);
 if(!exception)return 1;
 ((void (*)(void *))t[17])(env);
 ((void (*)(void *,void *))t[23])(env,exception);
 return 0;
}
static void drop(void *env,void *object) {
 if(env&&object)((void (*)(void *,void *))(*(void ***)env)[23])(env,object);
}
static int java_int(const char *name,const char *signature,int a,int b) {
 void *env=v075_jni_env();
 if(!env)return -1;
 void *cls=v075_jni_find(env,"com/taehyun/yagu/patch/PatchBridge");
 if(!good_env(env)||!cls)return -1;
 void *method=v075_jni_method(env,cls,name,signature);
 if(!good_env(env)||!method){drop(env,cls);return -1;}
 int result=v075_jni_int(env,cls,method,a,b);
 if(!good_env(env))result=-1;
 drop(env,cls);return result;
}
V074_API int v074_backup_ready(void) {int f=java_int("getFlags","()I",0,0);return f>=0&&(f&1);}
V074_API int v074_god_selected(void) {int f=java_int("getFlags","()I",0,0);return f>=0&&(f&1)&&(f&2);}
V074_API int v074_legacy_rhp_active(void) {return v075_pitch_hand()==0;}
V074_API int v074_set_god_selected(int selected) {return java_int("setGodSelected","(I)I",!!selected,0)==1;}
V074_API int v074_new_career_created(void) {return java_int("newCareerCreated","()I",0,0)==1;}
static int hand(int role){int h=java_int("getHands","()I",0,0);if(h<0)return -1;h=(h>>(role*2))&3;return h<2?h:-1;}
V074_API int v075_bat_hand(void){return hand(0);}
V074_API int v075_pitch_hand(void){return hand(1);}
V074_API int v075_set_creation_hands(int bat,int pit){if(bat<0||bat>1||pit<0||pit>1)return 0;return java_int("setHands","(II)I",bat,pit)==1;}
static u16 id(const u8*p){return p?(u16)(p[0]|((u16)p[1]<<8)):0;}
static u8 *at(u8*p,unsigned n){return *(u8 **)(p+n);}
static u8 *my_role(int pitcher){
 int mode=v075_game_mode();
 if(mode!=0&&mode!=4)return (u8*)0;
 u8 *dm=v075_data_manager();if(!dm)return (u8*)0;
#if __SIZEOF_POINTER__==8
 if(!at(dm,0x528))return (u8*)0;
 u8 *teams=at(dm,0x530);
#else
 if(!at(dm,0x4e8))return (u8*)0;
 u8 *teams=at(dm,0x4ec);
#endif
 if(!teams)return (u8*)0;
 int team=*(int*)(teams+4);if(team<0||team>=15)return (u8*)0;
 u8 *t=teams+8+team*0x3b4;
 if(t[2]>8||t[3]>12)return (u8*)0;
 unsigned n=pitcher?t[2]:t[3],stride=pitcher?52:44,base=pitcher?4:0x1a4;
 for(unsigned i=0;i<n;i++){u8*p=t+base+i*stride;if(id(p)==(pitcher?1100:1000))return p;}
 return (u8*)0;
}
V074_API void *v074_my_batter(void){return my_role(0);}
V074_API void *v074_my_pitcher(void){return my_role(1);}
static void copy_text(void *env,void *cls,void *method,int index,char *to,unsigned cap){
 void *str=v075_jni_object(env,cls,method,index);
 if(!good_env(env)||!str)return;
 void **t=*(void ***)env;
 const char *s=((const char *(*)(void*,void*,void*))t[169])(env,str,(void*)0);
 if(good_env(env)&&s){unsigned i=0;while(i+1<cap&&s[i]){to[i]=s[i];i++;}to[i]=0;((void(*)(void*,void*,const char*))t[170])(env,str,s);}
 drop(env,str);
}
static void load_texts(void){
 if(texts_ready)return;
 void *env=v075_jni_env();if(!env)return;
 void *cls=v075_jni_find(env,"com/taehyun/yagu/patch/PatchBridge");if(!good_env(env)||!cls)return;
 void *m=v075_jni_method(env,cls,"getText","(I)Ljava/lang/String;");
 if(!good_env(env)||!m){drop(env,cls);return;}
 copy_text(env,cls,m,0,name_buf,sizeof(name_buf));copy_text(env,cls,m,1,description_buf,sizeof(description_buf));
 copy_text(env,cls,m,2,bat_label,sizeof(bat_label));copy_text(env,cls,m,3,pit_label,sizeof(pit_label));
 drop(env,cls);texts_ready=1;
}
V074_API const char *v074_god_name(void){load_texts();return name_buf[0]?name_buf:"야구신";}
V074_API const char *v074_god_description(void){load_texts();return description_buf[0]?description_buf:"양투양타의 야구신. 모든 능력치 ∞";}
V074_API const char *v074_batter_label(void){load_texts();return bat_label[0]?bat_label:"타자";}
V074_API const char *v074_pitcher_label(void){load_texts();return pit_label[0]?pit_label:"투수";}
V074_API void v074_open_patch_manager(void){
 void *env=v075_jni_env();if(!env)return;
 void *cls=v075_jni_find(env,"com/taehyun/yagu/patch/PatchBridge");if(!good_env(env)||!cls)return;
 void *m=v075_jni_method(env,cls,"openManager","()V");
 if(good_env(env)&&m){v075_jni_void(env,cls,m);good_env(env);}drop(env,cls);
}
