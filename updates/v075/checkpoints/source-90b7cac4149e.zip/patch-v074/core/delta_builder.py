"""Add v0.7.5 code to the exact shipped v0.7.3 ELF; never rebuild an old mod.

Existing load addresses, relocations, assets and the v0.7.3 payload are retained.
The existing final RX segment is extended. Tiny zero-initialized state occupies
only the verified unused padding at the end of the existing final RW segment.
No RWX mapping, additional imports, or fixed runtime addresses are introduced.
"""
from __future__ import annotations
import hashlib, importlib.util, io, json, os, struct, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools/python'))
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_ARCH_ARM, CS_MODE_LITTLE_ENDIAN, CS_MODE_THUMB
from keystone import Ks, KS_ARCH_ARM64, KS_ARCH_ARM, KS_MODE_LITTLE_ENDIAN, KS_MODE_THUMB
BASE=ROOT.parent/'recovery/apk-inspection/lib'
EXPECTED={
 'arm64-v8a':'8a24bbf37ad03a878fe199c9dabcf542fb89b0fecca53c81874964d1682ae619',
 'armeabi-v7a':'6c106fd040674d9510b9dac9db80d362d65886d032f84181c914b17af7c16b03',
}
def align(n,a=16): return (n+a-1)//a*a
class DeltaBuilder:
 def __init__(self,abi):
  self.abi=abi;self.is64=abi=='arm64-v8a';self.original=(BASE/abi/'libgameDSO.so').read_bytes()
  self.sha=hashlib.sha256(self.original).hexdigest()
  if self.sha!=EXPECTED[abi]:raise ValueError('This delta accepts only the shipped v0.7.3 native library')
  self.image=bytearray(self.original);self.elf=ELFFile(io.BytesIO(self.original))
  self.ks=Ks(KS_ARCH_ARM64,KS_MODE_LITTLE_ENDIAN) if self.is64 else Ks(KS_ARCH_ARM,KS_MODE_THUMB)
  self.cs=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN) if self.is64 else Cs(CS_ARCH_ARM,CS_MODE_THUMB)
  loads=[(i,s) for i,s in enumerate(self.elf.iter_segments()) if s['p_type']=='PT_LOAD']
  self.rx_i,self.rx=max(((i,s)for i,s in loads if s['p_flags']==5),key=lambda x:x[1]['p_vaddr'])
  self.rw_i,self.rw=max(((i,s)for i,s in loads if s['p_flags']==6),key=lambda x:x[1]['p_vaddr'])
  if self.rx['p_offset']+self.rx['p_filesz']!=len(self.original):raise ValueError('Unexpected trailing bytes after v0.7.3 payload')
  self.base=align(self.rx['p_vaddr']+self.rx['p_filesz']);self.file_base=self.rx['p_offset']+self.base-self.rx['p_vaddr']
  self.state_base=align(self.rw['p_vaddr']+self.rw['p_memsz'])
  self.state_limit=self.rx['p_vaddr']
  self.extra=bytearray();self.patches=[];self.blocks=[];self.used=set();self.state_size=0
  dyn=self.elf.get_section_by_name('.dynsym');syms=list(dyn.iter_symbols())
  dem=subprocess.run(['c++filt'],input='\n'.join(s.name for s in syms),text=True,capture_output=True,check=True).stdout.splitlines()
  self.symbols={};self.by_name={};self.by_mangled={}
  for s,n in zip(syms,dem):
   if s['st_value'] and s['st_info']['type']=='STT_FUNC':
    self.by_mangled[s.name]=int(s['st_value']);self.by_name.setdefault(n,set()).add(int(s['st_value']))
    self.symbols[n]={'value':int(s['st_value']),'address':int(s['st_value'])&~int(not self.is64),'size':int(s['st_size']),'mangled':s.name}
  plt=self.elf.get_section_by_name('.plt')['sh_addr'];rels=self.elf.get_section_by_name('.rela.plt' if self.is64 else '.rel.plt')
  self.plt={};self.plt_dem={}
  for i,r in enumerate(rels.iter_relocations()):
   s=dyn.get_symbol(r['r_info_sym']);v=int(plt)+32+i*16
   self.plt[s.name]=v
  for n,s in zip(dem,syms):
   if s.name in self.plt:self.plt_dem.setdefault(n,set()).add(self.plt[s.name])
 def resolve(self,name):
  if isinstance(name,dict):return self.resolve(name[self.abi])
  if isinstance(name,int):return name
  if name in self.by_mangled:return self.by_mangled[name]
  values=self.by_name.get(name) or self.plt_dem.get(name)
  if values:
   if len(values)!=1:raise ValueError('Ambiguous symbol; use mangled name: '+name)
   return next(iter(values))
  if name in self.plt:return self.plt[name]
  raise KeyError(name)
 def sym(self,name):return self.resolve(name)&~int(not self.is64)
 def offset(self,address):
  for s in self.elf.iter_segments():
   if s['p_type']=='PT_LOAD' and s['p_vaddr']<=address<s['p_vaddr']+s['p_filesz']:
    return int(s['p_offset']+address-s['p_vaddr'])
  raise ValueError('Unmapped source address '+hex(address))
 def asm(self,text,address):
  b,_=self.ks.asm(text,address)
  if b is None:raise ValueError('Assembler failed')
  return bytes(b)
 def branch(self,source,target,link=False):
  target &= ~int(not self.is64)
  op=('bl' if link else 'b') if self.is64 else ('bl' if link else 'b.w')
  data=self.asm(f'{op} #{target}',source)
  if len(data)!=4:raise ValueError('Expected 4-byte branch')
  return data
 def append(self,name,data):
  while len(self.extra)%4:self.extra.append(0)
  address=self.base+len(self.extra);self.extra.extend(data)
  self.blocks.append({'name':name,'address':address,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
  return address
 def patch(self,address,data,reason,expected=None):
  off=self.offset(address);before=bytes(self.image[off:off+len(data)])
  if isinstance(expected,str):expected=bytes.fromhex(expected)
  if expected is not None and before!=expected:raise ValueError('Unexpected v0.7.3 bytes: '+reason)
  if before!=self.original[off:off+len(data)]:raise ValueError('Overlapping patch: '+reason)
  self.image[off:off+len(data)]=data
  self.patches.append({'address':address,'offset':off,'before':before.hex(),'after':data.hex(),'reason':reason})
 def patch_call(self,address,target,expected):self.patch(address,self.branch(address,target,True),'guarded callsite',expected)
 def trampoline(self,name):
  address=self.sym(name);off=self.offset(address);raw=self.original[off:off+4]
  ins=list(self.cs.disasm(raw,address))
  if not ins or sum(i.size for i in ins)!=4:raise ValueError('Split prologue: '+name)
  # Preserve the previously installed v0.7.3 wrapper instead of discarding it.
  if len(ins)==1 and ins[0].mnemonic in ('b','b.w'):
   return int(ins[0].op_str.replace('#',''),0)|int(not self.is64)
  for i in ins:
   if 'pc' in i.op_str or i.mnemonic.startswith(('b','adr','ldr')):
    raise ValueError('Needs explicit relocated trampoline: '+name+' '+i.mnemonic+' '+i.op_str)
  at=align(self.base+len(self.extra),4)
  return self.append(name+' prior entry',raw+self.branch(at+4,address+4))|int(not self.is64)
 def finish(self,path):
  n=self.base-self.rx['p_vaddr']+len(self.extra)
  pos=int(self.elf['e_phoff']+self.rx_i*self.elf['e_phentsize'])
  struct.pack_into('<QQ' if self.is64 else '<II',self.image,pos+(32 if self.is64 else 16),n,n)
  if self.state_size:
   end=self.state_base+self.state_size
   if end>self.state_limit:raise ValueError('State exceeds verified unused RW padding')
   p=int(self.elf['e_phoff']+self.rw_i*self.elf['e_phentsize'])
   struct.pack_into('<Q' if self.is64 else '<I',self.image,p+(40 if self.is64 else 20),end-self.rw['p_vaddr'])
  self.image.extend(b'\0'*(self.file_base-len(self.image)));self.image.extend(self.extra)
  new=ELFFile(io.BytesIO(self.image))
  if new['e_phnum']!=self.elf['e_phnum']:raise ValueError('Unexpected new load header')
  for s in new.iter_segments():
   if s['p_type']=='PT_LOAD':
    if s['p_flags']&3==3:raise ValueError('Writable executable mapping prohibited')
    if s['p_offset']%s['p_align']!=s['p_vaddr']%s['p_align']:raise ValueError('ELF mapping misalignment')
  allowed=set()
  for p in self.patches:allowed.update(range(p['offset'],p['offset']+len(bytes.fromhex(p['before']))))
  for idx in [self.rx_i,self.rw_i]:
   q=int(self.elf['e_phoff']+idx*self.elf['e_phentsize']);allowed.update(range(q,q+self.elf['e_phentsize']))
  changed=[i for i,(a,b)in enumerate(zip(self.original,self.image))if a!=b]
  if any(i not in allowed for i in changed):raise ValueError('Unlisted modification of shipped v0.7.3 library')
  path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(self.image)
  report={'abi':self.abi,'input_sha256':self.sha,'output_sha256':hashlib.sha256(self.image).hexdigest(),'patches':self.patches,'blocks':self.blocks,'state_base':self.state_base,'state_size':self.state_size,'changed_original_bytes':len(changed),'unlisted_original_changes':0,'original_addresses_and_relocations_preserved':True,'runtime_verified':False}
  path.with_suffix('.delta.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
  return report

def module_at(name):
 path=ROOT/name/'module.py';s=importlib.util.spec_from_file_location('delta_'+name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def build(abi,modules):
 b=DeltaBuilder(abi);bindings={};hooks={};sources=[]
 for name,m in modules:
  hooks.update(getattr(m,'HOOKS',{}))
  for a,n in {**getattr(m,'BINDINGS',{}),**getattr(m,'RAW_BINDINGS',{})}.items():
   v=b.resolve(n)
   if a in bindings and bindings[a]!=v:raise ValueError('Conflicting binding '+a)
   bindings[a]=v
  ss=getattr(m,'SOURCES',None)
  sources.extend(map(str,ss if ss is not None else sorted((ROOT/name).glob('*_payload.c'))))
 for export,name in hooks.items():
  if name in b.used:raise ValueError('Duplicate entry hook '+name)
  bindings['old_'+export]=b.trampoline(name);b.used.add(name)
 # Bound C function aliases retain Thumb/ARM state from the real ELF symbols.
 work=ROOT/'build/native'/abi;work.mkdir(parents=True,exist_ok=True)
 asm=['.text']
 for a,v in bindings.items():asm += [f'.global {a}',f'.hidden {a}',f'.type {a}, %function',f'.set {a}, {v}']
 (work/'bindings.S').write_text('\n'.join(asm)+'\n')
 start=align(b.base+len(b.extra))
 script=f'''PHDRS {{ code PT_LOAD FLAGS(5); state PT_LOAD FLAGS(6); }}
SECTIONS {{
 . = {start};
 .payload : {{ *(.text .text.*) *(.rodata .rodata.*) }} :code
 . = {b.state_base};
 .state (NOLOAD) : {{ *(.bss .bss.*) *(COMMON) }} :state
 .unexpected_data : {{ *(.data .data.*) *(.got .got.*) }} :state
 /DISCARD/ : {{ *(.eh_frame*) *(.ARM.exidx*) *(.ARM.extab*) *(.comment) *(.note*) }}
}}
'''
 (work/'payload.ld').write_text(script)
 zig=ROOT/'tools/python/ziglang/zig'
 target=['-target','aarch64-freestanding-none']if b.is64 else ['-target','thumb-freestanding-eabi','-mcpu=cortex_a7']
 command=[str(zig),'cc',*target,'-Oz','-fPIC','-ffreestanding','-fno-builtin','-fno-lto','-fno-stack-protector','-fno-unwind-tables','-fno-asynchronous-unwind-tables','-fvisibility=hidden','-fno-ident','-nostdlib','-static','-g','-Wl,--no-undefined','-Wl,--no-gc-sections','-Wl,-no-pie','-Wl,-e,v074_backup_ready','-Wl,--build-id=none','-Wl,-T,'+str(work/'payload.ld'),'-I'+str(ROOT/'core'),*sources,str(work/'bindings.S'),'-o',str(work/'payload.elf')]
 r=subprocess.run(command,text=True,capture_output=True);(work/'compiler.log').write_text(r.stdout+r.stderr)
 if r.returncode:raise RuntimeError(r.stderr)
 elf=ELFFile(io.BytesIO((work/'payload.elf').read_bytes()))
 for s in elf.iter_sections():
  if s['sh_type'] in ('SHT_REL','SHT_RELA')and s['sh_size']:raise ValueError('Unresolved relocation')
  if s['sh_flags']&2 and s.name not in ('.payload','.state')and s['sh_size']:raise ValueError('Unexpected allocated section: '+s.name)
 sec=elf.get_section_by_name('.payload');state=elf.get_section_by_name('.state')
 if sec['sh_addr']!=start:raise ValueError('Link address mismatch')
 while b.base+len(b.extra)<start:b.extra.append(0)
 b.append('v0.7.5 additive payload',sec.data());b.state_size=int(state['sh_size'])if state else 0
 syms={s.name:int(s['st_value'])for s in elf.get_section_by_name('.symtab').iter_symbols()if s['st_value']}
 for export,name in hooks.items():b.patch(b.sym(name),b.branch(b.sym(name),syms[export]),'v0.7.5 entry '+name)
 for _,m in modules:
  if hasattr(m,'install'):m.install(b,syms)
 report=b.finish(ROOT/'build/overlay/lib'/abi/'libgameDSO.so')
 manifest={'abi':abi,'symbols':syms,'bindings':bindings,'hooks':hooks,'base':start,'sources':sources,'state_size':b.state_size,'report':report}
 (work/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'abi':abi,'patches':len(b.patches),'payload_bytes':len(sec.data()),'state_bytes':b.state_size,'sha256':report['output_sha256']}))
 return manifest
if __name__=='__main__':
 names=sys.argv[1:] or ['core','pitcher','title','info']
 modules=[(n,module_at(n))for n in names]
 for abi in EXPECTED:build(abi,modules)
