#ifndef YAGU_V074_API_H
#define YAGU_V074_API_H
typedef unsigned char v074_u8;
typedef unsigned short v074_u16;
typedef unsigned int v074_u32;
typedef unsigned long long v074_u64;
typedef __UINTPTR_TYPE__ v074_uptr;
#define V074_API __attribute__((visibility("hidden")))
V074_API int v074_backup_ready(void);
V074_API void *v074_my_batter(void);
V074_API void *v074_my_pitcher(void);
V074_API int v074_god_selected(void);
V074_API int v074_set_god_selected(int selected);
V074_API int v074_legacy_rhp_active(void);
V074_API int v074_new_career_created(void);
V074_API void v074_open_patch_manager(void);
V074_API const char *v074_god_name(void);
V074_API const char *v074_god_description(void);
V074_API const char *v074_batter_label(void);
V074_API const char *v074_pitcher_label(void);
V074_API int v075_bat_hand(void);
V074_API int v075_pitch_hand(void);
V074_API int v075_set_creation_hands(int bat_left, int pit_left);
#endif
