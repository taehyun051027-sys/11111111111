from pathlib import Path
SOURCES=[str(Path(__file__).with_name('core_payload.c'))]
HOOKS={}
BINDINGS={
 'v075_data_manager':'CGsSingleton<CBBGDataMgr>::GetInstPtr()',
 'v075_game_mode':'CBBGStatic::GetCurGameMode()',
 'v075_jni_env':'CCGX_Native_GetJNIEnv',
 'v075_jni_find':'_JNIEnv::FindClass(char const*)',
 'v075_jni_method':'_JNIEnv::GetStaticMethodID(_jclass*, char const*, char const*)',
 'v075_jni_int':'_JNIEnv::CallStaticIntMethod(_jclass*, _jmethodID*, ...)',
 'v075_jni_void':'_JNIEnv::CallStaticVoidMethod(_jclass*, _jmethodID*, ...)',
 'v075_jni_object':'_JNIEnv::CallStaticObjectMethod(_jclass*, _jmethodID*, ...)',
}
