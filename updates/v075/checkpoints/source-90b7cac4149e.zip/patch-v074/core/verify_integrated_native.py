"""Execute final integrated native payload and real JNI C++ wrappers.

The VM's function-table services are callbacks, not an Android VM. Original
_JNIEnv::FindClass/GetStaticMethodID/CallStatic*Method bodies execute unmodified,
including the AArch64 and Thumb varargs adapters. No real save/device access.
"""
from pathlib import Path
import hashlib
import io
import json
import struct
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT / 'tools/python'))
from elftools.elf.elffile import ELFFile
from unicorn import Uc, UC_ARCH_ARM, UC_ARCH_ARM64, UC_MODE_THUMB, UC_MODE_ARM, UC_HOOK_CODE
from unicorn import UC_PROT_READ, UC_PROT_WRITE, UC_PROT_EXEC
from unicorn import arm_const as ar, arm64_const as a64
from capstone import Cs, CS_ARCH_ARM, CS_ARCH_ARM64, CS_MODE_THUMB, CS_MODE_LITTLE_ENDIAN
from delta_builder import DeltaBuilder, module_at, build

HEAP, STACK, STOP = 0x60000000, 0x61000000, 0x62000000
SP = STACK + 0x80000
MGR, TEAMS, SAVE = HEAP + 0x1000, HEAP + 0x10000, HEAP + 0x30000
ENV, TABLE, CLS, EXCEPTION, METHOD = [HEAP + x for x in (0x80000, 0x81000, 0x85000, 0x85080, 0x86000)]
TLS, VM_CALLBACK = HEAP + 0x8f000, HEAP + 0xf0000
METHODS = {
    'getFlags': '()I', 'getHands': '()I', 'setHands': '(II)I', 'setGodSelected': '(I)I',
    'newCareerCreated': '()I', 'getText': '(I)Ljava/lang/String;', 'openManager': '()V',
}


def align(n, size=4096): return (n + size - 1) // size * size


class Case:
    def __init__(self, abi, manifest, slide):
        self.abi, self.slide, self.manifest = abi, slide, manifest
        self.is64 = abi == 'arm64-v8a'
        self.ptr_size = 8 if self.is64 else 4
        self.symbols, self.bindings = manifest['symbols'], manifest['bindings']
        raw = (ROOT / 'build/overlay/lib' / abi / 'libgameDSO.so').read_bytes()
        self.elf = ELFFile(io.BytesIO(raw))
        self.uc = Uc(UC_ARCH_ARM64, UC_MODE_ARM) if self.is64 else Uc(UC_ARCH_ARM, UC_MODE_THUMB)
        self.regs = [getattr(a64, 'UC_ARM64_REG_X' + str(i)) for i in range(31)] if self.is64 else [getattr(ar, 'UC_ARM_REG_R' + str(i)) for i in range(13)]
        self.pc = a64.UC_ARM64_REG_PC if self.is64 else ar.UC_ARM_REG_PC
        self.sp = a64.UC_ARM64_REG_SP if self.is64 else ar.UC_ARM_REG_SP
        self.lr = a64.UC_ARM64_REG_X30 if self.is64 else ar.UC_ARM_REG_LR
        size = align(max(s['p_vaddr'] + s['p_memsz'] for s in self.elf.iter_segments() if s['p_type'] == 'PT_LOAD'))
        self.uc.mem_map(slide, size)
        for segment in self.elf.iter_segments():
            if segment['p_type'] == 'PT_LOAD':
                self.uc.mem_write(slide + segment['p_vaddr'], raw[segment['p_offset']:segment['p_offset'] + segment['p_filesz']])
        for address in [HEAP, STACK]: self.uc.mem_map(address, 0x100000)
        self.uc.mem_map(STOP, 4096)
        if self.is64:
            self.uc.reg_write(a64.UC_ARM64_REG_TPIDR_EL0, TLS)
            self.ptr(TLS + 0x28, 0x12345678)
        else:
            self.uc.reg_write(ar.UC_ARM_REG_C1_C0_2, 0xf00000)
            self.uc.reg_write(ar.UC_ARM_REG_FPEXC, 0x40000000)
            self.ptr(TLS, 0x12345678)
        # Android linker relative relocations plus the external stack protector
        # slot needed by the original Thumb JNI C++ varargs wrappers.
        dyn = self.elf.get_section_by_name('.dynsym')
        for section in self.elf.iter_sections():
            if section['sh_type'] not in ('SHT_REL', 'SHT_RELA'): continue
            for rel in section.iter_relocations():
                address, kind = slide + rel['r_offset'], rel['r_info_type']
                if kind == (1027 if self.is64 else 23):
                    addend = rel['r_addend'] if section['sh_type'] == 'SHT_RELA' else self.get_ptr(address)
                    self.ptr(address, slide + addend)
                symbol = dyn.get_symbol(rel['r_info_sym']).name if rel['r_info_sym'] else ''
                if symbol == '__stack_chk_guard': self.ptr(address, TLS)
        # Use ELF permissions. No payload byte may be writable at runtime.
        for segment in self.elf.iter_segments():
            if segment['p_type'] != 'PT_LOAD': continue
            start = segment['p_vaddr'] // 4096 * 4096
            end = align(segment['p_vaddr'] + segment['p_memsz'])
            flags = segment['p_flags']
            protection = (UC_PROT_READ if flags & 4 else 0) | (UC_PROT_WRITE if flags & 2 else 0) | (UC_PROT_EXEC if flags & 1 else 0)
            self.uc.mem_protect(slide + start, end - start, protection)
        self.uc.mem_write(TEAMS, bytes((i * 13 + 7) % 256 for i in range(0x8000)))
        self.uc.mem_write(SAVE, bytes((i * 7 + 3) % 256 for i in range(0x20000)))
        self.ptr(MGR + (0x528 if self.is64 else 0x4e8), SAVE)
        self.ptr(MGR + (0x530 if self.is64 else 0x4ec), TEAMS)
        self.uc.mem_write(TEAMS + 4, struct.pack('<I', 4))
        team = TEAMS + 8 + 4 * 0x3b4
        self.uc.mem_write(team, bytes([4, 0, 8, 12]))
        for i in range(8): self.uc.mem_write(team + 4 + i * 52, struct.pack('<H', 200 + i))
        for i in range(12): self.uc.mem_write(team + 0x1a4 + i * 44, struct.pack('<H', 300 + i))
        self.bat, self.pit = team + 0x1a4 + 5 * 44, team + 4 + 3 * 52
        self.uc.mem_write(self.bat, struct.pack('<H', 1000))
        self.uc.mem_write(self.pit, struct.pack('<H', 1100))
        self.uc.mem_write(self.bat + 0x23, b'\x11')
        self.uc.mem_write(self.pit + 0x23, b'\x25')
        self.ptr(ENV, TABLE)
        self.callbacks, self.events = {}, []
        self.flags, self.hands, self.mode = 3, 2, 4
        self.env_exists, self.fail, self.exception = True, '', 0
        self.refs, self.calls, self.released = {}, 0, 0
        self.texts = ['야구신', '양투양타의 야구신. 모든 능력치 ∞', '타자', '투수']
        self.cb('v075_jni_env', lambda: self.ret(ENV if self.env_exists else 0))
        self.cb('v075_data_manager', lambda: self.ret(MGR))
        self.cb('v075_game_mode', lambda: self.ret(self.mode))
        for index, callback in {6: self.find_class, 113: self.method,
                130: self.call_int, 115: self.call_object, 142: self.call_void,
                15: self.exception_occurred, 17: self.clear, 23: self.delete,
                169: self.string_chars, 170: self.release}.items():
            address = VM_CALLBACK + index * 16
            self.ptr(TABLE + index * self.ptr_size, address | int(not self.is64))
            self.callbacks[address] = callback
        self.uc.hook_add(UC_HOOK_CODE, self.oncode)

    def ptr(self, address, value):
        self.uc.mem_write(address, struct.pack('<Q' if self.is64 else '<I', value))

    def get_ptr(self, address):
        return struct.unpack('<Q' if self.is64 else '<I', self.uc.mem_read(address, self.ptr_size))[0]

    def cb(self, name, callback): self.callbacks[self.slide + (self.bindings[name] & ~1)] = callback

    def r(self, index, value=None):
        if value is not None: self.uc.reg_write(self.regs[index], value)
        return self.uc.reg_read(self.regs[index])

    def text(self, address, limit=512):
        return bytes(self.uc.mem_read(address, limit)).split(b'\0', 1)[0].decode()

    def ret(self, value):
        destination = self.uc.reg_read(self.lr)
        self.r(0, value & (0xffffffffffffffff if self.is64 else 0xffffffff))
        self.uc.reg_write(self.pc, destination)

    def oncode(self, uc, address, size, _):
        if address == STOP: uc.emu_stop()
        elif address in self.callbacks: self.callbacks[address]()

    def add_ref(self, pointer): self.refs[pointer] = self.refs.get(pointer, 0) + 1

    def exception_occurred(self):
        assert self.r(0) == ENV
        if self.exception: self.add_ref(EXCEPTION)
        self.ret(self.exception)

    def clear(self):
        assert self.r(0) == ENV
        self.exception = 0
        self.events.append(('clear_exception',))
        self.ret(0)

    def delete(self):
        assert self.r(0) == ENV
        pointer = self.r(1)
        assert self.refs.get(pointer, 0) > 0, ('unowned JNI local ref deletion', hex(pointer))
        self.refs[pointer] -= 1
        self.ret(0)

    def find_class(self):
        assert self.r(0) == ENV and self.text(self.r(1)) == 'com/taehyun/yagu/patch/PatchBridge'
        if self.fail == 'class':
            self.exception = EXCEPTION
            self.ret(0)
        else:
            self.add_ref(CLS)
            self.ret(CLS)

    def method(self):
        assert (self.r(0), self.r(1)) == (ENV, CLS)
        name, signature = self.text(self.r(2)), self.text(self.r(3))
        assert METHODS.get(name) == signature, (name, signature)
        self.events.append(('method', name, signature))
        if self.fail == 'method':
            self.exception = EXCEPTION
            self.ret(0)
        else: self.ret(METHOD + list(METHODS).index(name) * 16)

    def varargs(self, count):
        value = self.r(3)
        if self.is64:
            stack, gr_top, vr_top, gr_offset, vr_offset = struct.unpack('<QQQii', self.uc.mem_read(value, 32))
            out = []
            for _ in range(count):
                address = gr_top + gr_offset if gr_offset < 0 else stack
                out.append(struct.unpack('<i', self.uc.mem_read(address, 4))[0])
                if gr_offset < 0: gr_offset += 8
                else: stack += 8
            return out
        return [struct.unpack('<i', self.uc.mem_read(value + 4 * i, 4))[0] for i in range(count)]

    def call_int(self):
        assert (self.r(0), self.r(1)) == (ENV, CLS)
        name = list(METHODS)[(self.r(2) - METHOD) // 16]
        argc = 2 if name == 'setHands' else 1 if name == 'setGodSelected' else 0
        args = self.varargs(argc)
        self.events.append(('int', name, *args))
        if self.fail == 'invoke':
            self.exception = EXCEPTION
            self.ret(-1)
        elif name == 'getFlags': self.ret(self.flags)
        elif name == 'getHands': self.ret(self.hands)
        elif name == 'setHands':
            self.hands = args[0] | (args[1] << 2)
            self.ret(1)
        elif name == 'setGodSelected':
            self.flags = (self.flags & ~2) | (2 if args[0] else 0)
            self.ret(1)
        elif name == 'newCareerCreated': self.ret(1)
        else: raise AssertionError(name)

    def call_object(self):
        assert (self.r(0), self.r(1), self.r(2)) == (ENV, CLS, METHOD + list(METHODS).index('getText') * 16)
        index = self.varargs(1)[0]
        assert 0 <= index < 4
        reference = HEAP + 0x88000 + index * 16
        self.add_ref(reference)
        self.events.append(('getText', index))
        self.ret(reference)

    def call_void(self):
        assert (self.r(0), self.r(1), self.r(2)) == (ENV, CLS, METHOD + list(METHODS).index('openManager') * 16)
        self.events.append(('openManager',))
        self.ret(0)

    def string_chars(self):
        assert self.r(0) == ENV and self.r(2) == 0
        index = (self.r(1) - (HEAP + 0x88000)) // 16
        pointer = HEAP + 0x90000 + index * 256
        self.uc.mem_write(pointer, self.texts[index].encode() + b'\0')
        self.ret(pointer)

    def release(self):
        assert self.r(0) == ENV
        index = (self.r(1) - (HEAP + 0x88000)) // 16
        assert self.r(2) == HEAP + 0x90000 + index * 256
        self.released += 1
        self.ret(0)

    def call(self, name, *args):
        self.uc.reg_write(self.sp, SP)
        self.uc.reg_write(self.lr, STOP | int(not self.is64))
        for index, value in enumerate(args):
            if index < (8 if self.is64 else 4): self.r(index, value & (0xffffffffffffffff if self.is64 else 0xffffffff))
            else: self.uc.mem_write(SP + (index - 4) * 4, struct.pack('<I', value & 0xffffffff))
        address = (self.symbols[name] & ~int(not self.is64)) + self.slide
        try: self.uc.emu_start(address | int(not self.is64), 0, count=50000)
        except Exception as error:
            raise AssertionError((self.abi, name, hex(self.uc.reg_read(self.pc)), self.events[-6:])) from error
        assert self.uc.reg_read(self.pc) == STOP, (name, 'did not return')
        assert self.uc.reg_read(self.sp) == SP, 'stack imbalance'
        assert sum(self.refs.values()) == 0, ('JNI local reference leak', self.refs)
        self.calls += 1
        return self.r(0)

    def saved_hash(self):
        return hashlib.sha256(bytes(self.uc.mem_read(TEAMS, 0x8000)) + bytes(self.uc.mem_read(SAVE, 0x20000))).hexdigest()


def verify_case(abi, manifest, slide):
    case = Case(abi, manifest, slide)
    before = case.saved_hash()
    assert case.call('v074_backup_ready') == 1
    assert case.call('v074_god_selected') != 0
    for flags in (0, 1, 2, 3, 0x7fffffff):
        case.flags = flags
        assert case.call('v074_backup_ready') == (flags & 1)
        assert bool(case.call('v074_god_selected')) == bool((flags & 1) and (flags & 2))
    case.flags = 3
    for hands in range(16):
        case.hands = hands
        for role, function in [(0, 'v075_bat_hand'), (1, 'v075_pitch_hand')]:
            expected = (hands >> (role * 2)) & 3
            if expected >= 2: expected = 0xffffffff
            assert case.call(function) & 0xffffffff == expected
    for bat, pit in [(0, 0), (0, 1), (1, 0), (1, 1)]:
        assert case.call('v075_set_creation_hands', bat, pit) == 1
        assert case.events[-1] == ('int', 'setHands', bat, pit)
        assert case.hands == bat | (pit << 2)
    for bat, pit in [(-1, 0), (0, 2), (2, 2)]:
        events = list(case.events)
        assert case.call('v075_set_creation_hands', bat, pit) == 0
        assert case.events == events
    assert case.call('v074_set_god_selected', 0) == 1 and case.flags == 1
    assert case.call('v074_set_god_selected', 1) == 1 and case.flags == 3
    assert case.call('v074_new_career_created') == 1
    case.call('v074_open_patch_manager')
    assert case.events[-1] == ('openManager',)
    for function, expected in zip(['v074_god_name', 'v074_god_description', 'v074_batter_label', 'v074_pitcher_label'], case.texts):
        assert case.text(case.call(function)) == expected
    assert case.released == 4 and sum(e[0] == 'getText' for e in case.events) == 4
    assert case.call('v074_my_batter') == case.bat
    assert case.call('v074_my_pitcher') == case.pit
    for mode in [1, 2, 3, 5, 6]:
        case.mode = mode
        assert case.call('v074_my_batter') == 0 and case.call('v074_my_pitcher') == 0
    case.mode = 4
    assert case.call('v074_title_count') == 84
    assert case.call('v074_title_owned', SAVE + 8, 83) == 1
    assert case.call('v074_title_owned', SAVE + 12, 83) == 0
    for actor in [case.bat, case.pit]:
        assert case.call('v074_title_display_get', actor) == 83
    assert case.text(case.call('v074_title_name', 83, 1)) == '야구신'
    assert case.text(case.call('v074_title_effect', 83, 0)) == '모든 능력치 ∞'
    case.flags = 1
    assert case.call('v074_title_display_get', case.bat) == 17
    assert case.call('v074_title_display_get', case.pit) == 37
    case.call('v074_title_set', case.bat, 83)
    assert case.flags == 3
    # JNI errors clear the pending exception and drop all local references;
    # code fails closed and never turns backup_ready on after an error.
    for fail in ['class', 'method', 'invoke']:
        case.fail = fail
        assert case.call('v074_backup_ready') == 0
        assert case.exception == 0
    case.fail = ''
    case.env_exists = False
    assert case.call('v074_backup_ready') == 0
    assert case.call('v075_pitch_hand') & 0xffffffff == 0xffffffff
    assert case.saved_hash() == before
    return {'slide': hex(slide), 'native_calls': case.calls, 'save_fixture_sha256': before,
            'real_jni_cpp_wrappers_executed': True, 'jni_slots': [6, 15, 17, 23, 113, 115, 130, 142, 169, 170],
            'aapcs_varargs_verified': True, 'jni_local_refs_leaked': 0,
            'title_with_real_core_api_verified': True, 'physical_android_verified': False}


def audit(abi, manifest):
    original = DeltaBuilder(abi)
    updated_bytes = (ROOT / 'build/overlay/lib' / abi / 'libgameDSO.so').read_bytes()
    updated = ELFFile(io.BytesIO(updated_bytes))
    for name in ['.dynsym', '.dynstr', '.dynamic', '.rela.dyn', '.rela.plt', '.rel.dyn', '.rel.plt']:
        a, b = original.elf.get_section_by_name(name), updated.get_section_by_name(name)
        if a: assert b and a.data() == b.data(), name
    inherited, trampolines = [], []
    for export, symbol in manifest['hooks'].items():
        entry = original.sym(symbol)
        raw = original.original[original.offset(entry):original.offset(entry) + 4]
        ins = list(original.cs.disasm(raw, entry))
        target = manifest['bindings']['old_' + export] & ~int(not original.is64)
        if len(ins) == 1 and ins[0].mnemonic in ('b', 'b.w'):
            assert target == int(ins[0].op_str[1:], 0)
            inherited.append(symbol)
        else:
            off = original.rx['p_offset'] + target - original.rx['p_vaddr']
            assert updated_bytes[off:off + 4] == raw
            branch = list(original.cs.disasm(updated_bytes[off + 4:off + 8], target + 4))[0]
            assert int(branch.op_str[1:], 0) == entry + 4
            trampolines.append(symbol)
    assert manifest['state_size'] <= original.state_limit - original.state_base
    assert manifest['report']['unlisted_original_changes'] == 0
    # Exercise the builder's prior-wrapper path against two actual v0.7.3
    # entries, even though the new title/info entry hooks need prologues.
    prior_wrapper_samples = {}
    for symbol in ['CBBGDataMgr::GetRaisePitcher()',
                   'CBBGPlayerData::GetStatus(EnumBodyPart, unsigned char, unsigned char)']:
        entry = original.sym(symbol)
        raw = original.original[original.offset(entry):original.offset(entry) + 4]
        instruction = list(original.cs.disasm(raw, entry))[0]
        assert instruction.mnemonic in ('b', 'b.w')
        expected = int(instruction.op_str[1:], 0) | int(not original.is64)
        length = len(original.extra)
        assert original.trampoline(symbol) == expected and len(original.extra) == length
        prior_wrapper_samples[symbol] = hex(expected)
    return {'inherited_v073_wrappers': inherited, 'relocated_prologues': len(trampolines),
            'existing_v073_wrapper_targets_checked': prior_wrapper_samples,
            'dynamic_tables_unchanged': True, 'state_bytes': manifest['state_size'],
            'state_capacity_bytes': original.state_limit - original.state_base,
            'original_unlisted_byte_changes': 0}


def main():
    modules = [(name, module_at(name)) for name in ['core', 'pitcher', 'title', 'info']]
    report = {'version': 'v075', 'test_boundary': 'Native instructions and JNI ABI with VM/UI services simulated',
              'abis': [], 'physical_android_verified': False}
    for abi in ['arm64-v8a', 'armeabi-v7a']:
        manifest = build(abi, modules)
        report['abis'].append({'abi': abi, 'library_sha256': manifest['report']['output_sha256'],
            'audit': audit(abi, manifest), 'cases': [verify_case(abi, manifest, slide) for slide in [0x10000000, 0x38000000]]})
    path = HERE / 'integrated-verification.json'
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__': main()
