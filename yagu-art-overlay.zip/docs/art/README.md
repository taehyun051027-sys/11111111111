# 야구 — native-consumed artwork and identity overlay

## Deliverable

`overlay-v1/` contains **1,402 APK entries**. Merge its directory tree at the root
of the decoded/repacked APK. This overlay requires the parent native patch:
adding the files alone does not select the new team palettes or appended crests.
The original APK was read only; its SHA-256 remains:

`2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484`

Do not use `overlay/`: that is a superseded, incomplete first packing attempt.

## Exact identities

| Native team ID | Display name | Body palette | Helmet palette |
|---:|---|---|---|
| 0 | 알파 | blue | blue |
| 1 | 베타 | crimson | crimson |
| 2 | 감마 | emerald | emerald |
| 3 | 델타 | violet | violet |
| 4 | Original Pumas / 대구푸마즈 | original | original |
| 5 | 엡실론 | gold | gold |
| 6 | 제타 | cyan | cyan |
| 7 | 에타 | graphite | graphite |
| 8 | 세타 | navy | navy |
| 9 | 요타 | silver | silver |
| 10 | 입실론 | coral | coral |
| 11 | 파이 | blue | crimson |
| 12 | 카이 | violet | graphite |
| 13 | 프사이 | gold | emerald |
| 14 | 오메가 | blue | navy |

All six common string tables contain the exact requested Korean opponent names;
Pumas retains its original localized string. Native league kind9 (common string24)
is labeled Universal League / 유니버셜 리그. Selecting/unlocking it is native logic.

Players are numbered in ascending original-ID order without zero padding:
IDs1–180 map to1–180; IDs400–519 map to181–300; IDs800–804 map to301–305;
IDs810–814 map to306–310. My Player1000 and1100 are excluded. Existing save-name
overrides require the parent's runtime GetName hook.

Common strings330/426 and the explicit My Batter phrases in Mainmenu/RaiseYearUI
become localized two-way labels. Common331/427 (legacy My Pitcher) are retained.
The exact original and new UI fields are recorded in the manifest.

## Art consumed by native resource paths

- `assets/ui/CC_Team_Symbol_Parts.png/.pzc`: original1024×1024 pixels are retained
  in the top half of a1024×2048 atlas. Original61 images and55 frames are retained;
  append15images/frames. Frame55+team selects each new crest; reserved team4 is unused.
- `assets/bat/level_0/color_{10+team}/` and the corresponding `pit` folder:
  42generated component PNGs and their original PZC metadata per opponent team.
- `assets/defender/team_{team}/`: head, body, calves, stripes, arm, and leg PNG/PZC
  pairs per opponent. Original defender colour folders are unchanged.
- Eleven shared face/hair/skin PNGs replace their root paths. These are new shared
  component bases, not310individually painted portraits. Any player using these
  default resources—including My Player or Pumas—sees the new shared appearance.
- `assets/title/title_back.png`: image rect9 (Korean title) and rect14 (English
  title) both contain the new 야구 badge within the original frame bounds.
- Six launcher PNGs at resolved manifest densities120–640 are replaced.

The duplicate default mapping tables are changed as both `.dat` (native direct
consumer) and `.zt1`: Xlsteam_emblem_info, XlsBatterTeamUniformColorCombi,
XlsPitcherTeamUniformColorCombi. Team4's rows remain byte-for-byte original.

## Required native contracts

`CBBGTeamEditMgr::GetIdxOfTeamSymbol(layer, team)`:
for team!=4, layer0→55+team; layers1/2/3→-128; layer4→0. Preserve team4.

`CBBGTeamEditMgr::GetUniformPal(layer, team)`:
for team!=4, layers3,4,6,9,10,12,14,15,16,19,20,22,24,25,26,27,29,30→10+team.
Other layers retain their original value.

`CBBGCcPlayerRes::LoadResPlayerUniform(team,isBatter,costumeLevel,force)`:
normalize the costumeLevel argument to0 for opponents. For LoadResPlayerEquip,
normalize equipLevel to0 only for head/equipKind0. Extra GameRun resource lookup
hooks should select the new palettes directly for all generated garment parts.

Defender original path list uses8entries per palette. Entries0..5 are head,
body, calves, stripes, arm, leg. A64 MakeDefenderPZXMgr colour-dependent lookups
are at520b44,520b68,520b8c,520bb0,520bd4,520bf8 and
520ec4,520f24,520f84,520fe4,521044,5210a4. The native helper returns
`defender/team_N/{part}.pzc`, not a PNG path. Fixed ball/shadow/sliding lookups
must remain original; their IDs collide numerically with new palette10.

Additional live GameRun combination paths also derive legacy static resource IDs
from GetUniformPal. These need the parent's two extra hooks; simply letting
palette10–24 enter the old lookup table can select unrelated costumes.
`game_run_part_paths.json` documents the exact26batter/25pitcher part order.
`game_run_resources.txt` and its Thumb counterpart contain original instructions.

## Export and validation

Illustrations were created with the image generation tool. The Python packer
performs export conditioning only: crops, scales, packs the generated images,
and applies original alpha silhouettes to preserve skeleton joints/frame bounds.
Generated transparent gaps are filled with nearest generated opaque RGB samples;
original RGB is not used to repaint the new uniforms. The manifest records
coverage measurements, including one empty tiny defender frame whose colour was
extended from neighbouring generated samples.

Static checks passed673PNG/PZC pairs, with all source rectangles inside their
texture bounds. ZT1 streams, GST2 offsets and supported GXL schema sizes parse
strictly after editing.310player names are unique decimal strings. Pumas mapping
rows, original crest pixels, uniform paths, and defender paths remain preserved.

**Runtime verification is pending in this artifact.** Static atlas validation
cannot establish perfect animation appearance, texture packing capacity,
font glyph rendering, or the correctness of the parent native hooks. Equipment
and hair resources outside the normalized/default paths may remain original.
Do not describe this as fully tested until the integrated APK is exercised.

## Files for reproducibility

- `tools/build_art_overlay.py`: SHA-gated packer and identity transformer.
- `generated/`: actual image-generation source PNGs.
- `*_reference_slots.json`: exact extraction/packing slot maps.
- `art_overlay_manifest.json`: all output hashes, source provenance, UI edits,
  palette assignments, export measurements and static validation.
- `team_and_player_identity.json`: compact exact naming map.
- `analysis/data/tools/zt1_codec.py` in the parent workspace supplies strict codecs.

Run the packer with a fresh output directory:

```sh
python3 build-work/art/tools/build_art_overlay.py \
  --apk upload/baseball-superstars-2013-1-2-9.apk \
  --out build-work/art/overlay-regenerated
```

The APK is never overwritten. The generated source PNGs are reused exactly;
regeneration of illustrations is not required to reproduce the overlay.

## Public source snapshot v1.2

The installable overlay is `overlays/art` and contains 1,408 unique APK entries.
It merges 1,402 base entries with the twelve-file brand delta; six common tables
replace existing entries and six main-frame tables are new overlay entries.
The merged manifest is `docs/art/art_overlay_manifest.json`. The historical base
manifest beside the exporter describes the 1,402-entry base only.

All four legacy GameRun clothing path hooks and all twelve defender path hooks
are included in candidate4 source. The earlier required-contract section records
the observations that informed these hooks; it is not a claim that runtime
animation has passed. The regenerated source artwork and both native ABIs were
independently rebuilt; see `verification/rebuild_verification.json`.
