"""Execute the compiled payload at nonzero ELF load biases in Unicorn.

This verifies authored PIC code, read-only state addressing, entry branches,
original-call bindings, and selected original leaf methods. Android's dynamic
linker and the complete game are not emulated; external service calls use
documented callbacks. The zero-bias image is deliberately unmapped, so an
accidental absolute reference into it fails instead of succeeding silently.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder, align
from payload_builder import add_payload, HOOKS, BINDINGS
from gameplay_hooks import add_gameplay_hooks
from verify_gameplay_hooks import Case, HEAP, MGR, BATTER, STOP, SP
from unicorn import UC_PROT_READ, UC_PROT_EXEC

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
TEAMS = HEAP + 0x20000
SAVE = HEAP + 0x40000
TEAM = TEAMS + 8 + 4 * 0x3b4
BAT = TEAM + 0x1a4 + 5 * 44
PIT = TEAM + 4
RECORD = SAVE + 0xe8c + 4 * 256
MODE = SAVE + 8


class RelocatedCase(Case):
    def __init__(self, builder, slide):
        super().__init__(builder)
        self.slide = slide
        size = align(builder.base + len(builder.extra))
        self.uc.mem_map(slide, size)
        for segment in builder.elf.iter_segments():
            if segment['p_type'] == 'PT_LOAD':
                off = segment['p_offset']
                self.uc.mem_write(slide + segment['p_vaddr'],
                                  bytes(builder.image[off:off + segment['p_filesz']]))
        self.uc.mem_write(slide + builder.base, bytes(builder.extra))
        self.uc.mem_unmap(0, size)
        self.uc.mem_protect(slide, size, UC_PROT_READ | UC_PROT_EXEC)
        self.callbacks = {address + slide: callback
                          for address, callback in self.callbacks.items()}

    def run_relative(self, address):
        super().run(address + self.slide)


def prepare_case(builder, slide):
    c = RelocatedCase(builder, slide)
    c.ptr(MGR + (0x530 if builder.is64 else 0x4ec), TEAMS)
    c.ptr(MGR + (0x528 if builder.is64 else 0x4e8), SAVE)
    c.uc.mem_write(TEAMS + 4, struct.pack('<i', 4))
    c.uc.mem_write(TEAM, bytes([4, 0, 8, 12]))
    for index in range(8):
        actor = TEAM + 4 + index * 52
        c.uc.mem_write(actor, bytes([0xa5]) * 52)
        c.uc.mem_write(actor, struct.pack('<H', 400 + index))
        c.uc.mem_write(actor + 0x13, bytes([index]))
    for index in range(12):
        actor = TEAM + 0x1a4 + index * 44
        c.uc.mem_write(actor, bytes([0x5a]) * 44)
        c.uc.mem_write(actor, struct.pack('<H', index + 1))
        c.uc.mem_write(actor + 0x13, bytes([index]))
    c.uc.mem_write(BAT, struct.pack('<H', 1000))
    c.uc.mem_write(BAT + 2, b'MyPlayer\0' + bytes(8))
    return c


def verify_slide(builder, payload, slide):
    c = prepare_case(builder, slide)
    symbols = payload['symbols']
    bindings = payload['original_bindings']
    checks = []
    calls = 0

    def call_address(relative, *args):
        nonlocal calls
        calls += 1
        c.stopped = None
        c.uc.reg_write(c.sp, SP)
        c.uc.reg_write(c.lr, STOP if builder.is64 else STOP | 1)
        mask = (1 << (64 if builder.is64 else 32)) - 1
        for index, arg in enumerate(args):
            if index < (8 if builder.is64 else 4):
                c.r(index, arg & mask)
            else:
                c.uc.mem_write(SP + (index - 4) * 4, struct.pack('<I', arg & 0xffffffff))
        c.run_relative(relative)
        assert c.stopped == STOP
        assert c.uc.reg_read(c.sp) == SP, ('stack imbalance', builder.abi, hex(relative))
        return c.r(0)

    def call(name, *args):
        # Enter through the actual patched original function whenever possible.
        if name in HOOKS:
            return call_address(builder.sym(HOOKS[name]), *args)
        return call_address(symbols[name], *args)

    for actor, rfid in ((BAT, 1000), (BATTER, 1100)):
        c.uc.mem_write(actor, struct.pack('<H', rfid))
        state = call('yagu_state', actor)
        assert state == symbols['my_state'] + slide
        raw = bytes(c.uc.mem_read(state, 8 + 43 * 16))
        assert struct.unpack_from('<II', raw) == (1, 1000)
        assert all(struct.unpack_from('<QII', raw, offset) == (0, 1, 0)
                   for offset in range(8, len(raw), 16))
    assert call('yagu_state', 0) == 0
    c.uc.mem_write(BATTER, struct.pack('<H', 22))
    assert call('yagu_state', BATTER) == 0
    checks.append('43 tagged scalars resolve to relocated read-only state for both My IDs')
    checks.append('null and ordinary actors do not acquire unbounded state')

    before = bytes(c.uc.mem_read(TEAM, 0x3b4))
    assert call('get_pitcher', MGR) == PIT
    after = bytes(c.uc.mem_read(TEAM, 0x3b4))
    assert after[4 + 52:] == before[4 + 52:]
    assert after[2:4] == before[2:4]
    assert struct.unpack_from('<H', after, 4)[0] == 1100
    assert bytes(c.uc.mem_read(PIT + 2, 17)) == bytes(c.uc.mem_read(BAT + 2, 17))
    assert call('pitcher_record', MGR) == RECORD
    assert bytes(c.uc.mem_read(RECORD, 32)) == struct.pack('<H', 1100) + bytes(30)
    c.uc.mem_write(RECORD + 8, struct.pack('<I', 54321))
    assert call('get_pitcher', MGR) == PIT
    assert struct.unpack('<I', c.uc.mem_read(RECORD + 8, 4))[0] == 54321
    checks.append('patched GetRaisePitcher reaches PIC payload and preserves owned BAT-save bounds')
    checks.append('paired record lookup and repeated role sync preserve existing statistics')

    # The native pregame rotation moves pitcher objects without moving records.
    # The role synchronizer must resolve the persistent record by RFID, not by
    # the actor's new physical roster slot.
    rotation_before = bytes(c.uc.mem_read(PIT, 4 * 52))
    records_before = bytes(c.uc.mem_read(RECORD, 256))
    c.uc.mem_write(PIT, rotation_before[52:] + rotation_before[:52])
    assert call('get_pitcher', MGR) == PIT + 3 * 52
    assert call('pitcher_record', MGR) == RECORD
    assert bytes(c.uc.mem_read(RECORD, 256)) == records_before
    assert sum(struct.unpack_from('<H', records_before, index * 32)[0] == 1100
               for index in range(8)) == 1
    c.uc.mem_write(PIT, rotation_before)
    assert call('get_pitcher', MGR) == PIT
    assert call('pitcher_record', MGR) == RECORD
    checks.append('physical pitcher rotation preserves the original unique RFID-bound record')

    seen = []
    fallback = bindings['original_get_pitcher'] + slide
    c.callbacks[fallback] = lambda: (seen.append(c.r(0)), c.ret(HEAP + 0x99000))
    mode_binding = builder.sym(BINDINGS['game_mode']) + slide
    c.callbacks[mode_binding] = lambda: c.ret(1)
    assert call('get_pitcher', MGR) == HEAP + 0x99000
    assert seen == [MGR]
    c.callbacks[mode_binding] = lambda: c.ret(4)
    checks.append('noncareer fallback reaches relocated original binding with intact argument ABI')

    # Execute original special-level and normal-training setters, not mocks.
    # Their four-byte relocated prologues rejoin the original method correctly.
    c.uc.mem_write(BAT + 0x2a, b'\x05')
    call('set_special_level', BAT, 0xffffffff)
    assert bytes(c.uc.mem_read(BAT + 0x2a, 1)) == b'\xa5'
    assert call('special_level', BAT) == 10
    c.uc.mem_write(BATTER + 0x2a, b'\x25')
    assert call('special_level', BATTER) == 2
    call('set_special_level', BATTER, 3)
    assert bytes(c.uc.mem_read(BATTER + 0x2a, 1)) == b'\x35'
    checks.append('special getter/setter use bounded nibble adapter; normal player stays original')

    for part in range(4):
        call('set_training_level', MODE, part, 0x7fffffff)
        assert call('training_level', MODE, part) == 7
    assert bytes(c.uc.mem_read(MODE + 0x504, 4)) == bytes([7]) * 4
    c.uc.mem_write(MODE + 0x504 + 4, b'\x03')
    assert call('training_level', MODE, 4) == 3
    other_mode = MODE + 0x1000
    call('set_training_level', other_mode, 2, 5)
    assert call('training_level', other_mode, 2) == 5
    checks.append('four training adapters store 7; unowned mode and out-of-scope getter fall back')

    # The original pitch setter calls a min/max leaf through its PLT. Its clamp
    # contract is mocked; the original instruction sequence performs the write.
    clamp_plt = (0x72d750 if builder.is64 else 0x470130) + slide
    def clamp():
        lo, value, hi = [c.r(index) & 0xffffffff for index in range(3)]
        signed = lambda value: value if value < 0x80000000 else value - 0x100000000
        c.ret(min(max(signed(value), signed(lo)), signed(hi)))
    c.callbacks[clamp_plt] = clamp
    for pitch in (0, 27):
        call('set_pitch_level', MODE, pitch, 0xffffffff)
        assert call('pitch_level', MODE, pitch) == 10
        assert bytes(c.uc.mem_read(MODE + 0x3f0 + pitch, 1)) == b'\x0a'
    c.uc.mem_write(MODE + 0x3f0 + 28, b'\x02')
    assert call('pitch_level', MODE, 28) == 2
    call('set_pitch_level', other_mode, 27, 4)
    assert call('pitch_level', other_mode, 27) == 4
    checks.append('pitch endpoints 0 and 27 use 0..10 clamp; index 28 and other mode stay original')

    # Passive wrappers require an already owned/nonzero skill. Model the original
    # membership result, then verify adapter routing and unchanged boolean ABI.
    passive_original = bindings['original_passive_level'] + slide
    for finite in (0, 1, 7):
        c.callbacks[passive_original] = lambda finite=finite: c.ret(finite)
        assert call('passive_level', MODE, 2) == (10 if finite > 0 else finite)
        assert call('passive_level', other_mode, 2) == finite
    seen = []
    passive_set_original = bindings['original_set_passive_level'] + slide
    def passive_set():
        seen.append(tuple(c.r(index) & 0xffffffff for index in range(4)))
        c.ret(0)
    c.callbacks[passive_set_original] = passive_set
    for context, index, value, check, expected in (
            (MODE, 2, 0xffffffff, 1, 10),
            (MODE, -1, 4, 0, 4),
            (other_mode, 2, 6, 1, 6)):
        call('set_passive_level', context, index, value, check)
        assert seen[-1] == (context, index & 0xffffffff, expected, check)
    checks.append('passive adapters retain learned-skill membership and original setter boolean ABI')

    for value in (0, 0xffffffff):
        call('set_level', BAT, value)
        assert call('level', BAT) == 250
        call('set_status', BAT, 3, value)
        assert call('pure_status', BAT, 3) == 10000
    assert call('yagu_state', PIT) == symbols['my_state'] + slide
    checks.append('level/status boundary writes preserve relocated semantic state')
    checks.append('zero-bias executable mapping absent; appended code/state protected read-execute')
    return {'slide': hex(slide), 'passed': len(checks), 'native_calls': calls,
            'checks': checks, 'android_runtime_verified': False}


def verify(abi):
    source = ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so'
    builder = PatchBuilder(abi, source.read_bytes())
    add_gameplay_hooks(builder)
    payload = add_payload(builder, workdir=WORK / 'relocation_build' / abi)
    slides = (0x123450000, 0x7000000000) if builder.is64 else (0x10001000, 0xb3000000)
    results = [verify_slide(builder, payload, slide) for slide in slides]
    return {'abi': abi, 'source_sha256': builder.sha,
            'payload_sha256': hashlib.sha256(
                (WORK / 'relocation_build' / abi / 'payload.elf').read_bytes()).hexdigest(),
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'passed': sum(result['passed'] for result in results),
            'native_calls': sum(result['native_calls'] for result in results),
            'slides': results,
            'limits': ['Original ELF dynamic relocations and Android loader are not exercised.',
                       'External engine services are mocked at their relocated ABI boundaries.',
                       'No complete game, visual glyph, save-to-disk, or all-menu verification.'],
            'android_runtime_verified': False}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'relocation_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))
