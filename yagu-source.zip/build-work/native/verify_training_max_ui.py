"""Verify the two training MAX call sites retain all original font arguments."""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks
from payload_builder import add_payload
from training_max_ui import add_training_max_ui_hooks
from verify_relocation import prepare_case, BAT, TEAM
from verify_gameplay_hooks import ROOT, HEAP, SP

WORK = Path(__file__).resolve().parent
UI = HEAP + 0xf000
TEXT = HEAP + 0xf100
BUFFER = HEAP + 0xf200


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'training_max_build' / abi)
    hooks = add_training_max_ui_hooks(b, payload['symbols'])
    slides = (0x123450000, 0x7000000000) if b.is64 else (0x10001000, 0xb3000000)
    cases = []
    for slide in slides:
        for hook in hooks:
            for kind in ('owned_batter', 'owned_pitcher', 'ordinary', 'null_actor', 'null_ui'):
                c = prepare_case(b, slide)
                c.uc.mem_write(UI, bytes([0xa5]) * 0x100)
                c.uc.mem_write(TEXT, b'MAX\0')
                c.uc.mem_write(BUFFER, bytes([0xb6]) * 64)
                actor_id = 1100 if kind == 'owned_pitcher' else 1000 if kind == 'owned_batter' else 22
                c.uc.mem_write(BAT, struct.pack('<H', actor_id))
                c.ptr(UI + (0x38 if b.is64 else 0x24), 0 if kind == 'null_actor' else BAT)
                c.ptr(SP + (0x478 if b.is64 else 0x34c), 0 if kind == 'null_ui' else UI)
                expected = [BUFFER, TEXT, 20, 1, 255, 0, 0, 255]
                for i, value in enumerate(expected):
                    if b.is64 or i < 4:
                        c.r(i, value)
                    else:
                        c.uc.mem_write(SP + (i - 4) * 4, struct.pack('<I', value))
                before_ui = bytes(c.uc.mem_read(UI, 0x100))
                before_team = bytes(c.uc.mem_read(TEAM, 0x3b4))
                before_buffer = bytes(c.uc.mem_read(BUFFER, 64))
                called = []
                owned = kind.startswith('owned_')

                def original_font():
                    actual = [c.r(i) if b.is64 or i < 4 else struct.unpack('<I', c.uc.mem_read(SP + (i - 4) * 4, 4))[0] for i in range(8)]
                    assert c.uc.reg_read(c.sp) == SP
                    assert actual[:1] + actual[2:] == expected[:1] + expected[2:]
                    assert actual[1] == (hook['text'] + slide if owned else TEXT)
                    text = bytes(c.uc.mem_read(actual[1], 4))
                    assert text == ('\u221e\0'.encode() if owned else b'MAX\0')
                    called.append(text.decode().rstrip('\0'))
                    c.ret(0x5a5a)

                c.callbacks[hook['original'] + slide] = original_font
                c.stops = {hook['site'] + 4 + slide}
                c.run_relative(hook['site'])
                assert len(called) == 1 and c.r(0) == 0x5a5a
                assert c.uc.reg_read(c.sp) == SP
                assert bytes(c.uc.mem_read(UI, 0x100)) == before_ui
                assert bytes(c.uc.mem_read(TEAM, 0x3b4)) == before_team
                assert bytes(c.uc.mem_read(BUFFER, 64)) == before_buffer
                cases.append({'slide': hex(slide), 'site': hex(hook['site']), 'context': kind, 'text': called[0]})
    return {'abi': abi, 'passed': len(cases), 'cases': cases,
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'all_eight_font_arguments_preserved_except_owned_text': True,
            'original_font_and_layout_retained': True, 'android_runtime_verified': False}


if __name__ == '__main__':
    reports = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'training_max_ui_verification.json').write_text(json.dumps(reports, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps([{'abi': r['abi'], 'passed': r['passed']} for r in reports]))
