"""Verify nonvisual personal-record policy at actual patched native entries.

The game/save service boundaries are mocked. The injected compiled code, exact
original entry branches, original comparator/abs methods and raw record leaves
execute at nonzero ELF load biases. This is not an Android full-match test.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from payload_builder import add_payload, HOOKS
from verify_relocation import prepare_case, BAT, PIT, TEAM, TEAMS, SAVE, MODE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP

WORK = Path(__file__).resolve().parent
EVENT = HEAP + 0x90000
SCALAR = HEAP + 0x91000
BAT_METRICS = {1: 0, 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6,
               9: 7, 10: 13, 11: 9, 12: 10, 13: 11, 14: 12}
PIT_METRICS = {1: 0, 2: 1, 3: 2, 4: 4, 5: 5, 6: 6, 7: 7,
               8: 1, 9: 8, 10: 9, 11: 10, 13: 3, 14: 11, 15: 12}
ZERO_PIT = {0, 2, 3, 5, 10, 11}
THRESHOLDS = (0, 1, 255, 65535, 0x7fffffff, -1, -65535, -0x80000000)


def signed32(value):
    value &= 0xffffffff
    return value if value < 0x80000000 else value - 0x100000000


def verify(abi):
    source = ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so'
    b = PatchBuilder(abi, source.read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'record_core_build' / abi)
    symbols = payload['symbols']
    bindings = payload['original_bindings']
    slide = 0x7865430000 if b.is64 else 0x98432000
    c = None
    record = {}
    seen = []
    totals = {'owned_lookup': 0, 'event_conditions': 0, 'year_goals': 0,
              'fallbacks': 0, 'scope_rejections': 0, 'comparisons': 0,
              'original_comparison_parity': 0, 'finite_raw_leaves': 0}

    def call_address(address, *args):
        c.stopped = None
        c.stops = {STOP}
        c.uc.reg_write(c.sp, SP)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        mask = (1 << (64 if b.is64 else 32)) - 1
        preserved = range(19, 30) if b.is64 else (4, 5, 6, 7, 8, 9, 10, 11)
        saved = {index: c.r(index) for index in preserved}
        for index, value in enumerate(args):
            if index < (8 if b.is64 else 4):
                c.r(index, value & mask)
            else:
                c.uc.mem_write(SP + (index - 4) * 4, struct.pack('<I', value & 0xffffffff))
        c.run_relative(address)
        assert c.stopped == STOP and c.uc.reg_read(c.sp) == SP
        assert all(c.r(index) == value for index, value in saved.items()), ('callee-save', abi, hex(address))
        return c.r(0)

    def call(name, *args):
        address = b.sym(HOOKS[name]) if name in HOOKS else symbols[name]
        return call_address(address, *args)

    def configure(mode=4):
        nonlocal c, record, seen
        c = prepare_case(b, slide)
        seen = []
        c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(mode)
        c.ptr(MGR + ((0x520 if mode == 3 else 0x528) if b.is64
                     else (0x4e4 if mode == 3 else 0x4e8)), SAVE)
        c.uc.mem_write(PIT, struct.pack('<H', 1100))
        record = {}
        for role in range(2):
            base = SAVE + ((0xee4 if mode == 3 else 0xe8c) if role
                           else (0x1de4 if mode == 3 else 0x1d8c))
            stride, count = (32, 8) if role else (24, 12)
            c.uc.mem_write(base, bytes([0x6d]) * (15 * count * stride))
            # Record slots deliberately differ from the physical roster slots.
            record[role] = base + 4 * count * stride + (6 if role else 9) * stride
            c.uc.mem_write(record[role], struct.pack('<H', 1100 if role else 1000))
        for alias, argc in (('year_goal', 3), ('record_check_bat', 4), ('record_check_pit', 4)):
            def fallback(alias=alias, argc=argc):
                seen.append((alias, tuple(c.r(i) & 0xffffffff for i in range(argc))))
                c.ret(0x57)
            c.callbacks[bindings['original_' + alias] + slide] = fallback
        return c

    # The six appended honors leave the previous33 scalar offsets stable.
    configure()
    p = call('yagu_record_state', BAT)
    raw = bytes(c.uc.mem_read(p, 8 + 39 * 16))
    assert struct.unpack_from('<II', raw) == (3, 1000)
    for index in range(39):
        zero = (13 <= index < 26 and index - 13 in ZERO_PIT) or index == 32
        assert struct.unpack_from('<QII', raw, 8 + 16 * index) == (0, 0 if zero else 1, 0)

    for mode in (3, 4):
        configure(mode)
        state_before = bytes(c.uc.mem_read(p, len(raw)))
        save_before = bytes(c.uc.mem_read(SAVE, 0x4000))
        roster_before = bytes(c.uc.mem_read(TEAM, 0x3b4))
        for role in range(2):
            assert call('yagu_current_personal_record', role) == record[role]
            assert call('yagu_owned_records', record[role], role) == p
            assert call('yagu_owned_records', record[1 - role], role) == 0
            assert call('yagu_owned_records', 0, role) == 0
            stride = 32 if role else 24
            duplicate = record[role] + stride
            c.uc.mem_write(duplicate, struct.pack('<H', 1100 if role else 1000))
            assert call('yagu_owned_records', duplicate, role) == 0
            c.uc.mem_write(duplicate, bytes([0x6d]) * 2)
            for metric in range(19):
                pointer = call('yagu_owned_record_metric', record[role], role, metric)
                if role == 0 and metric >= 15:
                    assert pointer == 0
                else:
                    expected_kind = 0 if ((role and metric in ZERO_PIT) or (not role and metric == 13)) else 1
                    assert struct.unpack('<QII', c.uc.mem_read(pointer, 16)) == (0, expected_kind, 0)
                totals['owned_lookup'] += 1
            for metric in (-1, 19, 0x7fffffff):
                assert call('yagu_owned_record_metric', record[role], role, metric) == 0
            totals['owned_lookup'] += 8
            for honor in range(6):
                pointer = call('yagu_owned_honor_metric', record[role], role, honor)
                assert pointer == p + 8 + (33 + honor) * 16
                assert struct.unpack('<QII', c.uc.mem_read(pointer, 16)) == (0, 1, 0)
                totals['owned_lookup'] += 1

        for role, metrics in ((0, BAT_METRICS), (1, PIT_METRICS)):
            alias = 'record_check_pit' if role else 'record_check_bat'
            for selector, metric in metrics.items():
                zero = metric in ZERO_PIT if role else metric == 13
                for period in (1, 2):
                    for threshold in THRESHOLDS:
                        value = call(alias, EVENT, selector, period, threshold)
                        expected = (int(threshold == 0) if threshold >= 0 else int(threshold != -0x80000000)) if zero else int(threshold >= 0)
                        assert value == expected, (abi, mode, role, selector, period, threshold, value, expected)
                        totals['event_conditions'] += 1
            # Unsupported selectors and period flags must reach original code.
            for selector, period, threshold in ((1, 0, 9), (1, 3, 9), (1, 4, 9), (1, 7, 9),
                                                 (1, -1, 9), (23, 2, -21), (24, 1, 1),
                                                 (25, 1, 1), (32, 1, 1), (35, 1, 1),
                                                 (0, 1, 1), (36, 1, 1), (12 if role else 8, 1, 9)):
                before = len(seen)
                assert call(alias, EVENT, selector, period, threshold) == 0x57
                assert seen[before:] == [(alias, (EVENT, selector & 0xffffffff, period & 0xffffffff, threshold & 0xffffffff))]
                totals['fallbacks'] += 1
            assert call(alias, 0, 1, 1, 9) == 0x57
            totals['fallbacks'] += 1

        for goal in (range(7) if mode == 4 else range(8)):
            for threshold in THRESHOLDS:
                expected = int(threshold >= 0) if mode == 3 and goal in (0, 5) else 1
                assert call('year_goal', MODE, goal, threshold) == expected
                totals['year_goals'] += 1
        for owner, goal in ((MODE, -1), (MODE, 8), (MODE + 0x1000, 0), (0, 0)):
            before = len(seen)
            assert call('year_goal', owner, goal, 123) == 0x57
            assert seen[before:] == [('year_goal', (owner, goal & 0xffffffff, 123))]
            totals['fallbacks'] += 1
        if mode == 4:
            assert call('year_goal', MODE, 7, 123) == 0x57
            totals['fallbacks'] += 1

        assert bytes(c.uc.mem_read(p, len(raw))) == state_before
        assert bytes(c.uc.mem_read(SAVE, 0x4000)) == save_before
        assert bytes(c.uc.mem_read(TEAM, 0x3b4)) == roster_before

        # Actual original raw getters retain finite counters, including values
        # larger than the original 16-bit batter counter range on pitching.
        for symbol, role, offset, width, value in (
                ('CBBGBatterRecData::GetAtBat()', 0, 2, 2, 65535),
                ('CBBGBatterRecData::GetHit()', 0, 4, 2, 65534),
                ('CBBGPitcherRecData::GetK()', 1, 8, 4, 0x7ffffffe),
                ('CBBGPitcherRecData::GetOut()', 1, 4, 4, 65536)):
            original = bytes(c.uc.mem_read(record[role] + offset, width))
            c.uc.mem_write(record[role] + offset, value.to_bytes(width, 'little'))
            assert call_address(b.sym(symbol), record[role]) == value
            c.uc.mem_write(record[role] + offset, original)
            totals['finite_raw_leaves'] += 1

    # Scope rejects a matching ID on an opponent or an unrelated save; no
    # callable policy is established by a raw RFID alone.
    for kind in ('noncareer', 'missing_manager', 'missing_save', 'missing_teams',
                 'invalid_team', 'negative_team', 'missing_actor', 'wrong_record_id',
                 'opponent_only_actor', 'invalid_roster_count', 'unrelated_save'):
        for role in range(2):
            configure()
            actor = PIT if role else BAT
            if kind == 'noncareer': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            elif kind == 'missing_manager': c.callbacks[b.sym(GETMGR) + slide] = lambda: c.ret(0)
            elif kind == 'missing_save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
            elif kind == 'missing_teams': c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
            elif kind in ('invalid_team', 'negative_team'):
                c.uc.mem_write(TEAMS + 4, struct.pack('<i', 15 if kind == 'invalid_team' else -1))
            elif kind == 'missing_actor': c.uc.mem_write(actor, struct.pack('<H', 22))
            elif kind == 'wrong_record_id': c.uc.mem_write(record[role], struct.pack('<H', 22))
            elif kind == 'opponent_only_actor':
                c.uc.mem_write(actor, struct.pack('<H', 22))
                other = TEAMS + 8 + 5 * 0x3b4 + (4 if role else 0x1a4)
                c.uc.mem_write(other, struct.pack('<H', 1100 if role else 1000))
            elif kind == 'invalid_roster_count': c.uc.mem_write(TEAM + (2 if role else 3), bytes([9 if role else 13]))
            elif kind == 'unrelated_save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), SAVE + 0x10000)
            alias = 'record_check_pit' if role else 'record_check_bat'
            assert call('yagu_current_personal_record', role) == 0
            assert call('yagu_owned_records', record[role], role) == 0
            assert call(alias, EVENT, 9 if role else 6, 1, 65535) == 0x57
            totals['scope_rejections'] += 1

    # Exercise the actual compiled typed comparison with 64-bit finite values,
    # invalid/overflow tags and infinity, beyond the legacy field widths.
    configure()
    for kind, finite in ((0, 0), (0, 1), (0, 65535), (0, 65536),
                         (0, 0x7fffffff), (0, 0xffffffffffffffff),
                         (1, 0), (2, 0), (99, 0)):
        c.uc.mem_write(SCALAR, struct.pack('<QII', finite, kind, 0))
        for threshold in THRESHOLDS:
            actual = signed32(call('yagu_record_event_compare', SCALAR, threshold))
            if kind not in (0, 1): expected = -1
            elif kind == 1: expected = int(threshold >= 0)
            elif threshold >= 0: expected = int(finite >= threshold)
            elif threshold == -0x80000000: expected = 0
            else: expected = int(finite < -threshold)
            assert actual == expected, ('event comparator', abi, kind, finite, threshold, actual, expected)
            for upper in (0, 1):
                actual = signed32(call('yagu_record_goal_compare', SCALAR, threshold, upper))
                expected = -1 if kind not in (0, 1) else int(not upper) if kind == 1 else int(finite <= threshold) if upper else int(finite >= threshold)
                assert actual == expected
                totals['comparisons'] += 1
            totals['comparisons'] += 1
    assert signed32(call('yagu_record_event_compare', 0, 1)) == -1

    # Run original IsCheckVal and GsAbs, including signed INT_MIN. A PLT thunk
    # is resolved to the original leaf body; the computation itself is real.
    abs_plt = 0x730b90 if b.is64 else 0x4734d0
    abs_body = b.sym('GsAbs(int)') + slide + (0 if b.is64 else 1)
    c.callbacks[abs_plt + slide] = lambda: c.uc.reg_write(c.pc, abs_body)
    for finite in (0, 1, 32767, 65535, 0x7fffffff):
        c.uc.mem_write(SCALAR, struct.pack('<QII', finite, 0, 0))
        for threshold in THRESHOLDS:
            native = call_address(b.sym('CBBGEvent::IsCheckVal(int, int)'), EVENT, threshold, finite)
            typed = call('yagu_record_event_compare', SCALAR, threshold)
            assert typed == native, ('native parity', abi, finite, threshold, typed, native)
            totals['original_comparison_parity'] += 1

    return {'abi': abi, 'slide': hex(slide), 'source_sha256': b.sha,
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'passed': sum(totals.values()), 'cases': totals,
            'record_schema': 3, 'record_scalars': 39, 'unbounded_scalars': 32,
            'finite_zero_scalars': 7, 'event_periods': [1, 2],
            'bat_event_selectors': BAT_METRICS, 'pit_event_selectors': PIT_METRICS,
            'original_entry_sites': {name: hex(b.sym(HOOKS[name])) for name in
                                     ('year_goal', 'record_check_bat', 'record_check_pit')},
            'preserved': ['raw finite record getters and save bytes',
                          'finite match-local period4 and observed period7',
                          'team standings/economy conditions and unrelated modes',
                          'original fallback arguments and callee-save registers'],
            'limits': ['This suite does not verify local-rank presentation or interim appraisal; those require their own consumer tests.',
                       'No Android full match or complete career progression is established by this test.'],
            'android_runtime_verified': False}


if __name__ == '__main__':
    result = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'record_core_verification.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps([{key: item[key] for key in ('abi', 'passed', 'cases')} for item in result], indent=2))
