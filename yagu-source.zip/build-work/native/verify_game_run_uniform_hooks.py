"""Execute all four legacy clothing lookup hooks under a nonzero load bias.

The complete current injection order is used. Each loop part is checked for
every team, including original Pumas/nonclothing paths and invalid team/part
fallbacks. The native texture loader itself is outside this instruction test.
"""
import hashlib
import json
import os
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks
from payload_builder import add_payload
from infinity_ui import add_infinity_ui_hooks
from defender_hooks import add_defender_hooks
from game_run_uniform_hooks import add_game_run_uniform_hooks
from verify_relocation import RelocatedCase
from verify_gameplay_hooks import ROOT, HEAP, SP, STOP
from verify_defender_hooks import read_c_string
from unicorn.arm64_const import UC_ARM64_REG_NZCV
from unicorn.arm_const import UC_ARM_REG_APSR
import unicorn.arm64_const as arm64
import unicorn.arm_const as arm

WORK = Path(__file__).resolve().parent
ART = WORK.parent / 'art'
ART_OVERLAY = Path(os.environ.get('YAGU_ART_OVERLAY', str(ROOT / 'overlays/art/assets')))
TABLE = HEAP + 0x20000
STRINGS = HEAP + 0x50000
ACTOR = HEAP + 0x80000
MAKER = HEAP + 0x90000
CLOTHING = {
    'bat': {1, 2, 5, 6, 7, 10, 11, 12, 13, 14, 16, 18, 19, 20, 21, 22, 24, 25},
    'pit': {3, 4, 5, 7, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23},
}


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'uniform_build' / abi)
    add_infinity_ui_hooks(b, payload['symbols']['yagu_state'])
    add_defender_hooks(b, payload['symbols']['yagu_defender_path'])
    sites = add_game_run_uniform_hooks(b, payload['symbols'])
    slide = 0x7323450000 if b.is64 else 0xa3450000
    c = RelocatedCase(b, slide)
    schema = json.loads((ART / 'game_run_part_paths.json').read_text())
    flags = UC_ARM64_REG_NZCV if b.is64 else UC_ARM_REG_APSR
    fp = arm64.UC_ARM64_REG_X29 if b.is64 else arm.UC_ARM_REG_R7
    fregs = [getattr(arm64 if b.is64 else arm,
                     f'UC_ARM64_REG_Q{i}' if b.is64 else f'UC_ARM_REG_D{i}') for i in range(32)]
    fvalues = [((0x1234567800000000 + i) << 64 | (0xfedcba9800000000 + i))
               if b.is64 else 0x1234567800000000 + i for i in range(32)]
    outcomes = []
    verified_assets = set()
    cases = 0
    for context in sites:
        role = context['role']
        parts = schema[role]
        counts = {'new_clothing': 0, 'original_fallback': 0}
        for team in list(range(15)) + [-1, 15, 0x7fffffff]:
            for part in list(range(len(parts))) + [-1, len(parts), 0x7fffffff]:
                selected = 0 <= team < 15 and team != 4 and part in CLOTHING[role]
                # New clothing must not read any original table entry at all.
                table_arg = 0xf0000000 if selected else TABLE
                index = 0x200 + (part % 51)
                original = f'original/{role}/team_{team}/part_{part}.pzc'
                original_pointer = STRINGS
                c.uc.mem_write(original_pointer, original.encode('ascii') + b'\0')
                c.ptr(TABLE + index * (8 if b.is64 else 4), original_pointer)
                for position, register in enumerate(c.regs):
                    if register != c.lr:
                        c.uc.reg_write(register, 0x12340000 + position)
                c.uc.reg_write(c.sp, SP)
                c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
                c.uc.reg_write(fp, SP + 0x800)
                c.r(0, MAKER)
                if b.is64:
                    c.r(8, table_arg)
                    c.r(9, index)
                    c.ptr(SP + 8, ACTOR)
                    part_address = SP + 0x800 - 0x18 if role == 'bat' else SP + 0x18
                else:
                    c.r(1, table_arg)
                    c.r(2, index)
                    c.ptr(SP + 4, ACTOR)
                    part_address = SP + context['part_offset']
                c.uc.mem_write(ACTOR + context['team_offset'], struct.pack('<i', team))
                c.uc.mem_write(part_address, struct.pack('<i', part))
                c.uc.reg_write(flags, 0xa0000000)
                for register, value in zip(fregs, fvalues):
                    c.uc.reg_write(register, value)
                before = [c.uc.reg_read(register) for register in c.regs]
                c.stopped = None
                c.stops = {context['site'] + 4 + slide}
                c.run_relative(context['site'])
                assert c.stopped == context['site'] + 4 + slide
                assert c.uc.reg_read(c.sp) == SP
                pointer = c.r(1)
                path = read_c_string(c, pointer)
                if selected:
                    expected = parts[part].replace('/color_0/', f'/color_{10 + team}/')
                    assert payload['base'] + slide <= pointer < payload['base'] + payload['size'] + slide
                    pzc = ART_OVERLAY / path
                    assert pzc.is_file() and pzc.with_suffix('.png').is_file(), path
                    verified_assets.add(path)
                    counts['new_clothing'] += 1
                else:
                    expected = original
                    assert pointer == original_pointer
                    counts['original_fallback'] += 1
                assert path == expected, (abi, role, team, part, path, expected)
                before[1] = pointer
                assert [c.uc.reg_read(register) for register in c.regs] == before
                assert c.r(0) == MAKER
                assert c.uc.reg_read(flags) & 0xf0000000 == 0xa0000000
                assert [c.uc.reg_read(register) for register in fregs] == fvalues
                cases += 1
        outcomes.append({'role': role, 'site': hex(context['site']),
                         'team_offset': hex(context['team_offset']), **counts})
    assert len(verified_assets) == 490
    report = {'abi': abi, 'source_sha256': b.sha,
              'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
              'header_sha256': hashlib.sha256((WORK / 'game_run_paths.h').read_bytes()).hexdigest(),
              'slide': hex(slide), 'sites_passed': len(sites), 'instruction_cases_passed': cases,
              'unique_existing_pzc_png_pairs': len(verified_assets), 'sites': outcomes,
              'preservation_verified': ['texture-maker first argument', 'all GPRs except path result',
                                        'stack and LR', 'condition flags', 'all 32 SIMD/FP registers'],
              'limits': ['Stops before the texture loader; decoding and rendering are not exercised.',
                         'No full Android gameplay or device visual verification.'],
              'android_runtime_verified': False}
    return report


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'game_run_uniform_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps([{key: result[key] for key in ('abi', 'sites_passed', 'instruction_cases_passed',
                                                  'unique_existing_pzc_png_pairs')}
                      for result in results], indent=2))
