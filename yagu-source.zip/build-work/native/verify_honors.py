"""Exercise scoped honors through actual original and patched event entries.

The original selector table, honor getter, IsCheckVal/GsAbs, and finite award
increment code execute. Only singleton/aggregate-service boundaries are mocked.
Injected code runs at nonzero ELF load biases with the zero-bias image unmapped.
This is instruction verification, not an Android season-completion claim.
"""
import hashlib
import json
import struct
import sys
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from payload_builder import HOOKS
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from honors_policy import stage_payload, HONORS, integrate_source, integrate_builder
from verify_relocation import prepare_case, TEAM, TEAMS, BAT, PIT, SAVE, MODE
from verify_gameplay_hooks import HEAP, MGR, SP, STOP
from unicorn.arm64_const import UC_ARM64_REG_TPIDR_EL0

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'analysis/world-career/tools'))
from original_audit import Original

EVENT = HEAP + 0x90000
TLS = HEAP + 0x95000
THRESHOLDS = (0, 1, 250, 255, 256, 65535, 0x7fffffff,
              -1, -250, -255, -65535, -0x80000000)
PERIODS = (-0x80000000, -1, 0, 1, 2, 3, 4, 7, 255, 0x7fffffff)
GETTERS = (
    'CBBGRaiseMode::GetTotalPenntraceVictoryCnt()',
    'CBBGRaiseMode::GetTotalPenntraceMVPCnt()',
    'CBBGRaiseMode::GetTotalPostSeasonVictoryCnt()',
    'CBBGRaiseMode::GetTotalPostSeasonMVPCnt()',
    'CBBGRaiseMode::GetUserTeamCubGameVictoryCnt()',
    'CBBGRaiseMode::GetUserCubGameMVPCnt()',
)
INCREMENTS = tuple(name.replace('::Get', '::Add', 1) for name in GETTERS)
OFFSETS = (0x418, 0x419, 0x41a, 0x41b, 0x529, 0x52a)
ZERO_PIT = {0, 2, 3, 5, 10, 11}


def invoke(c, address, *args):
    c.stopped = None
    c.stops = {STOP}
    c.uc.reg_write(c.sp, SP)
    c.uc.reg_write(c.lr, STOP if c.is64 else STOP | 1)
    saved = {i: c.r(i) for i in (range(19, 30) if c.is64 else range(4, 12))}
    for i, value in enumerate(args):
        c.r(i, value & ((1 << (64 if c.is64 else 32)) - 1))
    c.run_relative(address)
    assert c.stopped == STOP and c.uc.reg_read(c.sp) == SP
    assert all(c.r(i) == value for i, value in saved.items()), ('callee-save', hex(address))
    return c.r(0)


def original_plt(c):
    b = c.b
    dyn = b.elf.get_section_by_name('.dynsym')
    # C1/C2 and D1/D2 symbols may share a demangled label. Use raw dynsym
    # aliases instead of a demangled dictionary that collapses them.
    defined = {symbol.name: symbol['st_value'] & ~int(not b.is64)
               for symbol in dyn.iter_symbols() if symbol['st_value']}
    start = b.elf.get_section_by_name('.plt')['sh_addr']
    rels = b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
    for i, relocation in enumerate(rels.iter_relocations()):
        name = dyn.get_symbol(relocation['r_info_sym']).name
        if name in defined:
            target = (defined[name] + c.slide) | int(not b.is64)
            c.callbacks[start + 32 + i * 16 + c.slide] = (
                lambda target=target: c.uc.reg_write(c.pc, target))
    if b.is64:
        c.uc.reg_write(UC_ARM64_REG_TPIDR_EL0, TLS)
    else:
        found = []
        for relocation in b.elf.get_section_by_name('.rel.dyn').iter_relocations():
            if dyn.get_symbol(relocation['r_info_sym']).name == '__stack_chk_guard':
                c.ptr(c.slide + relocation['r_offset'], TLS)
                found.append(relocation['r_offset'])
        assert len(found) == 1


def configure(builder, slide, mode=4, payload=None):
    c = prepare_case(builder, slide)
    c.callbacks[builder.sym(GETMODE) + slide] = lambda: c.ret(mode)
    save_offset = (0x520 if mode == 3 else 0x528) if builder.is64 else (0x4e4 if mode == 3 else 0x4e8)
    c.ptr(MGR + save_offset, SAVE)
    c.uc.mem_write(PIT, struct.pack('<H', 1100))
    records = {}
    for role in range(2):
        base = SAVE + ((0xee4 if mode == 3 else 0xe8c) if role
                       else (0x1de4 if mode == 3 else 0x1d8c))
        stride, count = (32, 8) if role else (24, 12)
        c.uc.mem_write(base, b'\x6d' * (15 * count * stride))
        records[role] = base + 4 * count * stride + (6 if role else 9) * stride
        c.uc.mem_write(records[role], struct.pack('<H', 1100 if role else 1000))
    seen = []
    if payload:
        for role, alias in enumerate(('record_check_bat', 'record_check_pit')):
            def fallback(alias=alias):
                seen.append((alias, tuple(c.r(i) & 0xffffffff for i in range(4))))
                c.ret(0x57)
            c.callbacks[payload['original_bindings']['original_' + alias] + slide] = fallback
    else:
        original_plt(c)
        # This constructor/aggregate service is irrelevant to selectors26..31;
        # its result is still initialized as the native caller ABI requires.
        for name in ('CBBGRecordAnalyzer::CBBGRecordAnalyzer()',
                     'CBBGRecordAnalyzer::~CBBGRecordAnalyzer()'):
            c.callbacks[builder.sym(name) + slide] = lambda: c.ret(0)
        for role_name in ('BATTER', 'PITCHER'):
            for prefix in ('GetComulatede', 'Get'):
                name = 'CBBGRecordAnalyzer::' + prefix + 'RAISE_' + role_name + 'DATA()'
                def aggregate():
                    out = c.r(8) if c.is64 else c.r(0)
                    c.uc.mem_write(out, bytes(20))
                    c.ret(out)
                c.callbacks[builder.sym(name) + slide] = aggregate
    return c, records, seen


def selector_evidence(abi):
    original = Original(abi)
    specs = ((0x28e428, 0x424f68), (0x28e4b4, 0x425a30)) if original.is64 else (
        (0x28fc2c, 0x28fc2c), (0x2902f0, 0x2902f0))
    rows = []
    for role, (table, base) in enumerate(specs):
        entries = struct.unpack('<35i' if original.is64 else '<35H',
                                original.read(table, 140 if original.is64 else 70))
        for honor in range(6):
            selector = 26 + honor
            arm = base + entries[selector - 1] * (1 if original.is64 else 2)
            end = base + entries[selector] * (1 if original.is64 else 2)
            calls = []
            for ins in original.cs.disasm(original.read(arm, end - arm), arm):
                if ins.mnemonic in ('bl', 'blx'):
                    target = int(ins.op_str[1:], 16)
                    calls.append((ins.address, original.labels.get(target)))
            expected = ['[PLT] ' + GETTERS[honor], '[PLT] CBBGEvent::IsCheckVal(int, int)']
            assert [name for _, name in calls] == expected, (abi, role, selector, calls)
            rows.append({'role': role, 'selector': selector, 'table': hex(table),
                         'arm': hex(arm), 'getter': GETTERS[honor],
                         'getter_call': hex(calls[0][0]), 'comparator_call': hex(calls[1][0])})
    return rows


def verify(abi, source_dir):
    original_bytes = (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes()
    b = PatchBuilder(abi, original_bytes)
    add_gameplay_hooks(b)
    old_root = payload_builder.ROOT
    payload_builder.ROOT = source_dir
    try:
        payload = payload_builder.add_payload(b, workdir=WORK / 'honors_build' / abi)
    finally:
        payload_builder.ROOT = old_root
    symbols = payload['symbols']
    slide = 0x7965430000 if b.is64 else 0xa1432000
    totals = {'schema_fields': 0, 'owned_metrics': 0, 'patched_events': 0,
              'scope_rejections': 0, 'original_selector_comparisons': 0,
              'original_finite_getters': 0, 'original_award_increments': 0,
              'unchanged_award_code': 0, 'fallbacks': 0}
    evidence = selector_evidence(abi)

    for mode in (3, 4):
        c, records, seen = configure(b, slide, mode, payload)
        state = invoke(c, symbols['yagu_record_state'], BAT)
        raw = bytes(c.uc.mem_read(state, 8 + 39 * 16))
        assert struct.unpack_from('<II', raw) == (3, 1000)
        for index in range(39):
            zero = (13 <= index < 26 and index - 13 in ZERO_PIT) or index == 32
            assert struct.unpack_from('<QII', raw, 8 + index * 16) == (0, 0 if zero else 1, 0)
            totals['schema_fields'] += 1
        before_save = bytes(c.uc.mem_read(SAVE, 0x4000))
        before_roster = bytes(c.uc.mem_read(TEAMS, 8 + 15 * 0x3b4))
        for role in range(2):
            entry = b.sym(HOOKS['record_check_pit' if role else 'record_check_bat'])
            for honor in range(6):
                pointer = invoke(c, symbols['yagu_owned_honor_metric'], records[role], role, honor)
                assert pointer == state + 8 + (33 + honor) * 16
                totals['owned_metrics'] += 1
                for period in PERIODS:
                    for threshold in THRESHOLDS:
                        result = invoke(c, entry, EVENT, 26 + honor, period, threshold)
                        assert result == int(threshold >= 0), (abi, mode, role, honor, period, threshold, result)
                        totals['patched_events'] += 1
                assert not seen
            for honor in (-1, 6, 0x7fffffff, -0x80000000):
                assert invoke(c, symbols['yagu_owned_honor_metric'], records[role], role, honor) == 0
                totals['owned_metrics'] += 1
            for record in (0, records[1 - role], records[role] + (32 if role else 24)):
                if record:
                    old = bytes(c.uc.mem_read(record, 2))
                    c.uc.mem_write(record, struct.pack('<H', 1100 if role else 1000))
                assert invoke(c, symbols['yagu_owned_honor_metric'], record, role, 0) == 0
                if record: c.uc.mem_write(record, old)
                totals['owned_metrics'] += 1
            for selector in (23, 24, 25, 32, 33, 34, 35, 36, -1):
                index = len(seen)
                assert invoke(c, entry, EVENT, selector, 7, -255) == 0x57
                assert seen[index:] == [(('record_check_pit' if role else 'record_check_bat'),
                                         (EVENT, selector & 0xffffffff, 7, (-255) & 0xffffffff))]
                totals['fallbacks'] += 1
            for selector in range(26, 32):
                index = len(seen)
                assert invoke(c, entry, 0, selector, 1, 1) == 0x57
                assert len(seen) == index + 1
                totals['fallbacks'] += 1
            seen.clear()
        assert bytes(c.uc.mem_read(state, len(raw))) == raw
        assert bytes(c.uc.mem_read(SAVE, 0x4000)) == before_save
        assert bytes(c.uc.mem_read(TEAMS, 8 + 15 * 0x3b4)) == before_roster

    for kind in ('noncareer', 'manager', 'save', 'teams', 'team15', 'teamnegative',
                 'actor', 'record_id', 'opponent_actor', 'count', 'unrelated_save'):
        for role in range(2):
            c, records, seen = configure(b, slide, 4, payload)
            actor = PIT if role else BAT
            if kind == 'noncareer': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            elif kind == 'manager': c.callbacks[b.sym(GETMGR) + slide] = lambda: c.ret(0)
            elif kind == 'save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
            elif kind == 'teams': c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
            elif kind in ('team15', 'teamnegative'):
                c.uc.mem_write(TEAMS + 4, struct.pack('<i', 15 if kind == 'team15' else -1))
            elif kind == 'actor': c.uc.mem_write(actor, struct.pack('<H', 22))
            elif kind == 'record_id': c.uc.mem_write(records[role], struct.pack('<H', 22))
            elif kind == 'opponent_actor':
                c.uc.mem_write(actor, struct.pack('<H', 22))
                other = TEAMS + 8 + 5 * 0x3b4 + (4 if role else 0x1a4)
                c.uc.mem_write(other, struct.pack('<H', 1100 if role else 1000))
            elif kind == 'count': c.uc.mem_write(TEAM + (2 if role else 3), bytes([9 if role else 13]))
            elif kind == 'unrelated_save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), SAVE + 0x10000)
            entry = b.sym(HOOKS['record_check_pit' if role else 'record_check_bat'])
            for honor in range(6):
                assert invoke(c, symbols['yagu_owned_honor_metric'], records[role], role, honor) == 0
                for threshold in (255, -255):
                    index = len(seen)
                    assert invoke(c, entry, EVENT, 26 + honor, 1, threshold) == 0x57
                    assert len(seen) == index + 1
                    totals['scope_rejections'] += 1

    # Full original event prologue + selector table + actual honor getter +
    # original comparator execute with finite counters. All period values have
    # the same result in these six branches; do not infer this from a mock.
    control = PatchBuilder(abi, original_bytes)
    for mode in (3, 4):
        c, _, _ = configure(control, slide, mode)
        for role in range(2):
            entry = control.sym(HOOKS['record_check_pit' if role else 'record_check_bat'])
            for honor in range(6):
                for finite in (0, 1, 250, 255):
                    c.uc.mem_write(MODE + OFFSETS[honor], bytes([finite]))
                    assert invoke(c, control.sym(GETTERS[honor]), MODE) == finite
                    totals['original_finite_getters'] += 1
                    for period in (1, 2, 4, 7, -1):
                        for threshold in THRESHOLDS:
                            result = invoke(c, entry, EVENT, 26 + honor, period, threshold)
                            expected = int(finite >= threshold) if threshold >= 0 else int(
                                threshold != -0x80000000 and finite < -threshold)
                            assert result == expected, ('original', abi, mode, role, honor, finite, period, threshold, result, expected)
                            totals['original_selector_comparisons'] += 1
        for honor, symbol in enumerate(INCREMENTS):
            for finite in (0, 249, 250, 255):
                c.uc.mem_write(MODE + OFFSETS[honor], bytes([finite]))
                invoke(c, control.sym(symbol), MODE)
                value = c.uc.mem_read(MODE + OFFSETS[honor], 1)[0]
                expected = min(250, finite + 1) if honor < 4 else (finite + 1) & 255
                assert value == expected, ('original increment', abi, symbol, finite, value, expected)
                totals['original_award_increments'] += 1

    # Compare complete original code bytes for every getter/increment as well
    # as every original award presentation method, not merely the entry bytes.
    for name, symbol in b.symbols.items():
        if name not in GETTERS + INCREMENTS and not name.startswith('CBBGUIPostAward::'):
            continue
        address, size = symbol['address'], symbol['size']
        start = b.offset(address)
        assert bytes(b.image[start:start + size]) == original_bytes[start:start + size], name
        totals['unchanged_award_code'] += 1

    return {'abi': abi, 'slide': hex(slide), 'original_sha256': b.sha,
            'staged_c_sha256': hashlib.sha256((source_dir / 'yagu_payload.c').read_bytes()).hexdigest(),
            'passed': sum(totals.values()), 'cases': totals,
            'selector_evidence': evidence, 'schema': 3, 'scalars': 39,
            'unbounded_scalars': 32, 'finite_zero_scalars': 7,
            'own_record_required': True, 'raw_award_and_season_procedures_unchanged': True,
            'android_runtime_verified': False,
            'limits': ['No new trophy-history page was added.',
                       'Original finite award/save counters are compatibility bookkeeping.',
                       'Long-career year/ranking-history capacity remains separately unmodified.']}


if __name__ == '__main__':
    staged = WORK / 'honors_build' / 'source'
    manifest = stage_payload(staged)
    # Both transformation functions must be repeatable, preserving unrelated
    # root changes and never duplicating the six fields or the event hook.
    text = (staged / 'yagu_payload.c').read_text()
    assert integrate_source(text) == text
    builder_text = integrate_builder((WORK / 'payload_builder.py').read_text())
    assert integrate_builder(builder_text) == builder_text
    results = [verify(abi, staged) for abi in ('arm64-v8a', 'armeabi-v7a')]
    report = {'stage': manifest, 'results': results,
              'passed': sum(item['passed'] for item in results)}
    (WORK / 'honors_verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'stage': manifest, 'passed': report['passed'],
                      'results': [{key: item[key] for key in ('abi', 'passed', 'cases')}
                                  for item in results]}, indent=2))
