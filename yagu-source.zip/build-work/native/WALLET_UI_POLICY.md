# Existing G / Star balance display

This module projects the separate typed local wallet into the original game UI. It does not define the wallet's purchasing, spending or eligibility policy; those belong to `wallet_payload.inc` and `wallet_policy.py`.

## Scope

`yagu_wallet_text(0)` and `yagu_wallet_text(1)` must return a value before any display changes. The current wallet policy accepts the exact manager-owned option object in the common menu (`mode0`) or an owned active career (`mode3/4`). Missing options, unrelated modes and mismatched owned actors retain the original finite display. No wallet/save bytes are written by these UI wrappers.

The original `CBBGFrameUI::AddGFNumber` creates individual decimal nodes when its last boolean is false. For G and Star with an active typed wallet, the entry wrapper chooses its existing single-node branch. Its rectangle, tag, z order and alignment then reach the same original fitted-font mechanism already used throughout the game. This also covers `AddEventTopUI`, which calls `AddGFNumber`.

| Original balance consumer | AArch64 call | Thumb call |
| --- | --- | --- |
| Main/event frame single balance | `0x376ce4` | `0x22006a` |
| Charge menu G balance | `0x4c70c8` | `0x2fb96e` |
| Charge menu Star balance | `0x4c71b0` | `0x2fba28` |
| Purchase popup owned balance | `0x403f74` | `0x27b208` |
| Existing event text G balance | `0x429ccc` | `0x292d3e` |

There is one entry hook and five call-site hooks per ABI. The shared `MC_knlSprintk` and shared number-font helper are not patched by this module. Purchase costs, item descriptions, rewards and the other frame-number kind retain their original bytes and formatting.

## Original layout and style

The digit sites retain their original rectangle, tag, z, alignment, visibility, WIPI setting, offsets and alpha. They render one infinity glyph through the game's existing `CBBStringBuffer` → `GetChangeFont` → `AddChildFitSystemFont` path. The original G digits have an orange gradient and Star digits a cyan gradient; the font projection uses opaque foreground RGB samples `(255,202,52)` and `(114,237,255)` from the shipped `CC_Main_FrameUI.png`. The font is the original 18px system-font style, not a new widget. It does not reproduce the digit-sprite gradient pixel for pixel.

The popup already uses system fonts, so its exact incoming font size and RGBA are preserved. Temporary string storage exceeds the original object size on each ABI, calls the original constructor, and uses the in-place `D2` destructor. It never calls the deleting `D0` destructor on stack storage.

For the one event balance formatter, a bounded parser converts one existing `%d` field to `%s` and inserts the wallet text. Literal `%%` is preserved. Other formats and missing wallet state call the original formatter with the original numeric argument. Prices and reward formatting use different call sites and are unchanged.

## Integration

After the core wallet has been integrated into a source string:

```python
from wallet_ui_policy import integrate_source, integrate_builder
source = integrate_source(source)
builder_source = integrate_builder(builder_source)
```

The source transform adds `wallet_ui_payload.inc`; the builder transform adds its one entry hook, original-function bindings and `add_wallet_ui_hooks` invocation. `stage_payload(output_dir, source_dir)` recursively copies required local quoted includes under a flat-filename guard for isolated compilation. It does not modify the shared source.

## Verification and limits

`verify_wallet_ui.py` executes the compiled C and assembly at nonzero ASLR on both ABIs. It checks common menus, both career modes, missing wallet objects, unrelated modes, wrong actor ownership, original numeric fallbacks, popup font/color preservation, currency colors, all fitted layout arguments, boolean stack widths, string lifetime, event formatting and unchanged price instructions. Cocos string/font allocation and rendering boundaries are explicitly mocked, so these are instruction and ABI checks, not Android screenshot evidence.

The completed instruction run passed338 checks:139 AArch64 and199 Thumb. The wallet include hash was `d791651b9fe381f73405621c38c572018dc0b6c8af782875b0117d094d8aa240`; the UI source and compiled-stage hashes are recorded in `wallet_ui_verification.json`.

Actual Android verification of these newly added balance projections remains pending until the integrated APK is installed and the original menu/shop screens are observed. The instruction report is not evidence of an actual Android purchase.
