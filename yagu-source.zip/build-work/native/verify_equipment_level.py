"""Execute enhancement state, original bounded storage/table and UI hooks.

Both ABIs run at nonzero load bias. Original option getter, original clamped
adder, actual GVXL GetVal/GetSize and original enhancement bonus caller execute.
UI checks stop at the existing formatter/font boundary, not a rendered screen.
"""
import hashlib
import json
import struct
import sys
import types
import zipfile
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks, GETMODE
from special_uses_policy import stage_payload as stage_special, BINDINGS as SPECIAL_BINDINGS
from equipment_level_policy import stage_payload, HOOKS, BINDINGS, integrate_career_ui_source
from equipment_level_ui import add_equipment_level_ui_hooks, FORMATTERS, FONT, LEVEL, NUMBER
from verify_honors import configure, invoke, original_plt
from verify_relocation import TEAMS, TEAM, BAT, PIT, SAVE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
from verify_elite_world import original_cap_table, LOADER, DEFINE
from unicorn.arm64_const import UC_ARM64_REG_X29
from unicorn.arm_const import UC_ARM_REG_R7

WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'analysis/data/tools'))
from zt1_codec import RecordTable, StringTable, unpack_zt1

OPTION = HEAP + 0xa0000
OTHER_OPTION = HEAP + 0xa2000
BUFFER = HEAP + 0xa4000
FORMAT = HEAP + 0xa6000
LABEL = HEAP + 0xa7000
UI = HEAP + 0xa8000
INFINITY = '\u221e'


def signed(value):
    value &= 0xffffffff
    return value - 0x100000000 if value & 0x80000000 else value


def cstr(c, addr, bound=1024):
    return bytes(c.uc.mem_read(addr, bound)).split(b'\0', 1)[0]


def verify(abi, source_dir):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    root_before = payload_builder.ROOT
    hooks_before, bindings_before = dict(payload_builder.HOOKS), dict(payload_builder.BINDINGS)
    payload_builder.ROOT = source_dir
    payload_builder.HOOKS.update(HOOKS)
    payload_builder.BINDINGS.update(SPECIAL_BINDINGS)
    payload_builder.BINDINGS.update(BINDINGS)
    try:
        payload = payload_builder.add_payload(b, workdir=WORK / 'equipment_level_build' / abi)
    finally:
        payload_builder.ROOT = root_before
        payload_builder.HOOKS.clear(); payload_builder.HOOKS.update(hooks_before)
        payload_builder.BINDINGS.clear(); payload_builder.BINDINGS.update(bindings_before)
    symbols = payload['symbols']
    career = types.ModuleType('equipment_staged_career_ui')
    exec(compile(integrate_career_ui_source((WORK/'career_ability_ui.py').read_text()),
                 'equipment-staged-career-ui', 'exec'), career.__dict__)
    number = career.add_rest_current_condition_hook(b, symbols)
    sites = add_equipment_level_ui_hooks(b, symbols)
    slide = 0x7c76543000 if b.is64 else 0xa7654000
    counts = dict(schema=0, owned_storage=0, original_finite_storage=0,
                  typed_scope=0, menu_identity=0, original_table=0,
                  formatter_locales=0, formatter_rejection=0, ui_sites=0,
                  main_font=0, shared_number=0, typed_max_branch=0,quest_comparisons=0,
                  next_table_calls=0,purchase_cancellation=0)
    with zipfile.ZipFile(ROOT/'upload/baseball-superstars-2013-1-2-9.apk') as z:
        strength = RecordTable.parse(unpack_zt1(z.read('assets/data/XlsStrengthItem.zt1')))
        common = [StringTable.parse(unpack_zt1(z.read(n))) for n in z.namelist()
                  if n.endswith('/StrCOMMON_BB2013.zt1')]
    assert strength.row_count == 100 and struct.unpack('<hbbbh',strength.row(99)) == (1865,25,35,10,1250)

    def setup(mode=4):
        c, _, _ = configure(b, slide, mode, payload)
        original_plt(c)
        c.callbacks[b.sym('CBBGStatic::IsBatMode()') + slide] = lambda: c.ret(mode == 4)
        c.ptr(MGR+(0x518 if b.is64 else 0x4e0),OPTION)
        c.ptr(MGR+(0x528 if b.is64 else 0x4e8),SAVE if mode in (0,4) else 0)
        c.ptr(MGR+(0x520 if b.is64 else 0x4e4),SAVE if mode == 3 else 0)
        c.ptr(MGR+(0x38 if b.is64 else 0x30),BAT)
        c.ptr(MGR+(0x40 if b.is64 else 0x34),PIT)
        c.uc.mem_write(OPTION,bytes([0x33])*0x300)
        c.uc.mem_write(OTHER_OPTION,bytes([0x19])*0x300)
        c.uc.mem_write(LABEL,'파워'.encode()+b'\0')
        c.uc.mem_write(BUFFER,b'\x61'*1024)
        return c

    def call(c,name,*args):
        return invoke(c,b.sym(HOOKS[name]) if name in HOOKS else symbols[name],*args)

    def sprint(c):
        """Model the original variadic formatter boundary, preserving ABI args."""
        fmt = cstr(c,c.r(1)).decode()
        args = []
        conversions=[]
        i=0
        while i < len(fmt):
            if fmt[i]=='%':
                i+=1
                if fmt[i]!='%': conversions.append(fmt[i])
            i+=1
        for i,conversion in enumerate(conversions):
            value = c.r(i+2) if b.is64 or i<2 else struct.unpack('<I',c.uc.mem_read(c.uc.reg_read(c.sp)+(i-2)*4,4))[0]
            args.append(cstr(c,value).decode() if conversion=='s' else signed(value))
        rendered=(fmt%tuple(args)).encode()
        assert len(rendered)<900
        c.uc.mem_write(c.r(0),rendered+b'\0')
        c.ret(len(rendered))

    for mode in (3,4):
        print(abi,'storage mode',mode,flush=True)
        c=setup(mode)
        state=call(c,'yagu_state',BAT)
        raw=bytes(c.uc.mem_read(state,8+51*16))
        assert struct.unpack_from('<II',raw)==(4,1000)
        assert all(struct.unpack_from('<QII',raw,8+16*i)==(0,1,0) for i in range(51))
        counts['schema']+=52
        role_values=(0,) if mode==3 else (0,1)
        for is_batter in role_values:
            for part in range(4):
                selected=0x154+is_batter*4+part
                for old in (0,1,77,78,98,99,-1,-128,127):
                    for delta in (-100000,-99,-1,0,1,99,100000):
                        c.uc.mem_write(OPTION+selected,bytes([old&255]))
                        before=bytes(c.uc.mem_read(OPTION,0x300))
                        assert call(c,'equip_level',OPTION,is_batter,part)==99
                        call(c,'add_equip_level',OPTION,is_batter,part,delta)
                        after=bytes(c.uc.mem_read(OPTION,0x300))
                        assert after==before[:selected]+b'\x63'+before[selected+1:]
                        assert bytes(c.uc.mem_read(state,len(raw)))==raw
                        counts['owned_storage']+=1
                for old in (0,1,78,98,99):
                    for delta in (-1000,-1,0,1,1000):
                        c.uc.mem_write(OTHER_OPTION+selected,bytes([old]))
                        before=bytes(c.uc.mem_read(OTHER_OPTION,0x300))
                        assert call(c,'equip_level',OTHER_OPTION,is_batter,part)==old
                        call(c,'add_equip_level',OTHER_OPTION,is_batter,part,delta)
                        expect=min(99,max(0,old+delta))
                        assert bytes(c.uc.mem_read(OTHER_OPTION,0x300))==before[:selected]+bytes([expect])+before[selected+1:]
                        counts['original_finite_storage']+=1
                assert call(c,'yagu_equipment_scalar',OPTION,is_batter,part)==state+8+(47+part)*16
                counts['typed_scope']+=1
        for option,role,part in ((0,1,0),(OTHER_OPTION,1,0),(OPTION,-1,0),(OPTION,2,0),(OPTION,1,-1),(OPTION,1,4),(OPTION,1,10000)):
            assert call(c,'yagu_equipment_scalar',option,role,part)==0
            counts['typed_scope']+=1
        for role,actor in ((0,PIT),(1,BAT)):
            expected=mode==4 or role==0
            assert bool(call(c,'yagu_equipment_player_scalar',actor,0))==expected
            copy=HEAP+0xac000
            c.uc.mem_write(copy,bytes(c.uc.mem_read(actor,52 if not role else 44)))
            assert call(c,'yagu_equipment_player_scalar',copy,0)==0
            counts['menu_identity']+=2
        for key,mutate,restore in (
            ('no_save', lambda:c.ptr(MGR+(0x528 if b.is64 else 0x4e8) if mode==4 else MGR+(0x520 if b.is64 else 0x4e4),0),
                        lambda:c.ptr(MGR+(0x528 if b.is64 else 0x4e8) if mode==4 else MGR+(0x520 if b.is64 else 0x4e4),SAVE)),
            ('bad_team',lambda:c.uc.mem_write(TEAMS+4,struct.pack('<i',15)),lambda:c.uc.mem_write(TEAMS+4,struct.pack('<i',4))),
            ('no_actor',lambda:c.uc.mem_write(BAT if mode==4 else PIT,struct.pack('<H',25)),lambda:c.uc.mem_write(BAT if mode==4 else PIT,struct.pack('<H',1000 if mode==4 else 1100))),
            ('bad_count',lambda:c.uc.mem_write(TEAM+3,b'\x0d'),lambda:c.uc.mem_write(TEAM+3,b'\x0c')),
        ):
            mutate()
            assert call(c,'yagu_equipment_current',0)==0,key
            restore();counts['typed_scope']+=1

        # Original GXL decoder reads the real shipped 100-row strength table.
        original_cap_table(c,strength)
        c.callbacks[b.sym('CBBGMgrDefine::GetXLData(EnumXlsData)')+slide]=lambda:(
            c.ret(LOADER) if c.r(1)==19 else (_ for _ in ()).throw(AssertionError('wrong XL enum')))
        c.callbacks[b.sym('CBBGDataMgr::GetRaiseMode(eGameMode)')+slide]=lambda:c.ret(SAVE+8)
        c.callbacks[b.sym('CBBGDataMgr::GetRaisePlayer(eGameMode)')+slide]=lambda:c.ret(BAT if mode==4 else PIT)
        c.callbacks[b.sym('CBBGPlayerData::IsBatter()')+slide]=lambda:c.ret(mode==4)
        rows=[]
        dyn=b.elf.get_section_by_name('.dynsym')
        plt=b.elf.get_section_by_name('.plt')['sh_addr']
        rels=b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
        getter_name=next(symbol.name for symbol in dyn.iter_symbols() if symbol['st_value'] and (symbol['st_value']&~int(not b.is64))==b.sym('GVXLLoader::GetVal(int, int)'))
        for index,rel in enumerate(rels.iter_relocations()):
            if dyn.get_symbol(rel['r_info_sym']).name==getter_name:
                def getval():
                    assert c.r(0)==LOADER and c.r(1)==0 and 0<=signed(c.r(2))<100
                    rows.append(c.r(2))
                    c.uc.reg_write(c.pc,(b.sym('GVXLLoader::GetVal(int, int)')+slide)|int(not b.is64))
                c.callbacks[plt+32+index*16+slide]=getval
        for part in range(4):
            for old in (0,78,98,99):
                c.uc.mem_write(OPTION+0x154+(4 if mode==4 else 0)+part,bytes([old]))
                for nxt in (0,1):
                    assert call(c,'equip_bonus',part,nxt)==1865
                    assert rows[-1]==99
                    counts['original_table']+=1
                assert call(c,'equip_success_per',UI,part)==100
                counts['original_table']+=1

        # Execute the five existing next-row callsites against the actual table.
        c.ptr(SP+0x70 if b.is64 else SP+0x3c,UI)
        parent=SP+0x500
        c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7,parent)
        for site in sites:
            if not site['label'].startswith('next_table_'):continue
            for part in (0,3):
                c.uc.mem_write(UI+(0xb8 if b.is64 else 0x6c),struct.pack('<i',part))
                c.uc.mem_write(parent-0xb4 if b.is64 else SP+0x114,struct.pack('<i',part))
                c.stopped=None;c.stops={site['site']+4+slide};c.uc.reg_write(c.sp,SP)
                for i,value in enumerate((LOADER,site['column'],100)):c.r(i,value)
                c.run_relative(site['site'])
                expected=struct.unpack('<hbbbh',strength.row(99))[site['column']]
                assert c.r(0)==expected and c.uc.reg_read(c.sp)==SP
                counts['next_table_calls']+=1

        c.callbacks[b.sym('MC_knlSprintk')+slide]=lambda:sprint(c)
        formats=['Lv %d','%s +%d']+[table.strings[i][:-1].decode() for table in common for i in (228,557,558,559)]
        for fmt in formats:
            c.uc.mem_write(FORMAT,fmt.encode()+b'\0')
            if fmt.count('%d')!=1 or ('%' in fmt.replace('%d','').replace('%s','').replace('%%','')): continue
            for part in range(4):
                result=call(c,'yagu_format_equipment',BUFFER,FORMAT,LABEL if '%s' in fmt else 0,part)
                expected=fmt.replace('%d','%s')%((cstr(c,LABEL).decode(),INFINITY) if '%s' in fmt else (INFINITY,))
                assert cstr(c,BUFFER).decode()==expected and result==len(expected.encode())
                counts['formatter_locales']+=1
        for fmt in ('%n','%100d','%d %d','%d %s','%s','x'*256,'%'):
            c.uc.mem_write(FORMAT,fmt.encode()+b'\0')
            before=bytes(c.uc.mem_read(BUFFER,1024))
            assert signed(call(c,'yagu_format_equipment',BUFFER,FORMAT,LABEL,0))==-1
            assert bytes(c.uc.mem_read(BUFFER,1024))==before
            counts['formatter_rejection']+=1

        # Both direct upgrade and random-box purchase stop before original
        # table100/debit/sync consumers, reusing the native MAX popup.
        c.uc.mem_write(FORMAT,b'MAX LEVEL\0')
        c.callbacks[b.sym(BINDINGS['equipment_resource_manager'])+slide]=lambda:c.ret(DEFINE)
        def common_string():
            assert c.r(0)==DEFINE and c.r(1)==546
            c.ret(FORMAT)
        c.callbacks[b.sym(BINDINGS['equipment_common_string'])+slide]=common_string
        popups=[]
        def popup():
            assert tuple(c.r(i) for i in range(4))==(FORMAT,2,1,1)
            popups.append(1);c.ret(0)
        c.callbacks[b.sym(BINDINGS['equipment_max_popup'])+slide]=popup
        for entry in ('equipment_process','equipment_lunch_buy'):
            part_off=(0xb8 if b.is64 else 0x6c) if entry=='equipment_process' else (0x9c if b.is64 else 0x58)
            for part in (0,3):
                c.uc.mem_write(UI,b'\x55'*0x100)
                c.uc.mem_write(UI+part_off,struct.pack('<i',part))
                before_ui=bytes(c.uc.mem_read(UI,0x100));before_option=bytes(c.uc.mem_read(OPTION,0x300))
                count=len(popups)
                call(c,entry,UI)
                assert len(popups)==count+1 and bytes(c.uc.mem_read(OPTION,0x300))==before_option
                expected_ui=bytearray(before_ui)
                if entry=='equipment_lunch_buy':expected_ui[0xa6 if b.is64 else 0x62]=1
                assert bytes(c.uc.mem_read(UI,0x100))==expected_ui
                counts['purchase_cancellation']+=1
            seen=[]
            original=payload['original_bindings']['original_'+entry]+slide
            c.callbacks[original]=lambda:(seen.append(c.r(0)),c.ret(0))
            c.uc.mem_write(UI+part_off,struct.pack('<i',4))
            call(c,entry,UI)
            assert seen==[UI]
            counts['purchase_cancellation']+=1

    # Main menu can show the exact saved actor while current gameMode is zero.
    c=setup(0)
    assert call(c,'yagu_equipment_current',0)==0
    assert cstr(c,call(c,'yagu_equipment_menu_text',BAT,1)).decode()=='Lv. '+INFINITY
    c.ptr(MGR+(0x38 if b.is64 else 0x30),HEAP+0xac000)
    assert call(c,'yagu_equipment_menu_text',BAT,1)==0
    counts['menu_identity']+=3

    def run_site(c, site, args, stop=None):
        c.stopped=None
        c.stops={site+4+slide if stop is None else stop}
        c.uc.reg_write(c.sp,SP)
        c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1)
        for i,value in enumerate(args):
            if i<(8 if b.is64 else 4):c.r(i,value)
            else:c.uc.mem_write(SP+(i-4)*4,struct.pack('<I',value))
        c.run_relative(site)
        assert c.uc.reg_read(c.sp)==SP

    for mode in (4,2):
        c=setup(mode)
        c.callbacks[b.sym('MC_knlSprintk')+slide]=lambda:sprint(c)
        for spec,site in zip(FORMATTERS[abi],sites[1:10]):
            label,_,_,has_label,offset,from_ui=spec
            for part in (0,3,4):
                if from_ui:
                    c.ptr(SP+offset,UI)
                    c.uc.mem_write(UI+(0xb8 if b.is64 else 0x6c),struct.pack('<i',part))
                else:c.uc.mem_write(SP+offset,struct.pack('<i',part))
                fmt='강화 성공 시 %s+%d' if has_label else 'Lv %d'
                c.uc.mem_write(FORMAT,fmt.encode()+b'\0')
                args=(BUFFER,FORMAT,LABEL,99) if has_label else (BUFFER,FORMAT,99,0)
                run_site(c,site['site'],args)
                output=fmt.replace('%d','%s')%((cstr(c,LABEL).decode(),INFINITY) if has_label else (INFINITY,)) if mode==4 and part<4 else fmt%((cstr(c,LABEL).decode(),99) if has_label else (99,))
                assert cstr(c,BUFFER).decode()==output,(abi,label,mode,part,cstr(c,BUFFER),output)
                counts['ui_sites']+=1

    for mode,actor,bool_arg,expected in ((4,BAT,1,True),(3,PIT,0,True),(0,BAT,1,True),(4,BAT,0,False),(4,TEAM+0x1a4,1,False)):
        c=setup(mode)
        frame=SP+0x400
        c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7,frame)
        c.ptr(SP+(0x178 if b.is64 else 0xe8),actor)
        c.uc.mem_write(SP+0x1b4 if b.is64 else frame-0xfd,bytes([bool_arg]))
        args=(BUFFER,100,1,16,18,255,192,255)
        seen=[]
        def font(owned):
            assert owned==expected
            if owned:assert cstr(c,c.r(1)).decode()=='Lv. '+INFINITY
            else:assert c.r(1)==100
            for i,value in enumerate(args):
                if i==1:continue
                actual=c.r(i) if i<(8 if b.is64 else 4) else struct.unpack('<I',c.uc.mem_read(SP+(i-4)*4,4))[0]
                assert actual==value,(i,actual,value)
            seen.append(owned);c.ret(0)
        c.callbacks[b.sym(FONT)+slide]=lambda:font(True)
        c.callbacks[b.sym(LEVEL)+slide]=lambda:font(False)
        run_site(c,sites[0]['site'],args)
        assert seen==[expected]
        counts['main_font']+=1

    for actor in (BAT,PIT,TEAM+0x1a4):
        for valid_caller in (True,False):
            c=setup(4)
            inner,parent=SP+0x2000,SP+0x3000
            c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7,inner)
            c.ptr(inner,parent)
            c.ptr(inner+(8 if b.is64 else 4),NUMBER[abi][1]+slide+(0 if valid_caller else 4))
            c.ptr(parent-(0x70 if b.is64 else 0x54),UI)
            c.ptr(UI+(0x30 if b.is64 else 0x20),actor)
            c.uc.mem_write(FORMAT,b'%d\0')
            c.callbacks[b.sym('MC_knlSprintk')+slide]=lambda:sprint(c)
            run_site(c,NUMBER[abi][0],(BUFFER,FORMAT,100))
            assert cstr(c,BUFFER).decode()==(INFINITY if valid_caller and actor in (BAT,PIT) else '100')
            counts['shared_number']+=1

    maximum=next(site for site in sites if site['label']=='max_decision')
    for mode in (4,2):
        for part in (0,3,4):
            for raw_level in (0,98,99):
                c=setup(mode)
                frame=SP+0x200
                c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7,frame)
                if b.is64:
                    c.uc.mem_write(frame-0xc,struct.pack('<i',part))
                    c.uc.mem_write(frame-0x10,struct.pack('<i',raw_level))
                    finite=0x507af4
                else:
                    c.uc.mem_write(SP+0x48,struct.pack('<i',part))
                    c.uc.mem_write(SP+0x44,struct.pack('<i',raw_level))
                    finite=0x32753e
                c.stopped=None;c.stops={maximum['maximum']+slide,finite+slide}
                c.uc.reg_write(c.sp,SP)
                c.run_relative(maximum['site'])
                expected=maximum['maximum'] if (mode==4 and part<4) or raw_level==99 else finite
                assert c.stopped==expected+slide and c.uc.reg_read(c.sp)==SP
                counts['typed_max_branch']+=1

    for mode in (3,4,2):
        c=setup(mode)
        for site in sites:
            if not site['label'].startswith('quest_'):continue
            for option in (OPTION,OTHER_OPTION):
                for threshold in (-2147483648,-1,0,1,26,100,101,65535,2147483647):
                    c.uc.mem_write(SP+site['threshold_sp'],struct.pack('<i',threshold))
                    c.uc.mem_write(SP+site['result_sp'],b'\0')
                    c.uc.mem_write(option+0x154+(4 if mode==4 else 0)+site['part'],b'\x19')
                    run_site(c,site['site'],(option,int(mode==4),site['part']),site['done']+slide)
                    expected=(mode in (3,4) and option==OPTION) or threshold<=26
                    assert c.uc.mem_read(SP+site['result_sp'],1)==bytes([expected]),(abi,mode,site,option,threshold)
                    counts['quest_comparisons']+=1

    return dict(abi=abi,load_bias=hex(slide),passed=sum(counts.values()),checks=counts,
                original_table_rows=strength.row_count,adapter=99,table_bonus_at_adapter=1865,
                display_sites=11,purchase_decision_sites=3,quest_decision_sites=16,next_row_sites=5,
                entry_hooks=len(HOOKS),patch_count_in_test=len(b.patches),
                android_runtime_verified=False)


if __name__=='__main__':
    base=WORK/'equipment_level_build'/'special-source'
    source=WORK/'equipment_level_build'/'source'
    super_stage=stage_special(base)
    stage=stage_payload(source,base)
    results=[verify(abi,source) for abi in ('arm64-v8a','armeabi-v7a')]
    report=dict(status='pass',base_c_sha256=super_stage['base_c_sha256'],
                staged_c_sha256=stage['staged_c_sha256'],player_schema=4,player_scalars=51,
                record_schema=4,record_scalars=40,total_checks=sum(x['passed'] for x in results),
                abis=results,semantic_infinity_not_adapter=True,android_runtime_verified=False,
                source_files={name:hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in
                  ('equipment_level_payload.inc','equipment_level_policy.py','equipment_level_ui.py','verify_equipment_level.py')})
    (WORK/'equipment_level_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
