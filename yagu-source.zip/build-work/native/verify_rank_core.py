"""Reconstructed local-rank regression suite for candidate7.

Runs the real patched Analyze entry and original finite record getters at two
nonzero ABI load biases. Roster/save service lookups are controlled fixtures;
no UI, remote rankings, Android renderer, or match simulation is claimed.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from payload_builder import add_payload, HOOKS, BINDINGS
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from verify_relocation import prepare_case, TEAMS, TEAM, SAVE, BAT, PIT
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP

WORK = Path(__file__).resolve().parent
ANALYZER = HEAP + 0x80000
UI = HEAP + 0x81000
LOCAL_TAB = HEAP + 0x82000
SORT = {1: ('rank_pit_win', 4), 2: ('rank_pit_lost', 5), 3: ('rank_pit_save', 7),
        4: ('rank_pit_era', 0), 5: ('rank_pit_er', 2), 6: ('rank_pit_k', 8),
        7: ('rank_pit_hold', 6), 8: ('rank_pit_whip', 11), 9: ('rank_pit_k9', 12),
        11: ('rank_bat_hit', 2), 12: ('rank_bat_hr', 5), 13: ('rank_bat_steal', 7),
        14: ('rank_bat_rbi', 6), 15: ('rank_bat_avg', 0), 16: ('rank_bat_slg', 10),
        17: ('rank_bat_obp', 11), 18: ('rank_bat_ops', 12)}
ZERO_SORTS = {2, 4, 5, 8}

def signed(n):
    n &= 0xffffffff
    return n - 0x100000000 if n & 0x80000000 else n

def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'rank_core_build' / abi)
    symbols, bindings = payload['symbols'], payload['original_bindings']
    slide = 0x7256430000 if b.is64 else 0x87543000
    c = prepare_case(b, slide)
    mode = [4]
    manager = [MGR]
    phase = [False, False, 45]
    fallback = []
    actors, records, activity, raw_values = {}, {}, {}, {}
    totals = {key: 0 for key in ['finite_getters', 'rank_tables', 'preserved_state', 'fallbacks', 'scope', 'navigation_helpers', 'typed_comparisons']}

    # Original internal leaves and arithmetic execute, rather than replacing
    # every opponent statistic with a test implementation.
    dyn = list(b.elf.get_section_by_name('.dynsym').iter_symbols())
    rel = b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
    plt = b.elf.get_section_by_name('.plt')['sh_addr']
    for i, r in enumerate(rel.iter_relocations()):
        address = int(dyn[r['r_info_sym']]['st_value'])
        if address:
            c.callbacks[slide + plt + 32 + i * 16] = lambda address=address: c.uc.reg_write(c.pc, address + slide)
    c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(mode[0])
    c.callbacks[b.sym(GETMGR) + slide] = lambda: c.ret(manager[0])
    c.callbacks[bindings['rank_get_team'] + slide] = lambda: c.ret(TEAMS + 8 + c.r(2) * 0x3b4 if 0 <= c.r(2) < 10 else 0)
    c.callbacks[bindings['rank_is_postseason'] + slide] = lambda: c.ret(int(phase[0]))
    c.callbacks[bindings['rank_is_cup'] + slide] = lambda: c.ret(int(phase[1]))
    # Original GetGameCount returns a signed byte promoted by the ABI, including
    # ARM32's caller-visible sign extension. A zero-extended mock is incorrect.
    c.callbacks[bindings['rank_game_count'] + slide] = lambda: c.ret(phase[2] if phase[2] < 128 else phase[2] - 256)
    for role in (0, 1):
        alias = 'rank_pitcher_record' if role else 'rank_batter_record'
        c.callbacks[bindings[alias] + slide] = lambda role=role: c.ret(records.get((role, c.r(2)), 0))

    def fallback_analyze():
        fifth = c.r(4) if b.is64 else struct.unpack('<I', c.uc.mem_read(c.uc.reg_read(c.sp), 4))[0]
        fallback.append(tuple(c.r(i) & 0xffffffff for i in range(4)) + (fifth & 0xff,))
        c.ret(0)
    c.callbacks[bindings['original_rank_analyze'] + slide] = fallback_analyze

    def call_address(address, *args):
        c.stops, c.stopped = {STOP}, None
        c.uc.reg_write(c.sp, SP)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        keep = (19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29) if b.is64 else (4, 5, 6, 7, 8, 9, 10, 11)
        before = {i: c.r(i) for i in keep}
        mask = (1 << (64 if b.is64 else 32)) - 1
        for i, value in enumerate(args):
            if i < (8 if b.is64 else 4): c.r(i, value & mask)
            else: c.uc.mem_write(SP + (i - 4) * 4, struct.pack('<I', value & 0xffffffff))
        start = address + slide
        c.uc.emu_start(start if b.is64 else start | 1, STOP, count=2000000)
        if c.uc.reg_read(c.pc) == STOP: c.stopped = STOP
        assert c.stopped == STOP and c.uc.reg_read(c.sp) == SP, (abi, hex(address), hex(c.uc.reg_read(c.pc)))
        assert all(c.r(i) == v for i, v in before.items()), ('callee-save', abi, hex(address))
        return c.r(0)

    def call(name, *args):
        return call_address(b.sym(HOOKS[name]) if name in HOOKS else symbols[name], *args)

    def configure(g=4):
        mode[0], manager[0] = g, MGR
        c.ptr(MGR + (0x520 if b.is64 else 0x4e4), SAVE)
        c.ptr(MGR + (0x528 if b.is64 else 0x4e8), SAVE)
        c.ptr(MGR + (0x530 if b.is64 else 0x4ec), TEAMS)
        c.uc.mem_write(SAVE, bytes(0x4000))
        c.uc.mem_write(TEAMS + 4, struct.pack('<I', 4))
        actors.clear(); records.clear(); activity.clear(); raw_values.clear()
        for team in range(10):
            base = TEAMS + 8 + team * 0x3b4
            c.uc.mem_write(base, bytes(0x3b4))
            c.uc.mem_write(base, bytes([team, 0, 2, 6]))
            for role, count, stride, offset, rec_count, rec_stride, rec_base in (
                    (0, 6, 44, 0x1a4, 12, 24, 0x1de4 if g == 3 else 0x1d8c),
                    (1, 2, 52, 4, 8, 32, 0xee4 if g == 3 else 0xe8c)):
                for i in range(count):
                    actor = base + offset + i * stride
                    is_hero = team == 4 and i == (0 if role else 5)
                    identity = (1100 if role else 1000) if is_hero else 100 + team * 20 + role * 10 + i
                    slot = (6 if role else 9) if is_hero else i
                    record = SAVE + rec_base + team * rec_count * rec_stride + slot * rec_stride
                    c.uc.mem_write(actor, struct.pack('<H', identity))
                    score = (team * 7 + i * 3) % 19
                    if role:
                        data = bytearray(32)
                        struct.pack_into('<H', data, 0, identity)
                        struct.pack_into('<I', data, 4, 3 * (score + 1))
                        struct.pack_into('<I', data, 8, score * 9)
                        for off, val in ((0xc, score + 2), (0xe, score + 1), (0x10, score + 1), (0x12, score % 4), (0x16, score % 7), (0x1c, score % 5 + 1), (0x1e, score % 6)):
                            struct.pack_into('<H', data, off, val)
                    else:
                        data = bytearray(struct.pack('<12H', identity, 20 + score * 8, 8 + score, 1, 1, score % 3 + 1, score * 3, score % 9, 0, score % 4, 1, 0))
                    if is_hero:
                        data[2:] = bytes(rec_stride - 2)
                    c.uc.mem_write(record, bytes(data))
                    actors[(role, team, i)] = actor
                    records[(role, actor)] = record
                    activity[(role, actor)] = 0 if is_hero else (3 * (score + 1) if role else 20 + score * 8)
        for sort, (alias, metric) in SORT.items():
            role = int(sort < 11)
            for (r, team, i), actor in actors.items():
                if r != role: continue
                raw_values[(sort, actor)] = signed(call_address(bindings[alias], records[(role, actor)]))
                totals['finite_getters'] += 1

    def reference(sort, descending, fixed):
        role = int(sort < 11)
        hero = PIT if role else BAT
        rev = not descending if sort in (4, 8) else bool(descending)
        min_ab, min_pitch = 113, 31
        if not fixed:
            if phase[0] or phase[1]: min_ab = min_pitch = 1
            else:
                games = phase[2] if phase[2] < 128 else phase[2] - 256
                div = lambda n, d: abs(n) // d * (-1 if n < 0 else 1)
                min_ab = max(1, div(div(games * 250, 10) + 9, 10))
                min_pitch = max(1, div(games * 70, 100))
        hero_value = (0, 0) if sort in ZERO_SORTS else (1, 0)
        result, hero_rank = [], 1
        for (r, team, i), actor in actors.items():
            if r != role: continue
            owned = actor == hero
            active = activity[(role, actor)]
            if not owned and active <= 0: continue
            rate = sort in ((4, 8, 9) if role else (15, 16, 17, 18))
            if rate and not owned and (active * 2 // 3 if role else active) < (min_pitch if role else min_ab): continue
            value = hero_value if owned else (0, raw_values[(sort, actor)])
            if not owned and ((value > hero_value) if (rev if role else True) else (value < hero_value)):
                hero_rank += 1
            at = next((j for j, x in enumerate(result) if (value > x[0] if rev else value < x[0])), len(result))
            if at < 10:
                result.insert(at, (value, actor, team)); result = result[:10]
                if owned: hero_rank = at + 1
        return [(x[1], x[2]) for x in result], hero_rank

    for g in (3, 4):
        configure(g)
        frozen_save = bytes(c.uc.mem_read(SAVE, 0x4000))
        frozen_roster = bytes(c.uc.mem_read(TEAMS, 8 + 15 * 0x3b4))
        for phase_value in ((False, False, 45), (True, False, 45), (False, True, 45), (False, False, 0), (False, False, 255)):
            phase[:] = phase_value
            for sort in SORT:
                for direction in (0, 1):
                    for fixed in (0, 1):
                        c.uc.mem_write(ANALYZER - 16, bytes([0xa7]) * 0xb0)
                        expected, hero_rank = reference(sort, direction, fixed)
                        call('rank_analyze', ANALYZER, sort, g, direction, fixed)
                        pofs, tofs, sofs = (8, 0x58, 0x80) if b.is64 else (4, 0x2c, 0x54)
                        for row in range(10):
                            actor = int.from_bytes(c.uc.mem_read(ANALYZER + pofs + row * (8 if b.is64 else 4), 8 if b.is64 else 4), 'little')
                            assert actor == (expected[row][0] if row < len(expected) else 0), (abi, g, sort, direction, fixed, phase_value, row, hex(actor), expected)
                            if actor:
                                team = struct.unpack('<I', c.uc.mem_read(ANALYZER + tofs + row * 4, 4))[0]
                                assert team == expected[row][1]
                        assert struct.unpack('<I', c.uc.mem_read(ANALYZER, 4))[0] == hero_rank
                        assert struct.unpack('<I', c.uc.mem_read(ANALYZER + sofs, 4))[0] == sort
                        assert c.uc.mem_read(ANALYZER - 16, 16) == bytes([0xa7]) * 16
                        assert c.uc.mem_read(ANALYZER + sofs + 4, 16) == bytes([0xa7]) * 16
                        totals['rank_tables'] += 1
        assert bytes(c.uc.mem_read(SAVE, 0x4000)) == frozen_save
        assert bytes(c.uc.mem_read(TEAMS, 8 + 15 * 0x3b4)) == frozen_roster
        totals['preserved_state'] += 2

    configure()
    for sort in (-1, 0, 10, 19, 0x7fffffff):
        prior = len(fallback)
        call('rank_analyze', ANALYZER, sort, 4, 1, 1)
        assert len(fallback) == prior + 1
        totals['fallbacks'] += 1
    for issue in ('wrong_game', 'missing_manager', 'missing_save', 'missing_teams', 'bad_team', 'missing_actor', 'bad_record', 'opponent_duplicate'):
        configure()
        if issue == 'wrong_game': mode[0] = 1
        elif issue == 'missing_manager': manager[0] = 0
        elif issue == 'missing_save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
        elif issue == 'missing_teams': c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
        elif issue == 'bad_team': c.uc.mem_write(TEAMS + 4, struct.pack('<i', 15))
        elif issue in ('missing_actor', 'opponent_duplicate'):
            c.uc.mem_write(BAT, struct.pack('<H', 12))
            if issue == 'opponent_duplicate': c.uc.mem_write(actors[(0, 5, 0)], struct.pack('<H', 1000))
        elif issue == 'bad_record': c.uc.mem_write(records[(0, BAT)], struct.pack('<H', 12))
        prior = len(fallback)
        call('rank_analyze', ANALYZER, 12, 4, 1, 1)
        assert len(fallback) == prior + 1
        assert call('yagu_rank_cell_text', BAT, 4, 0, 5) == 0
        totals['scope'] += 2

    configure()
    for tab in range(15):
        c.uc.mem_write(UI + (0x70 if b.is64 else 0x40), struct.pack('<i', tab))
        for direction in (-1, 1):
            assert call('yagu_rank_next_tab', UI, direction) == (tab + direction) % 15
            assert struct.unpack('<i', c.uc.mem_read(UI + (0x70 if b.is64 else 0x40), 4))[0] == tab
            totals['navigation_helpers'] += 1
        assert call('yagu_rank_is_batter', UI, LOCAL_TAB) == int(tab < 8)
        assert struct.unpack('<i', c.uc.mem_read(LOCAL_TAB, 4))[0] == (tab if tab < 8 else tab - 8)
        assert call('yagu_rank_local_tab', UI) == (tab if tab < 8 else tab - 8)
        assert call('yagu_rank_hero_player', int(tab < 8)) == (BAT if tab < 8 else PIT)
        totals['navigation_helpers'] += 3
    for g in (1, 3):
        mode[0] = g
        assert signed(call('yagu_rank_next_tab', UI, 1)) == -1
        assert signed(call('yagu_rank_is_batter', UI, LOCAL_TAB)) == -1
        assert call('yagu_rank_hero_player', 1) == 0
        totals['navigation_helpers'] += 3
    mode[0] = 4
    values = [(0, -0x80000000), (0, -1), (0, 0), (0, 65535), (0, 0x7fffffff), (1, 0)]
    for a in values:
        for z in values:
            expected = (a > z) - (a < z)
            assert signed(call('yagu_rank_relation', *a, *z)) == expected
            totals['typed_comparisons'] += 1
    return {'abi': abi, 'source_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(), 'load_bias': hex(slide), 'passed': sum(totals.values()), 'counts': totals, 'actual_finite_record_getters_executed': True, 'android_runtime_verified': False}

if __name__ == '__main__':
    reports = [verify(a) for a in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'rank_core_verification.json').write_text(json.dumps(reports, indent=2) + '\n')
    print(json.dumps(reports, indent=2))
