"""Scoped raw text for original award performance cells, preserving styling.

The three GetChangeFont sites are distinct from the shared career/roster sprintf
hook. Exact caller-return gates select only Ranker/Bonus performance cells.
MVP gifts, year-end money, all unrelated number widgets and malformed ownership
fall back with original arguments. The original font/size/color/layout remain.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE
from skill_points_hooks import skill_point_number_branches

FONT = 'CBBGStatic::GetChangeFont(CBBStringBuffer&, char const*, int, int, short, short, short, short)'
SITES = {
    'arm64-v8a': (
        ('integer', 0x5950d0, '7c6a0694', 0x46a02c, 0x46af24),
        ('average', 0x594bd8, 'ba6b0694', 0x469ed0, 0x46ae28),
        ('earned_run_average', 0x594da0, '486b0694', 0x469f78, 0x46aea0),
    ),
    'armeabi-v7a': (
        ('integer', 0x3849b6, 'edf08ced', 0x2bd84b, 0x2be2db),
        ('average', 0x3845f2, 'edf06eef', 0x2bd74f, 0x2be21d),
        ('earned_run_average', 0x384758, 'edf0baee', 0x2bd7cd, 0x2be279),
    ),
}


def add_award_record_ui_hooks(b, symbols):
    sites = []
    original = b.sym(FONT)
    current, past = symbols['yagu_award_current_text'], symbols['yagu_award_past_text']
    for label, site, expected, current_caller, past_caller in SITES[b.abi]:
        skill_points = skill_point_number_branches(b, symbols, site) if label == 'integer' else ''
        if b.is64:
            guard = 'cmp w2, #1\nb.lt original\ncmp w2, #2\nb.gt original' if label == 'integer' else 'cbnz w2, original'
            source = f'''{A64_SAVE}
{skill_points}
ldr x8, [x29, #8]
adrp x9, #{current_caller & ~4095}
add x9, x9, #{current_caller & 4095}
cmp x8, x9
b.eq current
adrp x9, #{past_caller & ~4095}
add x9, x9, #{past_caller & 4095}
cmp x8, x9
b.ne original
ldr x9, [x29]
cbz x9, original
ldur w2, [x9, #-0xc4]
{guard}
ldur x0, [x9, #-0xa8]
ldur x1, [x9, #-0xb0]
ldur w3, [x9, #-0xb4]
bl #{past}
b resolved
current:
ldr x9, [x29]
cbz x9, original
sub x9, x9, #0x200
ldr w2, [x9, #0x14]
{guard}
ldr x0, [x9, #0x20]
ldr x1, [x9, #0x18]
bl #{current}
resolved:
cbz x0, original
str x0, [sp, #8]
original:
{A64_RESTORE}
b #{original}'''
        else:
            current_delta = (current_caller - (site + 5)) & 0xffffffff
            past_delta = (past_caller - (site + 5)) & 0xffffffff
            guard = 'cmp r2, #1\nblt original\ncmp r2, #2\nbgt original' if label == 'integer' else 'cmp r2, #0\nbne original'
            source = f'''{T32_SAVE}
{skill_points}
ldr r3, [r7, #4]
movw r2, #{current_delta & 65535}
movt r2, #{current_delta >> 16}
add r2, lr
cmp r3, r2
beq current
movw r2, #{past_delta & 65535}
movt r2, #{past_delta >> 16}
add r2, lr
cmp r3, r2
bne original
ldr r3, [r7]
cmp r3, #0
beq original
ldr r2, [r3, #-0x94]
{guard}
ldr r0, [r3, #-0x84]
ldr r1, [r3, #-0x88]
ldr r3, [r3, #-0x8c]
bl #{past}
b resolved
current:
ldr r3, [r7]
cmp r3, #0
beq original
sub.w r3, r3, #0x200
ldr r2, [r3, #0x74]
{guard}
ldr r0, [r3, #0x7c]
ldr r1, [r3, #0x78]
bl #{current}
resolved:
cmp r0, #0
beq original
str r0, [sp, #4]
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Award own record styling: ' + label, source)
        b.patch(site, b.branch(site, hook, True), 'Render own award performance ' + label, expected)
        sites.append({'label': label, 'site': site, 'hook': hook,
                      'current_caller': current_caller, 'past_caller': past_caller})
    return sites
