"""Render typed owned career records in the original local ranking metric cell.

Only the two metric GetChangeFont calls inside RecordRankList::AddData are
changed. The caller must be the observed RecordRankUI table builder; its exact
row actor, team, role and normalized category determine the semantic lookup.
Names, ordinal ranks, opponent values and all eight font/style arguments keep
their original paths. No network ranking or new widget is introduced.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

FONT = 'CBBGStatic::GetChangeFont(CBBStringBuffer&, char const*, int, int, short, short, short, short)'
BAT_METRICS = (0, 2, 5, 6, 7, 10, 11, 12)
PIT_METRICS = (0, 4, 6, 7, 8, 11, 12)
PARENT_RETURN = {'arm64-v8a': 0x4f87fc, 'armeabi-v7a': 0x31d2c3}


def _metric_switch(is64):
    reg = 'w3' if is64 else 'r3'
    lines = [('cbnz w2, pitching' if is64 else 'cmp r2, #0\nbne pitching')]
    for role, values in (('batting', BAT_METRICS), ('pitching', PIT_METRICS)):
        if role == 'pitching': lines.append('pitching:')
        for index in range(len(values)):
            lines.extend((f'cmp {reg}, #{index}', f'b.eq {role}_{index}' if is64 else f'beq {role}_{index}'))
        lines.append('b original')
        for index, metric in enumerate(values):
            lines.extend((f'{role}_{index}:', f'mov {reg}, #{metric}' if is64 else f'movs {reg}, #{metric}', 'b resolved'))
    return '\n'.join(lines)


def rank_parent_context(b, site, destination):
    """Verified parent frame to destination (x8/r2); branch to original otherwise."""
    if b.is64:
        return f'''ldr x8, [x29, #8]
adrp x9, #0x4f8000
add x9, x9, #0x7fc
cmp x8, x9
b.ne original
ldr {destination}, [x29]
cbz {destination}, original
sub {destination}, {destination}, #0x3c0'''
    delta = (PARENT_RETURN[b.abi] - (site + 5)) & 0xffffffff
    return f'''ldr r3, [r7, #4]
movw r2, #{delta & 0xffff}
movt r2, #{delta >> 16}
add r2, lr
cmp r3, r2
bne original
ldr {destination}, [r7]
cmp {destination}, #0
beq original
sub.w {destination}, {destination}, #0x2c8'''


def add_local_rank_ui_hooks(b, symbols):
    original = b.sym(FONT)
    sites = [(0x4f9040, 'a0da0894'), (0x4f906c, '95da0894')] if b.is64 else [
             (0x31d836, '54f14cee'), (0x31d85a, '54f13aee')]
    output = []
    for site, expected in sites:
        if b.is64:
            source = f'''{A64_SAVE}
{rank_parent_context(b, site, 'x8')}
ldr w9, [x8, #0x1cc]
cmp w9, #9
b.hi original
b.eq hero
ldr x0, [x8, #0x158]
ldr w1, [x8, #0x14c]
b row
hero:
ldr x0, [x8, #0x1d0]
ldr w1, [x8, #0xa4]
row:
ldrb w2, [x8, #0x218]
and w2, w2, #1
eor w2, w2, #1
ldr w3, [x8, #0x22c]
{_metric_switch(True)}
resolved:
bl #{symbols['yagu_rank_cell_text']}
cbz x0, original
str x0, [sp, #8]
original:
{A64_RESTORE}
b #{original}'''
        else:
            source = f'''{T32_SAVE}
{rank_parent_context(b, site, 'r2')}
ldr r3, [r2, #0x134]
cmp r3, #9
bhi original
beq hero
ldr r0, [r2, #0xf8]
ldr r1, [r2, #0xf0]
b row
hero:
ldr r0, [r2, #0x138]
ldr r1, [r2, #0x7c]
row:
ldr r3, [r2, #0x170]
ldrb r2, [r2, #0x167]
and r2, r2, #1
eor r2, r2, #1
{_metric_switch(False)}
resolved:
bl #{symbols['yagu_rank_cell_text']}
cmp r0, #0
beq original
str r0, [sp, #4]
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Owned local ranking metric font ' + hex(site), source)
        b.patch(site, b.branch(site, hook, True), 'Project owned typed record in the original local rank cell', expected)
        output.append({'site': site, 'hook': hook, 'caller_return': PARENT_RETURN[b.abi]})
    return output
