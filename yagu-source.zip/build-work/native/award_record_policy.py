"""Stage only the existing own-player award-table text predicates."""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
INCLUDE = '#include "award_record_payload.inc"'


def integrate_source(source):
    if INCLUDE in source:
        if source.count(INCLUDE) != 1:
            raise ValueError('Repeated award record integration')
        return source
    for prerequisite in ('API const Scalar *yagu_owned_record_metric(',
                         'static u8 *owned_role_player(', 'static const char zero_text[]'):
        if prerequisite not in source:
            raise ValueError('Missing award record prerequisite: ' + prerequisite)
    return source.rstrip() + '\n\n' + INCLUDE + '\n'


def stage_payload(output_dir, source_dir=WORK):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    original = (source_dir / 'yagu_payload.c').read_text()
    staged = integrate_source(original)
    (output_dir / 'yagu_payload.c').write_text(staged)
    pending = re.findall(r'^#include "([^"]+)"', staged, re.MULTILINE)
    dependencies = {}
    while pending:
        name = pending.pop()
        if name in dependencies: continue
        if '/' in name or '\\' in name: raise ValueError('Unexpected dependency ' + name)
        raw = ((WORK if name == 'award_record_payload.inc' else source_dir) / name).read_bytes()
        (output_dir / name).write_bytes(raw)
        dependencies[name] = hashlib.sha256(raw).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"', raw.decode(), re.MULTILINE))
    manifest = {'base_c_sha256': hashlib.sha256(original.encode()).hexdigest(),
                'staged_c_sha256': hashlib.sha256(staged.encode()).hexdigest(),
                'dependencies': dependencies, 'shared_source_modified': False,
                'schema_changes': False, 'award_reward_changes': False}
    (output_dir / 'award_record_stage_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest
