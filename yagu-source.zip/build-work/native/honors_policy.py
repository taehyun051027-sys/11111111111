"""Stage the six personal-honors fields and their real local event consumers.

This module does not edit shared inputs. The parent explicitly applies the
returned text after review. No raw season counter, retirement, or award
presentation routine is patched. Repeated integration is idempotent; unexpected
schema/initializer shapes fail rather than silently changing unrelated code.
"""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
HONORS = ('pennant_titles', 'pennant_mvps', 'postseason_titles',
          'postseason_mvps', 'cup_titles', 'cup_mvps')
FIELD_ANCHOR = '    Scalar fielding_errors;\n} InfiniteRecords;'
FIELD_REPLACEMENT = ('    Scalar fielding_errors;\n'
                     '    /* Schema3 appends six honors; old33 offsets stay stable. */\n'
                     + ''.join('    Scalar ' + name + ';\n' for name in HONORS)
                     + '} InfiniteRecords;')
STATE_ANCHOR = '''static const InfiniteRecords my_records = {
    2, MY_BAT,
    {INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF},
    {ZERO, INF, ZERO, ZERO, INF, ZERO, INF, INF, INF, INF, ZERO, ZERO, INF},
    INF, INF, INF, INF, INF, INF, ZERO
};'''
STATE_REPLACEMENT = '''static const InfiniteRecords my_records = {
    3, MY_BAT,
    {INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF},
    {ZERO, INF, ZERO, ZERO, INF, ZERO, INF, INF, INF, INF, ZERO, ZERO, INF},
    INF, INF, INF, INF, INF, INF, ZERO,
    INF, INF, INF, INF, INF, INF
};'''
EVENT_ANCHOR = 'static int personal_event_check(int role, int selector, int period, int threshold) {'
EVENT_REPLACEMENT = '''#include "honors_payload.inc"
static int personal_event_check(int role, int selector, int period, int threshold) {
    /* Original selectors26..31 read career honors irrespective of period.
     * The other selectors retain their separately audited period policies. */
    if (selector >= 26 && selector <= 31)
        return yagu_honor_event_check(role, selector, threshold);'''


def once(source, old, new, label):
    if new in source:
        if source.count(new) != 1:
            raise ValueError('Repeated ' + label)
        return source
    if source.count(old) != 1:
        raise ValueError('Missing unique ' + label)
    return source.replace(old, new)


def integrate_source(source):
    source = once(source, FIELD_ANCHOR, FIELD_REPLACEMENT, 'record schema fields')
    source = once(source, STATE_ANCHOR, STATE_REPLACEMENT, 'record state initializer')
    source = once(source, EVENT_ANCHOR, EVENT_REPLACEMENT, 'honor event integration')
    return source


def integrate_builder(source):
    source = once(source, "'semantic_record_scalars': 33,",
                  "'semantic_record_schema': 3, 'semantic_record_scalars': 39,",
                  'record schema metadata')
    source = once(source, "'unbounded_record_scalars': 26,",
                  "'unbounded_record_scalars': 32,", 'record infinity metadata')
    source = once(source, "'typed_record_event_periods': [1, 2],",
                  "'typed_record_event_periods': [1, 2],\n"
                  "            'typed_honor_event_selectors': [26, 27, 28, 29, 30, 31],\n"
                  "            'typed_honor_event_period': 'independent, as in original selectors',",
                  'honor consumer metadata')
    return source


def stage_payload(output_dir, source_dir=WORK):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    original = (source_dir / 'yagu_payload.c').read_text()
    staged = integrate_source(original)
    (output_dir / 'yagu_payload.c').write_text(staged)
    # Include only the actual quoted local dependencies, recursively. This
    # also preserves independently reviewed elite/appearance additions.
    pending = re.findall(r'^#include "([^"]+)"', staged, re.MULTILINE)
    copied = {}
    while pending:
        name = pending.pop()
        if name in copied:
            continue
        if '/' in name or '\\' in name:
            raise ValueError('Unexpected local dependency ' + name)
        raw = ((WORK if name == 'honors_payload.inc' else source_dir) / name).read_bytes()
        (output_dir / name).write_bytes(raw)
        copied[name] = hashlib.sha256(raw).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"', raw.decode(), re.MULTILINE))
    manifest = {
        'base_c_sha256': hashlib.sha256(original.encode()).hexdigest(),
        'staged_c_sha256': hashlib.sha256(staged.encode()).hexdigest(),
        'local_dependencies': copied,
        'shared_source_modified': False,
        'record_schema': 3, 'record_scalars': 39, 'unbounded_scalars': 32,
        'finite_zero_scalars': 7, 'honors': list(HONORS),
        'selectors_both_roles': list(range(26, 32)),
        'period_policy': 'independent in original honor branches',
        'original_finite_season_awards_preserved': True,
    }
    (output_dir / 'honors_stage_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest
