#!/usr/bin/env python3
"""Exercise the real emulator GLES1 translator and its real host FBO dispatch.

This is not a mocked GL test, and it is not an Android full-game test. Each
renderer is loaded in a separate process with the exact original SDK backend.
The original renderer's missing support is an explicit negative control.
"""
import argparse
import ctypes as C
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent.parent / 'analysis/native/tools'))
from elftools.elf.elffile import ELFFile

U, I, P, F, B = C.c_uint, C.c_int, C.c_void_p, C.c_float, C.c_ubyte

def run_probe(renderer):
    raw = renderer.read_bytes()
    elf = ELFFile(io.BytesIO(raw))
    symbols = list(elf.get_section_by_name('.dynsym').iter_symbols())
    names = [s.name for s in symbols if s['st_value'] and s['st_info']['type'] == 'STT_FUNC']
    demangled = subprocess.run(['c++filt'], input='\n'.join(names), text=True,
                               capture_output=True, check=True).stdout.splitlines()
    functions = dict(zip(demangled, names))
    lib = C.CDLL(str(renderer.resolve()), mode=C.RTLD_GLOBAL)

    def fn(namespace, name, restype, *argtypes):
        prefix = 'translator::' + namespace + '::' + name + '('
        matches = [symbol for title, symbol in functions.items() if title.startswith(prefix)]
        if len(matches) != 1:
            raise ValueError('Ambiguous/missing native function: ' + prefix + ': ' + repr(matches))
        result = getattr(lib, matches[0]); result.restype = restype; result.argtypes = argtypes
        return result

    egl = lambda n, r, *a: fn('egl', n, r, *a)
    gl = lambda n, r, *a: fn('gles1', n, r, *a)
    # Exact original32 export has one unsigned argument. Newer source gained a
    # second null-EGL flag; that is not the ABI of this hash-locked renderer.
    egl('eglUseOsEglApi', None, U)(1)
    display = egl('eglGetDisplay', P, P)(None)
    major, minor = I(), I()
    if not display or not egl('eglInitialize', U, P, C.POINTER(I), C.POINTER(I))(display, C.byref(major), C.byref(minor)):
        raise RuntimeError('eglInitialize failed: ' + hex(egl('eglGetError', U)()))
    egl('eglSetMaxGLESVersion', None, I)(1)  # observed host ES3.0; 0 means ES2
    if not egl('eglBindAPI', U, U)(0x30a0):
        raise RuntimeError('eglBindAPI failed')
    attrs = (I * 17)(0x3033, 1, 0x3040, 1, 0x3024, 8, 0x3023, 8,
                     0x3022, 8, 0x3021, 8, 0x3025, 16, 0x3026, 8, 0x3038)
    configs = (P * 64)(); count = I()
    if not egl('eglChooseConfig', U, P, C.POINTER(I), C.POINTER(P), I, C.POINTER(I))(
            display, attrs, configs, 64, C.byref(count)) or not count.value:
        raise RuntimeError('No real GLES1 pbuffer configuration')
    cfg = configs[0]
    surf_attrs = (I * 5)(0x3057, 16, 0x3056, 16, 0x3038)
    context_attrs = (I * 3)(0x3098, 1, 0x3038)
    surface = egl('eglCreatePbufferSurface', P, P, P, C.POINTER(I))(display, cfg, surf_attrs)
    context = egl('eglCreateContext', P, P, P, P, C.POINTER(I))(display, cfg, None, context_attrs)
    if not surface or not context:
        raise RuntimeError('Real EGL surface/context creation failed: ' + hex(egl('eglGetError', U)()))
    make_current = egl('eglMakeCurrent', U, P, P, P, P)
    if not make_current(display, surface, surface, context):
        raise RuntimeError('eglMakeCurrent failed: ' + hex(egl('eglGetError', U)()))

    result = {'renderer': str(renderer.resolve()), 'sha256': hashlib.sha256(raw).hexdigest(),
              'egl_version': [major.value, minor.value], 'matching_config_count': count.value,
              'errors': {}, 'genuine_status_values': {}, 'android_runtime_verified': False}
    get_error = gl('glGetError', U)
    get_string = gl('glGetString', C.c_char_p, U)
    result['gl_version'] = (get_string(0x1f02) or b'').decode('ascii', 'replace')
    result['gl_renderer'] = (get_string(0x1f01) or b'').decode('ascii', 'replace')
    extensions = (get_string(0x1f03) or b'').decode('ascii', 'replace').split()
    result['oes_framebuffer_object'] = 'GL_OES_framebuffer_object' in extensions

    def sample(label):
        error = int(get_error())
        result['errors'][label] = error
        return error
    sample('initial')
    get_int = gl('glGetIntegerv', None, U, C.POINTER(I))
    def integer(token, label):
        value = I(); get_int(token, C.byref(value)); sample(label)
        return value.value

    gen_fbo = gl('glGenFramebuffersOES', None, I, C.POINTER(U))
    bind_fbo = gl('glBindFramebufferOES', None, U, U)
    delete_fbo = gl('glDeleteFramebuffersOES', None, I, C.POINTER(U))
    check_fbo = gl('glCheckFramebufferStatusOES', U, U)
    is_fbo = gl('glIsFramebufferOES', B, U)
    fbo = U()
    if not result['oes_framebuffer_object']:
        # Reproduce the original failure without invoking unconditional-null EXT
        # routes such as mipmap generation after support has already failed.
        gen_fbo(1, C.byref(fbo)); sample('negative_control_generate')
        bind_fbo(0x8d40, fbo); sample('negative_control_bind')
        result['genuine_status_values']['unsupported'] = int(check_fbo(0x8d40)); sample('negative_control_status')
        result['generated_fbo'] = fbo.value
        result['passed'] = False
        result['negative_control_observed'] = fbo.value == 0 and result['genuine_status_values']['unsupported'] == 0 and all(
            result['errors'][key] == 0x502 for key in ('negative_control_generate', 'negative_control_bind', 'negative_control_status'))
    else:
        original_bindings = {'framebuffer': integer(0x8ca6, 'initial_framebuffer_binding'),
                             'renderbuffer': integer(0x8ca7, 'initial_renderbuffer_binding'),
                             'texture2d': integer(0x8069, 'initial_texture_binding')}
        gen_tex = gl('glGenTextures', None, I, C.POINTER(U))
        bind_tex = gl('glBindTexture', None, U, U)
        del_tex = gl('glDeleteTextures', None, I, C.POINTER(U))
        tex_param = gl('glTexParameteri', None, U, U, I)
        tex_image = gl('glTexImage2D', None, U, I, I, I, I, I, U, U, P)
        texture = U(); gen_tex(1, C.byref(texture)); sample('generate_texture')
        bind_tex(0xde1, texture); sample('bind_texture')
        for key, value, label in ((0x2801, 0x2601, 'min_filter'), (0x2800, 0x2601, 'mag_filter'),
                                  (0x2802, 0x812f, 'wrap_s'), (0x2803, 0x812f, 'wrap_t')):
            tex_param(0xde1, key, value); sample(label)
        tex_image(0xde1, 0, 0x1908, 128, 128, 0, 0x1908, 0x1401, None); sample('texture_rgba128')
        gen_fbo(1, C.byref(fbo)); sample('generate_fbo')
        bind_fbo(0x8d40, fbo); sample('bind_fbo')
        result['generated_fbo'] = fbo.value
        result['is_fbo_after_bind'] = bool(is_fbo(fbo)); sample('is_fbo_after_bind')
        attach_tex = gl('glFramebufferTexture2DOES', None, U, U, U, U, I)
        attach_tex(0x8d40, 0x8ce0, 0xde1, texture, 0); sample('attach_color_texture')
        result['genuine_status_values']['color_texture'] = int(check_fbo(0x8d40)); sample('status_color_texture')
        attachment = gl('glGetFramebufferAttachmentParameterivOES', None, U, U, U, C.POINTER(I))
        object_type, object_name = I(), I()
        attachment(0x8d40, 0x8ce0, 0x8cd0, C.byref(object_type)); sample('attachment_type')
        attachment(0x8d40, 0x8ce0, 0x8cd1, C.byref(object_name)); sample('attachment_name')
        result['attachment_query'] = {'type': object_type.value, 'name': object_name.value,
                                      'expected_name': texture.value,
                                      'legacy_type_deviation': object_type.value == 0xde1,
                                      'spec_texture_enum': 0x1702}
        gl('glGenerateMipmapOES', None, U)(0xde1); sample('generate_mipmap')
        gen_rbo = gl('glGenRenderbuffersOES', None, I, C.POINTER(U))
        bind_rbo = gl('glBindRenderbufferOES', None, U, U)
        delete_rbo = gl('glDeleteRenderbuffersOES', None, I, C.POINTER(U))
        is_rbo = gl('glIsRenderbufferOES', B, U)
        rbo = U(); gen_rbo(1, C.byref(rbo)); sample('generate_renderbuffer')
        bind_rbo(0x8d41, rbo); sample('bind_renderbuffer')
        result['is_renderbuffer_after_bind'] = bool(is_rbo(rbo)); sample('is_renderbuffer_after_bind')
        gl('glRenderbufferStorageOES', None, U, U, I, I)(0x8d41, 0x81a5, 128, 128); sample('depth_renderbuffer_storage')
        get_rbo = gl('glGetRenderbufferParameterivOES', None, U, U, C.POINTER(I))
        rbo_properties = {}
        for key, token in (('width', 0x8d42), ('height', 0x8d43), ('internal_format', 0x8d44)):
            value = I(); get_rbo(0x8d41, token, C.byref(value)); sample('renderbuffer_' + key)
            rbo_properties[key] = value.value
        result['renderbuffer'] = rbo_properties
        attach_rbo = gl('glFramebufferRenderbufferOES', None, U, U, U, U)
        attach_rbo(0x8d40, 0x8d00, 0x8d41, rbo); sample('attach_depth_renderbuffer')
        result['genuine_status_values']['color_plus_depth'] = int(check_fbo(0x8d40)); sample('status_color_plus_depth')
        gl('glClearColor', None, F, F, F, F)(0.25, 0.5, 0.75, 1.0); sample('clear_color')
        gl('glClear', None, U)(0x4000); sample('real_color_clear')
        pixel = (B * 4)()
        gl('glReadPixels', None, I, I, I, I, U, U, P)(0, 0, 1, 1, 0x1908, 0x1401, pixel); sample('real_pixel_readback')
        result['pixel_rgba'] = list(pixel)
        attach_rbo(0x8d40, 0x8d00, 0x8d41, 0); sample('detach_depth')
        attach_tex(0x8d40, 0x8ce0, 0xde1, 0, 0); sample('detach_color')
        result['genuine_status_values']['missing_attachment'] = int(check_fbo(0x8d40)); sample('status_missing_attachment')
        bind_rbo(0x8d41, original_bindings['renderbuffer']); sample('restore_renderbuffer')
        bind_fbo(0x8d40, original_bindings['framebuffer']); sample('restore_framebuffer')
        bind_tex(0xde1, original_bindings['texture2d']); sample('restore_texture')
        delete_rbo(1, C.byref(rbo)); sample('delete_renderbuffer')
        delete_fbo(1, C.byref(fbo)); sample('delete_framebuffer')
        del_tex(1, C.byref(texture)); sample('delete_texture')
        result['is_fbo_after_delete'] = bool(is_fbo(fbo)); sample('is_fbo_after_delete')
        result['is_renderbuffer_after_delete'] = bool(is_rbo(rbo)); sample('is_renderbuffer_after_delete')
        final_bindings = {'framebuffer': integer(0x8ca6, 'final_framebuffer_binding'),
                          'renderbuffer': integer(0x8ca7, 'final_renderbuffer_binding'),
                          'texture2d': integer(0x8069, 'final_texture_binding')}
        result['bindings'] = {'initial': original_bindings, 'final': final_bindings}
        result['checks'] = {
            'every_observed_gl_error_zero': all(value == 0 for value in result['errors'].values()),
            'real_complete_status': result['genuine_status_values']['color_texture'] == 0x8cd5 and result['genuine_status_values']['color_plus_depth'] == 0x8cd5,
            'real_missing_attachment_status': result['genuine_status_values']['missing_attachment'] == 0x8cd7,
            'actual_color_readback': result['pixel_rgba'] == [64, 128, 191, 255],
            'renderbuffer_dimensions_and_format': rbo_properties == {'width': 128, 'height': 128, 'internal_format': 0x81a5},
            'object_lifecycle': fbo.value != 0 and result['is_fbo_after_bind'] and result['is_renderbuffer_after_bind'] and not result['is_fbo_after_delete'] and not result['is_renderbuffer_after_delete'],
            'bindings_restored': final_bindings == original_bindings,
            'attachment_name': object_name.value == texture.value,
        }
        result['passed'] = all(result['checks'].values())
        result['limitation'] = ('This original GLES1 wrapper reports attachment object type GL_TEXTURE_2D '
                                '(0x0de1) rather than the GL_TEXTURE enum (0x1702). The repair does not '
                                'change that existing query behavior; this result is not a full GL conformance claim.')
    make_current(display, None, None, None)
    egl('eglDestroyContext', U, P, P)(display, context)
    egl('eglDestroySurface', U, P, P)(display, surface)
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('renderer', type=Path)
    parser.add_argument('--sdk-root', type=Path, default=ROOT.parent / 'android/emulator32/emulator')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--worker', action='store_true')
    args = parser.parse_args()
    if not args.worker:
        env = dict(os.environ)
        env['LD_LIBRARY_PATH'] = str(args.sdk_root.resolve() / 'lib64/gles_swiftshader') + ':' + str(args.sdk_root.resolve() / 'lib64')
        env['ANDROID_EMU_HEADLESS'] = '1'
        env['ANDROID_EGL_ON_EGL'] = '1'
        command = [sys.executable, str(Path(__file__).resolve()), str(args.renderer.resolve()),
                   '--sdk-root', str(args.sdk_root.resolve()), '--output', str(args.output.resolve()), '--worker']
        raise SystemExit(subprocess.run(command, env=env).returncode)
    result = run_probe(args.renderer)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2), flush=True)
