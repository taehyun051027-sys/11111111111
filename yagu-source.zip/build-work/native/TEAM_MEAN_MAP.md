# Owned team mean as a derived Unbounded level

## Canonical rule

A nonempty finite-size team's arithmetic mean includes infinity when its included players contain the actual owned My player with Unbounded level. `team_mean_payload.inc` derives this view from the existing `my_state.level`; it adds no saved field and does not grant another player an infinite level.

The predicate requires the exact active owned team pointer, a valid nonempty roster, a present actual owned role actor, and `includeMy == true`. Another team, a detached copy, missing saves/manager/teams, invalid counts, noncareer context or explicit My exclusion falls back to the original finite mean.

## Local consumer boundary

The global `CBBGTeamData::GetTeamLevel(bool)` remains unchanged. In particular, `GetMyRaiseTeamLv()` passes `true` and is used by the original network CONNECT_V2 path. Network STATISTICS and SECURITY also query team level directly. Those original getters and callers are byte-preserved.

Only the local `CBBGDataMgr::GetTeamLv(int)` call to `GetTeamLevel(bool)` is redirected:

| Local call | ARM64 | Thumb |
|---|---:|---:|
| `GetTeamLv` mean adapter | 0x36e2c4 | 0x21a6d6 |

Its exact owned inclusive mean returns a bounded 250 legacy adapter; other means execute the original arithmetic. Four verified local quest comparisons consult the actual tagged mean, so their signed finite threshold does not cap the derived level:

| Local quest comparison | ARM64 | Thumb |
|---|---:|---:|
| First menu goal | 0x45625c | 0x2b0294 |
| Second menu goal | 0x45693c | 0x2b06de |
| First team goal | 0x53e128 | 0x34abde |
| Second team goal | 0x53e808 | 0x34b028 |

Each original `>=` success path remains the actual flag-setting path. Unowned execution retains its original compare and branch. GPR/SIMD/stack and original comparison flags are preserved. The original `StrengthAllPlayerUI::CheckStrengthAllPlayer()` uses explicit My exclusion and remains unchanged.

## Original UI

| Existing team-level cell | ARM64 | Thumb |
|---|---:|---:|
| Frame header formatter | 0x37b090 | 0x222ea4 |
| Main career menu number | 0x45f870 | 0x2b676e |

The header retains its existing formatter/font chain. The main menu's sprite-only number cannot represent infinity, so the exact owned cell uses the game's existing system-font helper with the same rectangle, tag, depth, alignment, offsets, visibility and WIPI flag. Ordinary/opponent cells keep the original number renderer. No new UI or control is added.

## Integration and verification

`team_mean_policy.py` provides pure `integrate_source()` / `integrate_builder()` transformations. New files are `team_mean_payload.inc`, `team_mean_hooks.py` and this policy module. Seven original sites per ABI are asserted before replacement, including the four original two-instruction comparison pairs.

`verify_team_mean.py` executes compiled derived-state lookup, original finite averaging with and without My, the original local getter, original quest instructions and both text adapters at nonzero ASLR. It checks ownership failures, signed thresholds, GPR/SIMD/flags, pointer arguments, and Thumb stack alignment. AArch64 stacked `int`/`bool` arguments are checked at their ABI-defined 32-bit width; the upper four bytes of each eight-byte argument slot are padding. The verifier also asserts that six original functions, including the network consumers and My-excluding check, are unchanged.

Other original team-level cells and network-facing `GetMyRaiseTeamLv()` formatting are not claimed covered by these two cells. This update addresses the observed main-menu level and matching frame header plus local threshold consumption; it is not an assertion that every team-level label has been audited.
