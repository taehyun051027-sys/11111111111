"""Local-only derived team-level integration. Original network getters stay."""
import hashlib
import json
import re
from pathlib import Path

WORK=Path(__file__).resolve().parent
INCLUDE='#include "team_mean_payload.inc"'
BINDINGS={'original_team_mean':'CBBGTeamData::GetTeamLevel(bool)'}


def once(source,old,new):
    if new in source:
        if source.count(new)!=1:raise ValueError('Duplicate team-mean integration')
        return source
    if source.count(old)!=1:raise ValueError('Missing team-mean integration anchor')
    return source.replace(old,new)


def integrate_source(source):
    return once(source,'#include "equipment_level_payload.inc"',
                '#include "equipment_level_payload.inc"\n'+INCLUDE)


def integrate_builder(source):
    addition=''.join('    '+repr(k)+': '+repr(v)+',\n'for k,v in BINDINGS.items())
    source=once(source,'BINDINGS = {\n','BINDINGS = {\n'+addition)
    source=once(source,'    from equipment_level_ui import add_equipment_level_ui_hooks',
                '    from equipment_level_ui import add_equipment_level_ui_hooks\n'
                '    from team_mean_hooks import add_team_mean_hooks')
    return once(source,"        add_equipment_level_ui_hooks(b,report['symbols'])",
                "        add_equipment_level_ui_hooks(b,report['symbols'])\n"
                "        add_team_mean_hooks(b,report['symbols'])")


def stage_payload(output_dir,source_dir=WORK):
    output_dir,source_dir=Path(output_dir),Path(source_dir);output_dir.mkdir(parents=True,exist_ok=True)
    original=(source_dir/'yagu_payload.c').read_text();source=integrate_source(original)
    (output_dir/'yagu_payload.c').write_text(source)
    pending=re.findall(r'^#include "([^"]+)"',source,re.M);deps={}
    while pending:
        name=pending.pop()
        if name in deps:continue
        if '/'in name or '\\'in name:raise ValueError('Unexpected include')
        raw=((WORK if name=='team_mean_payload.inc'else source_dir)/name).read_bytes()
        (output_dir/name).write_bytes(raw);deps[name]=hashlib.sha256(raw).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"',raw.decode(),re.M))
    manifest=dict(base_c_sha256=hashlib.sha256(original.encode()).hexdigest(),staged_c_sha256=hashlib.sha256(source.encode()).hexdigest(),dependencies=deps,shared_source_modified=False)
    (output_dir/'team_mean_stage_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    return manifest
