# Live mental duel: owned Unbounded order and original text cells

## Scope and semantics

The original pre-appearance ability banner uses `GetStatus(mental)` and compares its finite legacy projections. An owned My actor could therefore appear as 3,500 and tie a finite opponent even though its canonical mental ability is Unbounded.

`mental_duel_payload.inc` resolves the actual player pointer in the active entry's roster. It requires a valid career/save/team, a valid role count, the exact owned My role actor, and a distinct opposing entry with an actual finite roster actor. A matching reserved RFID on an opponent, a detached pointer, another teammate, noncareer context, or malformed pairing is not privileged.

The order is derived directly from `my_state.ability[3]`. A single owned Unbounded actor wins against the opposing finite actor. NPC versus NPC and invalid ownership execute the original finite comparisons. No scalar, score, passive inventory, skill level, or match counter is changed by this delta.

## Original decision paths

| Existing decision | ARM64 | Thumb |
|---|---:|---:|
| Appearance banner: winner | 0x3c7ef4 | 0x253eec |
| Appearance banner: color | 0x3c7f74 | 0x253f56 |
| Appearance banner: skill display order | 0x3c81b0 | 0x254112 |
| Appearance banner: sound decision | 0x3c8dcc | 0x254b7e |
| Next-pitch skill view: tie | 0x3bb1a4 | 0x24a8b4 |
| Next-pitch skill view: winner | 0x3bb1c8 | 0x24a8c8 |

Each inline adapter first executes the original comparison, preserves the original arithmetic result and all GPR/SIMD state, and replaces only the condition flags used by the existing decision when typed order exists. Invalid or ordinary pairings restore the exact original flags. Original conditional instructions, winner fields, visual queues and subsequent skill routines run normally. Thumb's Q flag remains unchanged.

## Existing text cells

The four original bounded `%s%d` formatter calls in `VisitSkillView` use a 24-byte destination and an eight-byte original `!cRRGGBB` color prefix. The typed adapter preserves the prefix and writes UTF-8 infinity, terminating within twelve bytes. Invalid prefixes, wrong destination capacity, and unowned players retain original formatting.

| Existing number position | ARM64 | Thumb |
|---|---:|---:|
| Pitcher on left | 0x3cb5d4 | 0x256d2e |
| Batter on right | 0x3cb620 | 0x256d68 |
| Pitcher on right | 0x3cb670 | 0x256d9c |
| Batter on left | 0x3cb6bc | 0x256dce |

The original font, color markup, rectangle, labels and layout remain. Only the exact owned My number becomes infinity. There is no new screen or control.

## Integration and verification

Pure transformations in `mental_duel_policy.py` append the include to `yagu_payload.c` and `add_mental_duel_hooks(b, symbols)` to the existing full builder. Ten sites per ABI are added with original-byte assertions. No player or record schema is extended.

`verify_mental_duel.py` runs the compiled policy and all ten hooks at nonzero ASLR. It exercises the original appearance winner/color path and next-pitch winner stores, invalid scope and duplicate-ID opponents, ties and signed finite boundaries, both left/right layouts, formatter capacities, buffer guards, and inline GPR/SIMD/flags/stack preservation. Service/graphics callbacks are identified in the test; actual Android rendering remains a separate runtime check.

The existing My HR/K result policy already returns before the two finite mental-bonus comparisons inside the original `BattingProcess`. This delta does not patch that unreachable original inner path. It does not claim every passive effect multiplier is an infinite floating-point value; the existing engine uses bounded skill/physics adapters.
