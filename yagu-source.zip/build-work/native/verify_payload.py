"""Run the actual injected AArch64/Thumb C code against guarded synthetic saves.

Engine methods outside this payload are mocked at documented ABI boundaries.
These are binary-integration tests; they do not claim a real nine-inning game.
"""
import json, struct
from pathlib import Path
from patch_builder import PatchBuilder
from payload_builder import add_payload, HOOKS, BINDINGS
from gameplay_hooks import add_gameplay_hooks
from verify_gameplay_hooks import Case, HEAP, MGR, BATTER, PITCHER, SIM, PLAY, BATM, PITM, STOP, SP

ROOT=Path(__file__).resolve().parents[2]
TEAMS=HEAP+0x20000
SAVE=HEAP+0x40000
TEAM=TEAMS+8+4*0x3b4
BAT=TEAM+0x1a4+5*44
PIT=TEAM+4
RECORD=SAVE+0xe8c+4*256

def verify(abi):
    b=PatchBuilder(abi,(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b); payload=add_payload(b, workdir=Path(__file__).resolve().parent/'payload_test_build'/abi)
    syms=payload['symbols']; bind=payload['original_bindings']; passed=[]
    def mark(label): passed.append(label)
    def new():
        c=Case(b)
        c.ptr(MGR+(0x530 if b.is64 else 0x4ec),TEAMS)
        c.ptr(MGR+(0x528 if b.is64 else 0x4e8),SAVE)
        c.uc.mem_write(TEAMS+4,struct.pack('<i',4))
        c.uc.mem_write(TEAM,bytes([4,0,8,12]))
        for i in range(8):
            p=TEAM+4+i*52
            c.uc.mem_write(p,bytes([0xa5])*52)
            c.uc.mem_write(p,struct.pack('<H',400+i))
            c.uc.mem_write(p+0x13,bytes([i]))
        for i in range(12):
            p=TEAM+0x1a4+i*44
            c.uc.mem_write(p,bytes([0x5a])*44)
            c.uc.mem_write(p,struct.pack('<H',1+i))
            c.uc.mem_write(p+0x13,bytes([i]))
        c.uc.mem_write(BAT,struct.pack('<H',1000))
        c.uc.mem_write(BAT+2,b'MyPlayer\0'+bytes(8))
        c.uc.mem_write(BAT+0x20,b'\x07')
        c.uc.mem_write(BAT+0x22,b'\x0c')
        c.uc.mem_write(BAT+0x2b,b'\x35')
        return c
    def call(c,name,*args):
        c.stopped=None
        c.uc.reg_write(c.sp,SP); c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1)
        for i,arg in enumerate(args):
            if i < (8 if b.is64 else 4): c.r(i,arg)
            else: c.uc.mem_write(SP+(i-4)*4,struct.pack('<I',arg))
        c.run(syms[name])
        assert c.uc.reg_read(c.sp)==SP,(abi,name,'unbalanced stack')
        return c.r(0)

    for rfid,expected in [(1000,True),(1100,True),(1,False),(0xffff,False)]:
        c=new();c.uc.mem_write(BATTER,struct.pack('<H',rfid))
        state=call(c,'yagu_state',BATTER)
        assert bool(state)==expected
        if expected:
            raw=bytes(c.uc.mem_read(state,8+46*16))
            assert struct.unpack_from('<II',raw)==(2,1000)
            for offset in range(8,len(raw),16):
                finite,kind,reserved=struct.unpack_from('<QII',raw,offset)
                assert finite==0 and kind==1 and reserved==0
        mark(f'actual semantic state: RFID {rfid} unbounded={expected}')
    c=new();assert call(c,'yagu_state',0)==0;mark('null actor is not unbounded')

    c=new();snapshot=bytes(c.uc.mem_read(TEAM,0x3b4));assert call(c,'yagu_ensure_two_way',MGR)==PIT
    after=bytes(c.uc.mem_read(TEAM,0x3b4))
    assert after[4+52:]==snapshot[4+52:] # no overflow into other pitchers / batters
    assert after[2:4]==snapshot[2:4]
    assert struct.unpack('<H',after[4:6])[0]==1100
    assert after[6:23]==snapshot[0x1a4+5*44+2:0x1a4+5*44+19]
    assert after[4+0x20]==7 and after[4+0x2b]==0x35
    assert after[4+0x22]&12==12 and after[4+0x21]&15==0
    assert struct.unpack('<I',after[4+0x30:4+0x34])[0]==10000
    assert bytes(c.uc.mem_read(RECORD,32))==struct.pack('<H',1100)+bytes(30)
    mark('separate 44/52-byte roles share saved identity; bounds and counts intact')
    c.uc.mem_write(RECORD+8,struct.pack('<I',123456))
    c.uc.mem_write(BAT+2,b'Renamed\0'+bytes(9))
    assert call(c,'yagu_ensure_two_way',MGR)==PIT
    assert bytes(c.uc.mem_read(PIT+2,8))==b'Renamed\0'
    assert struct.unpack('<I',c.uc.mem_read(RECORD+8,4))[0]==123456
    mark('repeat sync preserves existing pitching records and follows canonical rename')
    assert call(c,'yagu_pitcher_record',MGR)==RECORD
    mark('two-way pitcher record resolves inside BAT career save')
    # Actual team rotation moves pitcher objects without moving record slots.
    before_rotation=bytes(c.uc.mem_read(TEAM+4,4*52))
    c.uc.mem_write(TEAM+4,before_rotation[52:]+before_rotation[:52])
    assert call(c,'yagu_ensure_two_way',MGR)==PIT+3*52
    assert call(c,'yagu_pitcher_record',MGR)==RECORD
    assert struct.unpack('<I',c.uc.mem_read(RECORD+8,4))[0]==123456
    records=bytes(c.uc.mem_read(SAVE+0xe8c+4*256,256))
    assert sum(struct.unpack_from('<H',records,i*32)[0]==1100 for i in range(8))==1
    mark('physical pitcher rotation preserves one RFID-bound career record')
    # Simulate serialization/reload: copy the team and record to another address,
    # clear cached pointers, and bind the manager to the reloaded save.
    TEAMS2=HEAP+0x60000; SAVE2=HEAP+0x80000
    c.uc.mem_write(TEAMS2,bytes(c.uc.mem_read(TEAMS,0x4000)))
    c.uc.mem_write(SAVE2,bytes(c.uc.mem_read(SAVE,0x5000)))
    c.ptr(MGR+(0x530 if b.is64 else 0x4ec),TEAMS2)
    c.ptr(MGR+(0x528 if b.is64 else 0x4e8),SAVE2)
    c.ptr(MGR+(0x38 if b.is64 else 0x30),0);c.ptr(MGR+(0x40 if b.is64 else 0x34),0)
    reloaded=call(c,'yagu_ensure_two_way',MGR)
    assert reloaded==TEAMS2+8+4*0x3b4+4+3*52
    assert call(c,'yagu_state',reloaded)!=0
    assert struct.unpack('<I',c.uc.mem_read(SAVE2+0xe8c+4*256+8,4))[0]==123456
    mark('save reload reconstructs unbounded role state without finite sentinel')

    for scenario in ('not career','no save','invalid team','no my batter','invalid roster count'):
        c=new();before=bytes(c.uc.mem_read(TEAMS,0x4000))
        if scenario=='not career':c.callbacks[b.sym(BINDINGS['game_mode'])]=lambda:c.ret(1)
        elif scenario=='no save':c.ptr(MGR+(0x528 if b.is64 else 0x4e8),0)
        elif scenario=='invalid team':c.uc.mem_write(TEAMS+4,struct.pack('<i',-1))
        elif scenario=='no my batter':c.uc.mem_write(BAT,b'\x23\x00')
        else:c.uc.mem_write(TEAM+2,b'\x09')
        before=bytes(c.uc.mem_read(TEAMS,0x4000))
        assert call(c,'yagu_ensure_two_way',MGR)==0
        assert before==bytes(c.uc.mem_read(TEAMS,0x4000))
        mark('invalid context causes no roster write: '+scenario)

    # Entry-init ABI callback represents the original method's initial arrays.
    for team in (4,7):
        c=new()
        def init_stub():
            entry,mode,index=c.r(0),c.r(1),c.r(2)
            c.uc.mem_write(entry,bytes(range(14))+bytes(range(22))+bytes([mode,index,8,12]))
            c.ret(0)
        c.callbacks[bind['original_entry_init']]=init_stub
        call(c,'yagu_entry_init',PITM,4,team,0)
        data=bytes(c.uc.mem_read(PITM,0x28))
        assert list(data[:14])==list(range(14))
        assert sorted(data[14:26])==list(range(12))
        assert data[14]==(5 if team==4 else 0)
        mark(f'starting pitcher and batting lineup assigned only to own team {team}')

    for defense,bat_id,expected in [(True,19,0),(False,1000,0),(False,19,1)]:
        c=new();call(c,'yagu_ensure_two_way',MGR)
        c.uc.mem_write(BATM+0x25,bytes([7 if defense else 4]))
        c.uc.mem_write(PITM+0x25,bytes([4 if defense else 7]))
        c.uc.mem_write(PLAY+1,b'\x04');c.uc.mem_write(PLAY+9,b'\0\1')
        c.ptr(SIM+0x60,PLAY)
        base=0x78 if b.is64 else 0x6c
        c.ptr(SIM+base,BATM);c.ptr(SIM+base+(8 if b.is64 else 4),PITM)
        c.uc.mem_write(BATTER,struct.pack('<H',bat_id))
        c.callbacks[b.sym(BINDINGS['get_reserved_pitcher'])]=lambda:c.ret(PIT)
        c.callbacks[b.sym(BINDINGS['get_reserved_batter'])]=lambda:c.ret(BATTER)
        c.callbacks[bind['original_auto_simulate']]=lambda:c.ret(1)
        assert call(c,'yagu_auto_simulate',SIM)==expected
        mark(f'play control: defense={defense} batter={bat_id} autosim={expected}')

    c=new()
    for n in (0,1,65535,65536,0x7fffffff,0xffffffff):
        call(c,'yagu_set_level',BAT,n);assert call(c,'yagu_level',BAT)==250
        for part in range(4):
            call(c,'yagu_set_status',BAT,part,n)
            assert call(c,'yagu_pure_status',BAT,part)==10000
        state=call(c,'yagu_state',BAT)
        assert struct.unpack('<I',c.uc.mem_read(state+16,4))[0]==1
    mark('zero, uint16 overflow, INT_MAX and negative writes cannot downgrade infinity')
    for alias,args in [('level',(PITCHER,)),('pure_status',(PITCHER,2)),('set_status',(PITCHER,1,0xffffffff))]:
        c=new();c.uc.mem_write(PITCHER,struct.pack('<H',33));c.stops.add(bind['original_'+alias])
        call(c,'yagu_'+alias,*args)
        assert c.stopped==bind['original_'+alias]
        assert [c.r(i) for i in range(len(args))]==list(args)
        mark('normal-player fallback ABI: '+alias)

    for team in range(15):
        c=new()
        c.callbacks[bind['original_emblem']]=lambda:c.ret(99)
        c.callbacks[bind['original_uniform']]=lambda:c.ret(7)
        for layer in range(5):
            expected = 99 if team == 4 else (55+team if layer == 0 else (0 if layer == 4 else -128))
            assert (call(c,'yagu_emblem',HEAP,layer,team) & 0xffffffff) == (expected & 0xffffffff)
        for layer in (2,3,4,6,9,10,12,14,15,16,19,20,22,24,25,26,27,29,30):
            assert call(c,'yagu_uniform',HEAP,layer,team)==0
        assert call(c,'yagu_uniform',HEAP,1,team)==7
    mark('15-team original black clothing; Pumas included, emblem exception and non-clothing palette preserved')
    return {'abi':abi,'passed':len(passed),'checks':passed,'android_runtime_verified':False}

if __name__=='__main__':
    results=[verify(abi) for abi in ('arm64-v8a','armeabi-v7a')]
    Path(__file__).with_name('payload_verification.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))
