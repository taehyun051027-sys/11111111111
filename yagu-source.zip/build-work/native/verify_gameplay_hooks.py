"""Instruction-level regression verification, not an Android gameplay test.

Runs only the authored hook blocks and selected original pitch-rule getters in
Unicorn. Roster lookups are mocked at their call boundary so tests can exercise
actor identity, return ABI, the miss / strike / strikeout transition, original
fallback, and preservation of inline caller state independently of Android.
"""
import io,json,struct,sys
from pathlib import Path
from patch_builder import PatchBuilder,align
from gameplay_hooks import add_gameplay_hooks,BAT,GETBAT,GETPIT,GETMODE,GETMGR
from elftools.elf.elffile import ELFFile
from unicorn import Uc,UC_ARCH_ARM64,UC_ARCH_ARM,UC_MODE_ARM,UC_MODE_THUMB,UC_HOOK_CODE
from unicorn.arm64_const import *
from unicorn.arm_const import *

ROOT=Path(__file__).resolve().parents[2]
HEAP=0x2000000; STACK=0x4000000; SP=STACK+0x80000; STOP=0x6000000
BATM=HEAP+0x1000; PITM=HEAP+0x2000; BATTER=HEAP+0x3000; PITCHER=HEAP+0x4000
GAME=HEAP+0x5000; RULE=HEAP+0x7000; PLAY=HEAP+0x8000; RESULT=HEAP+0x9000; MODE=HEAP+0xa000
MGR=HEAP+0xb000; RAISE=HEAP+0xc000; SIM=HEAP+0xd000

class Case:
 def __init__(self,b):
  self.b=b;self.is64=b.is64;self.uc=Uc(UC_ARCH_ARM64,UC_MODE_ARM) if b.is64 else Uc(UC_ARCH_ARM,UC_MODE_THUMB)
  self.uc.mem_map(0,align(b.base+len(b.extra)))
  for s in b.elf.iter_segments():
   if s['p_type']=='PT_LOAD':self.uc.mem_write(s['p_vaddr'],bytes(b.image[s['p_offset']:s['p_offset']+s['p_filesz']]))
  self.uc.mem_write(b.base,bytes(b.extra));self.uc.mem_map(HEAP,0x100000);self.uc.mem_map(STACK,0x100000);self.uc.mem_map(STOP,4096)
  self.regs=[getattr(sys.modules[__name__],f'UC_ARM64_REG_X{i}') for i in range(29)]+[UC_ARM64_REG_X29,UC_ARM64_REG_X30] if self.is64 else [getattr(sys.modules[__name__],f'UC_ARM_REG_R{i}') for i in range(13)]
  self.pc=UC_ARM64_REG_PC if self.is64 else UC_ARM_REG_PC;self.sp=UC_ARM64_REG_SP if self.is64 else UC_ARM_REG_SP;self.lr=UC_ARM64_REG_X30 if self.is64 else UC_ARM_REG_LR
  self.uc.reg_write(self.sp,SP);self.uc.reg_write(self.lr,STOP if self.is64 else STOP|1)
  if not self.is64:
   self.uc.reg_write(UC_ARM_REG_C1_C0_2,0xf00000);self.uc.reg_write(UC_ARM_REG_FPEXC,0x40000000)
  for i,r in enumerate(self.regs):
   if r!=self.lr:self.uc.reg_write(r,0x110000+i)
  self.ptr(GAME+(0x410 if self.is64 else 0x2c8),BATM);self.ptr(GAME+(0x418 if self.is64 else 0x2cc),PITM)
  self.ptr(RULE+(16 if self.is64 else 8),PLAY)
  self.ptr(MGR+(0x530 if self.is64 else 0x4ec),RAISE);self.uc.mem_write(RAISE+4,struct.pack('<I',2))
  self.uc.mem_write(BATM+0x25,b'\2');self.uc.mem_write(PITM+0x25,b'\2')
  self.ptr(SIM+(0x90 if self.is64 else 0x78),PITM)
  self.uc.mem_write(BATTER,struct.pack('<H',1000));self.uc.mem_write(PITCHER,struct.pack('<H',1100))
  self.callbacks={};self.stops={STOP};self.stopped=None
  self.callbacks[b.sym(GETBAT)]=lambda:self.lookup(BATM,BATTER)
  self.callbacks[b.sym(GETPIT)]=lambda:self.lookup(PITM,PITCHER)
  self.callbacks[b.sym(GETMODE)]=lambda:self.ret(4)
  self.callbacks[b.sym(GETMGR)]=lambda:self.ret(MGR)
  self.uc.hook_add(UC_HOOK_CODE,self.oncode)
 def ptr(self,addr,value):self.uc.mem_write(addr,struct.pack('<Q' if self.is64 else '<I',value))
 def r(self,i,value=None):
  if value is not None:self.uc.reg_write(self.regs[i],value)
  return self.uc.reg_read(self.regs[i])
 def oncode(self,uc,addr,size,_):
  if addr in self.stops:self.stopped=addr;uc.emu_stop();return
  if addr in self.callbacks:self.callbacks[addr]()
 def ret(self,value):
  dest=self.uc.reg_read(self.lr);self.r(0,value);self.uc.reg_write(self.pc,dest)
 def lookup(self,manager,actor):
  actual=self.r(0);assert actual==manager,('wrong manager',hex(actual),hex(manager))
  dest=self.uc.reg_read(self.lr)
  for i in (range(1,19) if self.is64 else [1,2,3,12]):self.r(i,0x990000+i)
  if self.is64:
   for i in range(32):self.uc.reg_write(getattr(sys.modules[__name__],f'UC_ARM64_REG_Q{i}'),0xdecaf000+i)
  else:
   for i in range(8):self.uc.reg_write(getattr(sys.modules[__name__],f'UC_ARM_REG_D{i}'),0xdecaf000+i)
  self.r(0,actor);self.uc.reg_write(self.pc,dest)
 def run(self,address):
  self.uc.emu_start(address if self.is64 else address|1,STOP,count=10000)
  if self.uc.reg_read(self.pc)==STOP:self.stopped=STOP
  assert self.stopped is not None,('did not reach expected stop',hex(self.uc.reg_read(self.pc)))
 def original(self,name):
  return next(x['address'] for x in self.b.blocks if x['name']==name+' original prologue')

def verify(abi):
 b=PatchBuilder(abi,(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes());exp=add_gameplay_hooks(b);passed=[]
 def mark(label):passed.append(label)
 for bid,pid,result in [(1000,1100,'hr'),(1000,23,'hr'),(18,1100,'miss'),(18,23,'original')]:
  c=Case(b);c.uc.mem_write(BATTER,struct.pack('<H',bid));c.uc.mem_write(PITCHER,struct.pack('<H',pid))
  if b.is64:c.r(0,HEAP);c.r(1,BATM);c.r(2,PITM)
  else:c.r(0,RESULT);c.r(1,HEAP);c.r(2,BATM);c.r(3,PITM)
  before=[c.r(i) for i in range(9 if b.is64 else 4)];c.stops.add(c.original(BAT));c.run(b.sym(BAT))
  assert c.uc.reg_read(c.sp)==SP
  if result=='original':assert c.stopped==c.original(BAT) and before==[c.r(i) for i in range(len(before))]
  else:
   assert c.stopped==STOP
   data=struct.pack('<QI',c.r(0),c.r(1)&0xffffffff) if b.is64 else bytes(c.uc.mem_read(RESULT,12))
   assert data==(b'\x00'*6+b'\x01\x01'+struct.pack('<I',21) if result=='hr' else b'\x00'*12),(abi,data.hex())
  mark(f'batting ABI: attacker={bid}, pitcher={pid} -> {result}')
 for name,value in [('IntersectStrikeZone(int, int)',1),('IsWildPitch()',0),('IsHitByPitcher()',0)]:
  full='CBBGGameRun::'+name
  for pid in [1100,23]:
   c=Case(b);c.uc.mem_write(PITCHER,struct.pack('<H',pid));c.r(0,GAME);before=[c.r(i) for i in range(9 if b.is64 else 4)];c.stops.add(c.original(full));c.run(b.sym(full))
   assert c.uc.reg_read(c.sp)==SP
   if pid==1100:assert c.r(0)==value and c.stopped==STOP
   else:assert c.stopped==c.original(full) and before==[c.r(i) for i in range(len(before))]
   mark(f'live {name}: pitcher={pid}')
 # Inline point: original flag retained for other actors; identity forces one
 # only when the original batter animation/contact path reaches this point.
 for bid,flag in [(1000,0),(1000,1),(18,0),(18,1)]:
  c=Case(b);c.uc.mem_write(BATTER,struct.pack('<H',bid));frame=SP+0x200
  if b.is64:
   c.uc.reg_write(UC_ARM64_REG_X29,frame);c.uc.mem_write(frame-0x8c,bytes([flag]));c.ptr(SP+0x38,GAME);target=0x38d960;destreg=8
   c.uc.reg_write(UC_ARM64_REG_NZCV,0xa0000000)
   fpregs=[getattr(sys.modules[__name__],f'UC_ARM64_REG_Q{i}') for i in range(32)]
  else:
   c.uc.reg_write(UC_ARM_REG_R7,frame);c.uc.mem_write(frame-0x62,bytes([flag]));c.ptr(SP+0x24,GAME);target=0x22e67c;destreg=0
   c.uc.reg_write(UC_ARM_REG_APSR,0xa0000000)
   fpregs=[getattr(sys.modules[__name__],f'UC_ARM_REG_D{i}') for i in range(8)]
  for i,r in enumerate(fpregs):c.uc.reg_write(r,0x12340000+i)
  expected=[c.r(i) for i in range(len(c.regs))];expected[destreg]=1 if bid==1000 else flag
  c.stops.add(target);c.run(exp['timing']);assert c.stopped==target and c.uc.reg_read(c.sp)==SP
  assert expected==[c.r(i) for i in range(len(c.regs))],(abi,bid,'register mismatch',expected,[c.r(i) for i in range(len(c.regs))])
  assert [c.uc.reg_read(r) for r in fpregs]==[0x12340000+i for i in range(len(fpregs))]
  flags=c.uc.reg_read(UC_ARM64_REG_NZCV if b.is64 else UC_ARM_REG_APSR);assert flags&0xf0000000==0xa0000000
  mark(f'inline timing state preserved: batter={bid}, original_flag={flag}')
 # Execute the original PitchJudge, intercepting only its leaf getters.
 judge=b.sym('CBBGRuleEngine::PitchJudge(unsigned char)')
 for pid,strikes,zone,expected in [(1100,0,0,1),(1100,1,0,1),(1100,2,0,5),(23,0,0,4)]:
  c=Case(b);c.uc.mem_write(PITCHER,struct.pack('<H',pid));c.uc.mem_write(PLAY,b'\0'*64)
  for offset in [0x12,0x19,0x1a,0x24]:c.uc.mem_write(PLAY+offset,b'\1')
  c.uc.mem_write(PLAY+4,bytes([strikes]));c.r(0,RULE);c.r(1,zone)
  if b.is64:
   frame=SP+0x200;c.uc.reg_write(UC_ARM64_REG_X29,frame);c.ptr(frame-0x48,PITCHER);c.ptr(frame-0x38,SIM)
   getters={0x732380:lambda:int(c.uc.mem_read(PLAY+0x12,1)[0]),0x732760:lambda:int(c.uc.mem_read(PLAY+4,1)[0]),0x7325d0:lambda:0,0x732770:lambda:0}
  else:
   c.ptr(SP+0x8c,PITCHER);c.ptr(SP+0x54,SIM)
   getters={0x474cc0:lambda:int(c.uc.mem_read(PLAY+0x12,1)[0]),0x4750a0:lambda:int(c.uc.mem_read(PLAY+4,1)[0]),0x474f10:lambda:0,0x4750b0:lambda:0}
  for addr,fn in getters.items():c.callbacks[addr]=lambda fn=fn:c.ret(fn())
  c.run(exp['simulation_judge']);assert c.r(0)==expected,(abi,pid,strikes,c.r(0));assert c.uc.reg_read(c.sp)==SP
  if pid==1100:
   for offset in [0x12,0x19,0x1a,0x24]:assert c.uc.mem_read(PLAY+offset,1)==b'\0'
   assert c.uc.mem_read(PLAY+0x18,1)==b'\1'
  else:assert c.uc.mem_read(PLAY+0x12,1)==b'\1'
  mark(f'original PitchJudge: pitcher={pid}, strikes={strikes} -> judge={expected}')
 for name in ['CBBGRaiseMode::Initialize()','CBBGRaiseMode::GetRaiseCubKind()']:
  c=Case(b);c.r(0,MODE);c.run(b.sym(name));assert c.uc.mem_read(MODE+0x517,1)==b'\x09'
  if 'GetRaise' in name:assert c.r(0)==9
  mark('Universe 9: '+name)
 name='CBBGRaiseMode::SetRaiseCubKind(int)';c=Case(b);c.r(0,MODE);c.r(1,0);c.stops.add(c.original(name));c.run(b.sym(name));assert c.r(0)==MODE and c.r(1)==9;mark('Universe setter retains original side-effect path')
 for pid in [1100,23]:
  name='CBBGPitcherData::SetStamina(int)';c=Case(b);c.uc.mem_write(PITCHER,struct.pack('<H',pid));c.r(0,PITCHER);c.r(1,25);c.stops.add(c.original(name));c.run(b.sym(name));assert c.r(1)==(10000 if pid==1100 else 25);mark(f'stamina adapter actor scope: {pid}')
  name='CBBGEntryMgr::DecPitStaminaPer(int)';c=Case(b);c.uc.mem_write(PITCHER,struct.pack('<H',pid));c.r(0,PITM);c.r(1,25);c.stops.add(c.original(name));c.run(b.sym(name));assert c.stopped==(STOP if pid==1100 else c.original(name))
  if pid==1100:assert struct.unpack('<I',c.uc.mem_read(PITCHER+0x30,4))[0]==10000
  mark(f'stamina depletion scope: {pid}')
 for entry_team,mode,active,expected in [(2,4,True,1),(2,3,True,1),(3,4,True,0),(2,2,True,0),(2,4,False,0)]:
  c=Case(b);c.uc.mem_write(BATM+0x25,bytes([entry_team]));c.callbacks[b.sym(GETMODE)]=lambda mode=mode:c.ret(mode)
  if not active:c.ptr(MGR+(0x530 if b.is64 else 0x4ec),0)
  c.r(0,BATM);c.run(exp['owned_entry']);assert c.r(0)==expected and c.uc.reg_read(c.sp)==SP
  mark(f'ownership helper: team={entry_team}, mode={mode}, active={active}')
 # The same reserved RFID on an opponent's entry is not privileged.
 for role in ['batter','pitcher']:
  c=Case(b);c.uc.mem_write(BATM+0x25,b'\3');c.uc.mem_write(PITM+0x25,b'\3')
  if role=='batter':c.uc.mem_write(PITCHER,struct.pack('<H',23))
  else:c.uc.mem_write(BATTER,struct.pack('<H',18))
  if b.is64:c.r(0,HEAP);c.r(1,BATM);c.r(2,PITM)
  else:c.r(0,RESULT);c.r(1,HEAP);c.r(2,BATM);c.r(3,PITM)
  c.stops.add(c.original(BAT));c.run(b.sym(BAT));assert c.stopped==c.original(BAT)
  mark('opponent reserved RFID remains unmodified: '+role)
 for pid,team in [(1100,2),(1100,3),(23,2)]:
  name='CBBGEntryMgr::RsvChangePitcher(int, unsigned char)';c=Case(b);c.uc.mem_write(PITCHER,struct.pack('<H',pid));c.uc.mem_write(PITM+0x25,bytes([team]));c.r(0,PITM);c.stops.add(c.original(name));c.run(b.sym(name))
  assert c.stopped==(STOP if pid==1100 and team==2 else c.original(name))
  mark(f'substitution protection: pitcher={pid}, team={team}')
 return {'abi':abi,'passed':len(passed),'checks':passed,'android_runtime_verified':False}

if __name__=='__main__':
 results=[verify(x) for x in ['arm64-v8a','armeabi-v7a']]
 output=Path(__file__).with_name('hook_verification.json');output.write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results,indent=2))
