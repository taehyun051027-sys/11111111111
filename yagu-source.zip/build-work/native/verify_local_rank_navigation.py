"""Verify original rank controls, all15 category consumers and role-aware rows.

Runs compiled hooks at a nonzero ELF load bias. The native key handler, the
post-collision swipe decision, original Analyze dispatch and ratio-format branch
execute. Graphics construction and final rendering are callbacks/stop boundaries.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from payload_builder import add_payload
from local_rank_ui import add_local_rank_ui_hooks, PARENT_RETURN
from local_rank_navigation import add_local_rank_navigation_hooks, TABLE, ROLE, HERO
from verify_local_rank_ui import invoke, owned_case, parent_frame, BAT_RECORD
from verify_relocation import BAT, PIT, TEAM, TEAMS, SAVE, RECORD
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
import unicorn.arm64_const as arm64
import unicorn.arm_const as arm

WORK = Path(__file__).resolve().parent
UI = HEAP + 0xe000
SORTS = (15, 11, 12, 14, 13, 16, 17, 18, 4, 1, 7, 3, 6, 8, 9)


def signed32(value):
    return struct.unpack('<i', struct.pack('<I', value & 0xffffffff))[0]


def verify(abi):
    b = PatchBuilder(abi, (ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK/'local_rank_navigation_build'/abi)
    symbols = payload['symbols']
    add_local_rank_ui_hooks(b, symbols)
    nav = add_local_rank_navigation_hooks(b, symbols)
    slide = 0x7754321000 if b.is64 else 0x98543000
    c = owned_case(b, symbols, slide)
    offset = 0x70 if b.is64 else 0x40
    direction_offset = 0x68 if b.is64 else 0x38
    mode = [4]
    observed = []
    counts = {key: 0 for key in ('scroll_calls', 'original_key_paths', 'original_swipe_paths',
                                'role_calls', 'inline_differentials', 'original_sort_dispatch',
                                'drawn_header_indices', 'hero_rows', 'ratio_precision',
                                'scope_fallbacks', 'invalid_helper_inputs')}

    def tab(value): c.uc.mem_write(UI+offset, struct.pack('<I', value & 0xffffffff))
    def renderer():
        assert c.r(0) == UI
        observed.append(signed32(c.r(1)))
        tab(c.r(1))
        c.ret(0)
    def original_role(): c.ret(int(mode[0] == 4))
    c.callbacks[b.sym(TABLE)+slide] = renderer
    c.callbacks[b.sym(ROLE)+slide] = original_role
    c.callbacks[(0x72db90 if b.is64 else 0x470570)+slide] = original_role
    c.callbacks[b.sym(GETMODE)+slide] = lambda: c.ret(mode[0])
    c.callbacks[(0x72d850 if b.is64 else 0x470230)+slide] = lambda: c.ret(mode[0])

    for site in nav['scroll_calls']:
        for global_tab in range(15):
            tab(global_tab)
            invoke(c, site['site'], UI, 777, stop=site['site']+4+slide)
            assert observed[-1] == (global_tab + site['direction']) % 15
            counts['scroll_calls'] += 1

    key_address = b.sym('CBBGRecordRankUI::OnKeyPressed(int)')
    for current_mode, pages in ((4, 15), (3, 7)):
        mode[0] = current_mode
        for global_tab in range(pages):
            for key, direction in ((-3, 1), (-4, -1)):
                tab(global_tab)
                invoke(c, key_address, UI, key)
                assert observed[-1] == (global_tab+direction) % pages
                counts['original_key_paths'] += 1
        for key in (0, -1, -2, -5):
            before = len(observed)
            invoke(c, key_address, UI, key)
            assert len(observed) == before
            counts['original_key_paths'] += 1
    mode[0] = 4

    # Original threshold/direction logic after the original collision check.
    abs_plt = 0x730b90 if b.is64 else 0x4734d0
    c.callbacks[abs_plt+slide] = lambda: c.ret(abs(signed32(c.r(0))))
    swipe_start, swipe_end = (0x4f7abc, 0x4f7ba0) if b.is64 else (0x31cabc, 0x31cb44)
    for global_tab in range(15):
        for delta in (30, -30, 20, -20, 0):
            tab(global_tab)
            c.ptr(SP+(8 if b.is64 else 4), UI)
            c.uc.mem_write(SP+(0x24 if b.is64 else 0x18), struct.pack('<i', 100+delta))
            c.uc.mem_write(SP+(0x20 if b.is64 else 0x14), struct.pack('<i', 100))
            if b.is64: c.uc.mem_write(SP+0x1c, b'\1')
            else:
                c.uc.reg_write(arm.UC_ARM_REG_R7, SP+0x38)
                c.uc.mem_write(SP+0x13, b'\1')
            before = len(observed)
            invoke(c, swipe_start, stop=swipe_end+slide)
            if abs(delta) <= 20: assert len(observed) == before
            else:
                assert len(observed) == before+1
                assert observed[-1] == (global_tab + (1 if delta > 0 else -1)) % 15
                assert struct.unpack('<I', c.uc.mem_read(UI+direction_offset, 4))[0] == (1 if delta > 0 else 2)
            counts['original_swipe_paths'] += 1

    for site in nav['role_calls']:
        for global_tab in range(15):
            tab(global_tab)
            c.ptr(SP+site['ui_slot'], UI)
            if site['local_slot'] is not None:
                c.uc.mem_write(SP+site['local_slot'], struct.pack('<i', global_tab))
            invoke(c, site['site'], stop=site['site']+4+slide)
            assert c.r(0) == int(global_tab < 8)
            if site['local_slot'] is not None:
                assert struct.unpack('<i', c.uc.mem_read(SP+site['local_slot'], 4))[0] == (global_tab if global_tab < 8 else global_tab-8)
            assert struct.unpack('<i', c.uc.mem_read(UI+offset, 4))[0] == global_tab
            counts['role_calls'] += 1

    # Differentially execute original bytes with the intended local tab, then
    # the patched inline block with its global tab. GPR, SIMD, flags, LR, SP and
    # replayed caller-stack writes must match. Mode3 retains the raw field.
    flagreg = arm64.UC_ARM64_REG_NZCV if b.is64 else arm.UC_ARM_REG_APSR
    fregs = [getattr(arm64 if b.is64 else arm,
                    f'UC_ARM64_REG_Q{i}' if b.is64 else f'UC_ARM_REG_D{i}') for i in range(32)]
    fvalues = [((0x1234567800000000+i)<<64 | (0xfedcba9800000000+i))
               if b.is64 else 0x1234567800000000+i for i in range(32)]
    for site in nav['tab_loads']:
        address = site['site']+slide
        original = b.original[b.offset(site['site']):b.offset(site['site'])+4]
        patched = bytes(c.uc.mem_read(address, 4))
        for current_mode, values in ((4, range(15)), (3, (-1, 0, 7, 8, 14, 15, 0x7fffffff))):
            mode[0] = current_mode
            for global_tab in values:
                local = global_tab-8 if current_mode == 4 and 8 <= global_tab < 15 else global_tab
                snapshots = []
                for instructions, value in ((original, local), (patched, global_tab)):
                    c.uc.mem_write(address, instructions)
                    c.uc.ctl_remove_cache(address, address+4)
                    tab(value)
                    c.uc.mem_write(SP, bytes(0x200))
                    for i, register in enumerate(c.regs):
                        if register != c.lr: c.uc.reg_write(register, 0x12340000+i)
                    c.r(site['source'], UI)
                    c.uc.reg_write(flagreg, 0xa8000000)
                    for register, expected in zip(fregs, fvalues): c.uc.reg_write(register, expected)
                    invoke(c, site['site'], stop=address+4)
                    snapshots.append(([c.uc.reg_read(r) for r in c.regs],
                                      [c.uc.reg_read(r) for r in fregs],
                                      c.uc.reg_read(flagreg)&(0xf0000000 if b.is64 else 0xf8000000),
                                      c.uc.reg_read(c.sp), c.uc.reg_read(c.lr), bytes(c.uc.mem_read(SP, 0x200))))
                assert snapshots[0] == snapshots[1], (abi, hex(site['site']), current_mode, global_tab)
                counts['inline_differentials'] += 1
        c.uc.mem_write(address, patched)
    mode[0] = 4

    # Execute original local sort array selection with all fifteen global tabs.
    sort_calls = []
    def analyze():
        assert c.r(0) == UI+(0x80 if b.is64 else 0x50)
        assert c.r(2) == 4 and c.r(3) == 1
        last = c.r(4) if b.is64 else struct.unpack('<I', c.uc.mem_read(c.uc.reg_read(c.sp), 4))[0]
        assert last == 0
        sort_calls.append(c.r(1))
        c.ret(0)
    c.callbacks[(0x73afc0 if b.is64 else 0x47dc90)+slide] = analyze
    analyze_role = next(s for s in nav['role_calls'] if s['context'] == 'analyze')
    for global_tab, expected in enumerate(SORTS):
        tab(global_tab)
        c.ptr(SP+0x10, UI)
        invoke(c, analyze_role['site'], stop=(0x4f895c if b.is64 else 0x31d3aa)+slide)
        assert sort_calls[-1] == expected
        counts['original_sort_dispatch'] += 1

    draw = next(s for s in nav['role_calls'] if s['context'] == 'draw')
    for global_tab in range(15):
        tab(global_tab)
        c.ptr(SP+draw['ui_slot'], UI)
        frame = SP+0x200 if b.is64 else SP+0x100
        c.uc.reg_write(arm64.UC_ARM64_REG_X29 if b.is64 else arm.UC_ARM_REG_R7, frame)
        invoke(c, draw['site'], stop=(0x4f7440 if b.is64 else 0x31c5ea)+slide)
        header = struct.unpack('<i', c.uc.mem_read(frame-0xa8 if b.is64 else SP+0x6c, 4))[0]
        assert header == 0x50+global_tab
        counts['drawn_header_indices'] += 1

    # Row9 follows the selected actor, with original manager/mode preserved on
    # failure. It never chooses a player just because another row has that RFID.
    hero = nav['hero_call']
    hero_fallbacks = []
    def original_hero():
        hero_fallbacks.append((c.r(0), c.r(1)))
        c.ret(HEAP+0xef000)
    c.callbacks[b.sym(HERO)+slide] = original_hero
    for is_batter, actor in ((1, BAT), (0, PIT)):
        c.uc.mem_write(SP+(0x218 if b.is64 else 0x167), bytes([is_batter]))
        assert invoke(c, hero['site'], MGR, 4, stop=hero['site']+4+slide) == actor
        assert not hero_fallbacks
        counts['hero_rows'] += 1

    # Execute the actual original ratio selection, including opposing finite
    # values: BAT uses thousandths; PIT uses hundredths, inside the same mode4.
    decimal = nav['decimal_role_call']
    ratio_calls = []
    def ratio(digits):
        assert c.r(0) == 1234
        assert c.r(1) == SP+(0x170 if b.is64 else 0xd8)
        ratio_calls.append(digits)
        c.ret(0)
    for target, digits in ((0x72fb30 if b.is64 else 0x472540, 3),
                           (0x72fb40 if b.is64 else 0x472550, 2)):
        c.callbacks[target+slide] = lambda digits=digits: ratio(digits)
    for global_tab in range(15):
        tab(global_tab)
        role = int(global_tab >= 8)
        parent = parent_frame(c, role, global_tab-8 if role else global_tab, 0, BAT if not role else PIT, 4)
        c.ptr(parent+(0x1a0 if b.is64 else 0x120), UI)
        if b.is64: c.uc.mem_write(SP+0x134, struct.pack('<i', 1234))
        else: c.uc.mem_write(SP+0x1008, struct.pack('<i', 1234))
        invoke(c, decimal['site'], stop=(0x4f8fbc if b.is64 else 0x31d7e8)+slide)
        assert ratio_calls[-1] == (3 if global_tab < 8 else 2)
        counts['ratio_precision'] += 1

    # Missing or wrong owned records, changed mode, and duplicate My IDs outside
    # our team all reject the expansion. Each wrapper must keep original args.
    exclusions = ('legacy_mode3', 'noncareer', 'missing_save', 'missing_bat_record',
                  'missing_pit_record', 'missing_batter', 'missing_pitcher', 'no_manager')
    old = c
    for kind in exclusions:
        c = owned_case(b, symbols, slide)
        c.uc.mem_write(UI+offset, struct.pack('<i', 9))
        fallback_mode = 3 if kind == 'legacy_mode3' else 1 if kind == 'noncareer' else 4
        c.callbacks[b.sym(GETMODE)+slide] = lambda: c.ret(fallback_mode)
        c.callbacks[b.sym(ROLE)+slide] = lambda: c.ret(int(fallback_mode == 4))
        if kind == 'missing_save': c.ptr(MGR+(0x528 if b.is64 else 0x4e8), 0)
        elif kind == 'missing_bat_record': c.uc.mem_write(BAT_RECORD, struct.pack('<H', 77))
        elif kind == 'missing_pit_record': c.uc.mem_write(RECORD, struct.pack('<H', 77))
        elif kind == 'missing_batter':
            c.uc.mem_write(BAT, struct.pack('<H', 77))
            c.uc.mem_write(TEAMS+8+5*0x3b4+0x1a4, struct.pack('<H', 1000))
        elif kind == 'missing_pitcher':
            c.uc.mem_write(PIT, struct.pack('<H', 77))
            c.uc.mem_write(TEAMS+8+5*0x3b4+4, struct.pack('<H', 1100))
        elif kind == 'no_manager': c.callbacks[b.sym(GETMGR)+slide] = lambda: c.ret(0)
        for site in nav['scroll_calls']:
            seen = []
            def original_table():
                assert (c.r(0), c.r(1)) == (UI, 6)
                seen.append(True)
                c.ret(0)
            c.callbacks[b.sym(TABLE)+slide] = original_table
            invoke(c, site['site'], UI, 6, stop=site['site']+4+slide)
            assert seen == [True]
            counts['scope_fallbacks'] += 1
        for site in nav['role_calls']:
            c.ptr(SP+site['ui_slot'], UI)
            if site['local_slot'] is not None: c.uc.mem_write(SP+site['local_slot'], struct.pack('<i', 9))
            assert invoke(c, site['site'], stop=site['site']+4+slide) == int(fallback_mode == 4)
            if site['local_slot'] is not None:
                assert struct.unpack('<i', c.uc.mem_read(SP+site['local_slot'], 4))[0] == 9
            counts['scope_fallbacks'] += 1
        for is_batter in (0, 1):
            # The hero getter requires its selected role record; missing the
            # other role alone does not invalidate this actor lookup.
            selected_missing = (kind in ('missing_bat_record','missing_batter') and is_batter == 1
                                or kind in ('missing_pit_record','missing_pitcher') and is_batter == 0)
            if kind in ('missing_bat_record','missing_pit_record','missing_batter','missing_pitcher') and not selected_missing: continue
            seen = []
            def hero_original():
                assert (c.r(0), c.r(1)) == (MGR, 4)
                seen.append(True)
                c.ret(HEAP+0xef000)
            c.callbacks[b.sym(HERO)+slide] = hero_original
            c.uc.mem_write(SP+(0x218 if b.is64 else 0x167), bytes([is_batter]))
            assert invoke(c, hero['site'], MGR, 4, stop=hero['site']+4+slide) == HEAP+0xef000
            assert seen == [True]
            counts['scope_fallbacks'] += 1
    c = old
    mode[0] = 4
    for global_tab in (-1, 15, 0x7fffffff):
        tab(global_tab)
        assert signed32(invoke(c, symbols['yagu_rank_next_tab'], UI, 1)) == -1
        assert signed32(invoke(c, symbols['yagu_rank_is_batter'], UI, 0)) == -1
        assert signed32(invoke(c, symbols['yagu_rank_local_tab'], UI)) == global_tab
        counts['invalid_helper_inputs'] += 3
    tab(0)
    for direction in (-99, 0, 2, 99):
        assert signed32(invoke(c, symbols['yagu_rank_next_tab'], UI, direction)) == -1
        counts['invalid_helper_inputs'] += 1
    for helper, args in (('yagu_rank_next_tab', (0, 1)), ('yagu_rank_is_batter', (0, 0)), ('yagu_rank_local_tab', (0,))):
        assert signed32(invoke(c, symbols[helper], *args)) == -1
        counts['invalid_helper_inputs'] += 1

    return {'abi': abi, 'source_c_sha256': hashlib.sha256((WORK/'yagu_payload.c').read_bytes()).hexdigest(),
            'module_sha256': hashlib.sha256((WORK/'local_rank_navigation.py').read_bytes()).hexdigest(),
            'slide': hex(slide), 'navigation_sites': 19, 'counts': counts, 'total': sum(counts.values()),
            'global_categories': 15, 'batting_categories': 8, 'pitching_categories': 7,
            'original_sort_selectors': SORTS, 'ui_tab_offset': hex(offset),
            'original_control_geometry_unchanged': True, 'inline_register_flag_simd_differentials': True,
            'android_runtime_verified': False,
            'limits': ['Swipe tests start after the original collision check; hitbox rendering is not emulated.',
                       'Final fonts, graphics allocation and complete Android gameplay require runtime validation.']}


if __name__ == '__main__':
    result = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK/'local_rank_navigation_verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
