"""Exact SP decision, pitch-menu storage and existing-font caller scopes."""
from career_resource_ui import _a64_stack, _thumb_stack


# Each location is a real original GetRaiseMode(3) in SelectBallTypeUI.
PITCH_MODES = {
    'arm64-v8a': (
        ('commit', 0x52cee0, '28060894'),
        ('header', 0x52ef7c, '01fe0794'),
        ('details', 0x52f058, 'cafd0794'),
        ('details_alternate', 0x52f5c8, '6efc0794'),
        ('touch', 0x52fd74, '83fa0794'),
    ),
    'armeabi-v7a': (
        ('commit', 0x33fc6c, '31f180ea'),
        ('header', 0x34132a, '2ff122ef'),
        ('details', 0x3413be, '2ff1d8ee'),
        ('details_alternate', 0x3417f0, '2ff1beec'),
        ('touch', 0x341da6, '2ff1e4e9'),
    ),
}

# label, compare+conditional-branch address/bytes, mode original-SP slot,
# threshold register, original sufficient path. Finite fallback replays both
# instructions; the semantic test evaluates stock >= signed original cost.
DECISIONS = {
    'arm64-v8a': (
        ('passive_learn', 0x4f1cd0, '0801096b0b030054', 0xe8, 9, 0x4f1cd8),
        ('passive_upgrade', 0x4f2120, '0801096bcb040054', 0xe8, 9, 0x4f2128),
        ('pitch_learn', 0x5300bc, '0801096b4a010054', 0x70, 9, 0x5300e8),
        ('pitch_upgrade', 0x530140, '0801096b4a010054', 0x70, 9, 0x53016c),
    ),
    'armeabi-v7a': (
        ('passive_learn', 0x318cc0, '88421cdb', 0xa8, 1, 0x318cc4),
        ('passive_upgrade', 0x318f96, '88422fdb', 0xa8, 1, 0x318f9a),
        ('pitch_learn', 0x341fc6, '88420bda', 0x44, 1, 0x341fe2),
        ('pitch_upgrade', 0x342016, '88420bda', 0x44, 1, 0x342032),
    ),
}

# label, call to the original number widget, exact bytes, mode original-SP
# slot. These are available-SP cells, not skill costs or ordinary currencies.
# The widget's frame pointer +16(A64)/+8(Thumb) recovers its caller's SP even
# when the caller has a dynamically aligned frame.
NUMBER_CELLS = {
    'arm64-v8a': (
        ('passive_after_learning', 0x4ee47c, '81280994', 0xf0),
        ('passive_after_upgrade', 0x4ee61c, '19280994', 0xd0),
        ('passive_page', 0x4ef264, '07250994', 0x198),
        ('passive_table', 0x4efda8, '36220994', 0x108),
        ('pitch_page', 0x52f004, '9f250894', 0x158),
        ('pitch_info', 0x52d6c4, 'ef2b0894', 0x1d8),
        ('normal_training', 0x50d3c0, 'b0ac0894', 0x550),
        ('skill_training', 0x50deb8, 'f2a90894', 0x550),
        ('spring_camp', 0x55caa4, 'f76e0794', 0x408),
    ),
    'armeabi-v7a': (
        ('passive_after_learning', 0x3165e4, '64f15ced', 0xc4),
        ('passive_after_upgrade', 0x3166f8, '64f1d2ec', 0xac),
        ('passive_page', 0x316f82, '64f18ee8', 0x10c),
        ('passive_table', 0x3177d6, '63f164ec', 0xb0),
        ('pitch_page', 0x34138a, '39f18aee', 0xcc),
        ('pitch_info', 0x3401aa, '3af17aef', 0x110),
        ('normal_training', 0x32b1bc, '4ff170ef', 0x3a0),
        ('skill_training', 0x32ba12, '4ff146eb', 0x3a0),
        ('spring_camp', 0x35ee70, '1cf116e9', 0x2d4),
    ),
}


def skill_point_number_branches(b, symbols, site):
    """Assembly inserted after shared styling-hook register save; no patch."""
    if 'yagu_skill_point_text' not in symbols:
        return ''
    select, resolve = [], []
    for index, (label, call, expected, slot) in enumerate(NUMBER_CELLS[b.abi]):
        if bytes(b.original[b.offset(call):b.offset(call) + 4]).hex() != expected:
            raise ValueError('SP widget caller changed: ' + label)
        target = call + (4 if b.is64 else 5)
        if b.is64:
            select += [f'adrp x9, #{target & ~4095}', f'add x9, x9, #{target & 4095}',
                       'cmp x8, x9', f'b.eq sp_cell_{index}']
            resolve += [f'sp_cell_{index}:', f'ldr x0, [x29, #{16 + slot}]', 'b sp_text']
        else:
            delta = (target - (site + 5)) & 0xffffffff
            select += [f'movw r2, #{delta & 65535}', f'movt r2, #{delta >> 16}',
                       'add r2, lr', 'cmp r3, r2', f'beq sp_cell_{index}']
            resolve += [f'sp_cell_{index}:', f'ldr.w r0, [r7, #{8 + slot}]', 'b sp_text']
    if b.is64:
        return '\n'.join(['ldr x8, [x29, #8]', *select, 'b sp_not_selected', *resolve,
                          'sp_text:', f'bl #{symbols["yagu_skill_point_text"]}',
                          'cbz x0, original', 'str x0, [sp, #8]', 'b original',
                          'sp_not_selected:'])
    return '\n'.join(['ldr r3, [r7, #4]', *select, 'b sp_not_selected', *resolve,
                      'sp_text:', f'bl #{symbols["yagu_skill_point_text"]}',
                      'cmp r0, #0', 'beq original', 'str r0, [sp, #4]', 'b original',
                      'sp_not_selected:'])


def add_skill_points_hooks(b, symbols):
    output = []
    for label, site, expected in PITCH_MODES[b.abi]:
        b.patch(site, b.branch(site, symbols['yagu_sp_pitch_mode'], True),
                'Owned two-way pitch skill mode: ' + label, expected)
        output.append(dict(kind='mode', label=label, site=site,
                           hook=symbols['yagu_sp_pitch_mode'], expected=expected))
    for label, site, expected, mode_slot, threshold_reg, sufficient in DECISIONS[b.abi]:
        raw = bytes.fromhex(expected)
        pair = list(b.cs.disasm(raw, site))
        if len(pair) != 2 or pair[0].mnemonic not in ('cmp', 'subs'):
            raise ValueError('Unexpected SP comparison ' + hex(site))
        compare, branch = pair
        taken = int(branch.op_str[1:], 16)
        fallthrough = site + len(raw)
        insufficient = fallthrough if sufficient == taken else taken
        if sufficient not in (taken, fallthrough): raise ValueError('Invalid SP branch mapping')
        comparison = compare.mnemonic + ' ' + compare.op_str
        if b.is64:
            save, restore = _a64_stack()
            args = f'''ldr x0, [sp, #{704 + mode_slot}]
mov w1, #0
ldr w2, [sp, #{threshold_reg * 8}]
mov w3, #0
bl #{symbols['yagu_skill_point_compare']}
tbnz w0, #31, original
cbz w0, insufficient'''
            jump = 'b'
        else:
            save, restore = _thumb_stack()
            args = f'''ldr.w r0, [sp, #{288 + mode_slot}]
movs r1, #0
ldr r2, [sp, #{264 + threshold_reg * 4}]
movs r3, #0
bl #{symbols['yagu_skill_point_compare']}
cmp r0, #0
blt original
beq insufficient'''
            jump = 'b.w'
        source = f'''{comparison}
{save}
{args}
{restore}
{jump} #{sufficient}
insufficient:
{restore}
{jump} #{insufficient}
original:
{restore}
{branch.mnemonic} original_taken
{jump} #{fallthrough}
original_taken:
{jump} #{taken}'''
        hook = b.append_asm('Tagged SP affordability: ' + label, source)
        replacement = b.branch(site, hook)
        while len(replacement) < len(raw):
            replacement += b.asm('nop', site + len(replacement))
        if len(replacement) != len(raw): raise ValueError('SP comparison length')
        b.patch(site, replacement, 'Compare tagged skill points: ' + label, expected)
        output.append(dict(kind='decision', label=label, site=site, hook=hook,
                           expected=expected, mode_slot=mode_slot, threshold_reg=threshold_reg,
                           sufficient=sufficient, insufficient=insufficient,
                           original_true=taken, original_false=fallthrough))
    return output
