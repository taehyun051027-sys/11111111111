"""Execute compiled tagged SP, original learning stores and scoped text hooks.

Graphics, cost-table service, popup result and disk/registry services are test
boundaries. Original skill ownership/level increments, SP spending, used-SP
clamps/stores and comparison instructions run on both ABIs at nonzero ASLR.
"""
import hashlib
import json
import struct
import types
from pathlib import Path

import unicorn.arm64_const as a64
import unicorn.arm_const as arm
from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from skill_points_policy import stage_payload, HOOKS, BINDINGS, integrate_award_source
from skill_points_hooks import add_skill_points_hooks, NUMBER_CELLS, PITCH_MODES
from verify_honors import configure, invoke, original_plt
from verify_award_record_ui import complete_ui_before_awards, FONT
from verify_relocation import BAT, PIT, TEAMS, TEAM, SAVE, MODE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP

WORK = Path(__file__).resolve().parent
OTHER, UI, TEXT, BUFFER, POPUP, DEFINE = (HEAP + n for n in
    (0xb0000, 0xb1000, 0xb2000, 0xb3000, 0xb4000, 0xb5000))
THRESHOLDS = (-0x80000000, -65536, -1, 0, 1, 999, 10000, 60000, 65535, 0x7fffffff)


def verify(abi, source_dir):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    old_root = payload_builder.ROOT
    old_hooks, old_bindings = dict(payload_builder.HOOKS), dict(payload_builder.BINDINGS)
    payload_builder.ROOT = source_dir
    payload_builder.HOOKS.update(HOOKS)
    payload_builder.BINDINGS.update(BINDINGS)
    try:
        payload = payload_builder.add_payload(b, workdir=WORK / 'skill_points_build' / abi)
    finally:
        payload_builder.ROOT = old_root
        payload_builder.HOOKS.clear(); payload_builder.HOOKS.update(old_hooks)
        payload_builder.BINDINGS.clear(); payload_builder.BINDINGS.update(old_bindings)
    symbols = payload['symbols']
    complete_ui_before_awards(b, symbols)
    module = types.ModuleType('award_with_skill_points')
    exec(integrate_award_source((WORK / 'award_record_ui.py').read_text()), module.__dict__)
    awards = module.add_award_record_ui_hooks(b, symbols)
    from special_uses_hooks import add_special_uses_hooks
    from equipment_level_ui import add_equipment_level_ui_hooks
    from batting_rescue_hooks import add_batting_rescue_hook
    from signer_pin import add_signer_pin_patch
    add_special_uses_hooks(b, symbols)
    add_equipment_level_ui_hooks(b, symbols)
    add_batting_rescue_hook(b, symbols)
    sites = add_skill_points_hooks(b, symbols)
    add_signer_pin_patch(b, '0x6de25a17')
    integer = next(row for row in awards if row['label'] == 'integer')
    decisions = [row for row in sites if row['kind'] == 'decision']
    slide = 0x7d76543000 if b.is64 else 0xb5432000
    counts = dict(state=0, typed_comparisons=0, own_storage=0, finite_storage=0,
                  scope_rejections=0, pitch_mode_callers=0, decision_differentials=0,
                  typed_decisions=0, number_cells=0, original_passive_learning=0,
                  original_pitch_learning=0, unchanged_ledgers=0, reload=0,
                  award_coexistence=0)

    def setup(mode=4):
        c, records, _ = configure(b, slide, mode, payload)
        original_plt(c)
        c.callbacks[b.sym('CBBGStatic::IsBatMode()') + slide] = lambda: c.ret(mode == 4)
        c.callbacks[b.sym('CBBGStatic::IsPitMode()') + slide] = lambda: c.ret(mode == 3)
        c.callbacks[b.sym('CBBGStatic::IsRaiseMode()') + slide] = lambda: c.ret(1)
        c.callbacks[b.sym('CBBGDataMgr::GetRaisePlayer(eGameMode)') + slide] = lambda: c.ret(PIT if mode == 3 else BAT)
        c.uc.mem_write(MODE + 0x240, struct.pack('<HH', 0, 0))
        c.uc.mem_write(OTHER + 0x240, struct.pack('<HH', 19, 21))
        c.uc.mem_write(TEXT, b'19\0')
        return c, records

    def invalidate(c, kind, mode):
        if kind == 'missing_save': c.ptr(MGR + ((0x520 if mode == 3 else 0x528) if b.is64 else (0x4e4 if mode == 3 else 0x4e8)), 0)
        elif kind == 'missing_teams': c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
        elif kind == 'missing_actor': c.uc.mem_write(PIT if mode == 3 else BAT, struct.pack('<H', 7))
        elif kind == 'invalid_team': c.uc.mem_write(TEAMS + 4, struct.pack('<I', 15))
        elif kind == 'noncareer': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
        elif kind == 'missing_manager': c.callbacks[b.sym(GETMGR) + slide] = lambda: c.ret(0)

    for mode in (3, 4):
        c, _ = setup(mode)
        state = invoke(c, symbols['yagu_skill_point_state'], MODE)
        assert struct.unpack('<QII', c.uc.mem_read(state, 16)) == (0, 1, 0)
        player = invoke(c, symbols['yagu_state'], BAT)
        assert struct.unpack('<II', c.uc.mem_read(player, 8)) == (4, 1000)
        for index in range(51):
            assert struct.unpack('<QII', c.uc.mem_read(player + 8 + index * 16, 16)) == (0, 1, 0)
            counts['state'] += 1
        counts['state'] += 1
        before = bytes(c.uc.mem_read(MODE, 0x550))
        for value in THRESHOLDS:
            for op in range(6):
                got = invoke(c, symbols['yagu_skill_point_compare'], MODE, 0, value, op)
                expect = -1 if op >= 4 else int(op in (0, 2))
                assert got & 0xffffffff == expect & 0xffffffff
                counts['typed_comparisons'] += 1
            for alias in ('set_skill_points', 'add_skill_points'):
                invoke(c, b.sym(HOOKS[alias]), MODE, value)
                assert bytes(c.uc.mem_read(MODE, 0x550)) == before
                assert invoke(c, b.sym(HOOKS['skill_points']), MODE) == 10000
                assert invoke(c, symbols['yagu_skill_point_state'], MODE) == state
                counts['own_storage'] += 1
        for invalid in ('wrong_pointer', 'null_pointer', 'missing_save', 'missing_teams',
                        'missing_actor', 'invalid_team', 'noncareer', 'missing_manager'):
            t, _ = setup(mode)
            invalidate(t, invalid, mode)
            pointer = OTHER if invalid == 'wrong_pointer' else 0 if invalid == 'null_pointer' else MODE
            assert invoke(t, symbols['yagu_skill_point_state'], pointer) == 0
            assert invoke(t, symbols['yagu_skill_point_text'], pointer) == 0
            assert invoke(t, symbols['yagu_skill_point_compare'], pointer, 0, 0, 0) & 0xffffffff == 0xffffffff
            counts['scope_rejections'] += 1

        for value in THRESHOLDS:
            invoke(c, b.sym(HOOKS['set_skill_points']), OTHER, value)
            expected = min(60000, max(0, value))
            assert invoke(c, b.sym(HOOKS['skill_points']), OTHER) == expected
            assert struct.unpack('<H', c.uc.mem_read(OTHER + 0x240, 2))[0] == expected
            counts['finite_storage'] += 1
            c.uc.mem_write(OTHER + 0x240, struct.pack('<H', 19))
            # Avoid relying on host-language arithmetic for signed32 overflow.
            total = (19 + value) & 0xffffffff
            total = total - 0x100000000 if total & 0x80000000 else total
            invoke(c, b.sym(HOOKS['add_skill_points']), OTHER, value)
            assert invoke(c, b.sym(HOOKS['skill_points']), OTHER) == min(60000, max(0, total))
            assert struct.unpack('<H', c.uc.mem_read(OTHER + 0x242, 2))[0] == 21
            counts['finite_storage'] += 1

    print(abi, 'SP state/storage checks passed', flush=True)

    # Only the five exact pitch-menu calls are redirected.  Invalid/legacy
    # contexts call the unchanged original GetRaiseMode with its original args.
    for mode in (3, 4):
        for label, site, _ in PITCH_MODES[abi]:
            for invalid in ('valid', 'other_manager', 'other_request', 'missing_save',
                            'missing_teams', 'missing_actor', 'missing_pitcher', 'noncareer'):
                c, _ = setup(mode)
                invalidate(c, invalid, mode)
                if invalid == 'missing_pitcher': c.uc.mem_write(PIT, struct.pack('<H', 7))
                seen = []
                def fallback():
                    seen.append((c.r(0), c.r(1))); c.ret(OTHER)
                c.callbacks[b.sym(BINDINGS['original_sp_raise_mode']) + slide] = fallback
                dm, requested = (OTHER if invalid == 'other_manager' else MGR), (4 if invalid == 'other_request' else 3)
                c.r(0, dm); c.r(1, requested)
                c.uc.reg_write(c.sp, SP); c.stopped = None; c.stops = {site + 4 + slide}
                c.run_relative(site)
                active = mode == 4 and invalid == 'valid'
                assert c.r(0) == (MODE if active else OTHER)
                assert seen == ([] if active else [(dm, requested)])
                assert c.uc.reg_read(c.sp) == SP
                counts['pitch_mode_callers'] += 1

    # Compare inline state against execution of the real unmodified pair.
    flags = a64.UC_ARM64_REG_NZCV if b.is64 else arm.UC_ARM_REG_APSR
    vectors = [getattr(a64 if b.is64 else arm, ('UC_ARM64_REG_Q' if b.is64 else 'UC_ARM_REG_D') + str(i)) for i in range(32)]
    def machine(c):
        return ([c.r(i) for i in range(len(c.regs))], c.uc.reg_read(c.sp), c.uc.reg_read(c.lr),
                c.uc.reg_read(flags) & 0xf8000000, [c.uc.reg_read(r) for r in vectors])
    def branch_setup(c, row, ptr, lhs, rhs):
        c.uc.reg_write(c.sp, SP)
        for i in range(len(c.regs)): c.r(i, 0x12340000 + i)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        c.uc.reg_write(flags, 0xa0000000)
        for i, reg in enumerate(vectors): c.uc.reg_write(reg, 0x123456789abcdef0 + i)
        c.r(8 if b.is64 else 0, lhs & 0xffffffff); c.r(9 if b.is64 else 1, rhs & 0xffffffff)
        c.ptr(SP + row['mode_slot'], ptr)
        c.stopped = None; c.stops = {row['original_true'] + slide, row['original_false'] + slide}
    for mode in (3, 4):
        for row in decisions:
            c, _ = setup(mode); reference, _ = setup(mode)
            reference.uc.mem_write(row['site'] + slide, bytes.fromhex(row['expected']))
            for lhs, rhs in ((0, 1), (1, 0), (1, 1), (0, 65535), (10000, 0x7fffffff), (-1, 0), (0x7fffffff, -1)):
                branch_setup(reference, row, OTHER, lhs, rhs); reference.run_relative(row['site'])
                expected_state = machine(reference)
                branch_setup(c, row, OTHER, lhs, rhs); c.run_relative(row['site'])
                assert c.stopped == reference.stopped and machine(c) == expected_state
                counts['decision_differentials'] += 1
                branch_setup(c, row, MODE, lhs, rhs); c.run_relative(row['site'])
                assert c.stopped == row['sufficient'] + slide and machine(c) == expected_state
                counts['typed_decisions'] += 1

    # Exact number callers, with original font/color arguments and all caller
    # stack slots intact. The same shared hook continues to serve award cells.
    arguments = (BUFFER, TEXT, 1, 18, 211, 212, 213, 214)
    for mode in (3, 4):
        for label, call, _, slot in NUMBER_CELLS[abi]:
            for invalid in ('valid', 'wrong_pointer', 'null_pointer', 'wrong_caller', 'missing_save',
                            'missing_teams', 'missing_actor', 'noncareer'):
                for shift in ((0,) if b.is64 else (0, 4)):
                    c, _ = setup(mode); invalidate(c, invalid, mode)
                    inner = SP + 0x1000
                    c.uc.reg_write(a64.UC_ARM64_REG_X29 if b.is64 else arm.UC_ARM_REG_R7, inner)
                    caller = call + (4 if b.is64 else 5) + slide
                    c.ptr(inner + (8 if b.is64 else 4), caller + (2 if invalid == 'wrong_caller' else 0))
                    c.ptr(inner + (16 if b.is64 else 8) + slot,
                          OTHER if invalid == 'wrong_pointer' else 0 if invalid == 'null_pointer' else MODE)
                    stack = SP + shift
                    c.uc.reg_write(c.sp, stack)
                    for i, arg in enumerate(arguments):
                        if i < (8 if b.is64 else 4): c.r(i, arg)
                        else: c.uc.mem_write(stack + (i - 4) * 4, struct.pack('<I', arg))
                    observed = []
                    before = bytes(c.uc.mem_read(inner, 0x600))
                    def font():
                        text = bytes(c.uc.mem_read(c.r(1), 8)).split(b'\0', 1)[0]
                        assert text == ('∞'.encode() if invalid == 'valid' else b'19'), (abi, label, invalid, text)
                        for i, arg in enumerate(arguments):
                            if i == 1: continue
                            actual = c.r(i) if i < (8 if b.is64 else 4) else struct.unpack('<I', c.uc.mem_read(stack + (i - 4) * 4, 4))[0]
                            assert actual == arg
                        observed.append(text); c.ret(17)
                    c.callbacks[b.sym(FONT) + slide] = font
                    c.stopped = None; c.stops = {integer['site'] + 4 + slide}
                    c.run_relative(integer['site'])
                    assert len(observed) == 1 and c.uc.reg_read(c.sp) == stack
                    assert bytes(c.uc.mem_read(inner, 0x600)) == before
                    counts['number_cells'] += 1

    print(abi, 'SP caller/UI/decision checks passed', flush=True)

    # Original passive-learning commit starts from the actual popup dispatch;
    # after finite SP debit and used-SP ledger, actual skill bit/level stores
    # execute. Rendering and registry/disk service effects are boundaries.
    for mode in (3, 4):
        for popup, stop in ((26, 0x4ee39c if b.is64 else 0x316548),
                            (27, 0x4ee53c if b.is64 else 0x31665c)):
            for cost in (1, 50, 10001, 60000):
                c, _ = setup(mode)
                c.uc.mem_write(UI + (0x94 if b.is64 else 0x64), struct.pack('<I', 2))
                c.uc.mem_write(MODE + 0x200, struct.pack('<I', 1 << 2 if popup == 27 else 0))
                c.uc.mem_write(MODE + 0x206, b'\x02' if popup == 27 else b'\x00')
                c.callbacks[b.sym('CGsSingleton<CBBGCcPopup>::GetInstPtr()') + slide] = lambda: c.ret(POPUP)
                c.callbacks[b.sym('CBBGCcPopup::GetPopupID()') + slide] = lambda: c.ret(popup)
                c.callbacks[b.sym('CGsSingleton<CBBGMgrDefine>::GetInstPtr()') + slide] = lambda: c.ret(DEFINE)
                c.callbacks[b.sym('CBBGMgrDefine::GetValData(EnumXlsData, int, int)') + slide] = lambda: c.ret(cost)
                for name in ('CBBGDataMgr::SaveRegistry(unsigned char)', 'CBBGDataMgr::SetRegistryBatSkill(EnumPassiveSkills)',
                             'CBBGDataMgr::SetRegistryPitSkill(EnumPassiveSkills)'):
                    c.callbacks[b.sym(name) + slide] = lambda: c.ret(0)
                c.r(0, UI); c.uc.reg_write(c.sp, SP); c.stopped = None; c.stops = {stop + slide}
                c.run_relative(b.sym('CBBGSkillInfoUI::ProcessPopup()'))
                assert struct.unpack('<H', c.uc.mem_read(MODE + 0x240, 2))[0] == 0
                assert struct.unpack('<H', c.uc.mem_read(MODE + 0x242, 2))[0] == min(cost, 60000)
                assert struct.unpack('<I', c.uc.mem_read(MODE + 0x200, 4))[0] & (1 << 2)
                assert c.uc.mem_read(MODE + 0x206, 1)[0] == (3 if popup == 27 else 1)
                counts['original_passive_learning'] += 1

    # Whole original pitch Run entry through confirmation selection, bridge,
    # actual pitch-level write, debit and original used-SP store.
    for mode in (3, 4):
        for popup, stop in ((14, 0x52cf9c if b.is64 else 0x33fcda),
                            (16, 0x52d094 if b.is64 else 0x33fd7a)):
            for cost in (1, 50, 10001, 60000):
                c, _ = setup(mode)
                c.uc.mem_write(UI + (0x6c if b.is64 else 0x44), struct.pack('<I', 2))
                c.callbacks[b.sym('CGsSingleton<CBBGCcPopup>::GetInstPtr()') + slide] = lambda: c.ret(POPUP)
                c.callbacks[b.sym('CBBGCcPopup::GetPopupID()') + slide] = lambda: c.ret(popup)
                c.callbacks[b.sym('CBBGCcPopup::GetPopupResult()') + slide] = lambda: c.ret(1)
                c.callbacks[b.sym('CGsSingleton<CBBGMgrDefine>::GetInstPtr()') + slide] = lambda: c.ret(DEFINE)
                c.callbacks[b.sym('CBBGMgrDefine::GetValData(EnumXlsData, int, int)') + slide] = lambda: c.ret(cost)
                for repeat in range(3):
                    c.r(0, UI); c.uc.reg_write(c.sp, SP); c.stopped = None; c.stops = {stop + slide}
                    c.run_relative(b.sym('CBBGSelectBallTypeUI::Run()'))
                    assert struct.unpack('<H', c.uc.mem_read(MODE + 0x240, 2))[0] == 0
                    assert struct.unpack('<H', c.uc.mem_read(MODE + 0x242, 2))[0] == min((repeat + 1) * cost, 60000)
                    assert c.uc.mem_read(MODE + 0x3f2, 1)[0] == repeat + 1
                    counts['original_pitch_learning'] += 1

    print(abi, 'SP original learning checks passed', flush=True)

    for name in ('CBBGModeData::GetUsedSpecialPoint()', 'CBBGModeData::SetUsedSpecialPoint(int)',
                 'CBBGModeData::AddUsedSpecialPoint(int)', 'CBBGModeData::AddSkillLevel(EnumPassiveSkills, bool)',
                 'CBBGRaiseMode::AddBallTypeLv(int, int)'):
        address = b.sym(name); offset = b.offset(address); size = b.symbols[name]['size']
        assert b.image[offset:offset + size] == b.original[offset:offset + size]
        counts['unchanged_ledgers'] += 1
    c, _ = setup(4)
    next_save = HEAP + 0x60000
    c.uc.mem_write(next_save, bytes(c.uc.mem_read(SAVE, 0x4000)))
    c.ptr(MGR + (0x528 if b.is64 else 0x4e8), next_save)
    assert invoke(c, symbols['yagu_skill_point_state'], MODE) == 0
    assert invoke(c, symbols['yagu_skill_point_state'], next_save + 8) != 0
    assert invoke(c, b.sym(HOOKS['skill_points']), next_save + 8) == 10000
    counts['reload'] += 3

    # Existing award caller follows its old branch through the same site.
    for mode in (3, 4):
        c, records = setup(mode)
        inner, parent = SP + 0x1000, SP + 0x3000
        c.uc.reg_write(a64.UC_ARM64_REG_X29 if b.is64 else arm.UC_ARM_REG_R7, inner)
        c.ptr(inner, parent)
        c.ptr(inner + (8 if b.is64 else 4), integer['current_caller'] + slide)
        offsets = (-0x1e0, -0x1e8, -0x1ec) if b.is64 else (-0x184, -0x188, -0x18c)
        c.ptr(parent + offsets[0], records[0]); c.ptr(parent + offsets[1], records[1])
        c.uc.mem_write(parent + offsets[2], struct.pack('<I', 1))
        for i, arg in enumerate(arguments):
            if i < (8 if b.is64 else 4): c.r(i, arg)
            else: c.uc.mem_write(SP + (i - 4) * 4, struct.pack('<I', arg))
        observed = []
        def award_font():
            observed.append(bytes(c.uc.mem_read(c.r(1), 4))); c.ret(0)
        c.callbacks[b.sym(FONT) + slide] = award_font
        c.uc.reg_write(c.sp, SP); c.stopped = None; c.stops = {integer['site'] + 4 + slide}
        c.run_relative(integer['site'])
        assert observed == ['∞'.encode() + b'\0']
        counts['award_coexistence'] += 1

    final = b.finish(WORK / 'skill_points_build' / abi / 'libgameDSO.so')
    return dict(abi=abi, slide=hex(slide), passed=sum(counts.values()), counts=counts,
                source_c_sha256=hashlib.sha256((source_dir / 'yagu_payload.c').read_bytes()).hexdigest(),
                output_sha256=final['output_sha256'], patch_count=len(b.patches),
                sp_entry_hooks=3, typed_affordability_sites=4, exact_pitch_menu_mode_sites=5,
                number_cells=len(NUMBER_CELLS[abi]), scalar_namespace='separate immutable career resource',
                original_used_sp_ledger_preserved=True, android_runtime_verified=False,
                limits=['No Android skill learning or visual font rendering inferred from instruction tests.',
                        'Training/camp post-animation and other resources are separately audited; nine current-SP cells covered here.'])


if __name__ == '__main__':
    source_dir = WORK / 'skill_points_build' / 'source'
    manifest = stage_payload(source_dir)
    results = [verify(abi, source_dir) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'skill_points_verification.json').write_text(json.dumps(dict(stage=manifest, results=results), indent=2) + '\n')
    print(json.dumps(results, indent=2))
