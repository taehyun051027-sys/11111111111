/* Explicit offline development catalog. The current server catalog BSS,
 * NetworkMgr, NetResult, accounts, billing and receipt code are untouched.
 * Legacy APK table values are development prices, not a claim about the
 * publisher's current prices. Hair/dye/special skins use an explicit unit
 * development price in their original currency. */
API extern u8 *catalog_define(void);
API extern u8 *catalog_loader(u8 *, int);
API extern int catalog_x(u8 *);
API extern int catalog_y(u8 *);
API extern int catalog_value(u8 *, int, int);
API extern int catalog_original_equip_price(int, int, u8);
API extern int catalog_original_equip_discount(int, int, u8);
API extern int catalog_original_equip_sale(int, int, u8);
API extern int catalog_original_costume_price(int, int);
API extern int catalog_original_costume_discount(int, int);
API extern int catalog_original_costume_sale(int, int);
API extern int catalog_original_effect_price(int, u8);
API extern int catalog_original_effect_discount(int, u8);
API extern int catalog_original_effect_sale(int, u8);
API extern u8 catalog_original_effect_g(int, u8);
API extern void catalog_rotate(u8 *, int);
API extern void catalog_worldmap_popup(u8 *);
API extern u8 catalog_gift_running(u8 *);
API extern void catalog_gift_set_running(u8 *, u8);
API extern void catalog_create_buy_popup(int, u8, int);

static u8 *catalog_checked_loader(int id) {
    u8 *define = catalog_define();
    if (!define || id < 4 || id > 6) return (u8 *)0;
    u8 *loader = catalog_loader(define, id);
    if (!loader) return (u8 *)0;
    int columns = id == 4 ? 11 : id == 5 ? 10 : 6;
    int rows = id == 4 ? 60 : id == 5 ? 29 : 11;
    return catalog_x(loader) == columns && catalog_y(loader) == rows ? loader : (u8 *)0;
}
API int yagu_catalog_enabled(void) {
    return local_wallet_career() && catalog_checked_loader(4) &&
        catalog_checked_loader(5) && catalog_checked_loader(6);
}
static int catalog_equip_valid(int part, int item) {
    return part >= 0 && part <= 4 && item >= 0 && item < (part == 4 ? 10 : 15);
}
static int catalog_costume_valid(int part, int item) {
    return part >= 0 && part <= 3 && item >= 0 &&
        item < (part == 0 ? 11 : part == 3 ? 5 : 10);
}
static int catalog_effect_valid(int item, u8 batter) {
    return item >= 0 && item < ((batter & 1) ? 29 : 28);
}
API int yagu_catalog_equip_price(int part, int item, u8 batter) {
    if (!yagu_catalog_enabled() || !catalog_equip_valid(part, item))
        return catalog_original_equip_price(part, item, batter);
    int price;
    if (part == 4)
        price = catalog_value(catalog_checked_loader(6), (batter & 1) ? 0 : 1, item + 1);
    else {
        int column = ((batter & 1) ? 0 : 5) + (item >= 5);
        price = catalog_value(catalog_checked_loader(4), column, part * 15 + item);
    }
    return price >= 0 ? price : catalog_original_equip_price(part, item, batter);
}
API int yagu_catalog_costume_price(int part, int item) {
    if (!yagu_catalog_enabled() || !catalog_costume_valid(part, item))
        return catalog_original_costume_price(part, item);
    if (part != 0) return 1; /* Hair/dye: 1 G; special skin: 1 Star. */
    int price = catalog_value(catalog_checked_loader(6), game_mode() == TWO_WAY_MODE ? 0 : 1, item);
    return price >= 0 ? price : catalog_original_costume_price(part, item);
}
API int yagu_catalog_effect_price(int item, u8 batter) {
    if (!yagu_catalog_enabled() || !catalog_effect_valid(item, batter))
        return catalog_original_effect_price(item, batter);
    int price = catalog_value(catalog_checked_loader(5), (batter & 1) ? 0 : 5, item);
    return price >= 0 ? price : catalog_original_effect_price(item, batter);
}
API u8 yagu_catalog_effect_g(int item, u8 batter) {
    if (!yagu_catalog_enabled() || !catalog_effect_valid(item, batter))
        return catalog_original_effect_g(item, batter);
    return item < ((batter & 1) ? 7 : 6);
}
#define CATALOG_EQUIP_VIEW(name) \
API int yagu_catalog_equip_##name(int part, int item, u8 batter) { \
    return yagu_catalog_enabled() && catalog_equip_valid(part, item) ? 0 : \
        catalog_original_equip_##name(part, item, batter); \
}
CATALOG_EQUIP_VIEW(discount)
CATALOG_EQUIP_VIEW(sale)
#undef CATALOG_EQUIP_VIEW
#define CATALOG_COSTUME_VIEW(name) \
API int yagu_catalog_costume_##name(int part, int item) { \
    return yagu_catalog_enabled() && catalog_costume_valid(part, item) ? 0 : \
        catalog_original_costume_##name(part, item); \
}
CATALOG_COSTUME_VIEW(discount)
CATALOG_COSTUME_VIEW(sale)
#undef CATALOG_COSTUME_VIEW
#define CATALOG_EFFECT_VIEW(name) \
API int yagu_catalog_effect_##name(int item, u8 batter) { \
    return yagu_catalog_enabled() && catalog_effect_valid(item, batter) ? 0 : \
        catalog_original_effect_##name(item, batter); \
}
CATALOG_EFFECT_VIEW(discount)
CATALOG_EFFECT_VIEW(sale)
#undef CATALOG_EFFECT_VIEW

/* Request-site decisions enter the existing local UI continuation directly.
 * No network status is read as a synthetic success, and no network state is
 * written. `ui` comes from the exact original call frame. */
API int yagu_catalog_request(u8 *ui, int request_mode, int rotation) {
    if (!ui || request_mode != 6 || !yagu_catalog_enabled()) return 0;
    if (rotation) {
#if __SIZEOF_POINTER__ == 8
        u8 *mode = ptr(ui, 0xc8);
#else
        u8 *mode = ptr(ui, 0xa4);
#endif
        if ((rotation != 1 && rotation != 2) || !own_mode(mode)) return 0;
        catalog_rotate(mode, rotation);
    }
    return 1;
}
API int yagu_catalog_worldmap_ready(u8 *ui, int request_mode) {
    if (!ui || request_mode != 6 || !yagu_catalog_enabled()) return 0;
#if __SIZEOF_POINTER__ == 8
    ui[0x38] = 1;
#else
    ui[0x24] = 1;
#endif
    catalog_worldmap_popup(ui);
    return 1;
}
API int yagu_catalog_strength_ready(u8 *runnable, int request_mode, u8 *ui) {
    if (!runnable || !ui || request_mode != 6 || !yagu_catalog_enabled()) return 0;
#if __SIZEOF_POINTER__ == 8
    if (ptr(runnable, 0x160) != ui) return 0;
#else
    if (ptr(runnable, 0xf0) != ui) return 0;
#endif
    if (!catalog_gift_running(ui)) return 0;
    catalog_gift_set_running(ui, 0);
    catalog_create_buy_popup(0, 1, 0x4d);
    return 1;
}
