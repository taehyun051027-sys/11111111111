"""Render semantic My pitch speed in the existing pitch-result text label."""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE


def add_pitch_speed_ui_hooks(b, symbols):
    resolver = symbols['yagu_format_pitch_speed']
    formatter = b.sym('MC_knlSprintk')
    sites = [(0x3b9d80, 1, 'b4cd0d94'), (0x3b9d98, 0, 'aecd0d94')] if b.is64 else [
        (0x249ab4, 1, '26f2bce9'), (0x249ac2, 0, '26f2b6e9')]
    exports = []
    for site, english, expected in sites:
        if b.is64:
            source = f'''{A64_SAVE}
ldr x1, [sp, #0x98]
cbz x1, original
ldr x1, [x1, #0x1a8]
mov w2, #{english}
bl #{resolver}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{formatter}'''
        else:
            source = f'''{T32_SAVE}
ldr r1, [sp, #0x5c]
cmp r1, #0
beq original
ldr.w r1, [r1, #0x140]
movs r2, #{english}
bl #{resolver}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{formatter}'''
        hook = b.append_asm('Unbounded pitch-result speed ' + hex(site), source)
        b.patch(site, b.branch(site, hook, True), 'Render semantic owned My pitch speed', expected)
        exports.append({'site': site, 'hook': hook, 'english': english})
    return exports
