"""Verify real compiled award predicates and three actual font-call hooks.

Original GetPastRaise*Rec leaves execute for the ten-slot pointer policy.
UI layout is not rendered here; the complete original font/style arguments,
caller/frame bounds, finite fallbacks and unmodified save/roster are checked.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from award_record_policy import stage_payload, integrate_source
from award_record_ui import add_award_record_ui_hooks, SITES, FONT
from verify_honors import configure, invoke, original_plt
from verify_relocation import TEAM, TEAMS, BAT, PIT, SAVE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
from unicorn.arm64_const import UC_ARM64_REG_X29
from unicorn.arm_const import UC_ARM_REG_R7

WORK = Path(__file__).resolve().parent
TEXT = HEAP + 0x9a000
BUFFER = HEAP + 0x9b000
INFINITY = '\u221e'


def complete_ui_before_awards(b, symbols):
    """Use the final CLI's exact order, including the shared number formatter."""
    from infinity_ui import add_infinity_ui_hooks
    from game_run_uniform_hooks import add_game_run_uniform_hooks
    from personal_record_ui import add_personal_record_ui_hooks
    from pitch_speed_ui import add_pitch_speed_ui_hooks
    from personal_record_navigation import add_personal_record_navigation_hooks
    from career_ability_ui import add_career_ability_ui_hooks, add_rest_current_condition_hook
    from live_stats_ui import add_live_stats_ui_hooks
    from local_rank_ui import add_local_rank_ui_hooks
    from local_rank_navigation import add_local_rank_navigation_hooks
    from career_resource_ui import add_career_resource_ui_hooks, add_career_resource_decisions
    from training_max_ui import add_training_max_ui_hooks
    add_infinity_ui_hooks(b, symbols['yagu_state'])
    for function in (add_game_run_uniform_hooks, add_personal_record_ui_hooks,
                     add_pitch_speed_ui_hooks, add_personal_record_navigation_hooks,
                     add_career_ability_ui_hooks, add_rest_current_condition_hook,
                     add_live_stats_ui_hooks, add_local_rank_ui_hooks,
                     add_local_rank_navigation_hooks, add_career_resource_ui_hooks,
                     add_career_resource_decisions, add_training_max_ui_hooks):
        function(b, symbols)


def verify(abi, source_dir):
    original_bytes = (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes()
    b = PatchBuilder(abi, original_bytes)
    add_gameplay_hooks(b)
    old = payload_builder.ROOT
    payload_builder.ROOT = source_dir
    try:
        payload = payload_builder.add_payload(b, workdir=WORK / 'award_record_ui_build' / abi)
    finally:
        payload_builder.ROOT = old
    symbols = payload['symbols']
    complete_ui_before_awards(b, symbols)
    sites = add_award_record_ui_hooks(b, symbols)
    from signer_pin import add_signer_pin_patch
    from defender_hooks import verify_original_defender_lookups
    add_signer_pin_patch(b, '0x6de25a17')
    verify_original_defender_lookups(b)
    assert len(b.patches) == 140
    slide = 0x7a54321000 if b.is64 else 0xa5432000
    counts = {'owned_current_cells': 0, 'owned_past_cells': 0,
              'scope_fallbacks': 0, 'caller_and_index_fallbacks': 0,
              'original_past_pointer_parity': 0, 'invalid_past_pointer': 0,
              'original_award_procedures': 0, 'whole_number_widget': 0}
    args = (BUFFER, TEXT, 1, 18, 213, 214, 215, 216)

    def setup(mode):
        c, records, _ = configure(b, slide, mode, payload)
        role = mode == 3
        for i in range(10):
            pointer = SAVE + 0x830 + i * (32 if role else 24)
            c.uc.mem_write(pointer, struct.pack('<H', 1100 if role else 1000))
        c.uc.mem_write(TEXT, b'123.45\0')
        return c, records

    def frame(c, site, records, column, history=False, year=0, caller=None,
              record_override=None, parent_null=False):
        inner = SP + 0x1000
        parent = SP + 0x3000
        c.uc.reg_write(UC_ARM64_REG_X29 if c.is64 else UC_ARM_REG_R7, inner)
        c.ptr(inner, 0 if parent_null else parent)
        c.ptr(inner + (8 if c.is64 else 4),
              (site['past_caller'] if history else site['current_caller']) + slide if caller is None else caller + slide)
        if not history:
            bat_off, pit_off, col_off = (-0x1e0, -0x1e8, -0x1ec) if c.is64 else (-0x184, -0x188, -0x18c)
            bat, pit = records[0], records[1]
        else:
            bat_off, pit_off, col_off = (-0xa8, -0xb0, -0xc4) if c.is64 else (-0x84, -0x88, -0x94)
            slot = max(0, min(year, 9))
            bat, pit = SAVE + 0x830 + slot * 24, SAVE + 0x830 + slot * 32
            c.uc.mem_write(parent + (-0xb4 if c.is64 else -0x8c), struct.pack('<i', year))
        if record_override is not None:
            bat = pit = record_override
        c.ptr(parent + bat_off, bat)
        c.ptr(parent + pit_off, pit)
        c.uc.mem_write(parent + col_off, struct.pack('<i', column))
        return inner, parent

    def font_case(c, site, expected, *, stack_shift=0):
        actual_sp = SP + stack_shift
        c.uc.reg_write(c.sp, actual_sp)
        for i, value in enumerate(args):
            if i < (8 if c.is64 else 4): c.r(i, value)
            else: c.uc.mem_write(actual_sp + (i - 4) * 4, struct.pack('<I', value))
        observed = []
        def font():
            value = bytes(c.uc.mem_read(c.r(1), 8)).split(b'\0', 1)[0].decode()
            assert value == expected, (abi, site['label'], expected, value)
            if expected == '123.45': assert c.r(1) == TEXT
            for i, value in enumerate(args):
                if i == 1: continue
                actual = c.r(i) if i < (8 if c.is64 else 4) else struct.unpack('<I', c.uc.mem_read(actual_sp + (i - 4) * 4, 4))[0]
                assert actual == value, (abi, i, actual, value)
            assert c.uc.reg_read(c.sp) == actual_sp
            observed.append(expected)
            c.ret(17)
        c.callbacks[b.sym(FONT) + slide] = font
        c.stopped = None
        c.stops = {site['site'] + 4 + slide}
        c.run_relative(site['site'])
        assert c.stopped == site['site'] + 4 + slide and observed == [expected]
        assert c.uc.reg_read(c.sp) == actual_sp

    for mode in (3, 4):
        role = int(mode == 3)
        c, records = setup(mode)
        snapshot = bytes(c.uc.mem_read(SAVE, 0x4000))
        roster = bytes(c.uc.mem_read(TEAMS, 8 + 15 * 0x3b4))
        for position in (0, 1, 2):
            c.uc.mem_write(PIT + 0x21, bytes([position]))
            for site in sites:
                if (site['label'] == 'average' and role) or (site['label'] == 'earned_run_average' and not role):
                    continue
                for column in ((1, 2) if site['label'] == 'integer' else (0,)):
                    expected = '0' if role and column == 0 else INFINITY
                    for shift in ((0,) if c.is64 else (0, 4)):
                        frame(c, site, records, column)
                        font_case(c, site, expected, stack_shift=shift)
                        counts['owned_current_cells'] += 1
                        for year in (0, 1, 8, 9, 10, 127, 32767, 0x7fffffff):
                            frame(c, site, records, column, True, year)
                            font_case(c, site, expected, stack_shift=shift)
                            counts['owned_past_cells'] += 1
        assert bytes(c.uc.mem_read(SAVE, 0x4000)) == snapshot
        # Position is a deliberate fixture input. Apart from that byte, roster
        # storage remains exact through every font/helper call.
        c.uc.mem_write(PIT + 0x21, roster[PIT + 0x21 - TEAMS:PIT + 0x22 - TEAMS])
        assert bytes(c.uc.mem_read(TEAMS, len(roster))) == roster

        # The original getters use the same observed pointer math and do not
        # consult a second save for the active original role.
        getter = 'CBBGDataMgr::GetPastRaisePitcherRec(int)' if role else 'CBBGDataMgr::GetPastRaiseBatterRec(int)'
        for year in (0, 1, 8, 9, 10, 127, 32767, 0x7fffffff):
            pointer = invoke(c, b.sym(getter), MGR, year)
            assert pointer == SAVE + 0x830 + min(year, 9) * (32 if role else 24)
            counts['original_past_pointer_parity'] += 1

        for history in (False, True):
            for site in sites:
                column = 1 if site['label'] == 'integer' else 0
                for caller in (0x123457, 0x46a70c if c.is64 else 0x2bdd01,
                               0x46afe4 if c.is64 else 0x2be35f,
                               0x46b078 if c.is64 else 0x2be3cf):
                    frame(c, site, records, column, history, caller=caller, parent_null=True)
                    font_case(c, site, '123.45')
                    counts['caller_and_index_fallbacks'] += 1
                for invalid in ((-1, 0, 3, 0x7fffffff) if site['label'] == 'integer' else (-1, 1, 2, 3)):
                    frame(c, site, records, invalid, history)
                    font_case(c, site, '123.45')
                    counts['caller_and_index_fallbacks'] += 1
                frame(c, site, records, column, history, parent_null=True)
                font_case(c, site, '123.45')
                counts['caller_and_index_fallbacks'] += 1

        site = sites[0]
        for year in (-1, -128, -0x80000000):
            frame(c, site, records, 1, True, year)
            font_case(c, site, '123.45')
            counts['invalid_past_pointer'] += 1
        for pointer in (0, records[role], SAVE + 0x830 + (32 if role else 24),
                        SAVE + 0x1830, records[1 - role]):
            if pointer:
                previous = bytes(c.uc.mem_read(pointer, 2))
                c.uc.mem_write(pointer, struct.pack('<H', 1100 if role else 1000))
            frame(c, site, records, 1, True, 0, record_override=pointer)
            font_case(c, site, '123.45')
            if pointer: c.uc.mem_write(pointer, previous)
            counts['invalid_past_pointer'] += 1
        c.uc.mem_write(SAVE + 0x830, struct.pack('<H', 42))
        frame(c, site, records, 1, True, 0)
        font_case(c, site, '123.45')
        counts['invalid_past_pointer'] += 1

    for mode in (3, 4):
        role = int(mode == 3)
        for kind in ('noncareer', 'manager', 'save', 'teams', 'bad_team', 'actor',
                     'record_id', 'opponent_actor', 'count', 'invalid_position'):
            c, records = setup(mode)
            actor = PIT if role else BAT
            if kind == 'noncareer': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            elif kind == 'manager': c.callbacks[b.sym(GETMGR) + slide] = lambda: c.ret(0)
            elif kind == 'save': c.ptr(MGR + ((0x520 if role else 0x528) if c.is64 else (0x4e4 if role else 0x4e8)), 0)
            elif kind == 'teams': c.ptr(MGR + (0x530 if c.is64 else 0x4ec), 0)
            elif kind == 'bad_team': c.uc.mem_write(TEAMS + 4, struct.pack('<i', 15))
            elif kind == 'actor': c.uc.mem_write(actor, struct.pack('<H', 22))
            elif kind == 'record_id': c.uc.mem_write(records[role], struct.pack('<H', 22))
            elif kind == 'opponent_actor':
                c.uc.mem_write(actor, struct.pack('<H', 22))
                other = TEAMS + 8 + 5 * 0x3b4 + (4 if role else 0x1a4)
                c.uc.mem_write(other, struct.pack('<H', 1100 if role else 1000))
            elif kind == 'count': c.uc.mem_write(TEAM + (2 if role else 3), bytes([9 if role else 13]))
            elif kind == 'invalid_position':
                if not role: continue
                c.uc.mem_write(PIT + 0x21, b'\x0f')
            for history in (False, True):
                frame(c, sites[0], records, 2, history)
                font_case(c, sites[0], '123.45')
                counts['scope_fallbacks'] += 1

    # Execute the entire original integer widget with both shared formatter
    # and new styling hooks installed. String allocation/style/render services
    # are observed boundaries; the original stack frames and native formatting
    # path execute, exposing a wrong recovered parent-frame offset immediately.
    number = 'AddChildFitNumberSystemFont(int, int, cocos2d::_ccColor4B&, int, int, cocos2d::CCRect&, int, int, int, bool, bool)'
    final_font = 'AddChildFitSystemFont(char const*, int, int, cocos2d::CCRect&, int, int, int, bool, bool, bool)'
    color, rect = HEAP + 0x9c000, HEAP + 0x9c100
    for mode in (3, 4):
        for context in ('current', 'past', 'rest', 'mvp_gift', 'year_money', 'unknown'):
            c, records = setup(mode)
            c.uc.mem_write(PIT + 0x21, b'\0')
            history = context == 'past'
            inner, parent = frame(c, sites[0], records, 1, history)
            if context == 'current': caller = sites[0]['current_caller']
            elif context == 'past': caller = sites[0]['past_caller']
            elif context == 'rest':
                caller = 0x501698 if c.is64 else 0x322f43
                c.ptr(parent + (-0xa8 if c.is64 else -0x8c), SAVE + 8)
            elif context == 'mvp_gift': caller = 0x46a70c if c.is64 else 0x2bdd01
            elif context == 'year_money': caller = 0x46afe4 if c.is64 else 0x2be35f
            else: caller = 0x123457
            # The original widget itself constructs the inner frame; its saved
            # parent is the actual incoming FP and the actual LR from this call.
            c.uc.reg_write(UC_ARM64_REG_X29 if c.is64 else UC_ARM_REG_R7, parent)
            original_plt(c)
            for name in ('CBBStringBuffer::CBBStringBuffer(char const*)',
                         'CBBStringBuffer::~CBBStringBuffer()'):
                c.callbacks[b.sym(name) + slide] = lambda: c.ret(0)
            rendered, styled = [], []
            def sprintf():
                # Only the original integer fallback reaches this boundary;
                # the rest formatter writes the real semantic glyph itself.
                destination = c.r(0)
                value = str(c.r(2) & 0xffffffff).encode()
                c.uc.mem_write(destination, value + b'\0')
                c.ret(len(value))
            c.callbacks[b.sym('MC_knlSprintk') + slide] = sprintf
            def change_font():
                text = bytes(c.uc.mem_read(c.r(1), 16)).split(b'\0', 1)[0].decode()
                values = [c.r(i) if i < (8 if c.is64 else 4) else struct.unpack(
                    '<I', c.uc.mem_read(c.uc.reg_read(c.sp) + (i - 4) * 4, 4))[0]
                          for i in range(2, 8)]
                assert values == [1, 18, 213, 214, 215, 216], (abi, context, values)
                styled.append((text, c.r(1)))
                c.ret(0)
            c.callbacks[b.sym(FONT) + slide] = change_font
            c.callbacks[b.sym('CBBStringBuffer::Get()') + slide] = lambda: c.ret(styled[-1][1])
            def render():
                rendered.append(bytes(c.uc.mem_read(c.r(0), 16)).split(b'\0', 1)[0].decode())
                c.ret(0)
            c.callbacks[b.sym(final_font) + slide] = render
            c.uc.mem_write(color, bytes([213, 214, 215, 216]))
            c.uc.mem_write(rect, struct.pack('<ffff', 10, 20, 90, 22))
            input_args = (123, 18, color, 0, 0x654, rect, 0x22, 320, 240, 1, 1)
            c.uc.reg_write(c.sp, SP)
            c.uc.reg_write(c.lr, caller + slide)
            for i, value in enumerate(input_args):
                register_count = 8 if c.is64 else 4
                if i < register_count: c.r(i, value)
                else:
                    width = 8 if c.is64 else 4
                    c.uc.mem_write(SP + (i - register_count) * width,
                                   value.to_bytes(width, 'little'))
            c.stopped = None
            c.stops = {(caller + slide) & ~int(not c.is64)}
            c.run_relative(b.sym(number))
            expected = INFINITY if context in ('current', 'past', 'rest') else '123'
            assert styled and styled[-1][0] == expected and rendered == [expected], (abi, mode, context, styled, rendered)
            assert c.uc.reg_read(c.sp) == SP
            counts['whole_number_widget'] += 1

    # Every original award method, its monetary tables and record getters are
    # byte-for-byte preserved: only the shared text styling calls are patched.
    for name, item in b.symbols.items():
        if not (name.startswith('CBBGUIPostAward::') or name.startswith('CBBGDataMgr::GetPastRaise')):
            continue
        offset = b.offset(item['address'])
        assert bytes(b.image[offset:offset + item['size']]) == original_bytes[offset:offset + item['size']], name
        counts['original_award_procedures'] += 1
    result = b.finish(WORK / 'award_record_ui_build' / abi / 'full-composition.so')
    integrated = WORK / 'integrated/lib' / abi / 'libgameDSO.so'
    assert integrated.exists() and integrated.read_bytes() == (WORK / 'award_record_ui_build' / abi / 'full-composition.so').read_bytes(), 'Final CLI composition differs'
    return {'abi': abi, 'slide': hex(slide), 'original_sha256': b.sha,
            'source_c_sha256': hashlib.sha256((source_dir / 'yagu_payload.c').read_bytes()).hexdigest(),
            'passed': sum(counts.values()), 'cases': counts, 'sites': sites,
            'full_final_patch_count': len(b.patches), 'final_library_sha256': result['output_sha256'],
            'byte_identical_to_final_cli': True,
            'preserved': ['original typeface, font size, RGBA, layout and text pipeline',
                          'MVP gifts and monetary award numbers',
                          'all original award methods and finite saved record counters'],
            'history_policy': 'actual active-role owned save, exact original min(year,9) pointer and My RFID; negative years rejected',
            'android_runtime_verified': False}


if __name__ == '__main__':
    source_dir = WORK / 'award_record_ui_build' / 'source'
    manifest = stage_payload(source_dir)
    source = (source_dir / 'yagu_payload.c').read_text()
    assert integrate_source(source) == source
    results = [verify(abi, source_dir) for abi in ('arm64-v8a', 'armeabi-v7a')]
    report = {'stage': manifest, 'results': results,
              'passed': sum(item['passed'] for item in results)}
    (WORK / 'award_record_ui_verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'stage': manifest, 'passed': report['passed'],
                      'results': [{k: v[k] for k in ('abi', 'passed', 'cases')} for v in results]}, indent=2))
