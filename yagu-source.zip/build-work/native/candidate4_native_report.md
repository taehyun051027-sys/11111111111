# Candidate 4: typed personal-record rules

Candidate 4 adds nonvisual personal-record decisions to the frozen candidate 3 feature set. It retains the original finite match/event counters and save layouts, and uses an explicitly tagged, immutable personal-record policy for the verified career decisions described below. It does **not** establish that every legacy record consumer now understands infinity.

## Frozen output

| ABI | SHA-256 | Size | Original patch sites |
|---|---|---:|---:|
| arm64-v8a | `ba76429cf6b09ce2b19b7b9e4a30640f7c731d44495a2d2f93970f8dc9274180` | 8,080,264 bytes | 101 |
| armeabi-v7a | `fab28f82c69857423ab810798a4e8eb58660d9cb7917dff3dce8d9cb3c876224` | 5,045,684 bytes | 101 |

The immutable libraries and complete patch manifests are in `candidate4-native/lib/{abi}/`. The C source hash is `9e46f4178922d3b82580a1bd45c7ee4c46b58cee3121475c796686b971d7b57e`. Candidate 3 libraries remain unchanged in their separate directory.

## Semantic state

The player model remains 43 tagged unbounded scalars. Personal-record schema 2 contains 33 scalars: 26 `UNBOUNDED`, seven exact finite zero. Quality starts is now explicitly unbounded; fielding errors is explicitly zero. Existing 31 metric offsets remain stable. No large finite value or native IEEE infinity represents these record quantities.

The 13 batting table metrics are AVG, AB, H, doubles, triples, HR, RBI, steals, walks, sacrifices, slugging percentage, OBP and OPS. Their policy values are unbounded. The 13 pitching table metrics are ERA, innings, earned runs, allowed hits, wins, losses, holds, saves, strikeouts, pitches, allowed walks, WHIP and K/9. ERA, earned runs, allowed hits, losses, allowed walks and WHIP are zero; the other pitching metrics are unbounded. The additional metrics are games/appearances, starts, complete games, shutouts, perfect games, quality starts and fielding errors.

The extra games, starts, complete-game, shutout and perfect-game fields have a callable typed lookup. This candidate does not claim that a verified existing native consumer uses each of those five fields. A record tag is not evidence of full engine integration by itself.

## Ownership and save binding

`yagu_current_personal_record(role)` resolves only in career mode 3 or 4. It requires the active career save, a valid own-team index, the matching role actor in that team's actual bounded roster, and the role's record in that same active save. Record identity uses the persistent RFID rather than the current physical roster slot. Lookup does not create records or write to the save.

`yagu_owned_records(record, role)` accepts only that exact owned record pointer. A matching RFID on another team, in an unrelated save, or at another record address does not establish a personal-record policy.

| Active career | Batter-record array | Pitcher-record array |
|---|---|---|
| Mode 3 | save + `0x1de4` + team × `0x120`; 12 × 24-byte records | save + `0xee4` + team × `0x100`; 8 × 32-byte records |
| Mode 4 | save + `0x1d8c` + team × `0x120`; 12 × 24-byte records | save + `0xe8c` + team × `0x100`; 8 × 32-byte records |

These offsets are observed in both original ABIs' `CBBGDataMgr::GetBatterRec` and `GetPitcherRec`; see `record_ownership_a64.txt` and `record_core_thumb.txt`.

## Active nonvisual consumers

| Original entry | A64 address | Thumb address | New behavior |
|---|---|---|---|
| `CBBGRaiseMode::IsYearGoalCheck(int,int)` | `0x3734e0` | `0x21d9c4` | Reads typed owned metrics for the verified personal year-goal types. |
| `CBBGEvent::IsRecordCheckBat(int,int,int)` | `0x424df4` | `0x28fb40` | Reads typed owned batting metrics for the verified selectors and period flags. |
| `CBBGEvent::IsRecordCheckPit(int,int,int)` | `0x4258bc` | `0x290204` | Reads typed owned pitching metrics for the verified selectors and period flags. |

These are actual patched original entries, not new APIs that the original engine never reaches. The original event dispatcher calls the batting or pitching predicate while deciding whether an event can run. The original year-goal rule is called by the goal and reward machinery. Other original conditions and the original reward processing remain in place.

### Year goals

For batting, goal IDs 0–5 use AVG, hits, home runs, RBI, slugging and OPS, all compared with `>= threshold`. Goal 6 is popularity and remains original. Batting goal 7 reads an additional season-record field whose meaning is not established here, so it also remains original.

For pitching, IDs 0–5 use ERA, wins, holds, saves, strikeouts and WHIP. ERA and WHIP use the original `<= threshold` test against exact zero. The positive metrics use `>= threshold` against unbounded. Pitching ID 7 now uses explicit unbounded quality starts. Popularity ID 6 remains original.

### Event conditions

The original `IsCheckVal(threshold, actual)` has two distinct rules: a nonnegative threshold means `actual >= threshold`; a negative threshold means `actual < abs(threshold)`, strictly. The new typed comparison preserves those rules. An unbounded metric passes every finite lower-bound requirement and fails every finite upper-bound requirement. Zero adverse metrics obey ordinary exact comparisons. The original signed `INT_MIN` edge case is preserved and tested against the original native implementation.

Typed routing is limited to period 1, cumulative records, and period 2, current-season records. Strict parsing of all 14 Korean/English event streams found these flags in the shipped content, together with flags 4 and 7. Flag 4 is the match-local statistics path and remains original. Flag 7 is observed but has not been independently assigned a broader semantic meaning; it remains original as well. Other flags and unrelated selectors also fall through unchanged.

| Role | Selectors routed to typed metrics |
|---|---|
| Batter | 1 AVG; 2 AB; 3 H; 4 doubles; 5 triples; 6 HR; 7 RBI; 9 steals; 10 fielding errors; 11 sacrifices; 12 SLG; 13 OBP; 14 OPS |
| Pitcher | 1 ERA; 2 innings; 3 ER; 4 wins; 5 losses; 6 holds; 7 saves; 8 outs; 9 K; 10 pitches; 11 walks; 13 allowed hits; 14 WHIP; 15 K/9 |

The original no-op or unrelated selectors remain original, including team standings, event achievements, popularity, special-skill counts and summons. `record_selector_map.json` records the exact original branch targets and getter calls.

## What remains finite and why

The raw `CBBGBatterRecData` and `CBBGPitcherRecData` getters, setters and increment routines are unchanged. They still serve finite match accounting, per-event statistics, raw save data, team statistics and existing serialization. Native instruction tests explicitly check this separation at 65,535, 65,536 and signed 32-bit boundaries.

This candidate does not replace the 20-byte legacy aggregate record ABI with a typed object. Local ranking eligibility/insertion/hero-rank counting and interim appraisal still consume those original finite projections. They are material remaining integration gaps, not evidence that all record menus or career decisions are complete. Remote rankings and network behavior are unchanged.

## Verification

`verify_record_core.py` passes 1,429 cases per ABI, 2,858 total, at nonzero A64 and Thumb load biases. Tests execute the compiled payload through all three patched original entries, verify the exact original comparator and absolute-value methods, check thresholds beyond the old field widths, preserve fallback arguments and callee-saved registers, reject nonowned record identities, and compare the entire active save/roster/state before and after policy queries.

Candidate 4 also passes the existing payload/rotation tests (50), relocation checks (48 checks/208 native calls), personal-record font cases (208), six-page navigation tests, live player-info cases (280) and career ability UI cases (80). See the corresponding verification JSON and `verify_*_candidate4.log` files for their scope. These are instruction-level tests with documented game-service callbacks, not a complete Android game emulator.

Actual ARMv7 Android testing previously established candidate 2 startup, preserved signer acceptance, the modified title/menu and custom art. At candidate 4 freeze, player creation remained blocked by the original network error dialog. No full two-way match, completed perfect game or save/reload cycle is claimed from these tests. A64 has no successful Android app runtime verification in this environment.
