"""Run the actual compiled wallet UI wrappers at nonzero ASLR on both ABIs.

Cocos font/string boundaries are mocked explicitly. Every original layout,
popup color/font argument, finite fallback and untouched price call is checked.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks
import wallet_policy
from wallet_ui_policy import stage_payload,HOOKS,BINDINGS,FRAME,DIGITS,NUMBER,FONT,STYLE
from wallet_ui import add_wallet_ui_hooks
from verify_honors import configure,invoke,original_plt
from verify_relocation import BAT
from verify_gameplay_hooks import ROOT,HEAP,MGR,SP,STOP
from unicorn.arm64_const import UC_ARM64_REG_X29
from unicorn.arm_const import UC_ARM_REG_R7

WORK=Path(__file__).resolve().parent
OPTION=HEAP+0xb0000
BUFFER=HEAP+0xb2000
TEXT=HEAP+0xb4000
FORMAT=HEAP+0xb6000
COLOR=HEAP+0xb8000
RECT=HEAP+0xba000
UI=HEAP+0xbc000
INFINITY='\u221e'


def cstr(c,addr):
    data=bytearray()
    for i in range(2048):
        value=c.uc.mem_read(addr+i,1)[0]
        if not value:return bytes(data)
        data.append(value)
    raise AssertionError('Unterminated test string')


def verify(abi,source_dir):
    original=(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes()
    b=PatchBuilder(abi,original);add_gameplay_hooks(b)
    old_root=payload_builder.ROOT
    old_hooks,old_bindings=dict(payload_builder.HOOKS),dict(payload_builder.BINDINGS)
    payload_builder.ROOT=source_dir
    payload_builder.HOOKS.update(wallet_policy.HOOKS);payload_builder.HOOKS.update(HOOKS)
    payload_builder.BINDINGS.update(wallet_policy.BINDINGS);payload_builder.BINDINGS.update(BINDINGS)
    try:payload=payload_builder.add_payload(b,workdir=WORK/'wallet_ui_build'/abi)
    finally:
        payload_builder.ROOT=old_root
        payload_builder.HOOKS.clear();payload_builder.HOOKS.update(old_hooks)
        payload_builder.BINDINGS.clear();payload_builder.BINDINGS.update(old_bindings)
    symbols=payload['symbols'];sites=add_wallet_ui_hooks(b,symbols)
    slide=0x7d87654000 if b.is64 else 0xa8765000
    counts=dict(frame_entry=0,digits_font=0,popup_font=0,finite_fallback=0,
                event_format=0,unchanged_price_calls=0,buffer_lifecycle=0)
    # Exact complete/destruct-in-place alias: the deleting D0 variant must not
    # be called for the temporary stack buffer.
    dyn=b.elf.get_section_by_name('.dynsym')
    complete=next(s['st_value']&~int(not b.is64) for s in dyn.iter_symbols() if s.name=='_ZN15CBBStringBufferD2Ev')
    assert b.sym(BINDINGS['wallet_ui_string_destroy'])==complete

    def setup(available=True,mode=4,wrong_actor=False):
        c,_,_=configure(b,slide,mode,payload);original_plt(c)
        c.ptr(MGR+(0x518 if b.is64 else 0x4e0),OPTION if available else 0)
        if wrong_actor:c.uc.mem_write(BAT,struct.pack('<H',999))
        c.uc.mem_write(OPTION,b'\x39'*0x300)
        c.uc.mem_write(COLOR,bytes([11,101,201,231]))
        c.uc.mem_write(RECT,struct.pack('<4f',3.0,5.0,121.0,23.0))
        c.uc.mem_write(TEXT,INFINITY.encode()+b'\0')
        return c

    def args_at(c,count,widths=None):
        sp=c.uc.reg_read(c.sp)
        values=tuple(c.r(i) if i<(8 if b.is64 else 4) else
                     struct.unpack('<Q' if b.is64 else '<I',c.uc.mem_read(sp+(i-(8 if b.is64 else 4))*(8 if b.is64 else 4),8 if b.is64 else 4))[0]
                     for i in range(count))
        # AAPCS64 stack argument slots are eight bytes wide, but only the
        # declared scalar width is meaningful (bool stores use STRB).
        return tuple(value & ((1<<widths[i])-1) if widths and widths[i] else value
                     for i,value in enumerate(values))

    def start(c,site,args,shift=0):
        sp=SP+shift;c.stopped=None;c.stops={site+4+slide}
        c.uc.reg_write(c.sp,sp);c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1)
        for i,value in enumerate(args):
            if i<(8 if b.is64 else 4):c.r(i,value)
            else:c.uc.mem_write(sp+(i-(8 if b.is64 else 4))*(8 if b.is64 else 4),struct.pack('<Q' if b.is64 else '<I',value))
        c.run_relative(site)
        assert c.uc.reg_read(c.sp)==sp and c.stopped==site+4+slide

    scopes=((True,0,False),(True,3,False),(True,4,False),
            (False,4,False),(True,2,False),(True,4,True))
    for available,mode,wrong_actor in scopes:
        enabled=available and mode in (0,3,4) and not wrong_actor
        for kind in (0,1,2,-1):
            for single in (0,1):
                c=setup(available,mode,wrong_actor);seen=[]
                args=(UI,kind&0xffffffff,77,5,0x12345678,single)
                target=payload['original_bindings']['original_wallet_frame_numbers']+slide
                def original_frame():
                    got=args_at(c,6,(0,32,32,32,32,8))
                    assert got[:5]==args[:5]
                    assert got[5]==(1 if enabled and kind in (0,1) else single)
                    seen.append(1);c.ret(0)
                c.callbacks[target]=original_frame
                # Invoke with genuine stack arguments on Thumb.
                c.stopped=None;c.stops={STOP};c.uc.reg_write(c.sp,SP);c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1)
                for i,value in enumerate(args):
                    if i<(8 if b.is64 else 4):c.r(i,value)
                    else:c.uc.mem_write(SP+(i-4)*4,struct.pack('<I',value))
                c.run_relative(b.sym(FRAME))
                assert c.stopped==STOP and c.uc.reg_read(c.sp)==SP and seen==[1]
                counts['frame_entry']+=1

    for site in sites:
        if site['style']=='event':continue
        for available,mode,wrong_actor in scopes:
            enabled=available and mode in (0,3,4) and not wrong_actor
            for kind in ((0,1,2) if site['kind']=='header' else ((0,1) if site['kind']=='popup' else (site['kind'],))):
                for shift in ((0,) if b.is64 else (0,4)):
                    c=setup(available,mode,wrong_actor);sp=SP+shift;frame=sp+0x700
                    c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7,frame)
                    if site['kind']=='header':
                        c.uc.mem_write(frame-0x7c if b.is64 else sp+0xc0,struct.pack('<i',kind))
                    elif site['kind']=='popup':
                        c.ptr(sp+(0xa8 if b.is64 else 0x78),UI)
                        c.uc.mem_write(UI+(0x248 if b.is64 else 0x238),bytes([1-kind]))
                    digits=site['style']=='digits'
                    args=(UI,777,23,0x1234abcd,RECT,111,222,0,0x24,1,0,1,0,173) if digits else (777,21,COLOR,23,0x1234abcd,RECT,0x24,111,222,1,0)
                    lifecycle=[];styled=[];fitted=[];fallback=[]
                    def init():
                        assert cstr(c,c.r(1))==b''
                        assert c.uc.reg_read(c.sp)%4==0
                        lifecycle.append(('init',c.r(0)));c.ret(0)
                    def style():
                        got=args_at(c,8,(0,0,32,32,16,16,16,16))
                        assert lifecycle==[('init',got[0])]
                        assert cstr(c,got[1]).decode()==INFINITY
                        rgb=(255,202,52) if kind==0 else (114,237,255)
                        expected=(1,18,*rgb,173) if digits else (1,21,11,101,201,231)
                        assert got[2:]==expected,(abi,site['label'],got,expected)
                        styled.append(got);c.ret(0)
                    def string_get():
                        assert c.r(0)==lifecycle[0][1];c.ret(TEXT)
                    def fit():
                        got=args_at(c,10,(0,32,32,0,32,32,32,8,8,8))
                        assert got==(TEXT,23,0x1234abcd,RECT,0x24,111,222,1,0,1),(abi,site['label'],got)
                        fitted.append(got);c.ret(0)
                    def destroy():
                        assert c.r(0)==lifecycle[0][1]
                        lifecycle.append(('destroy',c.r(0)));c.ret(0)
                    def original_number():
                        widths=(0,32,32,32,0,32,32,32,32,8,8,8,8,32) if digits else (32,32,0,32,32,0,32,32,32,8,8)
                        got=args_at(c,len(args),widths);assert got==args,(abi,site['label'],got,args)
                        fallback.append(got);c.ret(0)
                    for name,callback in [('wallet_ui_string_init',init),('wallet_ui_change_font',style),
                                          ('wallet_ui_string_get',string_get),('wallet_ui_fit_font',fit),
                                          ('wallet_ui_string_destroy',destroy)]:
                        c.callbacks[b.sym(BINDINGS[name])+slide]=callback
                    c.callbacks[b.sym(DIGITS if digits else NUMBER)+slide]=original_number
                    before_option=bytes(c.uc.mem_read(OPTION,0x300))
                    start(c,site['site'],args,shift)
                    assert bytes(c.uc.mem_read(OPTION,0x300))==before_option
                    if enabled and kind in (0,1):
                        assert len(lifecycle)==2 and len(styled)==1 and len(fitted)==1 and not fallback
                        counts['buffer_lifecycle']+=1
                        counts['digits_font' if digits else 'popup_font']+=1
                    else:
                        assert fallback==[args] and not lifecycle and not styled and not fitted
                        counts['finite_fallback']+=1

    event=next(site for site in sites if site['style']=='event')
    for available,mode,wrong_actor in scopes:
        enabled=available and mode in (0,3,4) and not wrong_actor
        for fmt in ('%d','보유 G: %d','Balance: %d G','G %d / 100%%','%08d'):
            c=setup(available,mode,wrong_actor);c.uc.mem_write(FORMAT,fmt.encode()+b'\0')
            def sprint():
                format_=cstr(c,c.r(1)).decode();value=c.r(2)
                if '%s' in format_:value=cstr(c,value).decode()
                output=(format_%value).encode();c.uc.mem_write(c.r(0),output+b'\0');c.ret(len(output))
            c.callbacks[b.sym('MC_knlSprintk')+slide]=sprint
            start(c,event['site'],(BUFFER,FORMAT,789))
            expected=fmt.replace('%d','%s')%INFINITY if enabled and '%d' in fmt else fmt%789
            assert cstr(c,BUFFER).decode()==expected
            counts['event_format']+=1

    # These bytes are exactly the original price/description rendering calls.
    price_sites=(0x4041a8,) if b.is64 else (0x27b3dc,)
    # Verify the precise A64 site. The Thumb price instruction is discovered
    # from its original function's GetChangeFont call, not guessed here.
    if not b.is64:
        function=b.symbols['CBBGCcPopup::AddBuyPopup()'];start_addr=function['address']
        calls=[]
        for ins in b.cs.disasm(original[b.offset(start_addr):b.offset(start_addr)+function['size']],start_addr):
            if ins.mnemonic in ('bl','blx') and ins.op_str=='#0x4724d0':calls.append(ins.address)
        assert calls
        price_sites=tuple(calls)
    for address in price_sites:
        offset=b.offset(address);assert bytes(b.image[offset:offset+4])==original[offset:offset+4]
        counts['unchanged_price_calls']+=1
    assert not any(p['address'] in (0x595094,0x5950d0,0x384978,0x3849b6) for p in b.patches)
    return dict(abi=abi,load_bias=hex(slide),passed=sum(counts.values()),checks=counts,
                added_entry_hooks=1,added_display_sites=5,shared_formatter_modified=False,
                original_prices_unchanged=True,android_runtime_verified=False)


if __name__=='__main__':
    base=WORK/'wallet_ui_build'/'wallet-source'
    source=WORK/'wallet_ui_build'/'source'
    core=wallet_policy.stage_payload(base)
    staged=stage_payload(source,base)
    results=[verify(abi,source) for abi in ('arm64-v8a','armeabi-v7a')]
    report=dict(status='pass',base_c_sha256=core['base_c_sha256'],
                wallet_c_sha256=core['staged_c_sha256'],staged_c_sha256=staged['staged_c_sha256'],
                total_checks=sum(x['passed'] for x in results),abis=results,
                android_runtime_verified=False,
                source_files={name:hashlib.sha256((WORK/name).read_bytes()).hexdigest() for name in
                  ('wallet_ui_payload.inc','wallet_ui_policy.py','wallet_ui.py','verify_wallet_ui.py')})
    (WORK/'wallet_ui_verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
