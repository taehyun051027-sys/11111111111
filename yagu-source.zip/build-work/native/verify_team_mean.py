"""Derived mean, exact local caller, original quests and two original UI cells."""
import hashlib,json,struct
from pathlib import Path
import unicorn.arm64_const as a64
import unicorn.arm_const as arm
from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks,GETMODE,GETMGR
from team_mean_policy import stage_payload,BINDINGS
from team_mean_hooks import add_team_mean_hooks,FONT,NUMBER
from verify_honors import configure,invoke
from verify_original_plt_cache import original_plt
from verify_relocation import BAT,PIT,TEAM,TEAMS,MODE
from verify_gameplay_hooks import ROOT,HEAP,MGR,SP,STOP

WORK=Path(__file__).resolve().parent
OTHER=HEAP+0xb0000;BUFFER=HEAP+0xb1000;FORMAT=HEAP+0xb2000;RECT=HEAP+0xb3000
OPTEAM=TEAMS+8+5*0x3b4
SCOPES=('valid','opponent','detached','missing_save','missing_teams','missing_manager','noncareer','missing_my','empty','bad_count','bad_team')


def verify(abi,source):
 b=PatchBuilder(abi,(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes());add_gameplay_hooks(b)
 oldroot=payload_builder.ROOT;oldbindings=dict(payload_builder.BINDINGS)
 payload_builder.ROOT=source;payload_builder.BINDINGS.update(BINDINGS)
 try:payload=payload_builder.add_payload(b,workdir=WORK/'team_mean_build'/abi)
 finally:payload_builder.ROOT=oldroot;payload_builder.BINDINGS.clear();payload_builder.BINDINGS.update(oldbindings)
 symbols=payload['symbols'];sites=add_team_mean_hooks(b,symbols)
 slide=0x7f65432000 if b.is64 else 0xb7543000
 count=dict(state=0,local_adapter=0,original_finite_mean=0,quest_decisions=0,ui_header=0,ui_menu=0,preserved_functions=0)

 def setup(mode,scope='valid'):
  c,_,_=configure(b,slide,mode,payload);original_plt(c)
  c.uc.mem_write(OPTEAM,bytes([5,0,2,3]));c.uc.mem_write(OTHER,bytes([7,0,2,3]))
  for t in (TEAM,OPTEAM,OTHER):
   for role,n,stride,start in ((0,t==TEAM and 12 or 3,44,0x1a4),(1,t==TEAM and 8 or 2,52,4)):
    for i in range(n):c.uc.mem_write(t+start+i*stride+0x16,bytes([11+i+role*30]))
  team=TEAM;index=4;dm=MGR
  if scope=='opponent':team=OPTEAM;index=5
  elif scope=='detached':team=OTHER
  elif scope=='missing_save':c.ptr(MGR+((0x520 if mode==3 else 0x528)if b.is64 else(0x4e4 if mode==3 else 0x4e8)),0)
  elif scope=='missing_teams':c.ptr(MGR+(0x530 if b.is64 else 0x4ec),0)
  elif scope=='missing_manager':c.callbacks[b.sym(GETMGR)+slide]=lambda:c.ret(0)
  elif scope=='noncareer':c.callbacks[b.sym(GETMODE)+slide]=lambda:c.ret(1)
  elif scope=='missing_my':c.uc.mem_write(BAT,struct.pack('<H',9));c.uc.mem_write(PIT,struct.pack('<H',8))
  elif scope=='empty':c.uc.mem_write(TEAM+2,b'\0\0')
  elif scope=='bad_count':c.uc.mem_write(TEAM+3,b'\x0d')
  elif scope=='bad_team':c.uc.mem_write(TEAMS+4,struct.pack('<I',15))
  c.uc.mem_write(FORMAT,b'%d\0');c.uc.mem_write(BUFFER-8,b'\xaa'*48)
  return c,team,index,dm

 for mode in(3,4):
  for scope in SCOPES:
   c,team,index,dm=setup(mode,scope)
   for include in(0,1,2,-1):
    state=invoke(c,symbols['yagu_team_mean_state'],team,include)
    active=scope=='valid'and include==1
    assert bool(state)==active
    if state:assert struct.unpack('<QII',c.uc.mem_read(state,16))==(0,1,0)
    count['state']+=1
   # Exact local-call scope needs the actual requested team pointer. A detached
   # query is not the source of any original menu; index alone resolves TEAM.
   if scope!='detached':
    text=invoke(c,symbols['yagu_team_mean_text'],dm,index)
    assert bool(text)==(scope=='valid')
    count['state']+=1
   c,team,index,dm=setup(mode,scope);seen=[]
   c.callbacks[b.sym(BINDINGS['original_team_mean'])+slide]=lambda:(seen.append((c.r(0),c.r(1))),c.ret(37))
   for include in(0,1):
    before=bytes(c.uc.mem_read(TEAM,0x3b4));got=invoke(c,symbols['yagu_team_mean'],team,include)
    active=scope=='valid'and include==1
    assert got==(250 if active else 37)
    assert seen==([]if active else[(team,include)])
    assert bytes(c.uc.mem_read(TEAM,0x3b4))==before
    seen.clear();count['local_adapter']+=1

 # Original GetTeamLevel's exact finite arithmetic and explicit My exclusion.
 # Individual level and IsRaise leaves are supplied as independent input data;
 # their existing player/elite policy has its own regression suite.
 for mode in(3,4):
  c,team,_,_=setup(mode)
  c.callbacks[b.sym('CBBGPlayerData::GetLevel()')+slide]=lambda:c.ret(c.uc.mem_read(c.r(0)+0x16,1)[0])
  c.callbacks[b.sym('CBBGPlayerData::IsRaise()')+slide]=lambda:c.ret(c.r(0)in(BAT,PIT))
  for team in(TEAM,OPTEAM,OTHER):
   for include in(0,1):
    levels=[]
    for role,start,stride in((0,0x1a4,44),(1,4,52)):
     for i in range(c.uc.mem_read(team+(2 if role else 3),1)[0]):
      actor=team+start+i*stride
      if include or actor not in(BAT,PIT):levels.append(c.uc.mem_read(actor+0x16,1)[0])
    got=invoke(c,b.sym(BINDINGS['original_team_mean']),team,include)
    assert got==sum(levels)//len(levels);count['original_finite_mean']+=1

 # Real local DataMgr path calls the new adapter; service lookup supplies the
 # selected original roster. Opponent path still executes finite averaging.
 for mode in(3,4):
  for index,team in((4,TEAM),(5,OPTEAM)):
   c,_,_,_=setup(mode)
   c.callbacks[b.sym('CBBGDataMgr::GetRaiseTeam(eTeamIndex)')+slide]=lambda:c.ret(team)
   c.callbacks[b.sym('CBBGPlayerData::GetLevel()')+slide]=lambda:c.ret(37)
   got=invoke(c,b.sym('CBBGDataMgr::GetTeamLv(int)'),MGR,index)
   assert got==(250 if index==4 else 37);count['local_adapter']+=1

 flags=a64.UC_ARM64_REG_NZCV if b.is64 else arm.UC_ARM_REG_APSR
 vector=[getattr(a64 if b.is64 else arm,('UC_ARM64_REG_Q'if b.is64 else'UC_ARM_REG_D')+str(i))for i in range(32)]
 def snap(c):return([c.r(i)for i in range(len(c.regs))],c.uc.reg_read(c.lr),c.uc.reg_read(c.sp),c.uc.reg_read(flags)&0xf8000000,[c.uc.reg_read(v)for v in vector])
 def init(c,row,dm,lhs,rhs):
  for i in range(len(c.regs)):c.r(i,0x12340000+i)
  c.r(0,lhs&0xffffffff);c.r(8 if b.is64 else 1,rhs&0xffffffff)
  c.uc.reg_write(c.sp,SP);c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1);c.uc.reg_write(flags,0x58000000)
  for i,v in enumerate(vector):c.uc.reg_write(v,0xabcdef012345678+i)
  c.ptr(SP+row['dm_slot'],dm);c.stopped=None;c.stops={row['taken']+slide,row['fallthrough']+slide}
 for mode in(3,4):
  for row in(r for r in sites if r['kind']=='quest'):
   c,_,_,_=setup(mode);ref,_,_,_=setup(mode);ref.uc.mem_write(row['site']+slide,bytes.fromhex(row['expected']))
   for lhs,rhs in((0,1),(1,0),(250,250),(250,251),(0,0x7fffffff),(-1,0),(0x7fffffff,-1)):
    init(ref,row,OTHER,lhs,rhs);ref.run_relative(row['site']);expect=snap(ref)
    init(c,row,OTHER,lhs,rhs);c.run_relative(row['site']);assert snap(c)==expect and c.stopped==ref.stopped
    init(c,row,MGR,lhs,rhs);c.run_relative(row['site']);assert snap(c)==expect and c.stopped==row['fallthrough']+slide
    count['quest_decisions']+=2

 for mode in(3,4):
  for scope in SCOPES:
   if scope=='detached':continue
   for kind in('header','menu'):
    row=next(r for r in sites if r['kind']==kind)
    for shift in((0,)if b.is64 else(0,4)):
     c,team,index,dm=setup(mode,scope);stack=SP+shift
     c.ptr(stack+row['dm_slot'],dm);c.uc.mem_write(stack+row['index_slot'],struct.pack('<I',index))
     seen=[]
     if kind=='header':
      args=(BUFFER,FORMAT,250)
      for i,v in enumerate(args):c.r(i,v)
      def fallback():
       assert tuple(c.r(i)for i in range(3))==args
       seen.append('number');c.uc.mem_write(BUFFER,b'250\0');c.ret(3)
      c.callbacks[b.sym('MC_knlSprintk')+slide]=fallback
     else:
      args=(HEAP+0xc0000,250,3,0x4123497,RECT,400,240,0,34,1,0,1,0,255)
      for i,v in enumerate(args):
       if i<(8 if b.is64 else 4):c.r(i,v)
       else:c.uc.mem_write(stack+(i-(8 if b.is64 else 4))*(8 if b.is64 else 4),struct.pack('<Q'if b.is64 else'<I',v))
      def fallback():
       actual=tuple(c.r(i)if i<(8 if b.is64 else 4)else struct.unpack('<Q'if b.is64 else'<I',c.uc.mem_read(stack+(i-(8 if b.is64 else 4))*(8 if b.is64 else 4),8 if b.is64 else 4))[0]for i in range(14))
       assert actual==args;seen.append('number');c.ret(0)
      def font():
       text=bytes(c.uc.mem_read(c.r(0),4));assert text=='∞'.encode()+b'\0'
       sp=c.uc.reg_read(c.sp)
       actual=tuple(c.r(i)if i<(8 if b.is64 else 4)else struct.unpack('<I',c.uc.mem_read(sp+(i-(8 if b.is64 else 4))*(8 if b.is64 else 4),4))[0]for i in range(10))
       assert actual[1:]==(args[2],args[3],args[4],args[8],args[5],args[6],args[9],args[10],1),(abi,scope,actual,args)
       seen.append('font');c.ret(0)
      c.callbacks[b.sym(NUMBER)+slide]=fallback;c.callbacks[b.sym(FONT)+slide]=font
     c.uc.reg_write(c.sp,stack);c.stopped=None;c.stops={row['site']+4+slide};c.run_relative(row['site'])
     assert c.uc.reg_read(c.sp)==stack
     if kind=='header':assert bytes(c.uc.mem_read(BUFFER,4))==('∞'.encode()+b'\0'if scope=='valid'else b'250\0')
     else:assert seen==(['font']if scope=='valid'else['number'])
     count['ui_'+kind]+=1
 # Both direct network consumers, network-facing MyRaiseTeamLv and explicit
 # My-excluding strength check remain byte-for-byte original.
 for name in('CBBGTeamData::GetTeamLevel(bool)','CBBGDataMgr::GetMyRaiseTeamLv()',
             'CBBGMgrNetwork::API_BB2013_CS_STATISTICS_DATA()',
             'CBBGMgrNetwork::API_BB2013_CS_SECURITY_DATA()',
             'CBBGMgrNetwork::API_BB2013_CS_CONNECT_V2()',
             'CBBGStrengthAllPlayerUI::CheckStrengthAllPlayer()'):
  off=b.offset(b.sym(name));size=b.symbols[name]['size'];assert b.image[off:off+size]==b.original[off:off+size];count['preserved_functions']+=1
 final=b.finish(WORK/'team_mean_build'/abi/'libgameDSO.so')
 return dict(abi=abi,passed=sum(count.values()),counts=count,sites=sites,slide=hex(slide),
             source_c_sha256=hashlib.sha256((source/'yagu_payload.c').read_bytes()).hexdigest(),
             output_sha256=final['output_sha256'],android_runtime_verified=False)


if __name__=='__main__':
 source=WORK/'team_mean_build/source';stage=stage_payload(source)
 results=[verify(a,source)for a in('arm64-v8a','armeabi-v7a')]
 (WORK/'team_mean_verification.json').write_text(json.dumps(dict(stage=stage,results=results),indent=2)+'\n')
 print(json.dumps(results,indent=2))
