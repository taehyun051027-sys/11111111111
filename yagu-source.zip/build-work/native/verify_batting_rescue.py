"""Execute original contact-gate/event dispatch with the authored rescue.

This verifies input acceptance, original Swing/AtSwing calls, terminal-count
scope, one normal event0x6aa, and HBP scope. Complete scoring/animation is a
separate Android runtime gate; it is never fabricated by this test or patch.
"""
import hashlib
import json
import struct
import types
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import GETMODE, GETMGR, GETBAT, GETPIT
from special_uses_policy import BINDINGS as SPECIAL_BINDINGS, stage_payload as stage_special
from special_uses_hooks import add_special_uses_hooks
from batting_rescue_policy import BINDINGS, stage_payload, integrate_gameplay_source
from batting_rescue_hooks import add_batting_rescue_hook
from verify_honors import configure, invoke, original_plt, Original
from verify_award_record_ui import complete_ui_before_awards
from award_record_ui import add_award_record_ui_hooks
from verify_relocation import BAT, PIT, TEAM, TEAMS, MODE, SAVE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
from unicorn.arm64_const import UC_ARM64_REG_X29
from unicorn.arm_const import UC_ARM_REG_R7

WORK = Path(__file__).resolve().parent
GAME, BATOBJ, STAT, PLAY = (HEAP + n for n in (0xb0000, 0xb3000, 0xb4000, 0xb5000))
BATENTRY, PITENTRY = HEAP + 0xb6000, HEAP + 0xb7000
OTHER = HEAP + 0xb8000


def verify(abi, source_dir):
    raw = (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes()
    b = PatchBuilder(abi, raw)
    staged_gameplay = integrate_gameplay_source((WORK / 'gameplay_hooks.py').read_text())
    module = types.ModuleType('gameplay_hooks_rescue')
    module.__file__ = str(WORK / 'gameplay_hooks.py')
    exec(compile(staged_gameplay, module.__file__, 'exec'), module.__dict__)
    gameplay = module.add_gameplay_hooks(b)
    old_root, old_bindings = payload_builder.ROOT, dict(payload_builder.BINDINGS)
    payload_builder.ROOT = source_dir
    payload_builder.BINDINGS.update(SPECIAL_BINDINGS)
    payload_builder.BINDINGS.update(BINDINGS)
    try:
        payload = payload_builder.add_payload(b, workdir=WORK / 'batting_rescue_build' / abi)
    finally:
        payload_builder.ROOT = old_root
        payload_builder.BINDINGS.clear()
        payload_builder.BINDINGS.update(old_bindings)
    symbols = payload['symbols']
    complete_ui_before_awards(b, symbols)
    add_award_record_ui_hooks(b, symbols)
    add_special_uses_hooks(b, symbols)
    site = add_batting_rescue_hook(b, symbols)
    from signer_pin import add_signer_pin_patch
    add_signer_pin_patch(b, '0x6de25a17')
    assert len(b.patches) == 150
    slide = 0x7c76543000 if b.is64 else 0xab432000
    counts = dict(native_rescue_cases=0, scope_fallbacks=0, original_contact_paths=0,
                  original_event_dispatch=0, hbp_scope=0, original_code_preserved=0)
    once_offset, object_offset, stat_offset = (0x531, 0x4e0, 0x430) if b.is64 else (0x379, 0x334, 0x2d8)

    def setup(mode):
        c, _, _ = configure(b, slide, mode, payload)
        original_plt(c)
        c.callbacks[b.sym('CBBGStatic::IsBatMode()') + slide] = lambda: c.ret(mode == 4)
        c.ptr(GAME + (0x410 if b.is64 else 0x2c8), BATENTRY)
        c.ptr(GAME + (0x418 if b.is64 else 0x2cc), PITENTRY)
        c.ptr(GAME + object_offset, BATOBJ)
        c.ptr(GAME + stat_offset, STAT)
        c.ptr(STAT + (0x10 if b.is64 else 0xc), PLAY)
        c.uc.mem_write(BATENTRY + 0x25, b'\x04')
        c.uc.mem_write(PITENTRY + 0x25, b'\x05')
        c.callbacks[b.sym(GETBAT) + slide] = lambda: c.ret(BAT)
        c.callbacks[b.sym(GETPIT) + slide] = lambda: c.ret(OTHER)
        c.callbacks[b.sym('CBBGStatic::GetPlayData()') + slide] = lambda: c.ret(PLAY)
        c.callbacks[b.sym('CBBGGameRun::GetCurrentSwingPosition()') + slide] = lambda: c.ret(1)
        events = []
        def motion():
            assert c.r(0) == BATOBJ and c.r(1) == 3
            c.uc.mem_write(BATOBJ + 0x1c, struct.pack('<II', 3, 0))
            events.append(('motion', 3))
            c.ret(0)
        c.callbacks[b.sym('CBBGBatter::SetMotion(EnumBatterMotion)') + slide] = motion
        def game_point():
            assert c.r(0) == STAT
            events.append(('swing_stat', c.r(1)))
            c.ret(0)
        c.callbacks[b.sym('CBBGStatisticsMgr::PutOnGamePoint(int, int)') + slide] = game_point
        c.callbacks[b.sym('CBBGPlayData::IsBunt()') + slide] = lambda: c.ret(0)
        def send():
            events.append(('event', c.r(1), c.r(2), c.r(3)))
            c.ret(0)
        c.callbacks[b.sym('CBBEvt::SendEvent(int, int, void*)') + slide] = send
        c.callbacks[b.sym('CGsSingleton<CBBGSoundMgr>::GetInstPtr()') + slide] = lambda: c.ret(OTHER)
        c.callbacks[b.sym('CBBGSoundMgr::PlayEffect(int, bool)') + slide] = lambda: c.ret(0)
        c.callbacks[b.sym('CBBGGameRun_SoundMgr::GetInstPtr()') + slide] = lambda: c.ret(OTHER)
        c.callbacks[b.sym('CBBGGameRun_SoundMgr::Comment_SwingNMiss()') + slide] = lambda: c.ret(0)
        return c, events

    def reset(c, events, strikes=0, balls=0, manual=0, once=0):
        events.clear()
        c.uc.mem_write(BATOBJ, bytes(0x60))
        c.uc.mem_write(BATOBJ + 0x12, bytes([manual]))
        c.uc.mem_write(PLAY + 4, bytes([strikes, balls]))
        c.uc.mem_write(GAME + once_offset, bytes([once]))

    for mode in (3, 4):
        c, events = setup(mode)
        for frame, contact in ((-1, 10), (0, 10), (9, 10), (10, 10), (11, 10), (20, 10), (10, -1)):
            for strikes in (0, 1, 2):
                for balls in (0, 2, 3):
                    for manual in (0, 1):
                        for once in (0, 1):
                            reset(c, events, strikes, balls, manual, once)
                            before_save = bytes(c.uc.mem_read(SAVE, 0x800))
                            result = invoke(c, symbols['yagu_rescue_batting'], BATOBJ, GAME, frame, contact)
                            active = frame >= 0 and contact >= 0 and frame >= contact and not once
                            active = active and (manual or strikes == 2 or balls == 3)
                            assert result == (0 if active else 999), (abi, mode, frame, contact, strikes, balls, manual, once, result)
                            assert events == ([('motion', 3), ('swing_stat', 9)] if active and not manual else [])
                            assert c.uc.mem_read(GAME + once_offset, 1)[0] == once
                            assert bytes(c.uc.mem_read(SAVE, 0x800)) == before_save
                            counts['native_rescue_cases'] += 1

    for mode in (3, 4):
        for bad in ('opponent', 'other_actor', 'duplicate_id', 'absent_save', 'absent_teams',
                    'missing_batter', 'wrong_mode', 'null_game', 'wrong_object', 'missing_stats', 'missing_play'):
            c, events = setup(mode)
            reset(c, events, 2, 3)
            game = GAME
            if bad == 'opponent': c.uc.mem_write(BATENTRY + 0x25, b'\x05')
            if bad in ('other_actor', 'duplicate_id'):
                c.uc.mem_write(OTHER, struct.pack('<H', 1000 if bad == 'duplicate_id' else 5))
                c.callbacks[b.sym(GETBAT) + slide] = lambda: c.ret(OTHER)
            if bad == 'absent_save': c.ptr(MGR + ((0x520 if mode == 3 else 0x528) if b.is64 else (0x4e4 if mode == 3 else 0x4e8)), 0)
            if bad == 'absent_teams': c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
            if bad == 'missing_batter': c.uc.mem_write(BAT, b'\x11\x00')
            if bad == 'wrong_mode': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            if bad == 'null_game': game = 0
            if bad == 'wrong_object': c.ptr(GAME + object_offset, OTHER)
            if bad == 'missing_stats': c.ptr(GAME + stat_offset, 0)
            if bad == 'missing_play': c.callbacks[b.sym('CBBGStatic::GetPlayData()') + slide] = lambda: c.ret(0)
            result = invoke(c, symbols['yagu_rescue_batting'], BATOBJ, game, 10, 10)
            assert result == 999 and not events, (abi, mode, bad, result, events)
            counts['scope_fallbacks'] += 1

    # Execute the actual original gate through its existing SendEvent and once
    # write. Replaying it a second time must not enqueue another batting event.
    start, end = (0x38d8b4, 0x38da14) if b.is64 else (0x22e5fc, 0x22e6f2)
    for mode in (3, 4):
        for strikes, balls, manual, frame in ((0, 0, 0, 10), (2, 0, 0, 9), (2, 0, 0, 10),
                                               (0, 3, 0, 10), (0, 0, 1, 10), (2, 3, 0, 11)):
            c, events = setup(mode)
            reset(c, events, strikes, balls, manual)
            fp = SP + (0x130 if b.is64 else 0xe0)
            c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7, fp)
            c.ptr(SP + (0x38 if b.is64 else 0x24), GAME)
            if b.is64:
                c.uc.mem_write(fp - 0x80, struct.pack('<i', frame))
                c.uc.mem_write(fp - 0x84, struct.pack('<i', 10))
                c.uc.mem_write(fp - 0x88, b'\x00')
            else:
                c.uc.mem_write(SP + 0x84, struct.pack('<i', frame))
                c.uc.mem_write(SP + 0x80, struct.pack('<i', 10))
                c.uc.mem_write(fp - 0x61, b'\x00')
            c.r(8 if b.is64 else 0, GAME)
            active = frame >= 10 and (manual or strikes == 2 or balls == 3)
            for repeat in range(2):
                c.uc.reg_write(c.sp, SP)
                c.stopped = None
                c.stops = {end + slide}
                c.r(8 if b.is64 else 0, GAME)
                c.run_relative(start)
                assert c.stopped == end + slide and c.uc.reg_read(c.sp) == SP
                actual = [event for event in events if event[0] == 'event']
                assert actual == ([('event', 0x6aa, 0, 0)] if active else []), (abi, mode, repeat, events)
                assert c.uc.mem_read(GAME + once_offset, 1)[0] == active
                counts['original_contact_paths'] += 1

    # The original dispatcher consumes event0x6aa in its unchanged batting arm.
    original = Original(abi)
    branch_site = 0x393550 if b.is64 else 0x2321fc
    branch = next(original.cs.disasm(original.read(branch_site, 4), branch_site))
    assert branch.mnemonic in ('b.eq', 'beq.w')
    dispatch = int(branch.op_str[1:], 16)
    assert dispatch == (0x394278 if b.is64 else 0x232abc)
    for mode in (3, 4):
        c, _ = setup(mode)
        c.uc.reg_write(c.sp, SP)
        for i, value in enumerate((GAME, 0x6aa, 0, 0)): c.r(i, value)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        c.stopped = None
        c.stops = {dispatch + slide}
        c.run_relative(b.sym('CBBGGameRun::DoEvent(bbtagEvtData)'))
        assert c.stopped == dispatch + slide
        counts['original_event_dispatch'] += 1

    # HBP retains old pitcher protection and now protects exactly the own My
    # batter entry. A duplicate reserved RFID on an opponent remains ordinary.
    for mode in (1, 3, 4):
        for bid, bteam in ((1000, 4), (1000, 5), (7, 4)):
            for pid, pteam in ((1100, 4), (1100, 5), (8, 4)):
                c, _ = setup(mode if mode in (3, 4) else 4)
                c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(mode)
                c.uc.mem_write(BAT, struct.pack('<H', bid))
                c.uc.mem_write(OTHER, struct.pack('<H', pid))
                c.uc.mem_write(BATENTRY + 0x25, bytes([bteam]))
                c.uc.mem_write(PITENTRY + 0x25, bytes([pteam]))
                trampoline = c.original('CBBGGameRun::IsHitByPitcher()')
                c.callbacks[trampoline + slide] = lambda: c.ret(77)
                result = invoke(c, b.sym('CBBGGameRun::IsHitByPitcher()'), GAME)
                protected = mode in (3, 4) and ((bid == 1000 and bteam == 4) or (pid == 1100 and pteam == 4))
                assert result == (0 if protected else 77)
                counts['hbp_scope'] += 1
    for name in ('CBBGGameRun::DoEvent(bbtagEvtData)', 'CBBGBatter::Swing(int)',
                 'CBBGStatisticsMgr::AtSwing()', 'CBBGPlayData::GetStrike()', 'CBBGPlayData::GetBall()'):
        item = original.functions[name]
        offset = b.offset(item['address'])
        assert b.image[offset:offset + item['size']] == original.read(item['address'], item['size'])
        counts['original_code_preserved'] += 1
    result = b.finish(WORK / 'batting_rescue_build' / abi / 'libgameDSO.so')
    return dict(abi=abi, slide=hex(slide), counts=counts, asserted_cases=sum(counts.values()),
                patch_count=len(b.patches), output_sha256=result['output_sha256'],
                site=site, original_dispatch_target=hex(dispatch), android_runtime_verified=False)


if __name__ == '__main__':
    stage_special(WORK / 'batting_rescue_build/super_source')
    stage = stage_payload(WORK / 'batting_rescue_build/source', WORK / 'batting_rescue_build/super_source')
    results = [verify(abi, WORK / 'batting_rescue_build/source') for abi in ('arm64-v8a', 'armeabi-v7a')]
    report = dict(stage=stage, results=results, total_cases=sum(row['asserted_cases'] for row in results),
                  original_swing_and_event_path=True, no_score_out_or_record_write=True,
                  android_runtime_verified=False)
    (WORK / 'batting_rescue_verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
