"""Execute the compiled local wallet and exact purchase hooks on both ARM ABIs.

The Option getters execute as original code. Shop/UI/save boundaries are
explicitly recorded; Android purchase verification is a separate requirement.
Original account serializers, receipt/billing code and Option entries must be
byte identical. Tests use relocated code with address zero unmapped.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks, GETMODE
from wallet_policy import stage_payload, BINDINGS, HOOKS
from wallet_hooks import add_wallet_hooks, METHODS, ASYNC, RANGES
from verify_honors import configure, original_plt
from verify_award_record_ui import complete_ui_before_awards
from award_record_ui import add_award_record_ui_hooks
from special_uses_hooks import add_special_uses_hooks
from batting_rescue_hooks import add_batting_rescue_hook
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
from verify_relocation import BAT, PIT, SAVE, MODE

WORK = Path(__file__).resolve().parent
OPTION, FOREIGN, UI, MAP = (HEAP + n for n in (0x61000, 0x62000, 0x63000, 0x64000))


def args(c, count):
    nreg = 8 if c.is64 else 4
    return tuple(c.r(i) if i < nreg else struct.unpack('<I', c.uc.mem_read(c.uc.reg_read(c.sp)+(i-4)*4, 4))[0] for i in range(count))


def invoke(c, address, *values, stops=None):
    c.stopped = None
    c.stops = {STOP} if stops is None else stops
    c.uc.reg_write(c.sp, SP)
    c.uc.reg_write(c.lr, STOP if c.is64 else STOP | 1)
    saved = {i: c.r(i) for i in (range(19, 30) if c.is64 else range(4, 12))}
    mask = (1 << (64 if c.is64 else 32)) - 1
    for i, value in enumerate(values):
        if i < (8 if c.is64 else 4): c.r(i, value & mask)
        else: c.uc.mem_write(SP+(i-4)*4, struct.pack('<I', value & 0xffffffff))
    c.run_relative(address)
    assert c.stopped in c.stops and c.uc.reg_read(c.sp) == SP
    assert all(c.r(i) == value for i, value in saved.items())
    return c.r(0)


def verify(abi, stage):
    b = PatchBuilder(abi, (ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    saved_root, saved_bindings, saved_hooks = payload_builder.ROOT, dict(payload_builder.BINDINGS), dict(payload_builder.HOOKS)
    payload_builder.ROOT = stage
    payload_builder.BINDINGS.update(BINDINGS)
    payload_builder.HOOKS.update(HOOKS)
    try: payload = payload_builder.add_payload(b, workdir=WORK/'wallet_build'/abi)
    finally:
        payload_builder.ROOT = saved_root
        payload_builder.BINDINGS.clear(); payload_builder.BINDINGS.update(saved_bindings)
        payload_builder.HOOKS.clear(); payload_builder.HOOKS.update(saved_hooks)
    s, bind = payload['symbols'], payload['original_bindings']
    complete_ui_before_awards(b, s)
    add_award_record_ui_hooks(b, s)
    add_special_uses_hooks(b, s)
    if 'yagu_equipment_player_text' in s:
        from equipment_level_ui import add_equipment_level_ui_hooks
        add_equipment_level_ui_hooks(b,s)
    add_batting_rescue_hook(b, s)
    sites = add_wallet_hooks(b, s)
    assert len(sites) == 85
    from signer_pin import add_signer_pin_patch
    add_signer_pin_patch(b, '0x6de25a17')
    slide = 0x7c65432000 if b.is64 else 0xa8432000
    counts = dict(scalar=0, unlimited_cost=0, repeated_use=0, exact_hooks=0,
                  finite_original=0, fallback_abi=0, shops=0, local_actions=0,
                  original_transitions=0, typed_bounds=0, untouched=0)

    def setup(mode=4):
        c, _, _ = configure(b, slide, mode, payload)
        original_plt(c)
        c.ptr(MGR + (0x518 if b.is64 else 0x4e0), OPTION)
        c.callbacks[b.sym('CBBGStatic::IsBatMode()')+slide] = lambda: c.ret(mode == 4)
        for base in (OPTION, FOREIGN):
            c.uc.mem_write(base, bytes(0x400))
            c.uc.mem_write(base+0xa8, struct.pack('<i', 173))
            c.uc.mem_write(base+0x150, struct.pack('<i', 29))
        return c

    for mode in (0, 3, 4):
        c = setup(mode)
        state = invoke(c, s['yagu_wallet_state'], OPTION)
        assert state and struct.unpack('<II', c.uc.mem_read(state, 8)) == (1, 0)
        for kind in (0, 1):
            ptr = invoke(c, s['yagu_wallet_scalar'], OPTION, kind)
            assert ptr == state + 8 + 16*kind
            assert struct.unpack('<QII', c.uc.mem_read(ptr, 16)) == (0, 1, 0)
            text = invoke(c, s['yagu_wallet_text'], kind)
            assert bytes(c.uc.mem_read(text, 4)) == '\u221e'.encode() + b'\0'
            counts['scalar'] += 1
            for cost in (0, 1, 200000, 9999999, 10000000, 2**31-1, 2**32, 2**63, 2**64-1):
                values = (OPTION, kind, cost) if b.is64 else (OPTION, kind, cost & 0xffffffff, cost >> 32)
                assert invoke(c, s['yagu_wallet_can_spend'], *values) == 1
                counts['unlimited_cost'] += 1
        before = bytes(c.uc.mem_read(OPTION, 0x400))
        for repeat in range(24):
            for delta in (-2147483648, -9999999, -200000, -1, 0, 1, 2147483647):
                invoke(c, s['yagu_wallet_add_g'], OPTION, delta, 1)
                invoke(c, s['yagu_wallet_add_star'], OPTION, delta, repeat % 2, 11, 22, 33, 44)
                assert bytes(c.uc.mem_read(OPTION, 0x400)) == before
                assert invoke(c, s['yagu_wallet_get_g'], OPTION) == 9999999
                assert invoke(c, s['yagu_wallet_get_star'], OPTION) == 200000
                counts['repeated_use'] += 1
        for pointer in (0, FOREIGN, OPTION+4):
            assert invoke(c, s['yagu_wallet_state'], pointer) == 0
            counts['scalar'] += 1
        assert invoke(c, s['yagu_wallet_scalar'], OPTION, -1) == 0
        assert invoke(c, s['yagu_wallet_scalar'], OPTION, 2) == 0
        counts['scalar'] += 2
    print(abi, 'typed wallet and repeated spending passed', flush=True)
    for mode in (1, 2, 5, -1):
        c = setup(mode)
        assert invoke(c,s['yagu_wallet_state'],OPTION) == 0
        assert invoke(c,s['yagu_wallet_get_g'],OPTION) == 173
        assert invoke(c,s['yagu_wallet_get_star'],OPTION) == 29
        counts['scalar'] += 3
    for mode in (3, 4):
        c = setup(mode)
        c.uc.mem_write(PIT if mode == 3 else BAT, b'\x01\0')
        assert invoke(c,s['yagu_wallet_state'],OPTION) == 0
        assert invoke(c,s['yagu_wallet_get_g'],OPTION) == 173
        counts['scalar'] += 2

    for mode in (1, 3, 4):
        for alias, name in HOOKS.items():
            for owned in (False, True):
                c = setup(mode)
                if not owned: c.uc.mem_write(PIT if mode == 3 else BAT, b'\x01\0')
                seen = []
                shop = alias.removeprefix('wallet_').removesuffix('_connect')
                def buy(shop=shop): seen.append(('buy', shop, c.r(0))); c.ret(0)
                def fallback(alias=alias): seen.append(('original', alias, args(c, 2 if shop == 'bundle' else 1))); c.ret(73)
                c.callbacks[bind['wallet_'+shop+'_buy']+slide] = buy
                c.callbacks[bind['original_'+alias]+slide] = fallback
                invoke(c, b.sym(name), UI, 3)
                expected = mode in (3, 4) and owned
                assert len(seen) == 1 and seen[0][0] == ('buy' if expected else 'original'), (abi, mode, alias, owned, seen)
                assert seen[0][-1] == UI if expected else seen[0][-1] == ((UI, 3) if shop == 'bundle' else (UI,))
                counts['shops'] += 1
    print(abi, 'scoped local shop entries passed', flush=True)

    # Actual call sites keep all arguments, including stack-passed AddStar args.
    for row in sites:
        if row['site'] in ASYNC[b.abi] or row['site'] in RANGES[b.abi]: continue
        c = setup()
        target = METHODS[row['target']]
        arity = 1 if 'Get' in row['target'] else 3 if 'AddGPoint' in row['target'] else 7
        values = (OPTION, -1, 1, 11, 22, 33, 44)[:arity]
        before = bytes(c.uc.mem_read(OPTION, 0x400))
        result = invoke(c, row['hook'], *values)
        if 'GetGPoint' in row['target']: assert result == 9999999
        if 'GetStarPoint' in row['target']: assert result == 200000
        assert bytes(c.uc.mem_read(OPTION, 0x400)) == before
        counts['exact_hooks'] += 1
        original = bind[{'yagu_wallet_get_g':'wallet_original_get_g', 'yagu_wallet_get_star':'wallet_original_get_star',
                         'yagu_wallet_add_g':'wallet_original_add_g', 'yagu_wallet_add_star':'wallet_original_add_star'}[target]]
        seen = []
        def fallback(): seen.append(args(c, arity)); c.ret(79)
        c.callbacks[original+slide] = fallback
        values = (FOREIGN, 0xffffffff, 1, 11, 22, 33, 44)[:arity]
        assert invoke(c, row['hook'], *values) == 79
        assert seen == [values], (abi, row, seen, values)
        counts['fallback_abi'] += 1

    # All six asynchronous purchase routes are now local operations; failed
    # ownership still reaches the original AddStar call with untouched args.
    for row in sites:
        spec = ASYNC[b.abi].get(row['site'])
        if spec is None: continue
        kind, value, slot = spec
        for mode in (1, 3, 4):
            c = setup(mode)
            seen = []
            callbacks = {'wallet_worldmap_buy':1, 'wallet_lucky_buy':1, 'wallet_lucky_animate':1,
                         'wallet_camp_complete':1, 'wallet_set_skill_slots':2, 'wallet_skill_icon':4}
            for alias, arity in callbacks.items():
                def action(alias=alias, arity=arity): seen.append((alias, args(c, arity))); c.ret(0)
                c.callbacks[bind[alias]+slide] = action
            c.callbacks[bind['wallet_get_raise_mode']+slide] = lambda: c.ret(MODE)
            def fallback(): seen.append(('original', args(c, 7))); c.ret(0)
            c.callbacks[row['original']+slide] = fallback
            values = (OPTION, 0xffffffff, 1, 11, 22, 33, 44)
            if kind == 'action': c.ptr(SP+slot, UI)
            if mode == 1 or kind == 'action':
                invoke(c, row['hook'], *values)
                if mode == 1: assert seen == [('original', values)]
                else:
                    expected = [('wallet_worldmap_buy',(UI,))] if value == 0 else [('wallet_lucky_buy',(UI,)),('wallet_lucky_animate',(UI,))] if value == 1 else [('wallet_set_skill_slots',(MODE,2)),('wallet_skill_icon',(UI,1,3,0xffffffff)),('wallet_skill_icon',(UI,1,4,0xffffffff))] if value == 2 else [('wallet_camp_complete',(UI,))]
                    assert seen == expected, (abi, mode, spec, seen, expected)
                counts['local_actions'] += 1
            else:
                # Execute the original map darkness/command removal/state
                # transition after the exact confirmed training selection.
                c.ptr(SP+(0xd0 if b.is64 else 0x88), UI)
                c.ptr(UI+(0xf8 if b.is64 else 0xbc), MAP)
                methods = [('CBBGRaiseMapUI::SetMapDarkness(bool, int)',3),
                           ('CBBGRaiseMapUI::RemoveCommandUI()',1),('CBBState::ReserveState(int)',2)]
                for name, arity in methods:
                    def action(name=name, arity=arity): seen.append((name,args(c,arity))); c.ret(0)
                    c.callbacks[b.sym(name)+slide] = action
                exit_pc = (0x4982e0 if b.is64 else 0x2dc24e)+slide
                invoke(c, row['hook'], *values, stops={exit_pc})
                expected_state = 0x60 if row['site'] == (0x4975bc if b.is64 else 0x2db9b2) else 0x61
                assert seen == [(methods[0][0],(MAP,1,1)),(methods[1][0],(MAP,)),(methods[2][0],(UI+(0x68 if b.is64 else 0x48),expected_state))]
                counts['original_transitions'] += 1
    print(abi, 'exact calls and original local transitions passed', flush=True)

    for row in sites:
        spec = RANGES[b.abi].get(row['site'])
        if spec is None: continue
        low_slot, high_slot, yes, no = spec
        for lower in (-2147483648, -1, 0, 1, 10000000, 2147483647):
            for upper in (-2147483648, -1, 0, 1, 10000000, 2147483647):
                c = setup()
                c.uc.mem_write(SP+low_slot, struct.pack('<i', lower))
                c.uc.mem_write(SP+high_slot, struct.pack('<i', upper))
                invoke(c,row['hook'],OPTION,stops={yes+slide,no+slide})
                assert c.stopped == (yes if upper == 0 else no)+slide
                counts['typed_bounds'] += 1
        c = setup()
        assert invoke(c,row['hook'],FOREIGN) == 173
        counts['typed_bounds'] += 1

    c = setup()
    for name, field, cap in [('CBBGOption::GetGPoint()',0xa8,9999999),('CBBGOption::GetStarPoint()',0x150,200000)]:
        for value in (-1, 0, 1, 173, cap, cap+1, 2147483647):
            c.uc.mem_write(OPTION+field, struct.pack('<i',value))
            assert invoke(c,b.sym(name),OPTION) == min(cap,max(0,value))
            counts['finite_original'] += 1
    for name, fn in b.symbols.items():
        if name.startswith('CBBGMgrNetwork::') or name in METHODS or name in ('CBBGOption::SetGPoint(int)', 'CBBGOption::SetStarPoint(int)') or name.startswith(('Iab','gpg','Java_com_gamevil')):
            off = b.offset(fn['address'])
            assert bytes(b.image[off:off+fn['size']]) == b.original[off:off+fn['size']], name
            counts['untouched'] += 1
    result = b.finish(WORK/'wallet_build'/abi/'libgameDSO.so')
    return {'abi':abi,'source_c_sha256':hashlib.sha256((stage/'yagu_payload.c').read_bytes()).hexdigest(),
            'slide':hex(slide),'counts':counts,'case_count':sum(counts.values()),
            'patch_count':len(b.patches),'wallet_call_sites':len(sites),
            'output_sha256':result['output_sha256'],'android_purchase_verified':False}


if __name__ == '__main__':
    stage = WORK/'wallet_build'/'source'
    manifest = stage_payload(stage)
    reports = []
    for abi in ('arm64-v8a','armeabi-v7a'):
        report=verify(abi,stage); reports.append(report); print(json.dumps(report),flush=True)
    result={'stage':manifest,'abis':reports,'case_count':sum(r['case_count'] for r in reports),
            'limitations':['shop/UI service boundaries recorded, not Android rendering','no claim of infinite physical integer or server balance']}
    (WORK/'wallet_verification.json').write_text(json.dumps(result,indent=2)+'\n')
