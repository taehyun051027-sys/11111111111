"""Extend only the 12 observed defender color-path lookups.

The original path table has ten palettes. New palette IDs must never index
past that table. Common ball/shadow/slide entries remain on their original
lookup instructions and are not confused with palette extension indices.
"""
def verify_original_defender_lookups(b):
    """The black-uniform build retains the game's original palette-zero path.

    The old extended palette adapters remain available only to reproduce older
    checkpoints. Current builds must not patch these twelve source instructions.
    """
    if b.is64:
        sites = [0x520b44, 0x520b68, 0x520b8c, 0x520bb0, 0x520bd4, 0x520bf8,
                 0x520ec4, 0x520f24, 0x520f84, 0x520fe4, 0x521044, 0x5210a4]
        expected = bytes.fromhex('017969f8')
    else:
        sites = [0x3384a8, 0x3384c2, 0x3384dc, 0x3384f6, 0x338510, 0x33852a,
                 0x3386ae, 0x3386e4, 0x33871a, 0x338750, 0x338786, 0x3387bc]
        expected = bytes.fromhex('51f82210')
    for site in sites:
        offset = b.offset(site)
        if b.original[offset:offset + 4] != expected:
            raise ValueError('Unexpected original defender lookup at ' + hex(site))
        if b.image[offset:offset + 4] != expected:
            raise ValueError('Black-uniform build changed defender lookup at ' + hex(site))
    return {'original_lookup_sites': [hex(site) for site in sites],
            'original_bytes_preserved': True, 'palette': 0,
            'resource_family': 'defender/black'}

def add_defender_hooks(b, resolver):
    if b.is64:
        sites=[0x520b44,0x520b68,0x520b8c,0x520bb0,0x520bd4,0x520bf8,
               0x520ec4,0x520f24,0x520f84,0x520fe4,0x521044,0x5210a4]
        expected='017969f8'
        save='\n'.join(f'stp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0,18,2))
        restore='\n'.join(f'ldp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0,18,2))
        qsave='\n'.join(f'stp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0,32,2))
        qrestore='\n'.join(f'ldp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0,32,2))
    else:
        sites=[0x3384a8,0x3384c2,0x3384dc,0x3384f6,0x338510,0x33852a,
               0x3386ae,0x3386e4,0x33871a,0x338750,0x338786,0x3387bc]
        expected='51f82210'
    exports=[]
    for site in sites:
        if b.is64:
            source=f'''sub sp, sp, #704
{save}
stp x18, x30, [sp, #144]
mrs x8, nzcv
str x8, [sp, #160]
{qsave}
ldr x0, [sp, #64]
ldr x1, [sp, #72]
bl #{resolver}
str x0, [sp, #168]
{qrestore}
ldr x8, [sp, #160]
msr nzcv, x8
{restore}
ldp x18, x30, [sp, #144]
ldr x1, [sp, #168]
add sp, sp, #704
b #{site+4}'''
        else:
            source=f'''push.w {{r0-r3, r12, lr}}
sub sp, sp, #8
mrs r0, apsr
str r0, [sp]
vpush {{d0-d7}}
ldr r0, [sp, #76]
ldr r1, [sp, #80]
bl #{resolver}
str r0, [sp, #68]
vpop {{d0-d7}}
ldr r0, [sp]
msr APSR_nzcvq, r0
ldr r1, [sp, #4]
str r1, [sp, #12]
add sp, sp, #8
pop.w {{r0-r3, r12, lr}}
b.w #{site+4}'''
        hook=b.append_asm('Expanded defender palette path '+hex(site),source)
        b.patch(site,b.branch(site,hook),'Safe extended defender path lookup',expected)
        exports.append({'site':site,'hook':hook})
    return exports
