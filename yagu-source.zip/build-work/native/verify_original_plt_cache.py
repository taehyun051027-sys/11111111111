"""Cache only immutable ELF symbol/relocation metadata for native test fixtures.

Each fixture still has separate emulator memory, real original ARM instructions,
callbacks, TLS and stack canary. This is the same original_plt mapping used by
verify_honors, parsed once per unchanged PatchBuilder ELF rather than thousands
of times. It does not cache execution results or share mutable emulator state.
"""
from weakref import WeakKeyDictionary
from unicorn.arm64_const import UC_ARM64_REG_TPIDR_EL0
from verify_honors import TLS

_METADATA = WeakKeyDictionary()


def original_plt(c):
    b = c.b
    if b not in _METADATA:
        dyn = b.elf.get_section_by_name('.dynsym')
        defined = {s.name: s['st_value'] & ~int(not b.is64)
                   for s in dyn.iter_symbols() if s['st_value']}
        start = b.elf.get_section_by_name('.plt')['sh_addr']
        rels = b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
        routes = []
        for i, relocation in enumerate(rels.iter_relocations()):
            name = dyn.get_symbol(relocation['r_info_sym']).name
            if name in defined:
                routes.append((start + 32 + i * 16, defined[name]))
        guards = []
        if not b.is64:
            for relocation in b.elf.get_section_by_name('.rel.dyn').iter_relocations():
                if dyn.get_symbol(relocation['r_info_sym']).name == '__stack_chk_guard':
                    guards.append(relocation['r_offset'])
            assert len(guards) == 1
        _METADATA[b] = (routes, guards)
    routes, guards = _METADATA[b]
    for source, destination in routes:
        target = (destination + c.slide) | int(not b.is64)
        c.callbacks[source + c.slide] = lambda target=target: c.uc.reg_write(c.pc, target)
    if b.is64:
        c.uc.reg_write(UC_ARM64_REG_TPIDR_EL0, TLS)
    else:
        for offset in guards:
            c.ptr(c.slide + offset, TLS)
