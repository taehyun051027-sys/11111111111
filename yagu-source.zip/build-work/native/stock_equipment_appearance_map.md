# Stock black equipment selection

The equipment change selects files already present in the supplied APK. It adds
no native patch sites: the existing CcPlayerRes wrapper and the two existing
GameRun part-path adapters now select the observed stock resources. No PNG/PZC
is repainted or replaced, and no item ownership or ability field is written.

## Original equipment arguments

`CBBGCcPlayerRes::LoadResPlayerEquip(int,bool,int,int,bool)` is at A64 `0x4a4f98`
and Thumb `0x2e44c8`. Its `kind` argument has a different meaning for the two
roles. The original branches and filename literals were inspected directly.

| Kind | Batter appearance | Pitcher appearance |
|---|---|---|
| 0 | Helmet, stock level 0 | Hat, stock level 0 |
| 1 | Original bat item; palette 0 where applicable | Glove, stock level 0/color 0 |
| 2 | Shoes, stock level 7 | Original ball item, unchanged |
| 3 | Batting gloves, stock level 8 | Shoes, stock level 7 |

Selection applies to valid team indices 0–14, including Pumas. Invalid team or
equipment kinds use the original arguments. The original visibility/force flag,
resource receiver, team, role, and equipment kind are preserved.

## Live GameRun parts

| Role | Part indices | Selected stock paths |
|---|---|---|
| Batter | 8, 15 | `bat/level_8/batter_{left,right}_gloves.pzc` |
| Batter | 9, 17 | `bat/level_7/batter_{left,right}_shoe.pzc` |
| Pitcher | 2 | `pit/level_0/color_0/pitcher_gloves.pzc` |
| Pitcher | 9, 16 | `pit/level_7/pitcher_{right,left}_shoe.pzc` |

The 35 existing black garment paths plus these seven equipment paths make 42
stock PZC/PNG pairs. All are verified against the original APK. Other parts,
including face, hair, ball, and shadow, retain the original lookup.

The original level 8 batting gloves contain black leather and a gold wrist
trim. That trim remains; the change does not claim completely monochrome black
pixels for this stock item.

## Verification

The actual compiled adapters passed 6,408 menu argument/palette cases at nonzero
ARM64/Thumb load biases. These include 432 cases preserving the original
pitching ball selection. The actual two lookup hooks per ABI passed 2,052
team/part/scope cases, with original texture-maker argument, registers, flags,
stack, LR, and all SIMD/FP registers preserved. All 12 defender lookup
instructions per ABI remain byte-for-byte original.

These are native instruction and resource-existence checks. They stop before
the texture loader and do not establish full Android visual/gameplay success.
Per-file SHA256 values are in `stock_equipment_appearance_map.json`.
