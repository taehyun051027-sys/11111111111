"""Exercise substitution and original burst-mission branches at nonzero ASLR."""
from pathlib import Path
import hashlib,json,struct
from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks,GETMODE,GETMGR,GETBAT
from batter_presence_policy import stage_payload,HOOKS,BINDINGS
from batter_presence_hooks import add_batter_presence_hook
from verify_honors import configure
from verify_original_plt_cache import original_plt
from verify_wallet import invoke,args
from verify_relocation import BAT,PIT,SAVE,TEAM,TEAMS
from verify_gameplay_hooks import ROOT,HEAP,MGR,SP,STOP

WORK=Path(__file__).resolve().parent
ENTRY,GAME,MISSION,OTHER,LEVEL,RUNNERS,PLAY=(HEAP+n for n in (0xb0000,0xb1000,0xb3000,0xb4000,0xb5000,0xb6000,0xb7000))
SCOPES=('valid','opponent','other_batter','duplicate_id','entry_mode','other_mode',
        'missing_save','missing_teams','missing_manager','missing_actor','null_entry')

def verify(abi,source):
 b=PatchBuilder(abi,(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes());add_gameplay_hooks(b)
 oldroot=payload_builder.ROOT;oldhooks=dict(payload_builder.HOOKS);oldbindings=dict(payload_builder.BINDINGS)
 payload_builder.ROOT=source;payload_builder.HOOKS.update(HOOKS);payload_builder.BINDINGS.update(BINDINGS)
 try:payload=payload_builder.add_payload(b,workdir=WORK/'batter_presence_build'/abi)
 finally:
  payload_builder.ROOT=oldroot;payload_builder.HOOKS.clear();payload_builder.HOOKS.update(oldhooks)
  payload_builder.BINDINGS.clear();payload_builder.BINDINGS.update(oldbindings)
 symbols,bindings=payload['symbols'],payload['original_bindings'];site=add_batter_presence_hook(b,symbols)
 slide=0x7e23456000 if b.is64 else 0xac456000
 counts=dict(scope=0,owned_reservation=0,original_reservation=0,ai_abi=0,mission=0,original_mission_branches=0,
             original_current_batter_chain=0,original_chain_reservation=0)

 def setup(scope):
  c,_,_=configure(b,slide,4,payload);original_plt(c)
  c.uc.mem_write(ENTRY,bytes(0x300));c.uc.mem_write(ENTRY+0x24,b'\x04\x04')
  c.ptr(GAME+(0x410 if b.is64 else 0x2c8),ENTRY)
  c.uc.mem_write(MISSION+(0x5a if b.is64 else 0x42),b'\x01')
  c.callbacks[b.sym(GETBAT)+slide]=lambda:c.ret(BAT)
  if scope=='opponent':c.uc.mem_write(ENTRY+0x25,b'\x05')
  elif scope in ('other_batter','duplicate_id'):
   c.uc.mem_write(OTHER,struct.pack('<H',1000 if scope=='duplicate_id'else 5))
   c.callbacks[b.sym(GETBAT)+slide]=lambda:c.ret(OTHER)
  elif scope=='entry_mode':c.uc.mem_write(ENTRY+0x24,b'\x01')
  elif scope=='other_mode':c.callbacks[b.sym(GETMODE)+slide]=lambda:c.ret(1)
  elif scope=='missing_save':c.ptr(MGR+(0x528 if b.is64 else 0x4e8),0)
  elif scope=='missing_teams':c.ptr(MGR+(0x530 if b.is64 else 0x4ec),0)
  elif scope=='missing_manager':c.callbacks[b.sym(GETMGR)+slide]=lambda:c.ret(0)
  elif scope=='missing_actor':c.uc.mem_write(BAT,b'\x11\0')
  elif scope=='null_entry':c.ptr(GAME+(0x410 if b.is64 else 0x2c8),0)
  return c,0 if scope=='null_entry'else ENTRY

 # The chain below is intentionally not a roster-getter callback: execute
 # GetCurBatter -> EntryData::GetBatter -> GetTeamPtr -> GetRaiseTeam ->
 # TeamData::GetBatter using the actual entry bytes and active roster.
 # Every batting-order position and every possible My roster position is
 # checked, followed by finite teammates, an opponent with the reserved RFID,
 # and out-of-range roster indices handled by the original GetBatter bounds.
 chain_cases=[('owned',i)for i in range(12)]+[
     ('teammate',6),('opponent_reserved',5),('out_of_range',12),('out_of_range',255)]
 for kind,roster_index in chain_cases:
  for order in range(9):
   c,entry=setup('valid')
   c.callbacks.pop(b.sym(GETBAT)+slide)
   team=TEAM
   if kind=='owned':
    c.uc.mem_write(BAT,struct.pack('<H',901))
    actor=TEAM+0x1a4+44*roster_index
    c.uc.mem_write(actor,struct.pack('<H',1000))
   elif kind=='opponent_reserved':
    team=TEAMS+8+5*0x3b4
    c.uc.mem_write(team,bytes([5,0,8,12]))
    actor=team+0x1a4+44*roster_index
    c.uc.mem_write(actor,struct.pack('<H',1000))
    c.uc.mem_write(entry+0x25,b'\x05')
   elif kind=='teammate':actor=TEAM+0x1a4+44*roster_index
   else:actor=0
   c.uc.mem_write(entry+0x27,b'\x09')
   c.uc.mem_write(entry+0xe,bytes(range(9)))
   c.uc.mem_write(entry+0x32,bytes([order]))
   c.uc.mem_write(entry+0xe+order,bytes([roster_index]))
   before=bytes(c.uc.mem_read(entry,0x300))
   for function in ('CBBGEntryMgr::GetCurBatter()',
                    'CBBGEntryData::GetBatter(int)',
                    'CBBGEntryData::GetTeamPtr()',
                    'CBBGDataMgr::GetRaiseTeam(eTeamIndex)',
                    'CBBGTeamData::GetBatter(int)'):
    assert b.sym(function)+slide not in c.callbacks
   assert invoke(c,b.sym(GETBAT),entry)==actor,(abi,kind,order,roster_index)
   assert invoke(c,symbols['yagu_keep_owned_batter'],entry)==int(kind=='owned')
   assert bytes(c.uc.mem_read(entry,0x300))==before
   counts['original_current_batter_chain']+=1
   invoke(c,b.sym(HOOKS['keep_batter_reservation']),entry,2,0)
   if kind=='owned':assert bytes(c.uc.mem_read(entry,0x300))==before
   else:
    assert c.uc.mem_read(entry+0x295,1)==b'\x01'
    assert c.uc.mem_read(entry+0x297,1)==b'\x0b'
   counts['original_chain_reservation']+=1

 for scope in SCOPES:
  c,entry=setup(scope)
  before=bytes(c.uc.mem_read(SAVE,0x800))
  assert invoke(c,symbols['yagu_keep_owned_batter'],entry)==int(scope=='valid')
  assert bytes(c.uc.mem_read(SAVE,0x800))==before
  counts['scope']+=1
  if not entry:continue
  for index in (0,1,3,8):
   for immediate in (0,1):
    c,entry=setup(scope);events=[]
    c.callbacks[b.sym('CBBGEntryMgr::UpdatePlayer(unsigned char)')+slide]=lambda:(events.append((c.r(0),c.r(1)&255)),c.ret(0))
    before=bytes(c.uc.mem_read(ENTRY,0x300))
    invoke(c,b.sym(HOOKS['keep_batter_reservation']),entry,index,immediate)
    if scope=='valid':
     assert bytes(c.uc.mem_read(ENTRY,0x300))==before and not events
     counts['owned_reservation']+=1
    else:
     assert c.uc.mem_read(ENTRY+0x295,1)==b'\x01'
     assert c.uc.mem_read(ENTRY+0x297,1)==bytes([index+9])
     assert events==([(ENTRY,1)]if immediate else[])
     counts['original_reservation']+=1
  for force in (0,1,255):
   c,entry=setup(scope);seen=[]
   def original_ai():
    a=args(c,5);seen.append((*a[:4],a[4]&255));c.ret(1)
   c.callbacks[bindings['original_keep_batter_ai']+slide]=original_ai
   result=invoke(c,b.sym(HOOKS['keep_batter_ai']),LEVEL,entry,RUNNERS,PLAY,force)&255
   assert result==(0 if scope=='valid'else 1)
   assert seen==([]if scope=='valid'else[(LEVEL,entry,RUNNERS,PLAY,force)])
   counts['ai_abi']+=1

 for scope in SCOPES:
  for flag in (0,1,2,3):
   c,entry=setup(scope);c.uc.mem_write(MISSION+(0x5a if b.is64 else 0x42),bytes([flag]))
   got=invoke(c,symbols['yagu_keep_batter_mission'],MISSION,GAME)
   assert got==(0 if scope=='valid'else flag&1)
   counts['mission']+=1
   # Run the real original IsAceChange call and its following branch. A
   # protected batter takes the normal mission path, so no empty change-player
   # animation or counterfeit mission completion is needed.
   c,entry=setup(scope);c.uc.mem_write(MISSION+(0x5a if b.is64 else 0x42),bytes([flag]))
   non_ace,ace=(0x38aa30,0x38a8a0)if b.is64 else(0x22c870,0x22c77e)
   c.uc.reg_write(c.sp,SP);c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1)
   c.ptr(SP+(8 if b.is64 else 0),GAME);c.r(0,MISSION)
   c.stopped=None;c.stops={non_ace+slide,ace+slide};c.run_relative(site['site'])
   assert c.stopped==slide+(non_ace if scope=='valid'or not(flag&1)else ace)
   assert c.uc.reg_read(c.sp)==SP
   counts['original_mission_branches']+=1
 result={'abi':abi,'load_bias':hex(slide),'counts':counts,'case_count':sum(counts.values()),
         'added_entry_hooks':2,'added_mission_calls':1,'android_runtime_verified':False,
         'limits':['Full-season progression and Cocos animation require separate runtime validation.',
                   'AI fallback is ABI-recorded; original reservation and mission branch instructions execute.']}
 print(json.dumps(result),flush=True);return result

if __name__=='__main__':
 source=WORK/'batter_presence_build/source';stage=stage_payload(source)
 results=[verify(abi,source)for abi in ('arm64-v8a','armeabi-v7a')]
 report={'stage':stage,'results':results,'case_count':sum(r['case_count']for r in results)}
 (WORK/'batter_presence_verification.json').write_text(json.dumps(report,indent=2)+'\n')
