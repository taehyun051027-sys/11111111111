/* Available special uses and cumulative uses are different semantic values.
 * The live action counter and the original effect/duration state remain finite.
 * Only the nine audited local call sites use these adapters: no global getter,
 * network serialization, purchase, skill type or ball table is redirected. */
API extern u8 *original_special_raise_mode(u8 *, int);
API extern int original_special_count(u8 *);
API extern void original_special_add(u8 *, int);

API const Scalar *yagu_special_resource(u8 *mode) {
    if (!own_mode(mode) || !owned_role_player(data_manager(), game_mode() == 3))
        return (const Scalar *)0;
    return &my_state.special_uses;
}

API const Scalar *yagu_special_total(const u8 *record, int role) {
    const InfiniteRecords *records = yagu_owned_records(record, role);
    return records ? &records->special_uses : (const Scalar *)0;
}

API int yagu_special_event_check(int role, int threshold) {
    return yagu_record_event_compare(
        yagu_special_total(yagu_current_personal_record(role), role), threshold);
}

static u8 *special_owned_live_mode(u8 *game, int role) {
    int g = game_mode();
    u8 *dm = data_manager();
    if (!game || !dm || (g != 3 && g != TWO_WAY_MODE) || role < 0 || role > 1)
        return (u8 *)0;
    u8 *save = ptr(dm, g == 3 ? DM_PIT_SAVE : DM_BAT_SAVE);
    if (!save) return (u8 *)0;
    unsigned entry_offset = __SIZEOF_POINTER__ == 8 ? 0x410 : 0x2c8;
    u8 *entry = ptr(game, entry_offset + role * sizeof(void *));
    if (!owns_entry(dm, entry)) return (u8 *)0;
    u8 *actor = role ? get_reserved_pitcher(entry) : get_reserved_batter(entry);
    u8 *owned = owned_role_player(dm, role);
    if (!actor || !owned || actor != owned) return (u8 *)0;
    u8 *mode = save + 8;
    return yagu_special_resource(mode) ? mode : (u8 *)0;
}

/* The original two PIT scene callers ask for mode3, even when a paired pitcher
 * belongs to the active BAT save. At these callers the resulting pointer is
 * used only for Get/AddSpecialCnt and AddTotalSpecialSkillCnt: common RaiseMode
 * fields. No PIT skill-level array is ever reinterpreted as a BAT array. */
API u8 *yagu_special_live_mode(u8 *dm, int requested, u8 *game, int role) {
    if (dm == data_manager() && role == 1 && requested == 3
            && game_mode() == TWO_WAY_MODE) {
        u8 *mode = special_owned_live_mode(game, role);
        if (mode) return mode;
    }
    return original_special_raise_mode(dm, requested);
}

API int yagu_special_live_count(u8 *mode, u8 *game, int role) {
    if (mode && mode == special_owned_live_mode(game, role)) {
        const Scalar *value = yagu_special_resource(mode);
        /* The audited stock branches only ask whether one activation is
         * available. This is a boolean adapter of the typed comparison,
         * not a finite representation of the unbounded inventory. */
        return value && yagu_at_least(*value, 1);
    }
    return original_special_count(mode);
}

API void yagu_special_live_add(u8 *mode, int delta, u8 *game, int role) {
    if (mode && mode == special_owned_live_mode(game, role)) {
        const Scalar *value = yagu_special_resource(mode);
        if (value && value->kind == UNBOUNDED) {
            /* An actual finite spend leaves tagged infinity unchanged. Keep
             * the raw effect-item byte untouched; it is not the stock state. */
            Scalar result = delta < 0
                ? yagu_consume_finite(*value, (u64)(0u - (u32)delta))
                : yagu_add_finite(*value, (u32)delta);
            if (result.kind == UNBOUNDED) return;
        }
    }
    original_special_add(mode, delta);
}

API int yagu_format_special_live(char *dst, unsigned capacity, u8 *game, int role) {
    u8 *mode = special_owned_live_mode(game, role);
    const Scalar *value = mode ? yagu_special_resource(mode) : (const Scalar *)0;
    if (!dst || !value || value->kind != UNBOUNDED) return -1;
    /* Preserve the existing PIT white-color markup and both existing native
     * SystemFont labels. Capacity is the original bounded formatter argument. */
    const char *text = role ? "!cffffff\xe2\x88\x9e" : unbounded_text;
    unsigned length = 0;
    while (text[length]) ++length;
    if (capacity <= length) return -1;
    for (unsigned i = 0; i <= length; ++i) dst[i] = text[i];
    return (int)length;
}
