/* Existing local-wallet display consumers. Prices and rewards stay numeric. */
API extern void original_wallet_frame_numbers(u8 *, int, int, int, int, u8);
API extern void wallet_ui_original_digits(u8 *, int, int, int, u8 *, int, int, int,
                                         int, u8, u8, u8, u8, int);
API extern void wallet_ui_original_number(int, int, const u8 *, int, int, u8 *,
                                         int, int, int, u8, u8);
API extern void wallet_ui_string_init(void *, const char *);
API extern void wallet_ui_string_destroy(void *);
API extern const char *wallet_ui_string_get(void *);
API extern void wallet_ui_change_font(void *, const char *, int, int, short, short, short, short);
API extern void wallet_ui_fit_font(const char *, int, int, u8 *, int, int, int, u8, u8, u8);
API extern int wallet_ui_sprint(char *, const char *, ...);

API void yagu_wallet_frame_numbers(u8 *ui, int kind, int number, int z, int tag, u8 single) {
    /* The original animated path creates one node per decimal digit. Infinity
     * uses the original single-node path, including AddEventTopUI callers. */
    if ((kind == WALLET_G || kind == WALLET_STAR) && yagu_wallet_text(kind)) single = 1;
    original_wallet_frame_numbers(ui,kind,number,z,tag,single);
}

static void wallet_styled_text(const char *text, int size, const u8 *color,
                               int z, int tag, u8 *rect, int alignment,
                               int dx, int dy, u8 visible, u8 wipi) {
    /* Original CBBStringBuffer is24/16 bytes.32-byte aligned local storage
     * exceeds both sizes; its own constructor/destructor own any allocation. */
    u64 storage[4];
    wallet_ui_string_init(storage, "");
    wallet_ui_change_font(storage,text,1,size,color[0],color[1],color[2],color[3]);
    wallet_ui_fit_font(wallet_ui_string_get(storage),z,tag,rect,alignment,dx,dy,visible,wipi,1);
    wallet_ui_string_destroy(storage);
}

API void yagu_wallet_digits(u8 *frame, int number, int z, int tag, u8 *rect,
                            int dx, int dy, int spacing, int alignment,
                            u8 visible, u8 wipi, u8 a, u8 b, int alpha, int kind) {
    const char *text = yagu_wallet_text(kind);
    if (!text) {
        wallet_ui_original_digits(frame,number,z,tag,rect,dx,dy,spacing,alignment,
                                   visible,wipi,a,b,alpha);
        return;
    }
    /* The shipped digit atlases shade G orange and Star cyan. These are
     * opaque foreground samples from CC_Main_FrameUI.png (the original
     * glyphs use gradients). Keep those currency colors and original alpha
     * for the system-font infinity glyph in the same fitted rectangle. */
    const u8 color[4] = {kind == WALLET_G ? 255 : 114,
                          kind == WALLET_G ? 202 : 237,
                          kind == WALLET_G ? 52 : 255, (u8)alpha};
    wallet_styled_text(text,18,color,z,tag,rect,alignment,dx,dy,visible,wipi);
}

API void yagu_wallet_popup_number(int number, int size, const u8 *color,
                                  int z, int tag, u8 *rect, int alignment,
                                  int dx, int dy, u8 visible, u8 wipi, int kind) {
    const char *text = yagu_wallet_text(kind);
    if (!text || !color) {
        wallet_ui_original_number(number,size,color,z,tag,rect,alignment,dx,dy,visible,wipi);
        return;
    }
    /* Exact original GetChangeFont and fit-font arguments, only text changes. */
    wallet_styled_text(text,size,color,z,tag,rect,alignment,dx,dy,visible,wipi);
}

API int yagu_wallet_event_balance(char *dest, const char *format, int number, int kind) {
    const char *text = yagu_wallet_text(kind);
    if (!dest || !format || !text) return wallet_ui_sprint(dest,format,number);
    char translated[1024];
    int i, decimal=0;
    for(i=0;i<1023 && format[i];++i) {
        translated[i]=format[i];
        if(format[i]!='%') continue;
        if(i>=1022 || !format[i+1]) return wallet_ui_sprint(dest,format,number);
        ++i;
        if(format[i]=='%') translated[i]='%';
        else if(format[i]=='d' && ++decimal==1) translated[i]='s';
        else return wallet_ui_sprint(dest,format,number);
    }
    if(format[i] || decimal!=1) return wallet_ui_sprint(dest,format,number);
    translated[i]=0;
    return wallet_ui_sprint(dest,translated,text);
}
