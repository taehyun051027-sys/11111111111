"""Execute original roster numeric call sites with the compiled My-role predicate.

These checks exercise both real instruction sets and nonzero load biases.
They verify caller scoping, null safety, original sprintf fallback, stack and
buffer bounds. They do not claim Android UI or gameplay verification.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks
from payload_builder import add_payload
from career_ability_ui import add_rest_current_condition_hook
from roster_number_ui import CALLERS, ACTOR_FP_OFFSET
from verify_relocation import prepare_case, BAT, TEAM
from verify_gameplay_hooks import ROOT, HEAP, SP
from unicorn.arm_const import UC_ARM_REG_R7
from unicorn.arm64_const import UC_ARM64_REG_X29

WORK = Path(__file__).resolve().parent
OUTPUT = HEAP + 0xf010


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'roster_number_build' / abi)
    hook = add_rest_current_condition_hook(b, payload['symbols'])
    contexts = [(group, caller) for group, callers in CALLERS[abi].items() for caller in callers]
    contexts.append(('unknown', CALLERS[abi]['entry'][0] + 8))
    slides = (0x123450000, 0x7000000000) if b.is64 else (0x10001000, 0xb3000000)
    cases = []
    for slide in slides:
        for group, caller in contexts:
            for actor_id in (1000, 1100, 1, 180, 519, 999, 65535, None):
                c = prepare_case(b, slide)
                frame = SP + 0x1000
                c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7, frame)
                c.ptr(frame, SP + 0x2000)
                c.ptr(frame + (8 if b.is64 else 4), caller + slide)
                actor = BAT if actor_id is not None else 0
                if actor:
                    c.uc.mem_write(actor, struct.pack('<H', actor_id))
                for offset in set(ACTOR_FP_OFFSET[abi].values()):
                    c.ptr(frame + offset, actor)
                before = bytes(c.uc.mem_read(TEAM, 0x3b4))
                c.uc.mem_write(OUTPUT - 8, bytes([0xa5]) * 64)
                for i, value in enumerate((OUTPUT, HEAP + 0x100, 250, 0xabcdef)):
                    c.r(i, value)
                arguments = [c.r(i) for i in range(4)]
                called = []

                def fallback():
                    assert [c.r(i) for i in range(4)] == arguments
                    called.append(True)
                    c.uc.mem_write(OUTPUT, b'250\0')
                    c.ret(3)

                c.callbacks[b.sym('MC_knlSprintk') + slide] = fallback
                c.stops = {hook['site'] + 4 + slide}
                c.run_relative(hook['site'])
                owned = group != 'unknown' and actor_id in (1000, 1100)
                expected = '\u221e'.encode() if owned else b'250'
                assert bytes(c.uc.mem_read(OUTPUT, len(expected) + 1)) == expected + b'\0', (abi, group, actor_id)
                assert c.r(0) == len(expected)
                assert c.uc.reg_read(c.sp) == SP
                assert bool(called) == (not owned)
                assert bytes(c.uc.mem_read(TEAM, 0x3b4)) == before
                assert bytes(c.uc.mem_read(OUTPUT - 8, 8)) == bytes([0xa5]) * 8
                assert bytes(c.uc.mem_read(OUTPUT + len(expected) + 1, 16)) == bytes([0xa5]) * 16
                cases.append({'slide': hex(slide), 'context': group, 'caller': hex(caller),
                              'actor_id': actor_id, 'text': expected.decode()})
    return {'abi': abi, 'passed': len(cases), 'cases': cases,
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'original_font_and_layout_retained': True, 'buffer_bounds_preserved': True,
            'roster_memory_unchanged': True, 'android_runtime_verified': False}


if __name__ == '__main__':
    reports = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'roster_number_ui_verification.json').write_text(json.dumps(reports, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps([{'abi': r['abi'], 'passed': r['passed']} for r in reports]))
