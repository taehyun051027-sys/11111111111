"""Verify tagged speed/record semantics and the actual personal-table hooks."""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE
from payload_builder import add_payload
from infinity_ui import add_infinity_ui_hooks
from defender_hooks import add_defender_hooks
from game_run_uniform_hooks import add_game_run_uniform_hooks
from personal_record_ui import add_personal_record_ui_hooks, FONT
from verify_relocation import prepare_case, BAT, PIT, TEAM, TEAMS, SAVE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
from verify_defender_hooks import read_c_string
from unicorn.arm64_const import UC_ARM64_REG_X29
from unicorn.arm_const import UC_ARM_REG_R7

WORK = Path(__file__).resolve().parent
INFINITY = '\u221e'
ZERO_PITCH = {0, 2, 3, 5, 10, 11}


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'personal_records_build' / abi)
    symbols = payload['symbols']
    add_infinity_ui_hooks(b, symbols['yagu_state'])
    add_defender_hooks(b, symbols['yagu_defender_path'])
    add_game_run_uniform_hooks(b, symbols)
    sites = add_personal_record_ui_hooks(b, symbols)
    slide = 0x7543210000 if b.is64 else 0x93421000
    c = prepare_case(b, slide)

    def call(name, *args):
        c.stopped = None
        c.stops = {STOP}
        c.uc.reg_write(c.sp, SP)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        for index, value in enumerate(args):
            c.r(index, value & ((1 << (64 if b.is64 else 32)) - 1))
        c.run_relative(symbols[name])
        assert c.stopped == STOP and c.uc.reg_read(c.sp) == SP
        return c.r(0)

    assert call('yagu_ensure_two_way', MGR) == PIT
    state_checks = []
    for actor in (BAT, PIT):
        speed = call('yagu_pitch_speed', actor)
        assert struct.unpack('<QII', c.uc.mem_read(speed, 16)) == (0, 1, 0)
        state_checks.append('explicit tagged unbounded pitch speed for ' + str(struct.unpack('<H', c.uc.mem_read(actor, 2))[0]))
        records = call('yagu_record_state', actor)
        raw = bytes(c.uc.mem_read(records, 8 + 33 * 16))
        assert struct.unpack_from('<II', raw) == (2, 1000)
        for index in range(33):
            expected_kind = 0 if (13 <= index < 26 and index - 13 in ZERO_PITCH) or index == 32 else 1
            assert struct.unpack_from('<QII', raw, 8 + index * 16) == (0, expected_kind, 0)
        for role in range(2):
            for metric in range(13):
                p = call('yagu_record_scalar', actor, role, metric)
                assert p == records + 8 + (role * 13 + metric) * 16
        state_checks.append('33 immutable career metrics, including QS and exact-zero fielding errors')
    for actor in (0, TEAM + 4 + 52):
        assert call('yagu_pitch_speed', actor) == 0
        assert call('yagu_record_state', actor) == 0
        assert call('yagu_record_scalar', actor, 0, 5) == 0
    for role, metric in ((-1, 0), (2, 0), (0, -1), (1, 13)):
        assert call('yagu_record_scalar', BAT, role, metric) == 0
    state_checks.append('null, other RFIDs and invalid metric indices have no semantic override')

    contexts = []
    for site in sites:
        for parent_caller in ([0x4f55e0, 0x4f561c] if b.is64 else [0x31b1bf, 0x31b1e1]):
            for role in range(2):
                for metric in range(13):
                    frame = SP + 0x280 if b.is64 else SP + 0x218
                    parent_sp = SP + 0x1000
                    parent_frame = parent_sp + (0x290 if b.is64 else 0x1d8)
                    c.uc.reg_write(c.sp, SP)
                    c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7, frame)
                    c.ptr(frame, parent_frame)
                    c.ptr(frame + (8 if b.is64 else 4), parent_caller + slide)
                    c.uc.mem_write(parent_sp + (0xc0 if b.is64 else 0x77), bytes([1 - role]))
                    c.uc.mem_write(parent_sp + (0xd4 if b.is64 else 0x80), struct.pack('<i', metric // 6))
                    c.uc.mem_write(SP + (0xb4 if b.is64 else 0x84), struct.pack('<i', metric % 6))
                    c.uc.mem_write(HEAP + 0xe000, b'125\0')
                    args = [HEAP + 0xe100, HEAP + 0xe000, 1, 16, 255, 255, 0, 255]
                    for index, value in enumerate(args):
                        if index < (8 if b.is64 else 4): c.r(index, value)
                        else: c.uc.mem_write(SP + (index - 4) * 4, struct.pack('<I', value))
                    observed = []

                    def font():
                        expected = '0' if role == 1 and metric in ZERO_PITCH else INFINITY
                        actual = bytes(c.uc.mem_read(c.r(1), 4)).split(b'\0', 1)[0].decode('utf-8')
                        assert actual == expected, (abi, role, metric, actual, expected)
                        for index, value in enumerate(args):
                            if index == 1: continue
                            actual_arg = c.r(index) if index < (8 if b.is64 else 4) else struct.unpack('<I', c.uc.mem_read(SP + (index - 4) * 4, 4))[0]
                            assert actual_arg == value, (abi, index, actual_arg, value)
                        assert c.uc.reg_read(c.sp) == SP
                        observed.append(actual)
                        c.ret(17)

                    c.callbacks[b.sym(FONT) + slide] = font
                    c.stopped = None
                    c.stops = {site['site'] + 4 + slide}
                    c.run_relative(site['site'])
                    assert c.stopped == site['site'] + 4 + slide and len(observed) == 1
                    assert c.uc.reg_read(c.sp) == SP
                    contexts.append((role, metric, parent_caller))

    # A different AddData caller cannot inherit the personal-record override.
    c.ptr(frame + (8 if b.is64 else 4), 0x123456 + slide)
    c.r(0, args[0]); c.r(1, args[1]); c.r(2, args[2]); c.r(3, args[3])
    reached = []
    def fallback():
        assert c.r(1) == args[1]
        reached.append(True)
        c.ret(18)
    c.callbacks[b.sym(FONT) + slide] = fallback
    c.stopped = None
    c.run_relative(sites[-1]['site'])
    assert reached

    exclusions = []
    for kind in ('noncareer', 'no_save', 'opponent_only_my_id', 'bad_team', 'bad_metric'):
        d = prepare_case(b, slide)
        c_old = c
        c = d
        if kind == 'noncareer': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
        elif kind == 'no_save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
        elif kind == 'opponent_only_my_id':
            c.uc.mem_write(BAT, struct.pack('<H', 23))
            c.uc.mem_write(TEAMS + 8 + 5 * 0x3b4 + 0x1a4, struct.pack('<H', 1000))
        elif kind == 'bad_team': c.uc.mem_write(TEAMS + 4, struct.pack('<i', 15))
        assert call('yagu_personal_record_text', 0, 13 if kind == 'bad_metric' else 5) == 0
        exclusions.append(kind)
        c = c_old

    return {'abi': abi, 'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'slide': hex(slide), 'semantic_checks': state_checks,
            'ui_font_cases_passed': len(contexts), 'scope_exclusions': exclusions,
            'unrelated_caller_preserved': True, 'preserved_original_font_arguments': True,
            'record_metric_count': 33, 'unbounded_metric_count': 26, 'exact_zero_pitch_metrics': sorted(ZERO_PITCH),
            'limits': ['Personal record table only; rankings and live scoreboard are untouched.',
                       'Six-page navigation is verified separately by verify_record_navigation.py.',
                       'No Android glyph rasterization or full game validation.'], 'android_runtime_verified': False}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'personal_record_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps([{key: result[key] for key in ('abi', 'ui_font_cases_passed', 'scope_exclusions')}
                      for result in results], indent=2))
