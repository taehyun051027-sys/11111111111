import inspect
import verify_skill_points as v
from unicorn import UC_HOOK_MEM_INVALID
src=inspect.getsource(v.verify)
a=src.index('    for mode in (3, 4):\n')
z=src.index('    # Original passive-learning commit')
src=src[:a]+src[z:]
a=src.index("    for name in ('CBBGModeData::GetUsedSpecialPoint()'")
src=src[:a]+"    return counts\n"
src=src.replace('        return c, records', '''        def invalid(uc, access, address, size, value, user):
            print('INVALID', abi, 'mode',mode, 'addr',hex(address),'pc',hex(uc.reg_read(c.pc)-slide),'lr',hex(uc.reg_read(c.lr)-slide),'regs',[hex(c.r(i)) for i in range(4)],flush=True)
            return False
        c.uc.hook_add(UC_HOOK_MEM_INVALID, invalid)
        return c, records''')
src=src.replace('                c.run_relative(b.sym(\'CBBGSkillInfoUI::ProcessPopup()\'))', "                print('PASSIVE',abi,mode,popup,cost,flush=True)\n                c.run_relative(b.sym('CBBGSkillInfoUI::ProcessPopup()'))")
src=src.replace('                    c.run_relative(b.sym(\'CBBGSelectBallTypeUI::Run()\'))', "                    print('PITCH',abi,mode,popup,cost,repeat,flush=True)\n                    c.run_relative(b.sym('CBBGSelectBallTypeUI::Run()'))")
ns=vars(v).copy();ns['UC_HOOK_MEM_INVALID']=UC_HOOK_MEM_INVALID
exec(src,ns)
for abi in ('arm64-v8a','armeabi-v7a'):
    print(ns['verify'](abi,v.WORK/'skill_points_build/source'))
