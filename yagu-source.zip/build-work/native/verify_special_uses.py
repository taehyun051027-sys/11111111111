"""Native instruction tests for typed stock, exact live calls and real spending.

Runs both ABIs at nonzero ASLR, including the original PIT special-button
function and original BAT availability branch. Cocos queue/render singletons
are explicit boundaries. No Android gameplay claim is inferred from these.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks, GETMODE
from special_uses_policy import stage_payload, BINDINGS, integrate_source, integrate_builder
from special_uses_hooks import add_special_uses_hooks
from verify_honors import configure, invoke, original_plt, THRESHOLDS, PERIODS, Original
from verify_award_record_ui import complete_ui_before_awards
from award_record_ui import add_award_record_ui_hooks
from verify_relocation import TEAM, TEAMS, BAT, PIT, SAVE, MODE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP

WORK = Path(__file__).resolve().parent
GAME = HEAP + 0xa0000
SCENE = HEAP + 0xa2000
BATENTRY = HEAP + 0xa4000
PITENTRY = HEAP + 0xa5000
BUFFER = HEAP + 0xa6000
PARTICLE = HEAP + 0xa7000
OTHER_MODE = HEAP + 0xa8000


def signed(value):
    value &= 0xffffffff
    return value - (1 << 32) if value >> 31 else value


def verify(abi, source_dir):
    raw = (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes()
    b = PatchBuilder(abi, raw)
    add_gameplay_hooks(b)
    old_root, old_bindings = payload_builder.ROOT, dict(payload_builder.BINDINGS)
    payload_builder.ROOT = source_dir
    payload_builder.BINDINGS.update(BINDINGS)
    try:
        payload = payload_builder.add_payload(b, workdir=WORK / 'special_uses_build' / abi)
    finally:
        payload_builder.ROOT = old_root
        payload_builder.BINDINGS.clear()
        payload_builder.BINDINGS.update(old_bindings)
    symbols = payload['symbols']
    complete_ui_before_awards(b, symbols)
    add_award_record_ui_hooks(b, symbols)
    sites = add_special_uses_hooks(b, symbols)
    from signer_pin import add_signer_pin_patch
    add_signer_pin_patch(b, '0x6de25a17')
    assert len(b.patches) == 149
    slide = 0x7b64532000 if b.is64 else 0xa7432000
    counts = dict(schema=0, event_comparisons=0, total_scope=0, live_helpers=0,
                  hook_scope=0, original_bat_branch=0, original_pit_stock_load=0,
                  original_pit_activation=0, finite_original_stock=0,
                  unchanged_original_functions=0, original_selector32=0)

    def setup(mode=4, role=0):
        c, records, seen = configure(b, slide, mode, payload)
        original_plt(c)
        # IsBatMode is a direct read of the game's process-global mode GOT,
        # not a call through GetCurGameMode. Both represent the same fixture
        # boundary; the test does not emulate the Android singleton loader.
        c.callbacks[b.sym('CBBGStatic::IsBatMode()') + slide] = lambda: c.ret(mode == 4)
        for offset, entry in ((0x410 if b.is64 else 0x2c8, BATENTRY),
                              (0x418 if b.is64 else 0x2cc, PITENTRY)):
            c.ptr(GAME + offset, entry)
            c.uc.mem_write(entry + 0x25, bytes([4]))
        c.callbacks[b.sym('CBBGEntryMgr::GetRsvBatter()') + slide] = lambda: c.ret(BAT)
        c.callbacks[b.sym('CBBGEntryMgr::GetRsvPitcher()') + slide] = lambda: c.ret(PIT)
        c.uc.mem_write(MODE + 0x248 + (23 if mode == 3 else 24), b'\x00')
        c.uc.mem_write(BUFFER - 8, bytes([0x61]) * 80)
        return c, records, seen

    def put_this(c, row):
        c.ptr(SP + row['this_slot'], SCENE)
        c.ptr(SCENE + row['game_field'], GAME)

    def call_hook(c, row, *args):
        put_this(c, row)
        return invoke(c, row['hook'], *args)

    for mode in (3, 4):
        c, records, _ = setup(mode)
        state = invoke(c, symbols['yagu_state'], BAT)
        original43 = bytes(c.uc.mem_read(state + 8, 43 * 16))
        assert len(original43) == 43 * 16
        assert struct.unpack('<II', c.uc.mem_read(state, 8)) == (3, 1000)
        for index in range(47):
            assert struct.unpack('<QII', c.uc.mem_read(state + 8 + index * 16, 16)) == (0, 1, 0)
            counts['schema'] += 1
        record_state = invoke(c, symbols['yagu_record_state'], PIT)
        assert struct.unpack('<II', c.uc.mem_read(record_state, 8)) == (4, 1000)
        total = invoke(c, symbols['yagu_special_total'], records[1], 1)
        assert total == record_state + 8 + 39 * 16
        assert struct.unpack('<QII', c.uc.mem_read(total, 16)) == (0, 1, 0)
        stock = invoke(c, symbols['yagu_special_resource'], MODE)
        assert stock == state + 8 + 46 * 16
        counts['schema'] += 3
        for role in (0, 1):
            for threshold in THRESHOLDS:
                for period in PERIODS:
                    name = 'CBBGEvent::IsRecordCheckPit(int, int, int)' if role else 'CBBGEvent::IsRecordCheckBat(int, int, int)'
                    result = invoke(c, b.sym(name), HEAP + 0x90000, 32, period, threshold)
                    assert result == (threshold >= 0), (abi, mode, role, threshold, period, result)
                    counts['event_comparisons'] += 1
        for role in (0, 1):
            for pointer in (0, records[role] + (32 if role else 24), records[1 - role], PIT, BAT):
                assert invoke(c, symbols['yagu_special_total'], pointer, role) == 0
                counts['total_scope'] += 1
        for role in (0, 1):
            for delta in (-2147483648, -65536, -1, 0, 1, 0x7fffffff):
                before = bytes(c.uc.mem_read(MODE, 0x550))
                assert invoke(c, symbols['yagu_special_live_count'], MODE, GAME, role) == 1
                invoke(c, symbols['yagu_special_live_add'], MODE, delta, GAME, role)
                assert bytes(c.uc.mem_read(MODE, 0x550)) == before
                assert invoke(c, symbols['yagu_special_live_count'], MODE, GAME, role) == 1
                counts['live_helpers'] += 1

    # All exact hooks: own and deliberately invalid ownership contexts.
    invalids = ('valid', 'opponent', 'duplicate_actor', 'wrong_role_actor',
                'missing_save', 'missing_teams', 'missing_actor', 'wrong_mode',
                'missing_game', 'null_this')
    for mode in (3, 4):
        for row in sites:
            for invalid in invalids:
                c, _, _ = setup(mode, row['role'])
                entry = PITENTRY if row['role'] else BATENTRY
                actor_name = 'CBBGEntryMgr::GetRsvPitcher()' if row['role'] else 'CBBGEntryMgr::GetRsvBatter()'
                if invalid == 'opponent': c.uc.mem_write(entry + 0x25, b'\x05')
                if invalid == 'duplicate_actor':
                    c.uc.mem_write(HEAP + 0x98000, struct.pack('<H', 1100 if row['role'] else 1000))
                    c.callbacks[b.sym(actor_name) + slide] = lambda: c.ret(HEAP + 0x98000)
                if invalid == 'wrong_role_actor': c.callbacks[b.sym(actor_name) + slide] = lambda: c.ret(BAT if row['role'] else PIT)
                if invalid == 'missing_save': c.ptr(MGR + ((0x520 if mode == 3 else 0x528) if b.is64 else (0x4e4 if mode == 3 else 0x4e8)), 0)
                if invalid == 'missing_teams': c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
                if invalid == 'missing_actor': c.uc.mem_write(PIT if row['role'] else BAT, b'\x11\x00')
                if invalid == 'wrong_mode': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
                seen = []
                if row['kind'] == 'mode': args = (MGR, 3, 0x52, 0x53)
                elif row['kind'] == 'count': args = (MODE, 0x51, 0x52, 0x53)
                elif row['kind'] == 'add': args = (MODE, 0xffffffff, 0x52, 0x53)
                else: args = (BUFFER, 32, 0x52, 0x53)
                def fallback():
                    seen.append(tuple(c.r(i) for i in range(4)))
                    c.ret(77)
                # Both the original call's PLT target and direct C binding.
                c.callbacks[row['original'] + slide] = fallback
                if row['kind'] in ('mode', 'count', 'add'):
                    alias = {'mode': 'original_special_raise_mode', 'count': 'original_special_count', 'add': 'original_special_add'}[row['kind']]
                    c.callbacks[payload['original_bindings'][alias] + slide] = fallback
                put_this(c, row)
                if invalid == 'missing_game': c.ptr(SCENE + row['game_field'], 0)
                if invalid == 'null_this': c.ptr(SP + row['this_slot'], 0)
                before = bytes(c.uc.mem_read(MODE, 0x550))
                result = invoke(c, row['hook'], *args)
                valid = invalid == 'valid'
                if row['kind'] == 'mode': valid = valid and mode == 4
                if valid:
                    assert not seen, (abi, row, invalid, seen)
                    if row['kind'] == 'mode': assert result == MODE
                    if row['kind'] == 'count': assert result == 1
                    if row['kind'] == 'format':
                        expected = (b'!cffffff' if row['role'] else b'') + '\u221e'.encode()
                        assert result == len(expected)
                        assert bytes(c.uc.mem_read(BUFFER, len(expected) + 1)) == expected + b'\0'
                        assert bytes(c.uc.mem_read(BUFFER - 8, 8)) == b'a' * 8
                        assert bytes(c.uc.mem_read(BUFFER + len(expected) + 1, 8)) == b'a' * 8
                else:
                    assert len(seen) == 1, (abi, row, invalid, seen)
                    # Real helper forwards only the original method arguments;
                    # a direct formatter fallback preserves all four arguments.
                    arity = 4 if row['kind'] == 'format' or invalid == 'null_this' else 2 if row['kind'] in ('mode', 'add') else 1
                    assert seen[0][:arity] == args[:arity], (abi, row, invalid, seen, args)
                assert bytes(c.uc.mem_read(MODE, 0x550)) == before
                counts['hook_scope'] += 1

    # Actual original BAT input call + comparison chooses the normal effect path.
    print(abi, 'schema/events/hook scope passed', flush=True)
    bat = next(row for row in sites if row['label'] == 'bat_use_stock')
    for mode in (3, 4):
        for own in (False, True):
            for finite in (0, 1, 100):
                c, _, _ = setup(mode)
                c.uc.mem_write(MODE + 0x248 + (23 if mode == 3 else 24), bytes([finite]))
                if not own: c.uc.mem_write(BATENTRY + 0x25, b'\x05')
                put_this(c, bat)
                c.uc.reg_write(c.sp, SP)
                c.r(0, MODE)
                passed, failed = ((0x3e9d24, 0x3e9e3c) if b.is64 else (0x26aa60, 0x26ab12))
                c.stopped = None
                c.stops = {passed + slide, failed + slide}
                c.run_relative(bat['site'])
                assert c.stopped == (passed if own or finite else failed) + slide
                assert c.uc.reg_read(c.sp) == SP
                counts['original_bat_branch'] += 1

    # Actual original PIT initialization fragment: no PIT save exists in mode4.
    print(abi, 'original BAT stock branches passed', flush=True)
    enter = next(row for row in sites if row['label'] == 'pit_enter_mode')
    enter_start, enter_stop = ((0x3bad28, 0x3bad68) if b.is64 else (0x24a594, 0x24a5be))
    for mode in (3, 4):
        c, _, _ = setup(mode, 1)
        put_this(c, enter)
        c.uc.reg_write(c.sp, SP)
        c.stopped = None
        c.stops = {enter_stop + slide}
        c.run_relative(enter_start)
        assert c.stopped == enter_stop + slide
        assert struct.unpack('<I', c.uc.mem_read(SCENE + (0x24c if b.is64 else 0x1a0), 4))[0] == 1
        if mode == 4:
            assert bytes(c.uc.mem_read(MGR + (0x520 if b.is64 else 0x4e4), 8 if b.is64 else 4)) == bytes(8 if b.is64 else 4)
        counts['original_pit_stock_load'] += 1

    # Complete original PIT activation, including stock guard, selected type,
    print(abi, 'original PIT load passed', flush=True)
    # one finite match use and one finite stored total use on each real click.
    original = Original(abi)
    use_name = 'CBBGGameRun::AddUseSpecialCnt()'
    use_code = original.dump(use_name)
    expected_use_offset = 0x7ec if b.is64 else 0x65c
    # Validate the raw field from the original instructions, not a guessed slot.
    add_instructions = list(original.cs.disasm(original.read(original.functions[use_name]['address'], original.functions[use_name]['size']), original.functions[use_name]['address']))
    stores = [ins for ins in add_instructions if ins.mnemonic.startswith('str') and '#0x' in ins.op_str]
    field_stores = [ins for ins in stores if '[sp' not in ins.op_str]
    assert len(field_stores) == 1
    import re
    expected_use_offset = int(re.search(r'#(0x[0-9a-f]+)', field_stores[0].op_str).group(1), 16)
    for mode in (3, 4):
        for allowed in (False, True):
            c, _, _ = setup(mode, 1)
            c.ptr(SCENE + (0x368 if b.is64 else 0x2bc), GAME)
            c.uc.mem_write(SCENE + (0x24c if b.is64 else 0x1a0), struct.pack('<I', int(allowed)))
            events = []
            rect = SCENE + (0x358 if b.is64 else 0x2ac)
            rect_call = 0x7360f0 if b.is64 else 0x4789d0
            assert original.labels[rect_call] == '[PLT] cocos2d::CCRect::CCRectContainsPoint(cocos2d::CCRect const&, cocos2d::CCPoint const&)'
            c.callbacks[rect_call + slide] = lambda: c.ret(int(c.r(0) == rect))
            # This is the original STL queue append boundary, not the gameplay
            # choice or stock branch. Record every enqueued original effect ID.
            queue = 0x3b0748 if b.is64 else 0x243b28
            def push_event():
                events.append(struct.unpack('<I', c.uc.mem_read(c.r(1), 4))[0])
                c.ret(0)
            c.callbacks[queue + slide] = push_event
            c.callbacks[b.sym('CBBGDataMgr::GetRaisePitcher()') + slide] = lambda: c.ret(PIT)
            c.callbacks[b.sym('CBBGGameRun_ParticleMgr::GetInstPtr()') + slide] = lambda: c.ret(PARTICLE)
            c.callbacks[b.sym('CBBGGameRun_ParticleMgr::SetWhoParticleEffect(int)') + slide] = lambda: c.ret(0)
            c.uc.mem_write(MODE + 0x524, b'\x00\x00')
            for iteration in range(3):
                before = bytes(c.uc.mem_read(MODE + 0x248, 32))
                result = invoke(c, b.sym('CBBGGameRun_Scene_SltBallType::press_balltype(cocos2d::CCPoint)'), SCENE, 0, 0)
                assert result == allowed, (abi, mode, allowed, result)
                used = struct.unpack('<I', c.uc.mem_read(GAME + expected_use_offset, 4))[0]
                total = struct.unpack('<H', c.uc.mem_read(MODE + 0x524, 2))[0]
                assert used == total == (iteration + 1 if allowed else 0)
                assert bytes(c.uc.mem_read(MODE + 0x248, 32)) == before
                chosen = struct.unpack('<I', c.uc.mem_read(SCENE + (0x2b4 if b.is64 else 0x208), 4))[0]
                assert chosen == (22 if allowed else 0)
                assert bool(events) == allowed
                counts['original_pit_activation'] += 1

    # Original finite getter/setter ABI remains available to serialization and
    print(abi, 'original PIT activations passed', flush=True)
    # unowned consumers, including clamp behavior; no stock entry point patched.
    for mode in (3, 4):
        c, _, _ = setup(mode)
        for value in (-1, 0, 1, 99, 100, 101, 32767):
            invoke(c, b.sym('CBBGRaiseMode::SetSpecialCnt(int)'), MODE, value)
            result = invoke(c, b.sym('CBBGRaiseMode::GetSpecialCnt()'), MODE)
            assert result == max(0, min(value, 100)), (abi, mode, value, result)
            counts['finite_original_stock'] += 1
    for name in ('CBBGRaiseMode::GetSpecialCnt()', 'CBBGRaiseMode::SetSpecialCnt(int)',
                 'CBBGRaiseMode::AddSpecialCnt(int)', 'CBBGRaiseMode::GetTotalSpecialSkillCnt()',
                 'CBBGRaiseMode::AddTotalSpecialSkillCnt(int)', 'CBBGGameRun::AddUseSpecialCnt()',
                 'CBBGGameRun::CalSpecialHitCount()', 'CBBGGameRun::GetSpecialHitCount() const'):
        item = original.functions[name]
        offset = b.offset(item['address'])
        assert b.image[offset:offset + item['size']] == original.read(item['address'], item['size'])
        counts['unchanged_original_functions'] += 1

    # Both original selector32 arms read total special uses and IsCheckVal,
    # with no period branch. Execute the original event on a separate ELF.
    ob = PatchBuilder(abi, raw)
    for mode in (3, 4):
        oc, _, _ = configure(ob, slide, mode, None)
        for role in (0, 1):
            name = 'CBBGEvent::IsRecordCheckPit(int, int, int)' if role else 'CBBGEvent::IsRecordCheckBat(int, int, int)'
            for total in (0, 1, 60000):
                oc.uc.mem_write(MODE + 0x524, struct.pack('<H', total))
                for threshold in (0, 1, 60000, 60001, -1, -60001, -0x80000000):
                    for period in (0, 1, 2, 7):
                        result = invoke(oc, ob.sym(name), HEAP + 0x90000, 32, period, threshold)
                        expected = total >= threshold if threshold >= 0 else False if threshold == -0x80000000 else total < -threshold
                        assert result == expected, (abi, mode, role, total, threshold, period, result)
                        counts['original_selector32'] += 1

    out = WORK / 'special_uses_build' / abi / 'libgameDSO.so'
    result = b.finish(out)
    return {'abi': abi, 'slide': hex(slide), 'counts': counts,
            'asserted_cases': sum(counts.values()), 'patch_count': len(b.patches),
            'output_sha256': result['output_sha256'], 'sites': sites,
            'live_counter_offset': hex(expected_use_offset), 'android_runtime_verified': False}


if __name__ == '__main__':
    source_dir = WORK / 'special_uses_build' / 'source'
    stage = stage_payload(source_dir)
    assert integrate_source((source_dir / 'yagu_payload.c').read_text()) == (source_dir / 'yagu_payload.c').read_text()
    builder_source = (WORK / 'payload_builder.py').read_text()
    new_builder = integrate_builder(builder_source)
    assert integrate_builder(new_builder) == new_builder
    results = [verify(abi, source_dir) for abi in ('arm64-v8a', 'armeabi-v7a')]
    report = dict(stage=stage, results=results,
                  total_cases=sum(row['asserted_cases'] for row in results),
                  genuine_stock_comparison_and_spend=True,
                  original_event_and_finite_match_counters=True,
                  external_service_boundaries=['DataMgr singleton', 'current roster actor getter',
                      'Cocos geometry/queue/particle services in whole PIT button test',
                      'record aggregate constructor in original selector32 proof'],
                  android_runtime_verified=False)
    (WORK / 'special_uses_verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
