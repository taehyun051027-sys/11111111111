"""Execute live display hooks and their compiled C ownership resolver at ASLR.

Android font rasterization is a separate visual check. These tests execute the
actual hook instructions, the real semantic resolver and original-call routing,
while intercepting only the final existing graphics helper and engine lookups.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from payload_builder import add_payload
from live_stats_ui import add_live_stats_ui_hooks, FONT, ARGUMENTS
from verify_relocation import prepare_case, TEAMS, SAVE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, BATM, PITM, BATTER, PITCHER

WORK = Path(__file__).resolve().parent
NODE = HEAP + 0xe000
FRAME = HEAP + 0xe100
RECT = HEAP + 0xe200
TEXT = HEAP + 0xe300
STYLED_INFINITY = '!cFFFFFF!C\u221e'


def read_string(c, address, limit=64):
    return bytes(c.uc.mem_read(address, limit)).split(b'\0', 1)[0].decode('utf-8')


def set_args(c, args):
    registers = 8 if c.is64 else 4
    width = 8 if c.is64 else 4
    mask = (1 << (width * 8)) - 1
    for index, arg in enumerate(args):
        if index < registers:
            c.r(index, arg & mask)
        else:
            c.uc.mem_write(SP + (index - registers) * width,
                           (arg & mask).to_bytes(width, 'little'))


def get_args(c, count):
    registers = 8 if c.is64 else 4
    width = 8 if c.is64 else 4
    sp = c.uc.reg_read(c.sp)
    result = []
    for index in range(count):
        if index < registers:
            result.append(c.r(index))
        else:
            result.append(int.from_bytes(c.uc.mem_read(sp + (index - registers) * width, width), 'little'))
    return result


def args_for(site, compact=False):
    # Nonzero and negative offsets ensure the adapter copies layout arguments.
    dx, dy, alignment = (-5, 11, 0x22) if not compact else (9, -7, 0x44)
    visible, wipi = (1, 1) if not compact else (0, 0)
    if site['kind'] == 'number':
        return [NODE, FRAME, 137, 3, site['tag'], RECT, dx, dy, -2, alignment,
                visible, wipi, 0, 255]
    if site['kind'] == 'average':
        return [NODE, FRAME, 137, 3, 3, site['tag'], RECT, alignment, dx, dy, 0,
                visible, wipi, 0, 255]
    return [NODE, TEXT, 3, site['tag'], RECT, alignment, dx, dy, visible, wipi, 1]


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'live_stats_build' / abi)
    sites = add_live_stats_ui_hooks(b, payload['symbols'])
    slide = 0x7654300000 if b.is64 else 0x86432000
    cases = []
    contexts = ('my_owned', 'my_pitcher_career', 'alternate_layout', 'ordinary_owned',
                'my_opponent', 'wrong_role_id', 'not_career', 'no_save', 'no_manager',
                'no_teams', 'invalid_team', 'negative_team', 'null_entry', 'null_player')
    for site in sites:
        for kind in contexts:
            c = prepare_case(b, slide)
            role = site['role']
            entry, player = (PITM, PITCHER) if role else (BATM, BATTER)
            c.ptr(MGR + (0x520 if b.is64 else 0x4e4), SAVE)
            c.uc.mem_write(entry + 0x25, b'\x04')
            c.uc.mem_write(player, struct.pack('<H', 1100 if role else 1000))
            entry_slot, actor_slot = ((0x410, 0x400) if role else (0x418, 0x408)) if b.is64 else (
                (0x324, 0x31c) if role else (0x328, 0x320))
            c.ptr(SP + entry_slot, 0 if kind == 'null_entry' else entry)
            c.ptr(SP + actor_slot, 0 if kind == 'null_player' else player)
            if kind == 'my_pitcher_career':
                c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(3)
            elif kind == 'ordinary_owned':
                c.uc.mem_write(player, struct.pack('<H', 23))
            elif kind == 'my_opponent':
                c.uc.mem_write(entry + 0x25, b'\x05')
            elif kind == 'wrong_role_id':
                c.uc.mem_write(player, struct.pack('<H', 1000 if role else 1100))
            elif kind == 'not_career':
                c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            elif kind == 'no_save':
                c.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
            elif kind == 'no_manager':
                c.callbacks[b.sym(GETMGR) + slide] = lambda: c.ret(0)
            elif kind == 'no_teams':
                c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
            elif kind == 'invalid_team':
                c.uc.mem_write(TEAMS + 4, struct.pack('<i', 15))
            elif kind == 'negative_team':
                c.uc.mem_write(TEAMS + 4, struct.pack('<i', -1))

            c.uc.mem_write(RECT, struct.pack('<ffff', 78.0, 34.0, 44.0, 20.0))
            c.uc.mem_write(TEXT, b'!cFFFFFF!C----\0')
            args = args_for(site, kind == 'alternate_layout')
            set_args(c, args)
            original_args = get_args(c, len(args))
            stack_before = bytes(c.uc.mem_read(SP, 0x500))
            actor_before = bytes(c.uc.mem_read(player, 52))
            entry_before = bytes(c.uc.mem_read(entry, 0x80))
            rect_before = bytes(c.uc.mem_read(RECT, 16))
            seen = []
            expected_override = kind in ('my_owned', 'my_pitcher_career', 'alternate_layout')

            def original():
                assert not expected_override, (abi, site['name'], kind, 'unexpected fallback')
                assert c.uc.reg_read(c.sp) == SP
                assert get_args(c, len(args)) == original_args, (abi, site['name'], kind, 'argument drift')
                seen.append('original')
                c.ret(0)

            def font():
                if not expected_override:
                    original()
                    return
                actual = get_args(c, 11)
                assert read_string(c, actual[1]) == STYLED_INFINITY
                z, tag, rect, alignment, dx, dy, visible, wipi = ARGUMENTS[site['kind']]
                expected = [args[0], None, args[z], args[tag], args[rect], args[alignment],
                            args[dx], args[dy], args[visible], args[wipi], 1]
                pointer_indices = {0, 4}
                for index, value in enumerate(expected):
                    if index == 1:
                        continue
                    if index in pointer_indices:
                        assert actual[index] == value
                    else:
                        # int and bool argument values occupy the low word on A64.
                        assert (actual[index] & 0xffffffff) == (value & 0xffffffff), (
                            abi, site['name'], kind, index, actual[index], value)
                assert c.uc.reg_read(c.sp) == SP - (144 if b.is64 else 80)
                seen.append('infinity')
                c.ret(0)

            c.callbacks[site['original'] + slide] = original
            c.callbacks[b.sym(FONT) + slide] = font
            c.stops = {site['site'] + 4 + slide}
            c.run_relative(site['site'])
            assert c.stopped == site['site'] + 4 + slide
            assert c.uc.reg_read(c.sp) == SP
            assert seen == ['infinity' if expected_override else 'original']
            assert bytes(c.uc.mem_read(SP, 0x500)) == stack_before
            assert bytes(c.uc.mem_read(player, 52)) == actor_before
            assert bytes(c.uc.mem_read(entry, 0x80)) == entry_before
            assert bytes(c.uc.mem_read(RECT, 16)) == rect_before
            cases.append({'site': hex(site['site']), 'name': site['name'], 'context': kind,
                          'result': seen[0], 'tag': hex(site['tag'])})

    return {
        'abi': abi, 'slide': hex(slide), 'passed': len(cases), 'sites': len(sites),
        'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
        'source_ui_sha256': hashlib.sha256((WORK / 'live_stats_ui.py').read_bytes()).hexdigest(),
        'cases': cases, 'original_stack_and_actor_memory_unchanged': True,
        'original_node_tags_rectangles_alignment_visibility_preserved': True,
        'missing_record_cells_covered': True,
        'limits': ['Android glyph rasterization and panel appearance require an actual APK screenshot.',
                   'Scores, inning, pitch counts, batting order and pitcher ERA are unchanged.'],
        'android_runtime_verified': False,
    }


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'live_stats_ui_verification.json').write_text(
        json.dumps(results, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps([{key: r[key] for key in ('abi', 'slide', 'sites', 'passed')}
                      for r in results], indent=2))
