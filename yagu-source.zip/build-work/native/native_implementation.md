# Native gameplay and infinity UI implementation

This is the technical supplement for the original gameplay and four-context
UI modules. The current complete build, expanded UI coverage, personal-record
navigation, signer configuration and remaining limits are documented in
`candidate3_native_report.md`. Use the complete `payload_builder.py` CLI when
reproducing the current build.

## Integration

The input libraries are locked to the hashes in `patch_builder.EXPECTED`.
Compose all native modules with one builder so they share a single appended
read/execute segment:

```python
b = PatchBuilder(abi, original_library_bytes)
gameplay = add_gameplay_hooks(b)
payload = add_payload(b)
ui = add_infinity_ui_hooks(b, payload['symbols']['yagu_state'])
b.finish(output_library_path)
```

UI predicates call the compiled payload's
authoritative semantic `yagu_state(player)`; no numeric value is interpreted as
infinity. The standalone gameplay candidates do not include the parent's
two-way / semantic-state module and are not the final product.

## Implemented outcome paths

| Feature | Original engine boundary | Authored behavior |
|---|---|---|
| My swing / simulated batting | `CBBGLevelMgr::BattingProcess` | For own RFID 1000, return the normal contact+hit aggregate with home-run pattern 21. The original live / simulation result and scoring paths consume it. |
| Opponent contact suppression | Same batting boundary | Against own RFID 1100, return the normal miss aggregate. |
| Early / late accepted swings | Live pitch contact-frame timing flag | When an actual My batter animation reaches the original contact gate, enable the gate even outside its timing window. Untouched at-bats are not fabricated as swings. |
| Live strike judgment | `IntersectStrikeZone`, `IsHitByPitcher`, `IsWildPitch` | Own pitcher returns zone true, HBP false, wild pitch false. Original `PitchJudge` remains responsible for strike counts and strikeouts. |
| Simulated strike judgment | `CSimulation::Init_Judge` call to `PitchJudge` | Own pitcher supplies zone true and clears HBP / wild / dropped-third-strike / runner-play flags before original judgment. |
| Universe league | `CBBGRaiseMode::Initialize`, league getter and setter | Initialize / retain the observed league kind 9. |
| Fatigue | Pitcher stamina setter; entry stamina decrement | A full 10000 legacy stamina adapter is retained. This numeric adapter is not itself the semantic infinite value. |
| Pitcher replacement | `RsvChangePitcher`; live `DoCanBeChangePitcher` | Prevent removal when the current pitcher is own RFID 1100. Other pitchers retain original behavior. |

Gameplay ownership requires game mode 3 or 4, a non-null data manager and active
career, and equality between entry team index and active-career team index.
The same reserved RFID placed on an opposing entry does not receive the HR /
strikeout / substitution privileges. The raw `SetStamina` compatibility setter
has only RFID scope because it receives no entry manager; actual depletion and
outcome hooks additionally check ownership.

## ABI evidence

`BattingProcess` returns a 12-byte logical structure. Bytes 6 and 7 are the
contact and hit flags; the int32 at byte 8 is the batting pattern. ARM64 returns
the two register portions in x0/x1. ARMv7 uses an r0 hidden result pointer and
receives this/attacker/defender in r1/r2/r3. Authored wrappers use those distinct
ABIs and restore original arguments and stack position on unscoped fallback.

The timing hook preserves surrounding general-purpose state, floating-point
registers used by the selected path, and condition flags. The original live
contact event, home-run branch, scoring, statistics, inning and save machinery
remain downstream. A complete game must still be validated on Android.

## UI coverage

The actual output bytes are UTF-8 `∞` (`e2 88 9e`) and, in the start menu,
`Lv. ∞`. Identified contexts are:

1. Career frame player level.
2. Player information's four primary ability numbers, for both roles.
3. Player information experience display.
4. Start menu My player level.

The shared numeric-widget formatter is restricted to two exact call sites in
the player-information ability loop. The level-string formatter is restricted
to the player-level call in the start menu; equipment averages and team levels
keep their original rendering. Each scope extracts the actual player pointer
from the observed caller frame and asks `yagu_state` rather than comparing the
numeric display value with a chosen maximum.

Existing font size, color markup, parent nodes and geometry remain in use.
The existing UTF-8 rendering path receives infinity. Instruction tests prove
the bytes and routing, not that an Android font has rasterized the glyph.
Other menus, including some live player-info panels, entry lists and training
screens, have additional numeric display consumers outside this UI module.

## Verification

- `verify_gameplay_hooks.py`: 35 cases per ABI, 70 total. Checks native return
  ABI, actor scope, preservation of fallback arguments and stack, timing hook
  state, three successive original-judge results (strike, strike, strikeout),
  Universe state, stamina, ownership and pitcher-substitution scope.
- `verify_infinity_ui.py`: 14 cases per ABI, 28 total. Checks real UTF-8 output
  for both role IDs, original finite formatting for other players, vetted
  caller contexts and exclusion of unrelated numeric widgets.
- `verify_relocation.py`: 12 checks at each of two nonzero load biases per ABI,
  48 checks and 208 native calls total. The zero-bias mapping is removed and
  loaded code/state are read-execute. The actual compiled C payload resolves
  all 43 tagged scalars, enters through patched original functions, preserves
  the own-team roster and existing pitching record, and reaches relocated
  fallback functions. All eight special/training/pitch/passive getter/setter
  wrappers are exercised. Original special and training setters execute;
  the original pitch setter executes with its min/max leaf mocked. These tests
  do not reproduce Android's dynamic linker or original ELF relocations.
- `verify_defender_hooks.py`: 576 instruction cases across all 24 inline sites
  (12 per ABI), at nonzero load biases with the actual compiled path resolver.
  Each site is exercised with original palettes 0..9 and new palettes 10..24
  excluding 14. Exact paths, original texture-maker argument, general-purpose
  registers, 32 SIMD/FP registers, condition flags, stack, LR and continuation
  are checked. Texture decoding and appearance remain unverified here.
- `verify_starting_pitcher.py`: 14 original-instruction checks across the two
  ABIs. Confirms an initial current pitcher needs no reservation, a -1 byte at
  entry + 0x28 does not block `GetRsvPitcher`, and original mode-4 pitching
  records resolve by RFID inside the BAT save with a null PIT-save pointer.
- `verify_game_run_uniform_hooks.py`: 2,052 instruction cases across the four
  legacy batter/pitcher clothing load sites. Uses the complete integration
  order at nonzero load biases, exercises every team and all 26/25 loop parts,
  and checks invalid team/part fallbacks. All 490 selected new clothing paths
  have matching PZC and PNG files. Pumas, bat, glove, face, hair, shoes, ball,
  hand and shadow retain the observed original-table behavior. Every GPR
  except the intended path result, all 32 SIMD/FP registers, flags, stack,
  return address and the texture-maker first argument are preserved. For new
  clothing, the original table is deliberately unmapped in the test, proving
  the extended palette never indexes it. Image rendering remains unverified.
- JSON reports explicitly mark Android gameplay and glyph rendering as not
  established by these instruction tests.
- Patch reports retain original and output SHA-256, every changed original
  byte range, authored assembly, and appended segment address / size.

The patch builder reuses the original PT_NOTE program-header slot for an
additional RX PT_LOAD. Note bytes remain in the original image / sections;
original code addresses, GOT entries and dynamic relocations do not move.
This engineering decision still requires Android loader testing. The original
ELF page alignment is 4096; APK zip alignment alone does not establish 16 KiB
Android native-loader compatibility.

## Independent review findings for the parent payload

- Pitcher record RFID is a uint16 at record offset 0 on both ABIs.
- BAT career pitcher records use save + 0xe8c + team * 256 + order * 32.
  `AddPitcherRec` normally clears all 32 bytes; repeated two-way synchronization
  must preserve the record when RFID already matches.
- Player roster order is byte 0x13. Pitcher position is low nibble at 0x21.
  Skin uses bits 2-3 at 0x22. Hair / hair color share byte 0x2b.
- Default game end inning is stored as 8 (nine innings). The inspected
  `IsGameOver` contains normal inning/out/score comparisons and no mercy-score
  cutoff. The `ColdInn` field is referenced by popularity / record code.
- A level compatibility value of 250 fits the unsigned-byte level field.
  `GetNecessaryExp` has a fixed arithmetic result for levels >= 249, not an
  out-of-bounds table lookup. Legacy upgrade menus do contain max-250 gates;
  upper-bounded early-story eligibility also excludes level 250. Those are
  distinct from the canonical Unbounded level and need careful UI / onboarding
  validation before claiming every menu is converted.
- Original special-skill level is a four-bit field at player + 0x2a; the
  adapter 10 preserves the neighboring low nibble. Original pitch-level setter
  explicitly clamps its value to 0..10 before writing mode + 0x3f0 + pitch.
  Training levels occupy bytes at mode + 0x504 + part. The payload bounds its
  unbounded projections to four training parts and 28 pitch types.
- The two reviewed pitching consumers accept special-level adapter 10 without
  indexing beyond the observed curve resource. `GetBallType` at 0x5856c0 tests
  only whether the special level is positive and inserts fixed ball enum 22.
  `LoadResPlayer` passes it to `CCLPitch::SetPitchData`; for level >= 6 that
  method computes one-based curve index level + 10. The decoded `pitch.zt1`
  special kind 21 contains exactly 20 curves. Curve 20 ends at byte 25529,
  exactly the file size. Full evidence is in `special_level_bounds.json` and
  the adjoining consumer/curve disassembly files. This is static resource-bound
  validation, not a played special pitch.
- Passive skill membership and level are separate. Original membership uses
  a 32-bit bitset at mode + 0x200; the original level is a signed byte at
  mode + 0x204 + skill. The current payload promotes only a nonzero owned
  passive skill level. It does not unlock unlearned passive skills. Unknown
  indices are not proven safe by the new wrappers; original caller contracts
  remain necessary, especially when the original setter's check flag is false.
