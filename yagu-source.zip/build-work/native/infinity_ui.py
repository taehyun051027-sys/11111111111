"""Render the semantic Unbounded state at identified numeric UI consumers.

No numeric sentinel is returned by an ability or level getter. These wrappers
replace only the string formatting at four observed UI points. The original
size/color markup and normal UTF-8 text rendering paths stay in use. The shared
number widget is additionally restricted to the two PlayerInfo ability callers.
Actual Android font rendering is a separate runtime verification requirement.
"""
from gameplay_hooks import A64_SAVE,A64_RESTORE,T32_SAVE,T32_RESTORE
from patch_builder import PatchBuilder

def add_infinity_ui_hooks(b:PatchBuilder, is_unbounded_player_addr:int):
    """Predicate is yagu_state(player): non-null iff authoritative Unbounded."""
    predicate = is_unbounded_player_addr & ~int(not b.is64)
    sprintf = b.sym('MC_knlSprintk')
    exports={}
    for kind in ['frame_level','player_abilities','player_experience','menu_level']:
        prefix = kind=='menu_level'
        if b.is64:
            if kind=='frame_level':
                site,expected=0x377e7c,'75d50e94'
                actor='ldr x0, [sp, #0xd8]'
            elif kind=='player_experience':
                site,expected=0x4cd0ec,'d9800994'
                actor='ldr x0, [sp, #0x3c0]\ncbz x0, original\nldr x0, [x0, #0x30]'
            elif kind=='player_abilities':
                site,expected=0x59487c,'f5620694'
                actor='''ldr x8, [x29, #8]
adrp x9, #0x4cc000
add x9, x9, #0xc88
cmp x8, x9
b.eq ability_context
add x9, x9, #0x5c
cmp x8, x9
b.ne original
ability_context:
ldr x0, [x29, #0x390]
cbz x0, original
ldr x0, [x0, #0x30]'''
            else:
                site,expected=0x40f53c,'c5770c94'
                actor='''ldr x8, [x29, #8]
adrp x9, #0x461000
add x9, x9, #0x32c
cmp x8, x9
b.ne original
ldr x0, [x29, #0x198]'''
            source=f'''{A64_SAVE}
{actor}
cbz x0, original
bl #{predicate}
cbz x0, original
{A64_RESTORE}
{('movz w8, #0x764c; movk w8, #0x202e, lsl #16; str w8, [x0]' if prefix else '')}
movz w8, #0x88e2
movk w8, #0x009e, lsl #16
str w8, [x0, #{4 if prefix else 0}]
mov w0, #{7 if prefix else 3}
ret
original:
{A64_RESTORE}
b #{sprintf}'''
        else:
            if kind=='frame_level':
                site,expected=0x220bd8,'4ff22ae9'
                actor='ldr r0, [sp, #0x80]'
            elif kind=='player_experience':
                site,expected=0x2ffc08,None
                actor='ldr.w r0, [sp, #0x1b8]\ncmp r0, #0\nbeq original\nldr r0, [r0, #0x20]'
            elif kind=='player_abilities':
                site,expected=0x38432e,'ebf080ed'
                delta=(0x2ff93b-(site+5))&0xffffffff
                actor=f'''ldr r3, [r7, #4]
movw r2, #{delta&0xffff}
movt r2, #{delta>>16}
add r2, lr
cmp r3, r2
beq ability_context
add.w r2, r2, #0x54
cmp r3, r2
bne original
ability_context:
ldr.w r0, [r7, #0x1a8]
cmp r0, #0
beq original
ldr r0, [r0, #0x20]'''
            else:
                site,expected=0x2827b0,'edf13eeb'
                delta=(0x2b7b03-(site+5))&0xffffffff
                actor=f'''ldr r3, [r7, #4]
movw r2, #{delta&0xffff}
movt r2, #{delta>>16}
add r2, lr
cmp r3, r2
bne original
ldr.w r0, [r7, #0xf0]'''
            source=f'''{T32_SAVE}
{actor}
cmp r0, #0
beq original
bl #{predicate}
cmp r0, #0
beq original
{T32_RESTORE}
{('movw r1, #0x764c; movt r1, #0x202e; str r1, [r0]' if prefix else '')}
movw r1, #0x88e2
movt r1, #0x009e
str r1, [r0, #{4 if prefix else 0}]
movs r0, #{7 if prefix else 3}
bx lr
original:
{T32_RESTORE}
b.w #{sprintf}'''
            if expected is None:
                # Hash lock already guards the entire source; this observed
                # BLX must still resolve exactly to the original formatter PLT.
                off=b.offset(site);raw=b.original[off:off+4]
                ins=list(b.cs.disasm(raw,site))
                if len(ins)!=1 or ins[0].mnemonic!='blx' or ins[0].op_str!='#0x46fe30':
                    raise ValueError('Unverified experience formatter call')
                expected=raw.hex()
        hook=b.append_asm('Unbounded UI: '+kind,source)
        b.patch(site,b.branch(site,hook,True),'Render semantic infinity at '+kind,expected)
        exports[kind]=hook
    return exports
