"""Enter original contact handling for received swings or terminal PA counts."""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE


def add_batting_rescue_hook(b, symbols):
    target = symbols['yagu_rescue_batting']
    if b.is64:
        site, expected = 0x38d8c8, 'a2920e94'
        source = f'''{A64_SAVE}
ldr x1, [sp, #0x88]
ldur w2, [x29, #-0x80]
ldur w3, [x29, #-0x84]
bl #{target}
str x0, [sp]
{A64_RESTORE}
ret'''
    else:
        site, expected = 0x22e60c, '46f240eb'
        source = f'''{T32_SAVE}
ldr r1, [sp, #0x3c]
ldr r2, [sp, #0x9c]
ldr r3, [sp, #0x98]
bl #{target}
str r0, [sp]
{T32_RESTORE}
bx lr'''
    hook = b.append_asm('Owned two-strike delayed input rescue', source)
    b.patch(site, b.branch(site, hook, True),
            'Preserve own PA through original swing/contact/event path', expected)
    return {'site': site, 'hook': hook}


def owned_batter_and_pitcher_hbp(b, trampoline, owned):
    """Extend the existing HBP gate, with no second patch at its entry point."""
    from gameplay_hooks import pitcher_bool, GETBAT
    source = pitcher_bool(b, trampoline, 0, owned)
    getbat = b.sym(GETBAT)
    if b.is64:
        old = f'''original:
{A64_RESTORE}
b #{trampoline}'''
        new = f'''original:
ldr x0, [sp]
cbz x0, unscoped_hbp
ldr x0, [x0, #0x410]
cbz x0, unscoped_hbp
bl #{getbat}
cbz x0, unscoped_hbp
ldrh w9, [x0]
cmp w9, #1000
b.ne unscoped_hbp
ldr x0, [sp]
ldr x0, [x0, #0x410]
bl #{owned}
cbz w0, unscoped_hbp
{A64_RESTORE}
mov w0, #0
ret
unscoped_hbp:
{A64_RESTORE}
b #{trampoline}'''
    else:
        old = f'''original:
{T32_RESTORE}
b.w #{trampoline}'''
        new = f'''original:
ldr r0, [sp]
cmp r0, #0
beq unscoped_hbp
ldr.w r0, [r0, #0x2c8]
cmp r0, #0
beq unscoped_hbp
bl #{getbat}
cmp r0, #0
beq unscoped_hbp
ldrh r1, [r0]
movw r2, #1000
cmp r1, r2
bne unscoped_hbp
ldr r0, [sp]
ldr.w r0, [r0, #0x2c8]
bl #{owned}
cmp r0, #0
beq unscoped_hbp
{T32_RESTORE}
movs r0, #0
bx lr
unscoped_hbp:
{T32_RESTORE}
b.w #{trampoline}'''
    if source.count(old) != 1: raise ValueError('Changed original HBP wrapper shape')
    return source.replace(old, new)
