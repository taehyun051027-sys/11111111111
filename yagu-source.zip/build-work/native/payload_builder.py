"""Compile and link the freestanding two-way module at an appended ELF VA.

Every original entry is reached by a four-byte, hash-locked branch. Original
prologues live in relocation-checked trampolines. External function references
are resolved at link time; the injected image has no dynamic relocations.
"""
from __future__ import annotations
import io, json, os, subprocess
from pathlib import Path
from patch_builder import PatchBuilder, align, ELFFile

ROOT = Path(__file__).resolve().parent
ZIG = Path(os.environ.get('YAGU_ZIG', str(ROOT.parent / 'android/zig-python/ziglang/zig')))

HOOKS = {
    'keep_batter_reservation': 'CBBGEntryMgr::RsvChangeBatter(int, unsigned char)',
    'keep_batter_ai': 'CBBGLevelMgr::AIChangeBatterPlayer(CBBGEntryMgr*, CBBGRunnerMgr*, CBBGPlayData*, unsigned char)',
    'skill_points': 'CBBGModeData::GetSpecialPoint()',
    'set_skill_points': 'CBBGModeData::SetSpecialPoint(int)',
    'add_skill_points': 'CBBGModeData::AddSpecialPoint(int)',
    'wallet_frame_numbers': 'CBBGFrameUI::AddGFNumber(eGameFrameNum, int, int, int, bool)',
    'wallet_equip_connect': 'CBBGEquipStoreUI::ConnectStarVC()',
    'wallet_costume_connect': 'CBBGCostumeStoreUI::ConnectStarVC()',
    'wallet_effect_connect': 'CBBGEffectStoreUI::ConnectStarVC()',
    'wallet_frame_connect': 'CBBGFrameUI::ConnectStarVC()',
    'wallet_estimate_connect': 'CBBGGameEstimateUI::ConnectStarVC()',
    'wallet_bundle_connect': 'CBBGBundleItemStoreUI::ConnectStarVC(int)',
    'equip_level': 'CBBGOption::GetEquipItemLevel(bool, int)',
    'add_equip_level': 'CBBGOption::AddEquipItemLevel(bool, int, int)',
    'equip_bonus': 'CBBGStatic::GetAddAbilByEQItemLevel(int, bool)',
    'equip_success_per': 'CBBGStrengthItemUI::GetSuccessPer(int)',
    'equipment_process': 'CBBGStrengthItemUI::ProcessStrengthItem()',
    'equipment_lunch_buy': 'CBBGStrengthLunchUI::BuyCheck()',
    'get_pitcher': 'CBBGDataMgr::GetRaisePitcher()',
    'my_team': 'CBBGDataMgr::GetMyRaiseTeam()',
    'pitcher_record': 'CBBGDataMgr::GetRaisePitcherRec()',
    'entry_init': 'CBBGEntryData::initialization(eGameMode, eTeamIndex, int)',
    'entry_update': 'CBBGEntryData::UpdateEntryData()',
    'auto_simulate': 'CSimulation::IsAutoSimulate()',
    'is_raise_player': 'CSimulation::IsRaisePlayer()',
    'level': 'CBBGPlayerData::GetLevel()',
    'set_level': 'CBBGPlayerData::SetLevel(int)',
    'add_level': 'CBBGPlayerData::AddLevel()',
    'pure_status': 'CBBGPlayerData::GetPureStatus(EnumBodyPart)',
    'status': 'CBBGPlayerData::GetStatus(EnumBodyPart, unsigned char, unsigned char)',
    'set_status': 'CBBGPlayerData::SetStatus(EnumBodyPart, int)',
    'add_status': 'CBBGPlayerData::AddStatus(EnumBodyPart, int)',
    'special_level': 'CBBGPlayerData::GetSpecialSkillLV()',
    'set_special_level': 'CBBGPlayerData::SetSpecialSkillLV(int)',
    'condition': 'CBBGModeData::GetCondition()',
    'set_condition': 'CBBGModeData::SetCondition(int)',
    'add_condition': 'CBBGModeData::AddCondition(int)',
    'exp': 'CBBGModeData::GetExp()',
    'set_exp': 'CBBGModeData::SetExp(int)',
    'add_exp': 'CBBGModeData::AddExp(int)',
    'active_gauge': 'CBBGModeData::GetActiveGauge()',
    'set_active_gauge': 'CBBGModeData::SetActiveGauge(int)',
    'add_active_gauge': 'CBBGModeData::AddActiveGauge(int)',
    'max_active': 'CBBGModeData::GetRaiseMaxActiveVal()',
    'set_max_active': 'CBBGModeData::SetRaiseMaxActiveVal(int)',
    'popularity': 'CBBGModeData::GetPopularity()',
    'set_popularity': 'CBBGModeData::SetPopularity(int)',
    'add_popularity': 'CBBGModeData::AddPopularity(int)',
    'level_popup': 'CBBGModeData::CheckLevelUpPopup()',
    'training_level': 'CBBGRaiseMode::GetNormalTrainLv(EnumBodyPart)',
    'set_training_level': 'CBBGRaiseMode::SetNormalTrainLv(EnumBodyPart, int)',
    'pitch_level': 'CBBGRaiseMode::GetBallTypeLv(int)',
    'set_pitch_level': 'CBBGRaiseMode::SetBallTypeLv(int, int)',
    'passive_level': 'CBBGModeData::GetSkillLevel(EnumPassiveSkills)',
    'set_passive_level': 'CBBGModeData::SetSkillLevel(EnumPassiveSkills, int, bool)',
    'year_goal': 'CBBGRaiseMode::IsYearGoalCheck(int, int)',
    'record_check_bat': 'CBBGEvent::IsRecordCheckBat(int, int, int)',
    'record_check_pit': 'CBBGEvent::IsRecordCheckPit(int, int, int)',
    'rank_analyze': 'CBBGRecordAnalyzer::Analyze(EnumRecordSort, eGameMode, unsigned char, unsigned char)',
    'emblem': 'CBBGTeamEditMgr::GetIdxOfTeamSymbol(eTEAM_SYMBOL_LAYER, eTeamIndex)',
    'uniform': 'CBBGTeamEditMgr::GetUniformPal(eRES_PLAYER_LAYER, int)',
    'load_uniform': 'CBBGCcPlayerRes::LoadResPlayerUniform(int, bool, int, bool)',
    'load_equipment': 'CBBGCcPlayerRes::LoadResPlayerEquip(int, bool, int, int, bool)',
}
BINDINGS = {
    'catalog_define': 'CGsSingleton<CBBGMgrDefine>::GetInstPtr()',
    'catalog_loader': 'CBBGMgrDefine::GetXLData(EnumXlsData)',
    'catalog_x': 'GVXLLoader::GetX()',
    'catalog_y': 'GVXLLoader::GetY()',
    'catalog_value': 'GVXLLoader::GetVal(int, int)',
    'catalog_original_equip_price': 'CBBGStatic::GetNeedPriceBuyEquipItem(int, int, bool)',
    'catalog_original_equip_discount': 'CBBGStatic::GetDCPerBuyEquipItem(int, int, bool)',
    'catalog_original_equip_sale': 'CBBGStatic::GetSaleTypeBuyEquipItem(int, int, bool)',
    'catalog_original_costume_price': 'CBBGStatic::GetNeedPriceBuyCostumeItem(int, int)',
    'catalog_original_costume_discount': 'CBBGStatic::GetDCPerBuyCostumeItem(int, int)',
    'catalog_original_costume_sale': 'CBBGStatic::GetSaleTypeBuyCostumeItem(int, int)',
    'catalog_original_effect_price': 'CBBGStatic::GetNeedPriceBuyEffectItem(int, bool)',
    'catalog_original_effect_discount': 'CBBGStatic::GetDCPerBuyEffectItem(int, bool)',
    'catalog_original_effect_sale': 'CBBGStatic::GetSaleTypeBuyEffectItem(int, bool)',
    'catalog_original_effect_g': 'CBBGStatic::IsUseGpointBuyEffectItem(int, bool)',
    'catalog_rotate': 'CBBGModeData::SetEffectStoreListRotation(int)',
    'catalog_worldmap_popup': 'CBBGWorldmapBuylinkUI::AddBuyLinkPopup()',
    'catalog_gift_running': 'CBBGStrengthAllPlayerUI::GetRunningBegGiftPopup()',
    'catalog_gift_set_running': 'CBBGStrengthAllPlayerUI::SetRunningBegGiftPopup(bool)',
    'catalog_create_buy_popup': 'CBBGStatic::CreateBuyCCPopup(int, bool, int)',
    'presence_original_ace_change': 'CBBGGameRun_BurstMission::IsAceChange() const',
    'original_team_mean': 'CBBGTeamData::GetTeamLevel(bool)',
    'original_sp_raise_mode': 'CBBGDataMgr::GetRaiseMode(eGameMode)',
    'wallet_ui_original_digits': 'DrawCCFitNumber(ccpzx::CCPZXFrame*, int, int, int, cocos2d::CCRect&, int, int, int, int, bool, bool, bool, bool, int)',
    'wallet_ui_original_number': 'AddChildFitNumberSystemFont(int, int, cocos2d::_ccColor4B&, int, int, cocos2d::CCRect&, int, int, int, bool, bool)',
    'wallet_ui_string_init': 'CBBStringBuffer::CBBStringBuffer(char const*)',
    'wallet_ui_string_destroy': 'CBBStringBuffer::~CBBStringBuffer()',
    'wallet_ui_string_get': 'CBBStringBuffer::Get()',
    'wallet_ui_change_font': 'CBBGStatic::GetChangeFont(CBBStringBuffer&, char const*, int, int, short, short, short, short)',
    'wallet_ui_fit_font': 'AddChildFitSystemFont(char const*, int, int, cocos2d::CCRect&, int, int, int, bool, bool, bool)',
    'wallet_ui_sprint': 'MC_knlSprintk',
    'wallet_get_option': 'CBBGDataMgr::GetOption()',
    'wallet_original_get_g': 'CBBGOption::GetGPoint()',
    'wallet_original_get_star': 'CBBGOption::GetStarPoint()',
    'wallet_original_add_g': 'CBBGOption::AddGPoint(int, unsigned char)',
    'wallet_original_add_star': 'CBBGOption::AddStarPoint(int, bool, int, int, int, int)',
    'wallet_worldmap_buy': 'CBBGWorldmapBuylinkUI::BuyProcess()',
    'wallet_lucky_buy': 'CBBGLuckyBoxUI::BuyProcess()',
    'wallet_lucky_animate': 'CBBGLuckyBoxUI::ResultAniProcess()',
    'wallet_camp_complete': 'CBBGSpringCampUI::CompleteOverseas()',
    'wallet_set_skill_slots': 'CBBGModeData::SetPsvSkillMax(int)',
    'wallet_skill_icon': 'CBBGSkillInfoUI::ChangeSlotIcon(bool, int, int)',
    'wallet_get_raise_mode': 'CBBGDataMgr::GetRaiseMode(eGameMode)',
    'wallet_equip_buy': 'CBBGEquipStoreUI::BuyProcess()',
    'wallet_costume_buy': 'CBBGCostumeStoreUI::BuyProcess()',
    'wallet_effect_buy': 'CBBGEffectStoreUI::BuyProcess()',
    'wallet_frame_buy': 'CBBGFrameUI::BuyProcess()',
    'wallet_estimate_buy': 'CBBGGameEstimateUI::BuyProcess()',
    'wallet_bundle_buy': 'CBBGBundleItemStoreUI::BuyProcess()',
    'equipment_sprint': 'MC_knlSprintk',
    'equipment_get_val': 'GVXLLoader::GetVal(int, int)',
    'equipment_resource_manager': 'CGsSingleton<CBBGCcMgrRes>::GetInstPtr()',
    'equipment_common_string': 'CBBGCcMgrRes::GetCommonStr(int)',
    'equipment_max_popup': 'CBBGStatic::CreateDefaultCCPopup(char const*, int, int, bool)',
    'original_rescue_battable': 'CBBGBatter::IsBattable()',
    'original_rescue_swing': 'CBBGBatter::Swing(int)',
    'original_rescue_swing_position': 'CBBGGameRun::GetCurrentSwingPosition()',
    'original_rescue_at_swing': 'CBBGStatisticsMgr::AtSwing()',
    'original_rescue_current_batter': 'CBBGEntryMgr::GetCurBatter()',
    'original_rescue_play_data': 'CBBGStatic::GetPlayData()',
    'original_special_raise_mode': 'CBBGDataMgr::GetRaiseMode(eGameMode)',
    'original_special_count': 'CBBGRaiseMode::GetSpecialCnt()',
    'original_special_add': 'CBBGRaiseMode::AddSpecialCnt(int)',
    'game_mode': 'CBBGStatic::GetCurGameMode()',
    'data_manager': 'CGsSingleton<CBBGDataMgr>::GetInstPtr()',
    'get_reserved_pitcher': 'CBBGEntryMgr::GetRsvPitcher()',
    'get_reserved_batter': 'CBBGEntryMgr::GetRsvBatter()',
    'original_personal_record_table': 'CBBGRecordPersonalUI::AddTableTabUIText(int)',
    'original_past_pitcher_record': 'CBBGDataMgr::GetPastRaisePitcherRec(int)',
    'rank_get_team': 'CBBGDataMgr::GetTeam(eGameMode, eTeamIndex)',
    'rank_team_index': 'CBBGTeamData::GetTeamIdx()',
    'rank_batter_record': 'CBBGDataMgr::GetBatterRec(int, CBBGPlayerData*, bool)',
    'rank_pitcher_record': 'CBBGDataMgr::GetPitcherRec(int, CBBGPlayerData*, bool)',
    'rank_is_postseason': 'CBBGLeagueMode::IsPostSeason()',
    'rank_is_cup': 'CBBGLeagueMode::IsCubGame()',
    'rank_game_count': 'CBBGLeagueMode::GetGameCount(unsigned char)',
    'rank_bat_ab': 'CBBGBatterRecData::GetAtBat()',
    'rank_bat_hit': 'CBBGBatterRecData::GetHit()',
    'rank_bat_hr': 'CBBGBatterRecData::GetHomeRun()',
    'rank_bat_steal': 'CBBGBatterRecData::GetSteal()',
    'rank_bat_rbi': 'CBBGBatterRecData::GetRBI()',
    'rank_bat_avg': 'CBBGBatterRecData::GetAVR1000()',
    'rank_bat_slg': 'CBBGBatterRecData::GetAVR1000_BIG()',
    'rank_bat_obp': 'CBBGBatterRecData::GetOnBasePer1000()',
    'rank_bat_ops': 'CBBGBatterRecData::GetOps1000()',
    'rank_pit_out': 'CBBGPitcherRecData::GetOut()',
    'rank_pit_win': 'CBBGPitcherRecData::GetWin()',
    'rank_pit_lost': 'CBBGPitcherRecData::GetLost()',
    'rank_pit_save': 'CBBGPitcherRecData::GetSave()',
    'rank_pit_era': 'CBBGPitcherRecData::GetERA100()',
    'rank_pit_er': 'CBBGPitcherRecData::GetEarnedScore()',
    'rank_pit_k': 'CBBGPitcherRecData::GetK()',
    'rank_pit_hold': 'CBBGPitcherRecData::GetHold()',
    'rank_pit_whip': 'CBBGPitcherRecData::GetWHIP100()',
    'rank_pit_k9': 'CBBGPitcherRecData::GetK9100()',
}

def add_payload(b: PatchBuilder, *, include_art=True, workdir: Path | None=None):
    wd = workdir or ROOT / 'compiled' / b.abi
    wd.mkdir(parents=True, exist_ok=True)
    hooks = dict(HOOKS)
    if not include_art:
        for key in ('uniform','emblem','load_uniform','load_equipment'): hooks.pop(key)
    bindings = {alias: b.sym(name) for alias, name in BINDINGS.items()}
    # Non-injected art functions still satisfy unused callable payload exports.
    for alias in ('uniform', 'emblem', 'load_uniform', 'load_equipment'):
        if alias not in hooks: bindings['original_'+alias] = b.sym(HOOKS[alias])
    for alias, name in hooks.items():
        if name in b.used: raise ValueError('Overlapping owner for '+name)
        bindings['original_'+alias] = b.trampoline(name)
    # Explicit typed absolute symbols preserve Thumb interworking semantics.
    asm = ['.text']
    for alias, address in bindings.items():
        asm += [f'.global {alias}', f'.hidden {alias}', f'.type {alias}, %function',
                f'.set {alias}, {address | (0 if b.is64 else 1)}']
    (wd/'bindings.S').write_text('\n'.join(asm)+'\n')
    base = align(b.base + len(b.extra), 16)
    script = f'''PHDRS {{ payload PT_LOAD FLAGS(5); }}
SECTIONS {{
  . = {base};
  .payload : {{ *(.text .text.*) *(.rodata .rodata.*) }} :payload
  .data : {{ *(.data .data.*) *(.bss .bss.*) *(COMMON) }} :payload
  /DISCARD/ : {{ *(.eh_frame*) *(.ARM.exidx*) *(.ARM.extab*) *(.comment) *(.note*) }}
}}
'''
    (wd/'payload.ld').write_text(script)
    # Freestanding ELF uses the same AAPCS code ABI without Android's mandatory
    # PIE link driver; the final original Android .so remains position independent.
    target = ['-target', 'aarch64-freestanding-none'] if b.is64 else ['-target', 'thumb-freestanding-eabi', '-mcpu=cortex_a7']
    cmd = [str(ZIG), 'cc', *target, '-Oz', '-fPIC', '-ffreestanding', '-fno-builtin', '-fno-lto',
           '-fno-stack-protector', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables',
           '-fvisibility=hidden', '-fno-ident', '-nostdlib', '-static', '-g',
           '-Wl,--no-undefined', '-Wl,--no-gc-sections', '-Wl,-no-pie',
           '-Wl,-e,yagu_level', '-Wl,--build-id=none', '-Wl,-T,'+str(wd/'payload.ld'),
           str(ROOT/'yagu_payload.c'), str(wd/'bindings.S'), '-o', str(wd/'payload.elf')]
    result = subprocess.run(cmd, capture_output=True, text=True)
    (wd/'compiler.log').write_text(result.stdout+result.stderr)
    if result.returncode: raise RuntimeError(result.stderr)
    image=(wd/'payload.elf').read_bytes(); elf=ELFFile(io.BytesIO(image))
    for section in elf.iter_sections():
        if section['sh_type'] in ('SHT_REL','SHT_RELA') and section['sh_size']:
            raise ValueError('Payload has unresolved relocations')
    data=elf.get_section_by_name('.data')
    if data and data['sh_size']: raise ValueError('Read-only payload contains writable state')
    section=elf.get_section_by_name('.payload')
    if section['sh_addr'] != base: raise ValueError('Unexpected linked base')
    if base > b.base+len(b.extra): b.append('C payload alignment', b'\0'*(base-(b.base+len(b.extra))))
    address=b.append('Semantic infinity and two-way C payload', section.data(), 'yagu_payload.c')
    if address != base: raise ValueError('Payload append address mismatch')
    symbols={s.name: s['st_value'] & ~int(not b.is64) for s in elf.get_section_by_name('.symtab').iter_symbols() if s['st_value']}
    for alias, name in hooks.items():
        target_address=symbols['yagu_'+alias]
        b.patch(b.sym(name), b.branch(b.sym(name), target_address), 'two-way / semantic-state '+name)
        b.used.add(name)
    report={'abi':b.abi,'base':base,'size':len(section.data()),'symbols':symbols,
            'hooks':hooks,'original_bindings':bindings,
            'semantic_infinity':'tagged Unbounded; integer fields are compatibility adapters',
            'legacy_adapters':{'status':10000,'level':250,'special_level':10,
                               'passive_skill_level':10,'training_level':7,'pitch_level':10,
                               'action_points':30,'action_capacity':30,'popularity':32760},
            'android_runtime_verified':False}
    (wd/'payload_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report

if __name__ == '__main__':
    from gameplay_hooks import add_gameplay_hooks
    from infinity_ui import add_infinity_ui_hooks
    from defender_hooks import verify_original_defender_lookups
    from game_run_uniform_hooks import add_game_run_uniform_hooks
    from personal_record_ui import add_personal_record_ui_hooks
    from pitch_speed_ui import add_pitch_speed_ui_hooks
    from personal_record_navigation import add_personal_record_navigation_hooks
    from career_ability_ui import add_career_ability_ui_hooks, add_rest_current_condition_hook
    from live_stats_ui import add_live_stats_ui_hooks
    from local_rank_ui import add_local_rank_ui_hooks
    from local_rank_navigation import add_local_rank_navigation_hooks
    from career_resource_ui import add_career_resource_ui_hooks, add_career_resource_decisions
    from training_max_ui import add_training_max_ui_hooks
    from award_record_ui import add_award_record_ui_hooks
    from special_uses_hooks import add_special_uses_hooks
    from equipment_level_ui import add_equipment_level_ui_hooks
    from mental_duel_hooks import add_mental_duel_hooks
    from team_mean_hooks import add_team_mean_hooks
    from wallet_ui import add_wallet_ui_hooks
    from batting_rescue_hooks import add_batting_rescue_hook
    from batter_presence_hooks import add_batter_presence_hook
    from skill_points_hooks import add_skill_points_hooks
    from wallet_hooks import add_wallet_hooks
    from local_catalog_hooks import add_local_catalog_hooks
    from signer_pin import add_signer_pin_patch
    for abi in ('arm64-v8a','armeabi-v7a'):
        src=ROOT.parent.parent/'analysis/native/lib'/abi/'libgameDSO.so'
        b=PatchBuilder(abi,src.read_bytes())
        add_gameplay_hooks(b)
        report=add_payload(b)
        add_infinity_ui_hooks(b,report['symbols']['yagu_state'])
        add_game_run_uniform_hooks(b,report['symbols'])
        add_personal_record_ui_hooks(b,report['symbols'])
        add_pitch_speed_ui_hooks(b,report['symbols'])
        add_personal_record_navigation_hooks(b,report['symbols'])
        add_career_ability_ui_hooks(b,report['symbols'])
        add_rest_current_condition_hook(b,report['symbols'])
        add_live_stats_ui_hooks(b,report['symbols'])
        add_local_rank_ui_hooks(b,report['symbols'])
        add_local_rank_navigation_hooks(b,report['symbols'])
        add_career_resource_ui_hooks(b,report['symbols'])
        add_career_resource_decisions(b,report['symbols'])
        add_training_max_ui_hooks(b,report['symbols'])
        add_award_record_ui_hooks(b,report['symbols'])
        add_special_uses_hooks(b,report['symbols'])
        add_equipment_level_ui_hooks(b,report['symbols'])
        add_mental_duel_hooks(b,report['symbols'])
        add_team_mean_hooks(b,report['symbols'])
        add_wallet_ui_hooks(b,report['symbols'])
        add_batting_rescue_hook(b,report['symbols'])
        add_batter_presence_hook(b,report['symbols'])
        add_skill_points_hooks(b,report['symbols'])
        wallet_calls = add_wallet_hooks(b, report['symbols'])
        local_catalog = add_local_catalog_hooks(b, report['symbols'])
        signer_pin = add_signer_pin_patch(b, os.environ['YAGU_CERT_HASH']) if 'YAGU_CERT_HASH' in os.environ else None
        defender_paths = verify_original_defender_lookups(b)
        result = b.finish(ROOT/'integrated/lib'/abi/'libgameDSO.so')
        (ROOT/'integrated/lib'/abi/'integration_manifest.json').write_text(json.dumps({
            'abi': abi, 'payload': report, 'signer_pin': signer_pin,
            'defender_paths': defender_paths,
            'local_development_catalog': local_catalog,
            'local_wallet': {'schema': 1, 'typed_resources': ['G points', 'stars'], 'call_sites': wallet_calls},
            'output_sha256': result['output_sha256'], 'patch_count': len(b.patches),
            'semantic_player_schema': 4, 'semantic_player_scalars': 51,
            'semantic_record_schema': 4, 'semantic_record_scalars': 40,
            'unbounded_record_scalars': 33, 'finite_zero_record_scalars': 7,
            'finite_zero_pitching_record_scalars': 6,
            'typed_record_consumers': ['owned record lookup', 'year goals', 'personal event record conditions', 'local rank eligibility and ordering'],
            'typed_career_resources': ['action_points', 'action_capacity', 'popularity'],
            'typed_record_event_periods': [1, 2],
            'typed_honor_event_selectors': [26, 27, 28, 29, 30, 31],
            'typed_honor_event_period': 'independent, as in original selectors',
            'personal_record_pages': 6, 'local_rank_categories': 15,
            'local_rank_native_categories': 17, 'android_runtime_verified': False,
        }, indent=2)+'\n')
        print(abi, 'payload_bytes', report['size'], 'patches', len(b.patches))
