"""Compile and link the freestanding two-way module at an appended ELF VA.

Every original entry is reached by a four-byte, hash-locked branch. Original
prologues live in relocation-checked trampolines. External function references
are resolved at link time; the injected image has no dynamic relocations.
"""
from __future__ import annotations
import io, json, os, subprocess
from pathlib import Path
from patch_builder import PatchBuilder, align, ELFFile

ROOT = Path(__file__).resolve().parent
ZIG = Path(os.environ.get('YAGU_ZIG', str(ROOT.parent / 'android/zig-python/ziglang/zig')))

HOOKS = {
    'get_pitcher': 'CBBGDataMgr::GetRaisePitcher()',
    'my_team': 'CBBGDataMgr::GetMyRaiseTeam()',
    'pitcher_record': 'CBBGDataMgr::GetRaisePitcherRec()',
    'entry_init': 'CBBGEntryData::initialization(eGameMode, eTeamIndex, int)',
    'entry_update': 'CBBGEntryData::UpdateEntryData()',
    'auto_simulate': 'CSimulation::IsAutoSimulate()',
    'is_raise_player': 'CSimulation::IsRaisePlayer()',
    'level': 'CBBGPlayerData::GetLevel()',
    'set_level': 'CBBGPlayerData::SetLevel(int)',
    'add_level': 'CBBGPlayerData::AddLevel()',
    'pure_status': 'CBBGPlayerData::GetPureStatus(EnumBodyPart)',
    'status': 'CBBGPlayerData::GetStatus(EnumBodyPart, unsigned char, unsigned char)',
    'set_status': 'CBBGPlayerData::SetStatus(EnumBodyPart, int)',
    'add_status': 'CBBGPlayerData::AddStatus(EnumBodyPart, int)',
    'special_level': 'CBBGPlayerData::GetSpecialSkillLV()',
    'set_special_level': 'CBBGPlayerData::SetSpecialSkillLV(int)',
    'condition': 'CBBGModeData::GetCondition()',
    'set_condition': 'CBBGModeData::SetCondition(int)',
    'add_condition': 'CBBGModeData::AddCondition(int)',
    'exp': 'CBBGModeData::GetExp()',
    'set_exp': 'CBBGModeData::SetExp(int)',
    'add_exp': 'CBBGModeData::AddExp(int)',
    'level_popup': 'CBBGModeData::CheckLevelUpPopup()',
    'training_level': 'CBBGRaiseMode::GetNormalTrainLv(EnumBodyPart)',
    'set_training_level': 'CBBGRaiseMode::SetNormalTrainLv(EnumBodyPart, int)',
    'pitch_level': 'CBBGRaiseMode::GetBallTypeLv(int)',
    'set_pitch_level': 'CBBGRaiseMode::SetBallTypeLv(int, int)',
    'passive_level': 'CBBGModeData::GetSkillLevel(EnumPassiveSkills)',
    'set_passive_level': 'CBBGModeData::SetSkillLevel(EnumPassiveSkills, int, bool)',
    'year_goal': 'CBBGRaiseMode::IsYearGoalCheck(int, int)',
    'record_check_bat': 'CBBGEvent::IsRecordCheckBat(int, int, int)',
    'record_check_pit': 'CBBGEvent::IsRecordCheckPit(int, int, int)',
    'emblem': 'CBBGTeamEditMgr::GetIdxOfTeamSymbol(eTEAM_SYMBOL_LAYER, eTeamIndex)',
    'uniform': 'CBBGTeamEditMgr::GetUniformPal(eRES_PLAYER_LAYER, int)',
    'load_uniform': 'CBBGCcPlayerRes::LoadResPlayerUniform(int, bool, int, bool)',
    'load_equipment': 'CBBGCcPlayerRes::LoadResPlayerEquip(int, bool, int, int, bool)',
}
BINDINGS = {
    'game_mode': 'CBBGStatic::GetCurGameMode()',
    'data_manager': 'CGsSingleton<CBBGDataMgr>::GetInstPtr()',
    'get_reserved_pitcher': 'CBBGEntryMgr::GetRsvPitcher()',
    'get_reserved_batter': 'CBBGEntryMgr::GetRsvBatter()',
    'original_personal_record_table': 'CBBGRecordPersonalUI::AddTableTabUIText(int)',
    'original_past_pitcher_record': 'CBBGDataMgr::GetPastRaisePitcherRec(int)',
}

def add_payload(b: PatchBuilder, *, include_art=True, workdir: Path | None=None):
    wd = workdir or ROOT / 'compiled' / b.abi
    wd.mkdir(parents=True, exist_ok=True)
    hooks = dict(HOOKS)
    if not include_art:
        for key in ('uniform','emblem','load_uniform','load_equipment'): hooks.pop(key)
    bindings = {alias: b.sym(name) for alias, name in BINDINGS.items()}
    # Non-injected art functions still satisfy unused callable payload exports.
    for alias in ('uniform', 'emblem', 'load_uniform', 'load_equipment'):
        if alias not in hooks: bindings['original_'+alias] = b.sym(HOOKS[alias])
    for alias, name in hooks.items():
        if name in b.used: raise ValueError('Overlapping owner for '+name)
        bindings['original_'+alias] = b.trampoline(name)
    # Explicit typed absolute symbols preserve Thumb interworking semantics.
    asm = ['.text']
    for alias, address in bindings.items():
        asm += [f'.global {alias}', f'.hidden {alias}', f'.type {alias}, %function',
                f'.set {alias}, {address | (0 if b.is64 else 1)}']
    (wd/'bindings.S').write_text('\n'.join(asm)+'\n')
    base = align(b.base + len(b.extra), 16)
    script = f'''PHDRS {{ payload PT_LOAD FLAGS(5); }}
SECTIONS {{
  . = {base};
  .payload : {{ *(.text .text.*) *(.rodata .rodata.*) }} :payload
  .data : {{ *(.data .data.*) *(.bss .bss.*) *(COMMON) }} :payload
  /DISCARD/ : {{ *(.eh_frame*) *(.ARM.exidx*) *(.ARM.extab*) *(.comment) *(.note*) }}
}}
'''
    (wd/'payload.ld').write_text(script)
    # Freestanding ELF uses the same AAPCS code ABI without Android's mandatory
    # PIE link driver; the final original Android .so remains position independent.
    target = ['-target', 'aarch64-freestanding-none'] if b.is64 else ['-target', 'thumb-freestanding-eabi', '-mcpu=cortex_a7']
    cmd = [str(ZIG), 'cc', *target, '-Oz', '-fPIC', '-ffreestanding', '-fno-builtin', '-fno-lto',
           '-fno-stack-protector', '-fno-unwind-tables', '-fno-asynchronous-unwind-tables',
           '-fvisibility=hidden', '-fno-ident', '-nostdlib', '-static', '-g',
           '-Wl,--no-undefined', '-Wl,--no-gc-sections', '-Wl,-no-pie',
           '-Wl,-e,yagu_level', '-Wl,--build-id=none', '-Wl,-T,'+str(wd/'payload.ld'),
           str(ROOT/'yagu_payload.c'), str(wd/'bindings.S'), '-o', str(wd/'payload.elf')]
    result = subprocess.run(cmd, capture_output=True, text=True)
    (wd/'compiler.log').write_text(result.stdout+result.stderr)
    if result.returncode: raise RuntimeError(result.stderr)
    image=(wd/'payload.elf').read_bytes(); elf=ELFFile(io.BytesIO(image))
    for section in elf.iter_sections():
        if section['sh_type'] in ('SHT_REL','SHT_RELA') and section['sh_size']:
            raise ValueError('Payload has unresolved relocations')
    data=elf.get_section_by_name('.data')
    if data and data['sh_size']: raise ValueError('Read-only payload contains writable state')
    section=elf.get_section_by_name('.payload')
    if section['sh_addr'] != base: raise ValueError('Unexpected linked base')
    if base > b.base+len(b.extra): b.append('C payload alignment', b'\0'*(base-(b.base+len(b.extra))))
    address=b.append('Semantic infinity and two-way C payload', section.data(), 'yagu_payload.c')
    if address != base: raise ValueError('Payload append address mismatch')
    symbols={s.name: s['st_value'] & ~int(not b.is64) for s in elf.get_section_by_name('.symtab').iter_symbols() if s['st_value']}
    for alias, name in hooks.items():
        target_address=symbols['yagu_'+alias]
        b.patch(b.sym(name), b.branch(b.sym(name), target_address), 'two-way / semantic-state '+name)
        b.used.add(name)
    report={'abi':b.abi,'base':base,'size':len(section.data()),'symbols':symbols,
            'hooks':hooks,'original_bindings':bindings,
            'semantic_infinity':'tagged Unbounded; integer fields are compatibility adapters',
            'legacy_adapters':{'status':10000,'level':250,'special_level':10,
                               'passive_skill_level':10,'training_level':7,'pitch_level':10},
            'android_runtime_verified':False}
    (wd/'payload_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report

if __name__ == '__main__':
    from gameplay_hooks import add_gameplay_hooks
    from infinity_ui import add_infinity_ui_hooks
    from defender_hooks import add_defender_hooks
    from game_run_uniform_hooks import add_game_run_uniform_hooks
    from personal_record_ui import add_personal_record_ui_hooks
    from pitch_speed_ui import add_pitch_speed_ui_hooks
    from personal_record_navigation import add_personal_record_navigation_hooks
    from career_ability_ui import add_career_ability_ui_hooks, add_rest_current_condition_hook
    from live_stats_ui import add_live_stats_ui_hooks
    from signer_pin import add_signer_pin_patch
    for abi in ('arm64-v8a','armeabi-v7a'):
        src=ROOT.parent.parent/'analysis/native/lib'/abi/'libgameDSO.so'
        b=PatchBuilder(abi,src.read_bytes())
        add_gameplay_hooks(b)
        report=add_payload(b)
        add_infinity_ui_hooks(b,report['symbols']['yagu_state'])
        add_defender_hooks(b,report['symbols']['yagu_defender_path'])
        add_game_run_uniform_hooks(b,report['symbols'])
        add_personal_record_ui_hooks(b,report['symbols'])
        add_pitch_speed_ui_hooks(b,report['symbols'])
        add_personal_record_navigation_hooks(b,report['symbols'])
        add_career_ability_ui_hooks(b,report['symbols'])
        add_rest_current_condition_hook(b,report['symbols'])
        add_live_stats_ui_hooks(b,report['symbols'])
        signer_pin = add_signer_pin_patch(b, os.environ['YAGU_CERT_HASH']) if 'YAGU_CERT_HASH' in os.environ else None
        result = b.finish(ROOT/'integrated/lib'/abi/'libgameDSO.so')
        (ROOT/'integrated/lib'/abi/'integration_manifest.json').write_text(json.dumps({
            'abi': abi, 'payload': report, 'signer_pin': signer_pin,
            'output_sha256': result['output_sha256'], 'patch_count': len(b.patches),
            'semantic_player_scalars': 43, 'semantic_record_scalars': 33,
            'unbounded_record_scalars': 26, 'finite_zero_record_scalars': 7,
            'finite_zero_pitching_record_scalars': 6,
            'typed_record_consumers': ['owned record lookup', 'year goals', 'personal event record conditions'],
            'typed_record_event_periods': [1, 2],
            'personal_record_pages': 6, 'android_runtime_verified': False,
        }, indent=2)+'\n')
        print(abi, 'payload_bytes', report['size'], 'patches', len(b.patches))
