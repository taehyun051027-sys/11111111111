"""Expose the original BAT8 and PIT7 ranking pages in one owned two-way career.

The existing table, headers, arrows and swipe paths are retained. Global tabs
0..14 live in the original tab field; every six observed array/layout consumers
receives a bounded BAT0..7 or PIT0..6 local index. All rejected ownership scopes
fall through to original code. The existing hero row uses the chosen owned role.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE
from personal_record_navigation import checked_call
from local_rank_ui import rank_parent_context

TABLE = 'CBBGRecordRankUI::AddTableTabUIText(int)'
ROLE = 'CBBGStatic::IsBatMode()'
HERO = 'CBBGDataMgr::GetRaisePlayer(eGameMode)'


def add_local_rank_navigation_hooks(b, symbols):
    output = {'scroll_calls': [], 'role_calls': [], 'tab_loads': []}
    table = b.sym(TABLE)
    scroll = [(0x4f7b2c, 1), (0x4f7b3c, 1), (0x4f7b70, -1), (0x4f7b8c, -1),
              (0x4f7c54, 1), (0x4f7c64, 1), (0x4f7ca8, -1), (0x4f7cc8, -1)] if b.is64 else [
              (0x31cafc, 1), (0x31cb06, 1), (0x31cb22, -1), (0x31cb38, -1),
              (0x31cbae, 1), (0x31cbb8, 1), (0x31cbdc, -1), (0x31cbf2, -1)]
    for site, direction in scroll:
        if b.is64:
            source = f'''{A64_SAVE}
mov w1, #{direction}
bl #{symbols['yagu_rank_next_tab']}
tbnz w0, #31, original
str x0, [sp, #8]
original:
{A64_RESTORE}
b #{table}'''
        else:
            source = f'''{T32_SAVE}
mov.w r1, #{direction}
bl #{symbols['yagu_rank_next_tab']}
cmp r0, #0
blt original
str r0, [sp, #4]
original:
{T32_RESTORE}
b.w #{table}'''
        hook = b.append_asm('Original rank gesture direction ' + str(direction), source)
        checked_call(b, site, hook, 0x742040 if b.is64 else 0x4853e0,
                     'Cycle original local ranking gestures through all fifteen existing categories')
        output['scroll_calls'].append({'site': site, 'hook': hook, 'direction': direction})

    # Offsets below refer to each original caller's SP, before the wrapper save.
    role_sites = [(0x4f7d74, 'table', 0x1a0, 0x22c),
                  (0x4f8898, 'analyze', 0x10, None),
                  (0x4f7410, 'draw', 0xb8, None)] if b.is64 else [
                  (0x31cc5a, 'table', 0x120, 0x170),
                  (0x31d338, 'analyze', 0x10, None),
                  (0x31c5cc, 'draw', 0x68, None)]
    original_role = b.sym(ROLE)
    for site, context, ui_slot, local_slot in role_sites:
        if b.is64:
            local = f'add x1, sp, #{local_slot + 80}' if local_slot is not None else 'mov x1, #0'
            source = f'''{A64_SAVE}
ldr x0, [sp, #{ui_slot + 80}]
{local}
bl #{symbols['yagu_rank_is_batter']}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original_role}'''
        else:
            local = f'add.w r1, sp, #{local_slot + 24}' if local_slot is not None else 'movs r1, #0'
            source = f'''{T32_SAVE}
ldr r0, [sp, #{ui_slot + 24}]
{local}
bl #{symbols['yagu_rank_is_batter']}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original_role}'''
        hook = b.append_asm('Original rank layout role: ' + context, source)
        checked_call(b, site, hook, 0x72db90 if b.is64 else 0x470570,
                     'Select original batting or pitching ranking layout')
        output['role_calls'].append({'site': site, 'hook': hook, 'context': context,
                                     'ui_slot': ui_slot, 'local_slot': local_slot})

    if b.is64:
        loads = [(0x4f8010, 8, 8, False, '087140b9'), (0x4f81dc, 8, 8, False, '087140b9'),
                 (0x4f83d8, 8, 8, False, '087140b9'), (0x4f85cc, 8, 8, False, '087140b9'),
                 (0x4f8930, 8, 9, True, '097180b9'), (0x4f7434, 9, 9, False, '297140b9')]
        save = '\n'.join(f'stp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0, 18, 2))
        restore = '\n'.join(f'ldp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0, 18, 2))
        qsave = '\n'.join(f'stp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0, 32, 2))
        qrestore = '\n'.join(f'ldp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0, 32, 2))
        for site, src, dst, signed, expected in loads:
            conversion = 'sxtw x0, w0' if signed else 'mov w0, w0'
            source = f'''sub sp, sp, #704
{save}
stp x18, x30, [sp, #144]
mrs x8, nzcv
str x8, [sp, #160]
{qsave}
ldr x0, [sp, #{src*8}]
bl #{symbols['yagu_rank_local_tab']}
{conversion}
str x0, [sp, #168]
{qrestore}
ldr x8, [sp, #160]
msr nzcv, x8
{restore}
ldp x18, x30, [sp, #144]
ldr {'x' if signed else 'w'}{dst}, [sp, #168]
add sp, sp, #704
b #{site+4}'''
            hook = b.append_asm('Bound original local rank index ' + hex(site), source)
            b.patch(site, b.branch(site, hook), 'Normalize native ranking switch/layout index', expected)
            output['tab_loads'].append({'site': site, 'hook': hook, 'source': src,
                                        'destination': dst, 'signed': signed, 'size': 4, 'replay': ''})
    else:
        loads = [(0x31ce16, 0, 0, '006c3790', 'str r0, [sp, #0xdc]'),
                 (0x31cf14, 0, 0, '006c2a90', 'str r0, [sp, #0xa8]'),
                 (0x31d040, 0, 0, '006c1e90', 'str r0, [sp, #0x78]'),
                 (0x31d16c, 0, 0, '006c1590', 'str r0, [sp, #0x54]'),
                 (0x31d388, 0, 1, '016c06a8', 'add r0, sp, #0x18'),
                 (0x31c5e4, 1, 1, '096c0844', 'add r0, r1')]
        for site, src, dst, expected, replay in loads:
            source = f'''push.w {{r0-r3, r12, lr}}
sub sp, sp, #8
mrs r0, apsr
str r0, [sp]
vpush {{d0-d15}}
vpush {{d16-d31}}
ldr r0, [sp, #{264 + src*4}]
bl #{symbols['yagu_rank_local_tab']}
str r0, [sp, #{264 + dst*4}]
vpop {{d16-d31}}
vpop {{d0-d15}}
ldr r0, [sp]
msr APSR_nzcvq, r0
add sp, sp, #8
pop.w {{r0-r3, r12, lr}}
{replay}
b.w #{site+4}'''
            hook = b.append_asm('Bound original local rank index ' + hex(site), source)
            b.patch(site, b.branch(site, hook), 'Normalize native ranking switch/layout index', expected)
            output['tab_loads'].append({'site': site, 'hook': hook, 'source': src,
                                        'destination': dst, 'signed': False, 'size': 4, 'replay': replay})

    hero = 0x4f7eb8 if b.is64 else 0x31cd3e
    if b.is64:
        source = f'''{A64_SAVE}
ldrb w0, [sp, #0x268]
bl #{symbols['yagu_rank_hero_player']}
cbz x0, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{b.sym(HERO)}'''
    else:
        source = f'''{T32_SAVE}
ldrb r0, [sp, #0x17f]
bl #{symbols['yagu_rank_hero_player']}
cmp r0, #0
beq original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{b.sym(HERO)}'''
    hook = b.append_asm('Resolve original rank hero row to selected My role', source)
    checked_call(b, hero, hook, 0x72d860 if b.is64 else 0x470240,
                 'Select owned pitcher for the existing pitching hero row')
    output['hero_call'] = {'site': hero, 'hook': hook}

    # AddData chooses 3 versus 2 decimal digits from mode alone. Select the table
    # role for this one caller so finite opposing pitcher ratios retain units.
    decimal = 0x4f8f64 if b.is64 else 0x31d7b4
    if b.is64:
        source = f'''{A64_SAVE}
{rank_parent_context(b, decimal, 'x8')}
ldr x0, [x8, #0x1a0]
mov x1, #0
bl #{symbols['yagu_rank_is_batter']}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original_role}'''
    else:
        source = f'''{T32_SAVE}
{rank_parent_context(b, decimal, 'r2')}
ldr r0, [r2, #0x120]
movs r1, #0
bl #{symbols['yagu_rank_is_batter']}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original_role}'''
    hook = b.append_asm('Keep original rank decimal precision for selected role', source)
    checked_call(b, decimal, hook, 0x72db90 if b.is64 else 0x470570,
                 'Use batting/pitching ratio units in original ranking cells')
    output['decimal_role_call'] = {'site': decimal, 'hook': hook}
    return output
