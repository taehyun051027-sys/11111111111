"""Nine exact local SUPER call sites, retaining the original skill/event path."""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE


# label, original call, expected bytes, helper kind, role, old-SP this slot,
# this->GameRun field. Roles are BAT0 and PIT1. Offsets are before our push.
SITES = {
    'arm64-v8a': (
        ('pit_enter_mode', 0x3bad30, '94ce0d94', 'mode', 1, 0x28, 0x368),
        ('pit_use_mode', 0x3bed3c, '91be0d94', 'mode', 1, 0x08, 0x368),
        ('pit_enter_stock', 0x3bad48, '8ed10d94', 'count', 1, 0x28, 0x368),
        ('bat_visible_stock', 0x3e7214, '5b200d94', 'count', 0, 0x90, 0x158),
        ('bat_use_stock', 0x3e9d18, '9a150d94', 'count', 0, 0x18, 0x158),
        ('pit_use_spend', 0x3bed4c, '89c10d94', 'add', 1, 0x08, 0x368),
        ('bat_use_spend', 0x3e9e28, '52150d94', 'add', 0, 0x18, 0x158),
        ('bat_stock_text', 0x3e7248, '63070094', 'format', 0, 0x90, 0x158),
        ('pit_stock_text', 0x3bc5b0, 'fe060094', 'format', 1, 0x60, 0x368),
    ),
    'armeabi-v7a': (
        ('pit_enter_mode', 0x24a59a, '26f2eaed', 'mode', 1, 0x34, 0x2bc),
        ('pit_use_mode', 0x24d49a, '23f26aee', 'mode', 1, 0x0c, 0x2bc),
        ('pit_enter_stock', 0x24a5a8, '27f2eaeb', 'count', 1, 0x34, 0x2bc),
        ('bat_visible_stock', 0x268d64, '09f20ce8', 'count', 0, 0x60, 0x114),
        ('bat_use_stock', 0x26aa56, '07f294e9', 'count', 0, 0x10, 0x114),
        ('pit_use_spend', 0x24d4a6, '24f264ec', 'add', 1, 0x0c, 0x2bc),
        ('bat_use_spend', 0x26ab04, '07f234e9', 'add', 0, 0x10, 0x114),
        ('bat_stock_text', 0x268d84, '01f00efa', 'format', 0, 0x60, 0x114),
        ('pit_stock_text', 0x24b764, '01f0dcfa', 'format', 1, 0x54, 0x2bc),
    ),
}
HELPERS = {'mode': 'yagu_special_live_mode', 'count': 'yagu_special_live_count',
           'add': 'yagu_special_live_add', 'format': 'yagu_format_special_live'}


def add_special_uses_hooks(b, symbols):
    output = []
    for label, site, expected, kind, role, slot, field in SITES[b.abi]:
        instruction = next(b.cs.disasm(bytes.fromhex(expected), site))
        if instruction.mnemonic not in ('bl', 'blx') or instruction.size != 4:
            raise ValueError('Not an original call: ' + hex(site))
        target = int(instruction.op_str[1:], 16)
        helper = symbols[HELPERS[kind]]
        game_arg, role_arg = (1, 2) if kind == 'count' else (2, 3)
        if b.is64:
            load = f'''ldr x{game_arg}, [sp, #{slot + 80}]
cbz x{game_arg}, original
ldr x{game_arg}, [x{game_arg}, #{field}]
mov w{role_arg}, #{role}'''
            checked = 'tbnz w0, #31, original' if kind == 'format' else ''
            result = 'str x0, [sp]' if kind != 'add' else ''
            source = f'''{A64_SAVE}
{load}
bl #{helper}
{checked}
{result}
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{target}'''
        else:
            load = f'''ldr.w r{game_arg}, [sp, #{slot + 24}]
cmp r{game_arg}, #0
beq original
ldr.w r{game_arg}, [r{game_arg}, #{field}]
movs r{role_arg}, #{role}'''
            checked = 'cmp r0, #0\nblt original' if kind == 'format' else ''
            result = 'str r0, [sp]' if kind != 'add' else ''
            source = f'''{T32_SAVE}
{load}
bl #{helper}
{checked}
{result}
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{target}'''
        hook = b.append_asm('Typed special stock: ' + label, source)
        b.patch(site, b.branch(site, hook, True), 'Owned special-use ' + kind, expected)
        output.append(dict(label=label, site=site, hook=hook, kind=kind, role=role,
                           this_slot=slot, game_field=field, original=target))
    return output
