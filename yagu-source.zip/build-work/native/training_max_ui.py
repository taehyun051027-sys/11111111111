"""Use infinity in the original two training MAX cells for the My role actors."""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

FONT = 'CBBGStatic::GetChangeFont(CBBStringBuffer&, char const*, int, int, short, short, short, short)'
SITES = {'arm64-v8a': ((0x50ce3c, '218b0894'), (0x50d928, '66880894')),
         'armeabi-v7a': ((0x32ad5c, '47f1b8eb'), (0x32b5c8, '46f182ef'))}


def add_training_max_ui_hooks(b, symbols):
    predicate = symbols['yagu_state'] & ~int(not b.is64)
    original = b.sym(FONT)
    text = b.append('Training unbounded UTF-8 constant', '\u221e\0'.encode())
    exports = []
    for site, expected in SITES[b.abi]:
        if b.is64:
            source = f'''{A64_SAVE}
ldr x0, [sp, #0x4c8]
cbz x0, original
ldr x0, [x0, #0x38]
cbz x0, original
bl #{predicate}
cbz x0, original
{A64_RESTORE}
adrp x1, #{text & ~0xfff}
add x1, x1, #{text & 0xfff}
b #{original}
original:
{A64_RESTORE}
b #{original}'''
        else:
            delta = (text - (site + 5)) & 0xffffffff
            source = f'''{T32_SAVE}
ldr.w r0, [sp, #0x364]
cmp r0, #0
beq original
ldr r0, [r0, #0x24]
cmp r0, #0
beq original
bl #{predicate}
cmp r0, #0
beq original
{T32_RESTORE}
movw r1, #{delta & 0xffff}
movt r1, #{delta >> 16}
add r1, lr
b.w #{original}
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Training MAX cell owned infinity', source)
        b.patch(site, b.branch(site, hook, True), 'Original training MAX text for My role', expected)
        exports.append({'site': site, 'hook': hook, 'text': text, 'original': original})
    return exports
