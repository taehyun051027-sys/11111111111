"""Run the finite NPC policy and the original stat consumers on both ARM ABIs.

This stages a private C copy; it never edits the shared payload or an APK. The
original ELF is hash gated. PLT jumps are resolved to the original local symbols
as Android's linker would resolve them. Singleton access is the only callback
in the main original GetStatus/GetCurBatter/GetCurPitcher execution. Item bonus
boundary tests separately stub GetAddStatus, and say so in the report.
"""
import argparse
import hashlib
import json
import struct
import sys
import zipfile
from pathlib import Path

from patch_builder import PatchBuilder
import payload_builder
from payload_builder import HOOKS
from elite_world_policy import stage_payload
from verify_relocation import prepare_case, TEAMS, TEAM, BAT, PIT, SAVE
from verify_gameplay_hooks import HEAP, MGR, SP, STOP, GETMODE, GETMGR, GETBAT, GETPIT
from unicorn.arm64_const import UC_ARM64_REG_TPIDR_EL0

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'analysis/data/tools'))
from zt1_codec import RecordTable, unpack_zt1

STRIDE = 0x3b4
OPTION = HEAP + 0x61000
ENTRY = HEAP + 0x63000
DEFINE = HEAP + 0x64000
LOADER = HEAP + 0x65000
GXL_RAW = HEAP + 0x66000
GXL_OFFSETS = HEAP + 0x67000
TLS = HEAP + 0x68000
COPY_TEAMS = HEAP + 0x70000
OUTSIDE = HEAP + 0x99000
APK_SHA = '2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484'


def invoke(c, address, *args):
    c.stopped = None
    c.stops = {STOP}
    c.uc.reg_write(c.sp, SP)
    c.uc.reg_write(c.lr, STOP if c.is64 else STOP | 1)
    for i, value in enumerate(args):
        c.r(i, value & ((1 << (64 if c.is64 else 32)) - 1))
    c.run_relative(address)
    assert c.stopped == STOP and c.uc.reg_read(c.sp) == SP
    return c.r(0)


def original_plt(c):
    """Resolve every defined original PLT symbol; no original method is mocked."""
    b = c.b
    dyn = b.elf.get_section_by_name('.dynsym')
    defined = {v['mangled']: v['address'] for v in b.symbols.values()}
    start = b.elf.get_section_by_name('.plt')['sh_addr']
    rels = b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
    for index, rel in enumerate(rels.iter_relocations()):
        name = dyn.get_symbol(rel['r_info_sym']).name
        if name not in defined: continue
        destination = (defined[name] + c.slide) | int(not b.is64)
        c.callbacks[start + 32 + index*16 + c.slide] = (
            lambda destination=destination: c.uc.reg_write(c.pc, destination))


def read_rosters():
    path = ROOT/'upload/baseball-superstars-2013-1-2-9.apk'
    assert hashlib.sha256(path.read_bytes()).hexdigest() == APK_SHA
    with zipfile.ZipFile(path) as z:
        records = {}
        for role, filename, stride, count in (
                ('bat', 'XlsBATTER_DATA.zt1', 44, 180),
                ('pit', 'XlsPITCHER_DATA.zt1', 52, 120)):
            table = RecordTable.parse(unpack_zt1(z.read('assets/data/'+filename)))
            assert table.row_stride == stride and table.row_count == count
            records[role] = [table.row(i) for i in range(count)]
        records['init'] = RecordTable.parse(unpack_zt1(z.read('assets/data/XlsInitAbil.zt1')))
        assert records['init'].row_count == 8 and records['init'].row_stride == 8
    return records


def original_cap_table(c, table):
    """Initialize the observed GVXL ABI, then run actual GetVal/GetSize code."""
    b = c.b
    c.uc.mem_write(GXL_RAW, table.raw)
    c.uc.mem_write(GXL_OFFSETS, struct.pack('<'+'H'*len(table.offsets), *table.offsets))
    c.ptr(LOADER, GXL_RAW)
    c.ptr(LOADER+(8 if b.is64 else 4), GXL_OFFSETS)
    offset = 0x10 if b.is64 else 8
    c.uc.mem_write(LOADER+offset, struct.pack('<HHH', table.row_stride,table.row_count,len(table.types)))
    c.uc.mem_write(LOADER+(0x2c if b.is64 else 0x24), struct.pack('<i',2)) # GXL2 header delta
    c.ptr(DEFINE+(8 if b.is64 else 4),LOADER)
    name='CGsSingleton<CBBGMgrDefine>::GetInstPtr()'
    c.callbacks[b.sym(name)+c.slide]=lambda:c.ret(DEFINE)
    if b.is64:
        c.uc.reg_write(UC_ARM64_REG_TPIDR_EL0,TLS)
    else:
        dyn=b.elf.get_section_by_name('.dynsym')
        found=[]
        for relocation in b.elf.get_section_by_name('.rel.dyn').iter_relocations():
            if dyn.get_symbol(relocation['r_info_sym']).name=='__stack_chk_guard':
                c.ptr(c.slide+relocation['r_offset'],TLS)
                found.append(relocation['r_offset'])
        assert len(found)==1
    # libc's checked memory copy is the only imported data movement in GetVal.
    # We retain its explicit destination-bound check and copy exact guest bytes.
    dyn=b.elf.get_section_by_name('.dynsym')
    start=b.elf.get_section_by_name('.plt')['sh_addr']
    for index,rel in enumerate(b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt').iter_relocations()):
        if dyn.get_symbol(rel['r_info_sym']).name=='__memcpy_chk':
            def checked_copy():
                dest,source,size,bound=[c.r(i) for i in range(4)]
                assert size<=bound and bound==4
                c.uc.mem_write(dest,bytes(c.uc.mem_read(source,size)))
                c.ret(dest)
            c.callbacks[start+32+index*16+c.slide]=checked_copy


def fixture(b, payload, slide, rows, mode=4):
    c = prepare_case(b, slide)
    original_plt(c)
    c.callbacks.pop(b.sym(GETBAT)+slide, None)
    c.callbacks.pop(b.sym(GETPIT)+slide, None)
    c.callbacks[b.sym(GETMODE)+slide] = lambda: c.ret(mode)
    c.ptr(MGR + (0x518 if b.is64 else 0x4e0), OPTION)
    c.ptr(MGR + (0x528 if b.is64 else 0x4e8), SAVE if mode == 4 else 0)
    c.ptr(MGR + (0x520 if b.is64 else 0x4e4), SAVE if mode == 3 else 0)
    original_cap_table(c,rows['init'])
    for team in range(15):
        base = TEAMS + 8 + team*STRIDE
        c.uc.mem_write(base, bytes([team, 0, 8, 12]))
        for i in range(8): c.uc.mem_write(base+4+i*52, rows['pit'][team*8+i])
        for i in range(12): c.uc.mem_write(base+0x1a4+i*44, rows['bat'][team*12+i])
    c.uc.mem_write(BAT, struct.pack('<H', 1000))
    c.uc.mem_write(PIT, struct.pack('<H', 1100))
    return c


def expected_status(pure, level, grade, skills, enabled, rfid, extra=0, add=False):
    value = pure if rfid >= 2000 else pure + level*(grade+3)
    value = min(3500, value & 65535)
    if add: value = min(3500, value+extra) & 65535
    if enabled:
        for skill, delta in ((13, -50), (15, 50), (16, 50), (17, 50)):
            if skills & (1 << skill): value = min(2100, max(0, value+delta))
        if skills & (1 << 10): value //= 2
    return value


def verify(abi, rows):
    shared_sha = hashlib.sha256((WORK/'yagu_payload.c').read_bytes()).hexdigest()
    stage = WORK/'elite_world_build'/abi/'source'
    manifest = stage_payload(stage)
    b = PatchBuilder(abi, (ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
    old_root = payload_builder.ROOT
    try:
        payload_builder.ROOT = stage
        payload = payload_builder.add_payload(b, workdir=WORK/'elite_world_build'/abi)
    finally:
        payload_builder.ROOT = old_root
    assert hashlib.sha256((WORK/'yagu_payload.c').read_bytes()).hexdigest() == shared_sha
    s = payload['symbols']
    slide = 0x7654321000 if b.is64 else 0x96521000
    level = b.sym(HOOKS['level'])
    status = b.sym(HOOKS['status'])
    counts = {}
    checks = []

    # Every active slot across the exact fifteen real teams, in both career modes.
    for mode in (3, 4):
        c = fixture(b, payload, slide, rows, mode)
        snapshot = bytes(c.uc.mem_read(TEAMS, 0x3b48))
        for team in range(15):
            for role, total, offset, stride in (('pit', 8, 4, 52), ('bat', 12, 0x1a4, 44)):
                for index in range(total):
                    actor = TEAMS + 8 + team*STRIDE + offset + index*stride
                    ident = struct.unpack('<H', c.uc.mem_read(actor, 2))[0]
                    assert invoke(c, s['yagu_elite_npc'], actor) == int(ident not in (1000, 1100))
                    assert invoke(c, level, actor) == 250
                    assert bool(invoke(c, s['yagu_state'], actor)) == (ident in (1000, 1100))
                    counts['active_roster_slots'] = counts.get('active_roster_slots', 0) + 1
        assert bytes(c.uc.mem_read(TEAMS, 0x3b48)) == snapshot
    checks.append('All 15 active team rosters retain bytes, grades and skill masks; only My IDs have tagged infinity.')

    # Reject interior/header/inactive/spare/copy addresses before reading actor data.
    c = fixture(b, payload, slide, rows)
    bad = [0, 1, TEAMS-1, TEAMS, TEAMS+4, TEAMS+8, TEAMS+8+1,
           TEAMS+8+4+1, TEAMS+8+0x1a4+1,
           TEAMS+8+15*STRIDE, TEAMS+8+15*STRIDE+4,
           TEAMS+8+15*STRIDE+0x1a4, TEAMS+8+16*STRIDE, OUTSIDE]
    for actor in bad:
        assert invoke(c, s['yagu_elite_npc'], actor) == 0
    counts['nonmember_addresses'] = len(bad)

    # Validate active counts at both role boundaries, and invalid-count rejection.
    base = TEAMS+8
    for pit_count, bat_count in ((0,0),(1,1),(7,11),(8,12),(9,12),(8,13),(255,255)):
        c.uc.mem_write(base+2, bytes([pit_count,bat_count]))
        for role,total,offset,stride in (('pit',8,4,52),('bat',12,0x1a4,44)):
            for index in range(total):
                expected = int(pit_count <= 8 and bat_count <= 12 and index < (pit_count if role == 'pit' else bat_count))
                assert invoke(c,s['yagu_elite_npc'],base+offset+index*stride) == expected
                counts['active_slot_bounds'] = counts.get('active_slot_bounds',0)+1

    exclusions = ['no_manager','no_roster','no_save','wrong_save_only','own_negative','own15',
                  'own_invalid_count','missing_my_role','mode0','mode1','mode2','mode5','mode6']
    for mode in (3,4):
        for kind in exclusions:
            d = fixture(b,payload,slide,rows,mode)
            actor = TEAMS+8+0x1a4
            if kind == 'no_manager': d.callbacks[b.sym(GETMGR)+slide] = lambda d=d: d.ret(0)
            elif kind == 'no_roster': d.ptr(MGR+(0x530 if b.is64 else 0x4ec),0)
            elif kind in ('no_save','wrong_save_only'):
                d.ptr(MGR+((0x520 if b.is64 else 0x4e4) if mode==3 else (0x528 if b.is64 else 0x4e8)),0)
                if kind == 'wrong_save_only': d.ptr(MGR+((0x528 if b.is64 else 0x4e8) if mode==3 else (0x520 if b.is64 else 0x4e4)),SAVE)
            elif kind == 'own_negative': d.uc.mem_write(TEAMS+4,struct.pack('<i',-1))
            elif kind == 'own15': d.uc.mem_write(TEAMS+4,struct.pack('<i',15))
            elif kind == 'own_invalid_count': d.uc.mem_write(TEAM+2,b'\xff')
            elif kind == 'missing_my_role': d.uc.mem_write(PIT if mode==3 else BAT,struct.pack('<H',99))
            else:
                other_mode=int(kind[-1])
                d.callbacks[b.sym(GETMODE)+slide]=lambda d=d, other_mode=other_mode:d.ret(other_mode)
            assert invoke(d,s['yagu_elite_npc'],actor)==0,(abi,mode,kind)
            fallback=[]
            def original_level(d=d):
                fallback.append(d.r(0));d.ret(37)
            d.callbacks[payload['original_bindings']['original_level']+slide]=original_level
            assert invoke(d,level,actor)==37 and fallback==[actor]
            counts['excluded_contexts'] = counts.get('excluded_contexts',0)+1
            pure_fallback=[]
            def original_pure(d=d):
                pure_fallback.append((d.r(0),d.r(1)));d.ret(81)
            d.callbacks[payload['original_bindings']['original_pure_status']+slide]=original_pure
            assert invoke(d,b.sym(HOOKS['pure_status']),actor,2)==81 and pure_fallback==[(actor,2)]
            counts['excluded_pure_contexts']=counts.get('excluded_pure_contexts',0)+1
    checks.append('Header/interior/stale/spare16th-team pointers, inactive slots and unrelated modes preserve original level fallback.')

    # Read-only getter policy follows an actual relocated roster and later level writes.
    c=fixture(b,payload,slide,rows)
    actor=TEAMS+8+0x1a4
    source=bytes(c.uc.mem_read(TEAMS,0x3b48))
    c.uc.mem_write(COPY_TEAMS,source)
    c.ptr(MGR+(0x530 if b.is64 else 0x4ec),COPY_TEAMS)
    assert invoke(c,s['yagu_elite_npc'],actor)==0
    assert invoke(c,s['yagu_elite_npc'],actor+COPY_TEAMS-TEAMS)==1
    moved=actor+COPY_TEAMS-TEAMS
    assert invoke(c,level,moved)==250
    for stored in (1,37,230,250):
        invoke(c,b.sym(HOOKS['set_level']),moved,stored)
        assert bytes(c.uc.mem_read(moved+0x16,1))==bytes([stored])
        assert invoke(c,level,moved)==250
    counts['relocation_and_replacement_level'] = 7
    checks.append('A copied/reloaded team container is recognized only after DataMgr points to it; new stored levels stay intact while effective level is 250.')

    # Actual game entry -> actual team lookup -> actual actor slot, not copied UI data.
    for mode in (3,4):
        c=fixture(b,payload,slide,rows,mode)
        for team in range(15):
            c.uc.mem_write(ENTRY,bytes(0x80))
            c.uc.mem_write(ENTRY+0x24,bytes([mode,team]))
            c.uc.mem_write(ENTRY+0x32,b'\x02')
            c.uc.mem_write(ENTRY+0x0e+2,b'\x03')
            c.uc.mem_write(ENTRY,b'\x02')
            for name,expected in ((GETBAT,TEAMS+8+team*STRIDE+0x1a4+3*44),
                                  (GETPIT,TEAMS+8+team*STRIDE+4+2*52)):
                actual=invoke(c,b.sym(name),ENTRY)
                assert actual==expected,(abi,mode,team,name,hex(actual),hex(expected))
                assert invoke(c,level,actual)==250
                counts['original_match_entry_lookups']=counts.get('original_match_entry_lookups',0)+1
    checks.append('Original live GetCurBatter/GetCurPitcher, GetTeamPtr and TeamData methods consume the exact elite roster slots.')

    # Every original table row through the scoped pure getter and original
    # grade/status arithmetic and
    # original min/max functions. Select a non-My live roster slot for each role.
    c=fixture(b,payload,slide,rows)
    result_ranges={}
    for role,offset in (('bat',0x1a4),('pit',4)):
        actor=TEAMS+8+offset
        observed=[]
        for raw in rows[role]:
            c.uc.mem_write(actor,raw)
            rfid=struct.unpack_from('<H',raw)[0]
            grade=raw[0x17]&15
            for part in range(4):
                pure=struct.unpack_from('<H',raw,0x18+part*2)[0]
                actual=invoke(c,status,actor,part,0,0)
                assert invoke(c,b.sym(HOOKS['pure_status']),actor,part)==1400
                expected=expected_status(1400,250,grade,0,False,rfid)
                assert actual==expected,(abi,role,rfid,part,actual,expected)
                observed.append(actual)
                counts['original_stat_table_values']=counts.get('original_stat_table_values',0)+1
            assert bytes(c.uc.mem_read(actor,len(raw)))==raw
        result_ranges[role]=[min(observed),max(observed)]

    # All possible stored grade nibbles remain unchanged. Exercise actual skill
    # masks including each 2100-bound branch and final half-value branch.
    actor=TEAMS+8+0x1a4
    skill_masks=[0,1<<13,1<<15,1<<16,1<<17,1<<10,
                 (1<<13)|(1<<15)|(1<<16)|(1<<17),
                 (1<<13)|(1<<15)|(1<<16)|(1<<17)|(1<<10)]
    for grade in range(16):
        for pure in (0,170,2000,3500):
            raw=bytearray(rows['bat'][0]);raw[0x17]=(raw[0x17]&0xf0)|grade
            struct.pack_into('<H',raw,0x18,pure)
            for mask in skill_masks:
                struct.pack_into('<I',raw,0x24,mask)
                c.uc.mem_write(actor,bytes(raw))
                actual=invoke(c,status,actor,0,0,1)
                expected=expected_status(1400,250,grade,mask,True,1)
                assert actual==expected,(abi,grade,pure,hex(mask),actual,expected)
                assert bytes(c.uc.mem_read(actor,44))==bytes(raw)
                counts['original_grade_skill_clamps']=counts.get('original_grade_skill_clamps',0)+1
    checks.append('Original GetStatus/GsMin/GsMinMax consume finite pure1400 for all original rows and all 16 grade nibbles; 3500/2100 clamps and skill-halving survive.')

    # The item subsystem is intentionally outside this test fixture. Execute the
    # original item-add/clamp consumer with a stub only at GetAddStatus boundary.
    for extra in (0,50,1000,3500):
        raw=bytearray(rows['bat'][0]);struct.pack_into('<H',raw,0x18,2000)
        struct.pack_into('<I',raw,0x24,0)
        c.uc.mem_write(actor,bytes(raw))
        c.callbacks[b.sym('CBBGPlayerData::GetAddStatus(EnumBodyPart)')+slide]=lambda extra=extra:c.ret(extra)
        expected=expected_status(1400,250,0,0,False,1,extra,True)
        assert invoke(c,status,actor,0,1,0)==expected
        counts['original_item_clamp_boundary']=counts.get('original_item_clamp_boundary',0)+1
    c.callbacks.pop(b.sym('CBBGPlayerData::GetAddStatus(EnumBodyPart)')+slide)

    # Original GXL data and original setter/add paths, including the original
    # style5 pitcher whose computed cap row8 is out of bounds (GetVal returns0).
    c=fixture(b,payload,slide,rows)
    for row in range(8):
        for part in range(4):
            expected=struct.unpack_from('<h',rows['init'].row(row),part*2)[0]
            assert invoke(c,b.sym('GVXLLoader::GetVal(int, int)'),LOADER,part,row)==expected
            counts['original_gxl_cap_table']=counts.get('original_gxl_cap_table',0)+1
    style_counts={}
    original_style_anomalies=[]
    for role,offset in (('bat',0x1a4),('pit',4)):
        actor=TEAMS+8+offset
        style_counts[role]={}
        for raw in rows[role]:
            style=raw[0x22]>>4
            style_counts[role][style]=style_counts[role].get(style,0)+1
            cap_row=style//2+(6 if role=='pit' else 2)
            if cap_row>=rows['init'].row_count:
                original_style_anomalies.append({'role':role,'rfid':struct.unpack_from('<H',raw)[0],
                                                 'style':style,'original_cap_row':cap_row,
                                                 'original_setter_cap':0})
            for part in range(4):
                c.uc.mem_write(actor,raw)
                before=bytes(c.uc.mem_read(actor,len(raw)))
                invoke(c,b.sym(HOOKS['set_status']),actor,part,10000)
                expected=struct.unpack_from('<h',rows['init'].row(cap_row),part*2)[0] if cap_row<8 else 0
                after=bytes(c.uc.mem_read(actor,len(raw)))
                expected_bytes=bytearray(before);struct.pack_into('<H',expected_bytes,0x18+part*2,expected)
                assert after==bytes(expected_bytes),(abi,role,part,style,after.hex())
                assert invoke(c,b.sym(HOOKS['pure_status']),actor,part)==1400
                assert invoke(c,status,actor,part,0,0)==2150
                if cap_row>=8:
                    assert struct.unpack('<I',c.uc.mem_read(LOADER+(0x18 if b.is64 else 0x10),4))[0]==0x100
                counts['original_setter_all_rows_parts']=counts.get('original_setter_all_rows_parts',0)+1
        for style in style_counts[role]:
            sample=next(raw for raw in rows[role] if raw[0x22]>>4==style)
            cap_row=style//2+(6 if role=='pit' else 2)
            for part in range(4):
                for delta in (-1,1):
                    c.uc.mem_write(actor,sample)
                    invoke(c,b.sym(HOOKS['add_status']),actor,part,delta)
                    expected=min(1400,1400+delta) if cap_row<8 else 0
                    assert struct.unpack('<H',c.uc.mem_read(actor+0x18+part*2,2))[0]==expected
                    assert invoke(c,b.sym(HOOKS['pure_status']),actor,part)==1400
                    counts['original_add_status_styles']=counts.get('original_add_status_styles',0)+1
    checks.append('Actual GVXL GetVal/GetSize read XlsInitAbil and actual SetStatus/AddStatus retain their stored-value clamps for every original NPC style; original RFID471 style5 row8 error is preserved and reported.')

    # Only parts0..3 qualify. Wrong pointers/contexts retain the original pure
    # getter call ABI without permitting a synthetic out-of-range memory read.
    for actor,part in ((TEAMS+8+0x1a4,-1),(TEAMS+8+0x1a4,4),(TEAMS+8+0x1a4,99),
                       (BAT,-1),(BAT,4),(PIT,-1),(PIT,4),(OUTSIDE,0),(0,0)):
        seen=[]
        def pure_fallback():
            seen.append((c.r(0),c.r(1)&0xffffffff));c.ret(123)
        c.callbacks[payload['original_bindings']['original_pure_status']+slide]=pure_fallback
        assert invoke(c,b.sym(HOOKS['pure_status']),actor,part)==123
        assert seen==[(actor,part&0xffffffff)]
        counts['pure_invalid_parts_and_nonmembers']=counts.get('pure_invalid_parts_and_nonmembers',0)+1
    c.callbacks.pop(payload['original_bindings']['original_pure_status']+slide)

    # My actors still use their old semantic adapter. Out-of-roster actor uses
    # the actual original GetLevel and GetStatus (no fallback result mock).
    c=fixture(b,payload,slide,rows)
    for hero in (BAT,PIT):
        assert invoke(c,s['yagu_elite_npc'],hero)==0
        assert invoke(c,status,hero,0,0,0)==10000
    raw=bytearray(rows['bat'][0]);raw[0x16]=37
    struct.pack_into('<H',raw,0,2000) # Original HOF rule keeps raw status, no level bonus.
    c.uc.mem_write(OUTSIDE,bytes(raw))
    assert invoke(c,level,OUTSIDE)==37
    assert invoke(c,status,OUTSIDE,0,0,0)==struct.unpack_from('<H',raw,0x18)[0]
    counts['my_and_original_nonmember_status']=4
    # Other actor classes keep the original HOF/no-growth branch even when
    # occupying a live roster slot. No grade or role exception is rewritten.
    for ident in (800,810,2000,3000):
        actor=TEAMS+8+0x1a4
        raw=bytearray(rows['bat'][0]);struct.pack_into('<H',raw,0,ident)
        c.uc.mem_write(actor,bytes(raw))
        assert invoke(c,s['yagu_elite_npc'],actor)==1
        assert invoke(c,status,actor,0,0,0)==(1400 if ident>=2000 else 2150)
        counts['original_actor_class_branches']=counts.get('original_actor_class_branches',0)+1

    assert hashlib.sha256((WORK/'yagu_payload.c').read_bytes()).hexdigest()==shared_sha
    return {'abi':abi,'original_library_sha256':b.sha,'source':manifest,
            'policy_header_sha256':hashlib.sha256((WORK/'elite_world_policy.h').read_bytes()).hexdigest(),
            'load_bias':hex(slide),'case_counts':counts,'total':sum(counts.values()),
            'finite_npc_level':250,'finite_npc_pure_status':1400,
            'original_data_base_status_ranges':result_ranges,
            'original_style_counts':style_counts,'original_style_anomalies':original_style_anomalies,
            'checks':checks,'shared_source_modified':False,'android_runtime_verified':False,
            'limits':['No Android startup or full game is established by instruction execution.',
                      'The main status fixture has original game-running option false, so consumable store-item match effects are not exercised.',
                      'GetAddStatus is stubbed only for the four explicitly counted item-clamp boundary cases.',
                      'The only imported GVXL operation is a bound-checked memcpy callback; table GetVal/GetSize and original setters execute.',
                      'No new grade, skill, facility, season-count or career-year policy is implemented.']}


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--abi',choices=('arm64-v8a','armeabi-v7a'))
    args=parser.parse_args()
    rows=read_rosters()
    results=[verify(abi,rows) for abi in ([args.abi] if args.abi else ('arm64-v8a','armeabi-v7a'))]
    output=WORK/('elite_world_verification_'+args.abi+'.json' if args.abi else 'elite_world_verification.json')
    output.write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(results,indent=2))
