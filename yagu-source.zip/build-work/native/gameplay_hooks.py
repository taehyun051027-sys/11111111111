"""Actor-scoped gameplay instrumentation for one hash-locked private game copy.

The engine's existing scoring / record / inning transitions consume the normal
batting-result aggregate and pitch-judge values. This module does not fabricate
the scorecard or overwrite completed-game records. Android gameplay verification
is a separate gate from the instruction-level tests accompanying this module.
"""
from pathlib import Path
from patch_builder import PatchBuilder

BAT = 'CBBGLevelMgr::BattingProcess(CBBGEntryMgr*, CBBGEntryMgr*, CBBGRunnerMgr*, int, EnumBuntType, int, int, bbtagAcePlayerBonus, int, unsigned char, unsigned char, int, CBBGStatisticsMgr*, int, unsigned char, eBallType, unsigned char)'
GETBAT = 'CBBGEntryMgr::GetCurBatter()'
GETPIT = 'CBBGEntryMgr::GetCurPitcher()'
GETMODE = 'CBBGStatic::GetCurGameMode()'
GETMGR = 'CGsSingleton<CBBGDataMgr>::GetInstPtr()'

A64_SAVE = '''sub sp, sp, #80
stp x0, x1, [sp, #0]
stp x2, x3, [sp, #16]
stp x4, x5, [sp, #32]
stp x6, x7, [sp, #48]
stp x8, x30, [sp, #64]'''
A64_RESTORE = '''ldp x0, x1, [sp, #0]
ldp x2, x3, [sp, #16]
ldp x4, x5, [sp, #32]
ldp x6, x7, [sp, #48]
ldp x8, x30, [sp, #64]
add sp, sp, #80'''
T32_SAVE = 'push.w {r0-r3, r12, lr}'
T32_RESTORE = 'pop.w {r0-r3, r12, lr}'

def add_ownership_helper(b):
    """Entry manager belongs to the active My career, with null/mode guards."""
    mode, mgr = b.sym(GETMODE), b.sym(GETMGR)
    if b.is64:
        source=f'''stp x0, x30, [sp, #-16]!
cbz x0, no
bl #{mode}
cmp w0, #3
b.eq career
cmp w0, #4
b.ne no
career:
bl #{mgr}
cbz x0, no
ldr x0, [x0, #0x530]
cbz x0, no
ldr w8, [x0, #4]
ldr x0, [sp]
ldrsb w9, [x0, #0x25]
cmp w8, w9
cset w0, eq
b done
no:
mov w0, #0
done:
ldr x30, [sp, #8]
add sp, sp, #16
ret'''
    else:
        source=f'''push {{r0, lr}}
cmp r0, #0
beq no
bl #{mode}
cmp r0, #3
beq career
cmp r0, #4
bne no
career:
bl #{mgr}
cmp r0, #0
beq no
ldr.w r0, [r0, #0x4ec]
cmp r0, #0
beq no
ldr r1, [r0, #4]
ldr r0, [sp]
ldrsb.w r0, [r0, #0x25]
cmp r0, r1
beq yes
no:
movs r0, #0
b done
yes:
movs r0, #1
done:
pop {{r1, pc}}'''
    return b.append_asm('Entry belongs to active My career',source)

def batting(b, tramp, owned):
    getbat, getpit = b.sym(GETBAT), b.sym(GETPIT)
    if b.is64:
        return f'''{A64_SAVE}
mov x0, x1
cbz x0, check_pitcher
bl #{getbat}
cbz x0, check_pitcher
ldrh w9, [x0]
cmp w9, #1000
b.ne check_pitcher
ldr x0, [sp, #8]
bl #{owned}
cbnz w0, own_home_run
check_pitcher:
ldr x0, [sp, #16]
cbz x0, unscoped
bl #{getpit}
cbz x0, unscoped
ldrh w9, [x0]
cmp w9, #1100
b.ne unscoped
ldr x0, [sp, #16]
bl #{owned}
cbnz w0, opponent_miss
unscoped:
{A64_RESTORE}
b #{tramp}
own_home_run:
{A64_RESTORE}
movz x0, #0x0101, lsl #48
mov x1, #21
ret
opponent_miss:
{A64_RESTORE}
mov x0, #0
mov x1, #0
ret'''
    return f'''{T32_SAVE}
mov r0, r2
cmp r0, #0
beq check_pitcher
bl #{getbat}
cmp r0, #0
beq check_pitcher
ldrh r1, [r0]
movw r2, #1000
cmp r1, r2
bne check_pitcher
ldr r0, [sp, #8]
bl #{owned}
cmp r0, #0
bne own_home_run
check_pitcher:
ldr r0, [sp, #12]
cmp r0, #0
beq unscoped
bl #{getpit}
cmp r0, #0
beq unscoped
ldrh r1, [r0]
movw r2, #1100
cmp r1, r2
bne unscoped
ldr r0, [sp, #12]
bl #{owned}
cmp r0, #0
bne opponent_miss
unscoped:
{T32_RESTORE}
b.w #{tramp}
own_home_run:
{T32_RESTORE}
movs r1, #0
str r1, [r0, #0]
movw r1, #0
movt r1, #0x0101
str r1, [r0, #4]
movs r1, #21
str r1, [r0, #8]
bx lr
opponent_miss:
{T32_RESTORE}
movs r1, #0
str r1, [r0, #0]
str r1, [r0, #4]
str r1, [r0, #8]
bx lr'''

def pitcher_bool(b, tramp, value, owned):
    getpit = b.sym(GETPIT)
    if b.is64:
        return f'''{A64_SAVE}
cbz x0, original
ldr x0, [x0, #0x418]
cbz x0, original
bl #{getpit}
cbz x0, original
ldrh w9, [x0]
cmp w9, #1100
b.ne original
ldr x0, [sp]
ldr x0, [x0, #0x418]
bl #{owned}
cbz w0, original
{A64_RESTORE}
mov w0, #{value}
ret
original:
{A64_RESTORE}
b #{tramp}'''
    return f'''{T32_SAVE}
cmp r0, #0
beq original
ldr.w r0, [r0, #0x2cc]
cmp r0, #0
beq original
bl #{getpit}
cmp r0, #0
beq original
ldrh r1, [r0]
movw r2, #1100
cmp r1, r2
bne original
ldr r0, [sp]
ldr.w r0, [r0, #0x2cc]
bl #{owned}
cmp r0, #0
beq original
{T32_RESTORE}
movs r0, #{value}
bx lr
original:
{T32_RESTORE}
b.w #{tramp}'''

def force_stamina(b, tramp):
    if b.is64:
        return f'''cbz x0, original
ldrh w8, [x0]
cmp w8, #1100
b.ne original
mov w1, #10000
original:
b #{tramp}'''
    return f'''cmp r0, #0
beq original
ldrh r2, [r0]
movw r3, #1100
cmp r2, r3
bne original
movw r1, #10000
original:
b.w #{tramp}'''

def no_stamina_depletion(b, tramp, owned, refill=True):
    getpit = b.sym(GETPIT)
    if b.is64:
        return f'''{A64_SAVE}
cbz x0, original
bl #{owned}
cbz w0, original
ldr x0, [sp]
bl #{getpit}
cbz x0, original
ldrh w9, [x0]
cmp w9, #1100
b.ne original
{('mov w9, #10000; str w9, [x0, #0x30]' if refill else '')}
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{tramp}'''
    return f'''{T32_SAVE}
cmp r0, #0
beq original
bl #{owned}
cmp r0, #0
beq original
ldr r0, [sp]
bl #{getpit}
cmp r0, #0
beq original
ldrh r1, [r0]
movw r2, #1100
cmp r1, r2
bne original
{('movw r1, #10000; str r1, [r0, #0x30]' if refill else '')}
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{tramp}'''

def add_timing_hook(b, owned):
    getbat = b.sym(GETBAT)
    if b.is64:
        # Replace one local-flag load. All caller volatile registers, SIMD
        # registers and NZCV are preserved except the original destination x8.
        save = '\n'.join(f'stp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0,18,2))
        restore = '\n'.join(f'ldp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0,18,2))
        qsave = '\n'.join(f'stp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0,32,2))
        qrestore = '\n'.join(f'ldp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0,32,2))
        source = f'''sub sp, sp, #704
{save}
stp x18, x30, [sp, #144]
mrs x8, nzcv
str x8, [sp, #160]
ldurb w8, [x29, #-0x8c]
str w8, [sp, #168]
{qsave}
ldr x0, [sp, #0x2f8]
cbz x0, done
ldr x0, [x0, #0x410]
cbz x0, done
bl #{getbat}
cbz x0, done
ldrh w9, [x0]
cmp w9, #1000
b.ne done
ldr x0, [sp, #0x2f8]
ldr x0, [x0, #0x410]
bl #{owned}
cbz w0, done
mov w8, #1
str w8, [sp, #168]
done:
{qrestore}
ldr x8, [sp, #160]
msr nzcv, x8
{restore}
ldp x18, x30, [sp, #144]
ldr w8, [sp, #168]
add sp, sp, #704
b #0x38d960'''
        address, expected = 0x38d95c, 'a8435738'
    else:
        # 24-byte register save + 8-byte scratch + 64-byte d0-d7 save.
        # Caller GameRun is at old sp+0x24 -> new sp+0x84.
        source = f'''push.w {{r0-r3, r12, lr}}
sub sp, sp, #8
mrs r0, apsr
str r0, [sp, #0]
ldrb r0, [r7, #-0x62]
str r0, [sp, #4]
vpush {{d0-d7}}
ldr r0, [sp, #0x84]
cmp r0, #0
beq done
ldr.w r0, [r0, #0x2c8]
cmp r0, #0
beq done
bl #{getbat}
cmp r0, #0
beq done
ldrh r1, [r0]
movw r2, #1000
cmp r1, r2
bne done
ldr r0, [sp, #0x84]
ldr.w r0, [r0, #0x2c8]
bl #{owned}
cmp r0, #0
beq done
movs r0, #1
str r0, [sp, #68]
done:
vpop {{d0-d7}}
ldr r0, [sp, #0]
msr apsr_nzcvq, r0
ldr r0, [sp, #4]
str r0, [sp, #8]
add sp, sp, #8
pop.w {{r0-r3, r12, lr}}
b.w #0x22e67c'''
        address, expected = 0x22e678, '17f8620c'
    hook = b.append_asm('My swing contact-time flag', source)
    b.patch(address, b.branch(address, hook), 'My swing enters original contact event even outside timing window', expected)
    return hook

def add_simulation_judge_hook(b, owned):
    judge = b.sym('CBBGRuleEngine::PitchJudge(unsigned char)')
    if b.is64:
        source = f'''{A64_SAVE}
ldur x8, [x29, #-0x48]
cbz x8, original
ldrh w9, [x8]
cmp w9, #1100
b.ne original
ldur x0, [x29, #-0x38]
cbz x0, original
ldr x0, [x0, #0x90]
bl #{owned}
cbz w0, original
{A64_RESTORE}
ldr x8, [x0, #0x10]
cbz x8, judge
strb wzr, [x8, #0x12]
strb wzr, [x8, #0x19]
strb wzr, [x8, #0x1a]
strb wzr, [x8, #0x24]
mov w1, #1
strb w1, [x8, #0x18]
b judge
original:
{A64_RESTORE}
judge:
b #{judge}'''
        address, expected = 0x40c514, 'e3970c94'
    else:
        source = f'''{T32_SAVE}
ldr r2, [sp, #0xa4]
cmp r2, #0
beq original
ldrh r2, [r2]
movw r3, #1100
cmp r2, r3
bne original
ldr r0, [sp, #0x6c]
cmp r0, #0
beq original
ldr r0, [r0, #0x78]
bl #{owned}
cmp r0, #0
beq original
{T32_RESTORE}
ldr r2, [r0, #8]
cmp r2, #0
beq judge
movs r3, #0
strb r3, [r2, #0x12]
strb r3, [r2, #0x19]
strb r3, [r2, #0x1a]
strb.w r3, [r2, #0x24]
movs r1, #1
strb r1, [r2, #0x18]
b judge
original:
{T32_RESTORE}
judge:
b.w #{judge}'''
        address, expected = 0x2808f6, 'f4f174ea'
    hook = b.append_asm('My pitcher simulation judge arguments', source)
    b.patch(address, b.branch(address, hook, True), 'Simulation passes guaranteed strike into original PitchJudge for My pitcher', expected)
    return hook

def add_gameplay_hooks(b):
    exported = {}
    owned = exported['owned_entry'] = add_ownership_helper(b)
    exported['batting'] = b.hook(BAT, lambda t: batting(b, t, owned))
    for name, value in [('IntersectStrikeZone(int, int)',1),('IsWildPitch()',0),('IsHitByPitcher()',0)]:
        if name == 'IsHitByPitcher()':
            from batting_rescue_hooks import owned_batter_and_pitcher_hbp
            exported[name] = b.hook('CBBGGameRun::'+name,
                lambda t: owned_batter_and_pitcher_hbp(b, t, owned))
        else:
            exported[name] = b.hook('CBBGGameRun::'+name, lambda t, v=value: pitcher_bool(b, t, v, owned))
    exported['timing'] = add_timing_hook(b, owned)
    exported['simulation_judge'] = add_simulation_judge_hook(b, owned)
    b.replace_function('CBBGRaiseMode::Initialize()',
        'mov w1, #9; strb w1, [x0, #0x517]; ret' if b.is64 else 'movs r1, #9; strb.w r1, [r0, #0x517]; bx lr')
    b.replace_function('CBBGRaiseMode::GetRaiseCubKind()',
        'mov w1, #9; strb w1, [x0, #0x517]; mov w0, #9; ret' if b.is64 else 'movs r1, #9; strb.w r1, [r0, #0x517]; movs r0, #9; bx lr')
    exported['league_setter'] = b.hook('CBBGRaiseMode::SetRaiseCubKind(int)',
        lambda t: f'mov w1, #9; b #{t}' if b.is64 else f'movs r1, #9; b.w #{t}')
    exported['stamina_setter'] = b.hook('CBBGPitcherData::SetStamina(int)', lambda t: force_stamina(b,t))
    exported['stamina_depletion'] = b.hook('CBBGEntryMgr::DecPitStaminaPer(int)', lambda t: no_stamina_depletion(b,t,owned))
    exported['protect_pitcher'] = b.hook('CBBGEntryMgr::RsvChangePitcher(int, unsigned char)', lambda t: no_stamina_depletion(b,t,owned,False))
    exported['allow_pitcher_change'] = b.hook('CBBGGameRun::DoCanBeChangePitcher(CBBGPitcherData*)', lambda t: pitcher_bool(b,t,0,owned))
    return exported

if __name__ == '__main__':
    import json
    root = Path(__file__).resolve().parents[2]
    for abi in ['arm64-v8a','armeabi-v7a']:
        original = (root/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes()
        builder = PatchBuilder(abi, original)
        exports = add_gameplay_hooks(builder)
        result = builder.finish(Path(__file__).parent/'candidates'/abi/'libgameDSO.so')
        print(json.dumps({'abi':abi,'hash':result['output_sha256'],'segment':result['rx_segment'],'exports':exports}))
