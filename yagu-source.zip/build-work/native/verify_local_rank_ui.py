"""Execute original local-rank font callsites with actual compiled typed state.

The test uses nonzero ELF slides with zero-bias memory unmapped. Only Android
singleton lookup and the final original font call are callbacks; actor ownership,
stable record lookup, role/category mapping and all authored hooks execute.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from payload_builder import add_payload
from local_rank_ui import add_local_rank_ui_hooks, FONT, BAT_METRICS, PIT_METRICS, PARENT_RETURN
from verify_relocation import prepare_case, BAT, PIT, TEAM, TEAMS, SAVE, RECORD
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
from unicorn.arm64_const import UC_ARM64_REG_X29
from unicorn.arm_const import UC_ARM_REG_R7

WORK = Path(__file__).resolve().parent
BAT_RECORD = SAVE + 0x1d8c + 4 * 0x120 + 5 * 24
INFINITY = '\u221e'


def invoke(c, address, *args, stop=STOP):
    c.stopped = None
    c.stops = {stop}
    c.uc.reg_write(c.sp, SP)
    c.uc.reg_write(c.lr, STOP if c.is64 else STOP | 1)
    for i, value in enumerate(args):
        c.r(i, value & ((1 << (64 if c.is64 else 32)) - 1))
    c.run_relative(address)
    assert c.stopped == stop and c.uc.reg_read(c.sp) == SP
    return c.r(0)


def owned_case(b, symbols, slide):
    c = prepare_case(b, slide)
    c.uc.mem_write(BAT_RECORD, struct.pack('<H', 1000))
    assert invoke(c, symbols['yagu_ensure_two_way'], MGR) == PIT
    return c


def parent_frame(c, role, local, row, actor, team, caller=None):
    """Construct only observed AddData caller locals, at original offsets."""
    parent_sp = SP + 0x2000
    frame = SP + 0x1000
    c.uc.reg_write(UC_ARM64_REG_X29 if c.is64 else UC_ARM_REG_R7, frame)
    c.ptr(frame, parent_sp + (0x3c0 if c.is64 else 0x2c8))
    c.ptr(frame + (8 if c.is64 else 4), (PARENT_RETURN[c.b.abi] if caller is None else caller) + c.slide)
    c.uc.mem_write(parent_sp + (0x1cc if c.is64 else 0x134), struct.pack('<i', row))
    c.uc.mem_write(parent_sp + (0x218 if c.is64 else 0x167), bytes([1-role]))
    c.uc.mem_write(parent_sp + (0x22c if c.is64 else 0x170), struct.pack('<i', local))
    for slot in ((0x158, 0x1d0) if c.is64 else (0xf8, 0x138)):
        c.ptr(parent_sp + slot, actor)
    for slot in ((0x14c, 0xa4) if c.is64 else (0xf0, 0x7c)):
        c.uc.mem_write(parent_sp + slot, struct.pack('<i', team))
    return parent_sp


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'local_rank_ui_build' / abi)
    symbols = payload['symbols']
    sites = add_local_rank_ui_hooks(b, symbols)
    slide = 0x7634521000 if b.is64 else 0x97421000
    c = owned_case(b, symbols, slide)
    counts = {'owned_metric_cells': 0, 'opponent_metric_cells': 0, 'excluded_contexts': 0}
    fallback_text = HEAP + 0x90000
    c.uc.mem_write(fallback_text, b'123\0')
    args = [HEAP + 0x91000, fallback_text, 1, 16, 255, 254, 0, 253]

    def font_case(case, site, expected):
        seen = []
        for i, value in enumerate(args):
            if i < (8 if b.is64 else 4): case.r(i, value)
            else: case.uc.mem_write(SP + (i - 4) * 4, struct.pack('<I', value))
        def font():
            actual = bytes(case.uc.mem_read(case.r(1), 4)).split(b'\0', 1)[0].decode()
            assert actual == expected, (abi, hex(site['site']), actual, expected)
            if expected == '123': assert case.r(1) == fallback_text
            for i, value in enumerate(args):
                if i == 1: continue
                actual_arg = case.r(i) if i < (8 if b.is64 else 4) else struct.unpack('<I', case.uc.mem_read(SP + (i - 4) * 4, 4))[0]
                assert actual_arg == value, (abi, i, actual_arg, value)
            assert case.uc.reg_read(case.sp) == SP
            seen.append(actual)
            case.ret(17)
        case.callbacks[b.sym(FONT) + slide] = font
        invoke(case, site['site'], stop=site['site'] + 4 + slide)
        assert seen == [expected]

    for site in sites:
        for role, metrics in enumerate((BAT_METRICS, PIT_METRICS)):
            actor = BAT if not role else PIT
            for local, metric in enumerate(metrics):
                for row in range(10):
                    parent_frame(c, role, local, row, actor, 4)
                    expected = '0' if role and metric in (0, 11) else INFINITY
                    font_case(c, site, expected)
                    counts['owned_metric_cells'] += 1
                    # A matching reserved RFID in a different roster cannot inherit
                    # the owned actor's semantic record or display policy.
                    other = TEAMS + 8 + 5*0x3b4 + (4 if role else 0x1a4)
                    c.uc.mem_write(other, struct.pack('<H', 1100 if role else 1000))
                    parent_frame(c, role, local, row, other, 5)
                    font_case(c, site, '123')
                    counts['opponent_metric_cells'] += 1

    exclusions = ('unrelated_caller', 'missing_parent', 'negative_row', 'row10',
                  'negative_category', 'out_of_range_category', 'wrong_team',
                  'wrong_actor_same_team', 'missing_actor', 'missing_save',
                  'wrong_record_rfid', 'noncareer', 'no_manager', 'invalid_own_team')
    for site in sites:
        for role in range(2):
            for kind in exclusions:
                d = owned_case(b, symbols, slide)
                d.uc.mem_write(fallback_text, b'123\0')
                actor = BAT if not role else PIT
                parent_frame(d, role, 0, 9, actor, 4)
                if kind == 'unrelated_caller': parent_frame(d, role, 0, 9, actor, 4, 0x123456)
                elif kind == 'missing_parent': d.ptr(SP + 0x1000, 0)
                elif kind == 'negative_row': parent_frame(d, role, 0, -1, actor, 4)
                elif kind == 'row10': parent_frame(d, role, 0, 10, actor, 4)
                elif kind == 'negative_category': parent_frame(d, role, -1, 9, actor, 4)
                elif kind == 'out_of_range_category': parent_frame(d, role, 7 if role else 8, 9, actor, 4)
                elif kind == 'wrong_team': parent_frame(d, role, 0, 9, actor, 5)
                elif kind == 'wrong_actor_same_team': parent_frame(d, role, 0, 9, TEAM + 4 + 52, 4)
                elif kind == 'missing_actor': parent_frame(d, role, 0, 9, 0, 4)
                elif kind == 'missing_save': d.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
                elif kind == 'wrong_record_rfid': d.uc.mem_write(RECORD if role else BAT_RECORD, struct.pack('<H', 99))
                elif kind == 'noncareer': d.callbacks[b.sym(GETMODE)+slide] = lambda d=d: d.ret(1)
                elif kind == 'no_manager': d.callbacks[b.sym(GETMGR)+slide] = lambda d=d: d.ret(0)
                elif kind == 'invalid_own_team': d.uc.mem_write(TEAMS+4, struct.pack('<i', 15))
                font_case(d, site, '123')
                counts['excluded_contexts'] += 1

    return {'abi': abi, 'source_c_sha256': hashlib.sha256((WORK/'yagu_payload.c').read_bytes()).hexdigest(),
            'module_sha256': hashlib.sha256((WORK/'local_rank_ui.py').read_bytes()).hexdigest(),
            'slide': hex(slide), 'font_calls': len(sites), 'cases': counts, 'total': sum(counts.values()),
            'category_to_metric': {'batting': BAT_METRICS, 'pitching': PIT_METRICS},
            'preserved_original_font_style_args': True, 'android_runtime_verified': False,
            'limits': ['The final font rasterizer is intercepted; this does not verify glyph pixels.',
                       'Instruction execution does not establish Android startup or a completed game.']}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK/'local_rank_ui_verification.json').write_text(json.dumps(results, indent=2)+'\n')
    print(json.dumps(results, indent=2))
