"""Run original tournament menu routing: owned fixtures enter playable games.

No patch is needed for these menus. The original two team comparisons exclude
the owned fixture from computer-only simulation, for either home/away slot.
Tournament-table service results are fixtures; the complete original menu body,
its comparisons, result state and ordinary return execute at nonzero ASLR.
"""
from pathlib import Path
import json,struct
from patch_builder import PatchBuilder
from verify_relocation import prepare_case,MODE
from verify_original_plt_cache import original_plt
from verify_gameplay_hooks import ROOT,HEAP,MGR,SP,STOP

WORK=Path(__file__).resolve().parent
UI=HEAP+0xb0000
MODES=(
 ('postseason','CBBGPostSeasonUI::OnKeyPressed(int)',
  'CBBGLeagueMode::GetThPostSeason()',
  'CBBGLeagueMode::GetPostSeasonTeamIdx(int, unsigned char)',
  'CSimulation::Sim_PostSeason(eGameMode, CBBGLeagueMode*, int, int)',0xb8,0x5c),
 ('world','CBBGCupGameUI::OnKeyPressed(int)',
  'CBBGLeagueMode::GetThCubGame()',
  'CBBGLeagueMode::GetCubGameTeamIdx(int, unsigned char)',
  'CSimulation::Sim_CupGame(eGameMode, CBBGLeagueMode*, eTeamIndex, eTeamIndex)',0x98,0x50),
)

def verify(abi):
 b=PatchBuilder(abi,(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
 slide=0x7b98765000 if b.is64 else 0xa9876000
 cases=[]
 for label,method,round_method,teams_method,simulator,offset64,offset32 in MODES:
  for own in range(10):
   opponents=((own+1)%10,10+own%5)if label=='world'else((own+1)%10,(own+9)%10)
   for opponent in opponents:
    for side in (0,1,2):
     pair=(own,opponent)if side==0 else(opponent,own)if side==1 else((own+1)%10,(own+2)%10)
     c=prepare_case(b,slide);original_plt(c)
     c.callbacks[b.sym('CBBGDataMgr::GetRaiseMode(eGameMode)')+slide]=lambda:c.ret(MODE)
     c.callbacks[b.sym('CBBGDataMgr::GetRaiseTeamIndex()')+slide]=lambda:c.ret(own)
     c.callbacks[b.sym('CBBGLeagueMode::IsPostSeasonOver()')+slide]=lambda:c.ret(0)
     c.callbacks[b.sym('CBBGLeagueMode::GetCubGameVictoryTeam()')+slide]=lambda:c.ret(15)
     c.callbacks[b.sym(round_method)+slide]=lambda:c.ret(0)
     c.callbacks[b.sym(teams_method)+slide]=lambda:c.ret(pair[c.r(2)&1])
     c.uc.mem_write(UI,bytes(0x200))
     c.stopped=None;c.stops={STOP,b.sym(simulator)+slide}
     c.uc.reg_write(c.sp,SP);c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1)
     c.r(0,UI);c.r(1,0xfffffffb)
     c.run_relative(b.sym(method))
     if side<2:
      assert c.stopped==STOP,(abi,label,own,opponent,side,hex(c.stopped))
      offset=offset64 if b.is64 else offset32
      assert struct.unpack('<I',c.uc.mem_read(UI+offset,4))[0]==1
      assert c.uc.reg_read(c.sp)==SP
     else:
      assert c.stopped==b.sym(simulator)+slide
     cases.append({'stage':label,'own':own,'teams':pair,'route':'play'if side<2 else'other_teams_simulation'})
 report={'abi':abi,'load_bias':hex(slide),'case_count':len(cases),
         'original_methods_unchanged':True,'cases':cases}
 print(json.dumps({'abi':abi,'case_count':len(cases),'status':'pass'}),flush=True)
 return report

if __name__=='__main__':
 results=[verify(abi)for abi in ('arm64-v8a','armeabi-v7a')]
 report={'status':'pass','case_count':sum(r['case_count']for r in results),'results':results,
         'limits':['Table lookups are controlled fixtures; no complete season or world tournament is claimed.',
                   'This checks routing to play, not the separate in-game batting/pitching result policy.']}
 (WORK/'every_game_routing_verification.json').write_text(json.dumps(report,indent=2)+'\n')
