"""Original enhancement cells and typed MAX decision; no new UI elements."""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

FONT = 'CBBGStatic::GetChangeFont(CBBStringBuffer&, char const*, int, int, short, short, short, short)'
LEVEL = 'CBBGStatic::GetLevelStr(CBBStringBuffer&, int, int, int, short, short, short, short)'
MAIN = {'arm64-v8a': (0x4614b8, '9a600b94'), 'armeabi-v7a': (0x2b7bee, 'c4f1f8ea')}
NUMBER = {'arm64-v8a': (0x595094, 0x4ca610), 'armeabi-v7a': (0x384978, 0x2fe041)}
# offset is measured from the original SP before the wrapper saves registers.
FORMATTERS = {
    'arm64-v8a': (
        ('box_initial_level', 0x508d28, 'ca910894', 0, 0x1f8, False),
        ('box_initial_bonus', 0x508eec, '59910894', 1, 0x1f8, False),
        ('box_initial_next', 0x509054, 'ff900894', 1, 0x1f8, False),
        ('box_changed_level', 0x5084c4, 'e3930894', 0, 0x184, False),
        ('box_changed_bonus', 0x508684, '73930894', 1, 0x184, False),
        ('box_changed_next', 0x5087f4, '17930894', 1, 0x184, False),
        ('upgrade_result', 0x504f10, '50a10894', 0, 0x200, True),
        ('upgrade_failure', 0x505140, 'c4a00894', 0, 0x200, True),
        ('upgrade_restore', 0x5052e8, '5aa00894', 0, 0x200, True),
    ),
    'armeabi-v7a': (
        ('box_initial_level', 0x32811c, '47f188ee', 0, 0x10c, False),
        ('box_initial_bonus', 0x328248, '47f1f2ed', 1, 0x10c, False),
        ('box_initial_next', 0x32833a, '47f17aed', 1, 0x10c, False),
        ('box_changed_level', 0x327b72, '48f15ee9', 0, 0xd0, False),
        ('box_changed_bonus', 0x327c96, '48f1cce8', 1, 0xd0, False),
        ('box_changed_next', 0x327d90, '48f14ee8', 1, 0xd0, False),
        ('upgrade_result', 0x3256c2, '4af1b6eb', 0, 0x158, True),
        ('upgrade_failure', 0x32583a, '4af1faea', 0, 0x158, True),
        ('upgrade_restore', 0x325956, '4af16cea', 0, 0x158, True),
    ),
}
QUESTS = {
    'arm64-v8a': (
        (0x53e204,'4fed0794',0x104,0x10c),(0x53e24c,'3ded0794',0x104,0x10c),
        (0x53e294,'2bed0794',0x104,0x10c),(0x53e2dc,'19ed0794',0x104,0x10c),
        (0x53e8e4,'97eb0794',0x104,0x10c),(0x53e92c,'85eb0794',0x104,0x10c),
        (0x53e974,'73eb0794',0x104,0x10c),(0x53e9bc,'61eb0794',0x104,0x10c),
        (0x456338,'028d0b94',0x104,0x10c),(0x456380,'f08c0b94',0x104,0x10c),
        (0x4563c8,'de8c0b94',0x104,0x10c),(0x456410,'cc8c0b94',0x104,0x10c),
        (0x456a18,'4a8b0b94',0x104,0x10c),(0x456a60,'388b0b94',0x104,0x10c),
        (0x456aa8,'268b0b94',0x104,0x10c),(0x456af0,'148b0b94',0x104,0x10c),
    ),
    'armeabi-v7a': (
        (0x34ac64,'31f1ccea',0x78,0x83),(0x34ac90,'31f1b6ea',0x78,0x83),
        (0x34acbc,'31f1a0ea',0x78,0x83),(0x34ace8,'31f18aea',0x78,0x83),
        (0x34b0ae,'31f1a8e8',0x78,0x83),(0x34b0da,'31f192e8',0x78,0x83),
        (0x34b106,'31f17ce8',0x78,0x83),(0x34b132,'31f166e8',0x78,0x83),
        (0x2b031a,'cbf172ef',0x80,0x8b),(0x2b0346,'cbf15cef',0x80,0x8b),
        (0x2b0372,'cbf146ef',0x80,0x8b),(0x2b039e,'cbf130ef',0x80,0x8b),
        (0x2b0764,'cbf14ced',0x80,0x8b),(0x2b0790,'cbf136ed',0x80,0x8b),
        (0x2b07bc,'cbf120ed',0x80,0x8b),(0x2b07e8,'cbf10aed',0x80,0x8b),
    ),
}
NEXT_TABLE = {
    'arm64-v8a': (
        (0x50729c,'519a0894','ldur w3, [x29, #-0xb4]',4),
        (0x5072b8,'4a9a0894','ldur w3, [x29, #-0xb4]',3),
        (0x506530,'ac9d0894','ldr x3, [sp, #0xc0]\nldr w3, [x3, #0xb8]',4),
        (0x5066fc,'399d0894','ldr x3, [sp, #0xc0]\nldr w3, [x3, #0xb8]',2),
        (0x506778,'1a9d0894','ldr x3, [sp, #0xc0]\nldr w3, [x3, #0xb8]',3),
    ),
    'armeabi-v7a': (
        (0x326fa2,'49f10eeb','ldr r3, [sp, #0x12c]',4),
        (0x326fb4,'49f104eb','ldr r3, [sp, #0x12c]',3),
        (0x326684,'49f19cef','ldr r3, [sp, #0x54]\nldr r3, [r3, #0x6c]',4),
        (0x3267ac,'49f108ef','ldr r3, [sp, #0x54]\nldr r3, [r3, #0x6c]',2),
        (0x3267fa,'49f1e2ee','ldr r3, [sp, #0x54]\nldr r3, [r3, #0x6c]',3),
    ),
}


def equipment_number_branches(b, symbols):
    """Gates/body appended after the existing roster cells' finite fallback."""
    site, caller = NUMBER[b.abi]
    predicate = symbols['yagu_equipment_player_text'] & ~int(not b.is64)
    if b.is64:
        gate = f'''equipment_gate:
ldr x8, [x29, #8]
adrp x9, #{caller & ~0xfff}
add x9, x9, #{caller & 0xfff}
cmp x8, x9
b.ne original
ldr x0, [x29]
cbz x0, original
ldur x0, [x0, #-0x70]
cbz x0, original
ldr x0, [x0, #0x30]
b equipment_number'''
        body = f'''equipment_number:
bl #{predicate}
cbz x0, original
{A64_RESTORE}
movz w8, #0x88e2
movk w8, #0x009e, lsl #16
str w8, [x0]
mov w0, #3
ret'''
    else:
        delta = (caller - (site + 5)) & 0xffffffff
        gate = f'''equipment_gate:
ldr r3, [r7, #4]
movw r2, #{delta & 0xffff}
movt r2, #{delta >> 16}
add r2, lr
cmp r3, r2
bne original
ldr r0, [r7]
cmp r0, #0
beq original
ldr r0, [r0, #-0x54]
cmp r0, #0
beq original
ldr r0, [r0, #0x20]
b equipment_number'''
        body = f'''equipment_number:
bl #{predicate}
cmp r0, #0
beq original
{T32_RESTORE}
movw r1, #0x88e2
movt r1, #0x009e
str r1, [r0]
movs r0, #3
bx lr'''
    return gate, body


def add_equipment_level_ui_hooks(b, symbols):
    exports = []
    predicate = symbols['yagu_equipment_menu_text'] & ~int(not b.is64)
    site, expected = MAIN[b.abi]
    if b.is64:
        source = f'''{A64_SAVE}
ldr x0, [sp, #0x1c8]
ldrb w1, [sp, #0x204]
bl #{predicate}
cbz x0, original
str x0, [sp, #8]
{A64_RESTORE}
b #{b.sym(FONT)}
original:
{A64_RESTORE}
b #{b.sym(LEVEL)}'''
    else:
        source = f'''{T32_SAVE}
ldr r0, [sp, #0x100]
ldrb r1, [r7, #-0xfd]
bl #{predicate}
cmp r0, #0
beq original
str r0, [sp, #4]
{T32_RESTORE}
b.w #{b.sym(FONT)}
original:
{T32_RESTORE}
b.w #{b.sym(LEVEL)}'''
    hook = b.append_asm('Owned main enhancement mean in existing level font', source)
    b.patch(site, b.branch(site, hook, True), 'Owned enhancement mean text', expected)
    exports.append(dict(label='main_mean',site=site,hook=hook))

    formatter = symbols['yagu_format_equipment'] & ~int(not b.is64)
    original = b.sym('MC_knlSprintk')
    for label, site, expected, has_label, offset, from_ui in FORMATTERS[b.abi]:
        if b.is64:
            part = f'ldr x3, [sp, #{offset + 80}]\ncbz x3, original\nldr w3, [x3, #0xb8]' if from_ui else f'ldr w3, [sp, #{offset + 80}]'
            label_arg = '' if has_label else 'mov x2, xzr'
            source = f'''{A64_SAVE}
{part}
{label_arg}
bl #{formatter}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original}'''
        else:
            part = f'ldr r3, [sp, #{offset + 24}]\ncmp r3, #0\nbeq original\nldr r3, [r3, #0x6c]' if from_ui else f'ldr r3, [sp, #{offset + 24}]'
            label_arg = '' if has_label else 'movs r2, #0'
            source = f'''{T32_SAVE}
{part}
{label_arg}
bl #{formatter}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Original enhancement format: '+label, source)
        b.patch(site,b.branch(site,hook,True),'Typed enhancement text: '+label,expected)
        exports.append(dict(label=label,site=site,hook=hook,part_sp=offset,part_from_ui=from_ui,has_label=has_label))

    predicate = symbols['yagu_equipment_no_upgrade'] & ~int(not b.is64)
    if b.is64:
        site, expected, maximum, continuation = 0x507ae4, 'a8035fb8', 0x507c68, 0x507ae8
        source = f'''{A64_SAVE}
ldur w0, [x29, #-0xc]
bl #{predicate}
cmp w0, #1
b.ne original
{A64_RESTORE}
b #{maximum}
original:
{A64_RESTORE}
ldur w8, [x29, #-0x10]
b #{continuation}'''
    else:
        site, expected, maximum, continuation = 0x327536, '11980130', 0x327600, 0x32753a
        source = f'''{T32_SAVE}
ldr r0, [sp, #0x60]
bl #{predicate}
cmp r0, #1
bne original
{T32_RESTORE}
b.w #{maximum}
original:
{T32_RESTORE}
ldr r0, [sp, #0x44]
adds r0, #1
b.w #{continuation}'''
    hook = b.append_asm('Typed enhancement infinity follows original MAX message',source)
    b.patch(site,b.branch(site,hook,False),'No higher finite enhancement purchase',expected)
    exports.append(dict(label='max_decision',site=site,hook=hook,maximum=maximum,continuation=continuation))

    table_helper=symbols['yagu_equipment_table_value'] & ~int(not b.is64)
    for index,(site,expected,part,column) in enumerate(NEXT_TABLE[b.abi]):
        if b.is64:
            source=f'''{A64_SAVE}
{part}
bl #{table_helper}
str x0, [sp]
{A64_RESTORE}
ret'''
        else:
            source=f'''{T32_SAVE}
{part}
bl #{table_helper}
str r0, [sp]
{T32_RESTORE}
bx lr'''
        hook=b.append_asm('Bounded next enhancement table row '+str(index),source)
        b.patch(site,b.branch(site,hook,True),'Keep owned next enhancement in real table',expected)
        exports.append(dict(label='next_table_'+str(index),site=site,hook=hook,column=column))

    predicate = symbols['yagu_equipment_meets_goal'] & ~int(not b.is64)
    original = b.sym('CBBGOption::GetEquipItemLevel(bool, int)')
    for index,(site,expected,threshold_sp,result_sp) in enumerate(QUESTS[b.abi]):
        success=site+(24 if b.is64 else 14)
        if b.is64:
            source=f'''{A64_SAVE}
ldr w3, [sp, #{threshold_sp+80}]
bl #{predicate}
cmp w0, #1
b.ne original
{A64_RESTORE}
b #{success}
original:
{A64_RESTORE}
b #{original}'''
        else:
            source=f'''{T32_SAVE}
ldr r3, [sp, #{threshold_sp+24}]
bl #{predicate}
cmp r0, #1
bne original
{T32_RESTORE}
b.w #{success}
original:
{T32_RESTORE}
b.w #{original}'''
        hook=b.append_asm('Typed enhancement quest comparison '+str(index),source)
        b.patch(site,b.branch(site,hook,True),'Owned enhancement quest comparison',expected)
        exports.append(dict(label='quest_'+str(index),site=site,hook=hook,
                            threshold_sp=threshold_sp,result_sp=result_sp,
                            done=site+(36 if b.is64 else 22),part=index%4))
    return exports
