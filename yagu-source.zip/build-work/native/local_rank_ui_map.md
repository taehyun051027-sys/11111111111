# Original local ranking metric projection

Recovered from the hash-locked original libraries on 2026-11-19. This document
describes the local ranking screen, not any remote standing service.

`CBBGRecordRankList::AddData(int,const char*,const char*,int,int)` has separate
font calls for ordinal rank, player name, team name, and the metric. Only its two
metric calls are patched:

| Purpose | arm64-v8a | armeabi-v7a |
|---|---:|---:|
| Ordinary row metric font | `0x4f9040` | `0x31d836` |
| Highlighted hero row metric font | `0x4f906c` | `0x31d85a` |
| Required parent return address | `0x4f87fc` | `0x31d2c3` (Thumb) |

The parent is `CBBGRecordRankUI::AddTableTabUIText`. Its original stack frame
supplies all scope information. A64 parent SP is saved parent x29 minus `0x3c0`;
Thumb parent SP is saved parent r7 minus `0x2c8`.

| Parent local | A64 offset | Thumb offset |
|---|---:|---:|
| Row loop index, valid0..9 | `0x1cc` | `0x134` |
| Ordinary row actor | `0x158` | `0xf8` |
| Ordinary row team | `0x14c` | `0xf0` |
| Hero actor | `0x1d0` | `0x138` |
| Hero team | `0xa4` | `0x7c` |
| Original is-batter byte | `0x218` | `0x167` |
| Normalized category argument | `0x22c` | `0x170` |

The exact table actor and team reach
`yagu_rank_cell_text(player,team,role,metric)`. The C helper verifies the actual
owned roster pointer, active career save, and that role's stable RFID-bound
record. Matching RFID alone is insufficient. A NULL result preserves the original
numeric text. Only the text argument of the original eight-argument font call is
changed; colors, size, buffer, widget and geometry remain original.

| Local category | BAT metric | PIT metric |
|---:|---|---|
|0|AVG (`0`)|ERA (`0`), exact zero |
|1|Hits (`2`)|Wins (`4`) |
|2|Home runs (`5`)|Holds (`6`) |
|3|RBI (`6`)|Saves (`7`) |
|4|Stolen bases (`7`)|Strikeouts (`8`) |
|5|SLG (`10`)|WHIP (`11`), exact zero |
|6|OBP (`11`)|K/9 (`12`) |
|7|OPS (`12`)|No original eighth pitching category |

`verify_local_rank_ui.py` runs both compiled ABIs with nonzero ELF load bias.
Its output report distinguishes semantic instruction checks from actual Android
font rasterization and full-game validation.
