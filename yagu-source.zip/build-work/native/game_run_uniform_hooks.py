"""Replace four hash-locked legacy GameRun clothing path loads.

The original MakeCombinationResource loops use fixed path tables sized for
the shipped palettes. New opponent palettes require direct team/part lookup.
Only the path result register changes; texture maker, loop state, flags and
all live floating-point registers survive the resolver call.
"""


def add_game_run_uniform_hooks(b, symbols):
    if b.is64:
        sites = [
            {'site': 0x3e0ff8, 'role': 'bat', 'team_offset': 0x5c0, 'part': 'ldur w3, [x29, #-24]'},
            {'site': 0x3ede9c, 'role': 'pit', 'team_offset': 0x25c, 'part': 'ldr w3, [sp, #728]'},
        ]
        expected = '017969f8'
        save = '\n'.join(f'stp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0, 18, 2))
        restore = '\n'.join(f'ldp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0, 18, 2))
        qsave = '\n'.join(f'stp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0, 32, 2))
        qrestore = '\n'.join(f'ldp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0, 32, 2))
    else:
        sites = [
            {'site': 0x264cb8, 'role': 'bat', 'team_offset': 0x428, 'part_offset': 0x20},
            {'site': 0x26d31c, 'role': 'pit', 'team_offset': 0x1a8, 'part_offset': 0x10},
        ]
        expected = '51f82210'
    exports = []
    for context in sites:
        site = context['site']
        role = context['role']
        resolver = symbols['yagu_' + role + '_clothing_path']
        if b.is64:
            source = f'''sub sp, sp, #704
{save}
stp x18, x30, [sp, #144]
mrs x8, nzcv
str x8, [sp, #160]
{qsave}
ldr x0, [sp, #64]
ldr w1, [sp, #72]
ldr x8, [sp, #712]
ldr w2, [x8, #{context['team_offset']}]
{context['part']}
bl #{resolver}
str x0, [sp, #168]
{qrestore}
ldr x8, [sp, #160]
msr nzcv, x8
{restore}
ldp x18, x30, [sp, #144]
ldr x1, [sp, #168]
add sp, sp, #704
b #{site + 4}'''
        else:
            source = f'''push.w {{r0-r3, r12, lr}}
sub sp, sp, #8
mrs r0, apsr
str r0, [sp]
vpush {{d0-d7}}
ldr r0, [sp, #76]
ldr r1, [sp, #80]
ldr r2, [sp, #100]
ldr.w r2, [r2, #{context['team_offset']}]
ldr r3, [sp, #{96 + context['part_offset']}]
bl #{resolver}
str r0, [sp, #68]
vpop {{d0-d7}}
ldr r0, [sp]
msr APSR_nzcvq, r0
ldr r1, [sp, #4]
str r1, [sp, #12]
add sp, sp, #8
pop.w {{r0-r3, r12, lr}}
b.w #{site + 4}'''
        hook = b.append_asm(f'Expanded GameRun {role} clothing path {hex(site)}', source)
        b.patch(site, b.branch(site, hook), 'Safe extended GameRun clothing path lookup', expected)
        exports.append({**context, 'hook': hook, 'resolver': resolver})
    return exports
