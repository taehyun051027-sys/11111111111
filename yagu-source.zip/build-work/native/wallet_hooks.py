"""Call-site scoped local Unbounded wallet; account and billing code is intact.

The input ELF is SHA locked by PatchBuilder. We resolve its original PLT calls
and select only an explicit local-game class allowlist. Each patched instruction
is verified against the original call and its target. Six local shop entries
are integrated separately by wallet_policy.py. No server result, security
message, receipt, account balance, or original Option entry is changed here.
"""
import struct
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

METHODS = {
    'CBBGOption::GetGPoint()': 'yagu_wallet_get_g',
    'CBBGOption::GetStarPoint()': 'yagu_wallet_get_star',
    'CBBGOption::AddGPoint(int, unsigned char)': 'yagu_wallet_add_g',
    'CBBGOption::AddStarPoint(int, bool, int, int, int, int)': 'yagu_wallet_add_star',
}
LOCAL_CLASSES = {
    'CBBGFrameUI', 'CBBGCcPopup', 'CBBGEvent', 'CBBGEventMgr',
    'CBBGRaisePlayerRun', 'CBBGStrengthPlayerUI', 'CBBGEquipStoreUI',
    'CBBGCostumeStoreUI', 'CBBGSkillInfoUI', 'CBBGEffectStoreUI',
    'CBBGStrengthItemUI', 'CBBGTrainingUI', 'CBBGMidStoreUI', 'CBBGQuestUI',
    'CBBGRaiseLevelUpUI', 'CBBGSpringCampUI', 'CBBGStrengthLunchUI',
    'CBBGLuckyBoxUI', 'CBBGStrengthAllPlayerUI', 'CBBGBundleItemStoreUI',
    'CBBGWorldmapBuylinkUI', 'CBBGGameEstimateUI',
}
EXCLUDED = {'CBBGRaisePlayerRun::EVENT_HANDLER_MSTATE_RAISE_PLAYER_VS_NETWORK()'}
DISPLAY_ONLY = {'CBBGUIMenuCharge::DrawPointNum(int)'}


def original_calls(b):
    dyn = b.elf.get_section_by_name('.dynsym')
    selected = {b.symbols[n]['mangled']: n for n in METHODS}
    targets = {b.sym(n): n for n in METHODS}
    start = b.elf.get_section_by_name('.plt')['sh_addr']
    rels = b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
    for i, rel in enumerate(rels.iter_relocations()):
        raw = dyn.get_symbol(rel['r_info_sym']).name
        if raw in selected: targets[start + 32 + i*16] = selected[raw]
    seen = set()
    rows = []
    for name, fn in b.symbols.items():
        allowed = (name.split('::')[0] in LOCAL_CLASSES and name not in EXCLUDED) or name in DISPLAY_ONLY
        if not allowed or fn['address'] in seen: continue
        seen.add(fn['address'])
        offset = b.offset(fn['address'])
        code = b.original[offset:offset+fn['size']]
        if b.is64:
            instructions = b.cs.disasm(code, fn['address'])
        else:
            # Thumb functions contain inline jump tables. A linear disassembler
            # may stop at data and silently omit later real calls. Inspect only
            # 32-bit BL/BLX candidates at halfword boundaries and require a
            # decoded exact original symbol/PLT target before selecting one.
            instructions = []
            for at in range(0, len(code)-3, 2):
                first, second = struct.unpack_from('<HH', code, at)
                if first & 0xf800 != 0xf000 or second & 0xc000 != 0xc000: continue
                decoded = list(b.cs.disasm(code[at:at+4], fn['address']+at))
                if len(decoded) == 1 and decoded[0].size == 4: instructions.extend(decoded)
        for ins in instructions:
            if ins.mnemonic not in ('bl', 'blx') or not ins.op_str.startswith('#'): continue
            target = int(ins.op_str[1:], 16)
            if target not in targets: continue
            assert ins.size == 4
            rows.append(dict(site=ins.address, original=target, caller=name,
                             target=targets[target], expected=ins.bytes.hex()))
    return rows


# These original call frames contain the UI receiver; only a confirmed local
# purchase takes this path. Coordinates and all menu widgets remain original.
ASYNC = {
    'arm64-v8a': {
        0x51e7fc: ('action', 0, 0x28),  # World-map local effects.
        0x56ffec: ('action', 1, 0x38),  # Lucky-box result + original animation.
        0x4ee870: ('action', 2, 0x88),  # Existing second passive-skill slot pair.
        0x55f9b4: ('action', 3, 0x38),  # UI is x29-0x28 == original SP+0x38.
        0x4975bc: ('branch', 0x497f48, 0),
        0x497650: ('branch', 0x497f90, 0),
    },
    'armeabi-v7a': {
        0x336bc8: ('action', 0, 0x28),
        0x36c4d0: ('action', 1, 0x34),
        0x31688c: ('action', 2, 0x78),
        0x360fdc: ('action', 3, 0x34),
        0x2db9b2: ('branch', 0x2dbffa, 0),
        0x2dba20: ('branch', 0x2dc02c, 0),
    },
}
RANGES = {
    'arm64-v8a': {0x424570: (0xd8, 0xd4, 0x424644, 0x42463c)},
    'armeabi-v7a': {0x28f666: (0xa8, 0xa4, 0x28f6ec, 0x28f6e4)},
}


def range_source(b, symbols, row, spec):
    lower, upper, allowed, denied = spec
    resolver, original = symbols['yagu_wallet_g_range'], row['original']
    if b.is64:
        return f'''{A64_SAVE}
ldr w1, [sp, #{lower+80}]
ldr w2, [sp, #{upper+80}]
bl #{resolver}
tbnz w0, #31, fallback
cbz w0, denied
{A64_RESTORE}
b #{allowed}
denied:
{A64_RESTORE}
b #{denied}
fallback:
{A64_RESTORE}
b #{original}'''
    return f'''{T32_SAVE}
ldr.w r1, [sp, #{lower+24}]
ldr.w r2, [sp, #{upper+24}]
bl #{resolver}
cmp r0, #0
blt fallback
beq denied
{T32_RESTORE}
b.w #{allowed}
denied:
{T32_RESTORE}
b.w #{denied}
fallback:
{T32_RESTORE}
b.w #{original}'''


def async_source(b, symbols, row, spec):
    kind, value, slot = spec
    original = row['original']
    if b.is64:
        args = f'ldr x1, [sp, #{slot + 80}]\nmov w2, #{value}' if kind == 'action' else ''
        resolver = symbols['yagu_wallet_local_action' if kind == 'action' else 'yagu_wallet_local_enabled']
        success = 'ret' if kind == 'action' else f'b #{value}'
        return f'''{A64_SAVE}
{args}
bl #{resolver}
cbz w0, fallback
{A64_RESTORE}
{success}
fallback:
{A64_RESTORE}
b #{original}'''
    args = f'ldr.w r1, [sp, #{slot + 24}]\nmovs r2, #{value}' if kind == 'action' else ''
    resolver = symbols['yagu_wallet_local_action' if kind == 'action' else 'yagu_wallet_local_enabled']
    success = 'bx lr' if kind == 'action' else f'b.w #{value}'
    return f'''{T32_SAVE}
{args}
bl #{resolver}
cmp r0, #0
beq fallback
{T32_RESTORE}
{success}
fallback:
{T32_RESTORE}
b.w #{original}'''


def add_wallet_hooks(b, symbols):
    rows = original_calls(b)
    specs = ASYNC[b.abi]
    found = set()
    for row in rows:
        spec = specs.get(row['site'])
        range_spec = RANGES[b.abi].get(row['site'])
        if range_spec:
            assert row['target'] == 'CBBGOption::GetGPoint()'
            hook = b.append_asm('Typed local G event bounds', range_source(b, symbols, row, range_spec))
            row['typed_range'] = range_spec
        elif spec:
            assert row['target'] == 'CBBGOption::AddStarPoint(int, bool, int, int, int, int)'
            source = async_source(b, symbols, row, spec)
            hook = b.append_asm('Local wallet purchase continuation: '+row['caller'], source)
            row['local_action'] = spec
            found.add(row['site'])
        else:
            hook = symbols[METHODS[row['target']]]
        row['hook'] = hook
        b.patch(row['site'], b.branch(row['site'], hook, True),
                'Local wallet call: '+row['caller']+' -> '+row['target'], row['expected'])
    if found != set(specs): raise ValueError('Missing local purchase continuation')
    return rows
