/* A finite nonempty team's arithmetic mean includes infinity iff it includes
 * the actual owned My actor. This is a derived view of the canonical level,
 * with no new persistent field and no modification of any ordinary teammate. */
API extern int original_team_mean(u8 *, int);
API const Scalar *yagu_team_mean_state(u8 *team, int include_my) {
    u8 *dm = data_manager();
    if (include_my != 1 || !team || team != own_team(dm)
            || team[2] > 8 || team[3] > 12 || !(team[2] + team[3]))
        return (const Scalar *)0;
    if (!owned_role_player(dm, 0) && !owned_role_player(dm, 1)) return (const Scalar *)0;
    return &my_state.level;
}
API int yagu_team_mean(u8 *team, int include_my) {
    const Scalar *state = yagu_team_mean_state(team, include_my);
    return state && state->kind == UNBOUNDED ? LEVEL_ADAPTER : original_team_mean(team, include_my);
}
API const char *yagu_team_mean_text(u8 *dm, int index) {
    if (!dm || dm != data_manager() || index != own_team_index(dm)) return (const char *)0;
    const Scalar *state = yagu_team_mean_state(own_team(dm), 1);
    return state && state->kind == UNBOUNDED ? unbounded_text : (const char *)0;
}
API int yagu_format_team_mean(char *dst, u8 *dm, int index) {
    const char *text = yagu_team_mean_text(dm, index);
    if (!dst || !text) return -1;
    for (int i = 0; i < 4; ++i) dst[i] = text[i];
    return 3;
}
API int yagu_team_mean_goal(u8 *dm, int unused, int threshold, int unused_op) {
    (void)unused; (void)threshold; (void)unused_op;
    return yagu_team_mean_text(dm, own_team_index(dm)) ? 1 : -1;
}
