# 내 선수의 네 장비 강화 레벨

이 모듈은 원본 `강화 Lv` 항목을 담당한다. 선수의 `GetGrade()` 등급이나 장비 외형과는 다른 값이다. 공유 C/builder에 직접 수정하지 않고 `equipment_level_policy.py`의 순수 변환 함수로 합친다.

## 의미와 저장 호환

- SUPER의 player schema3 /47개 뒤에 `Scalar equipment_level[4]`를 추가한다. 적용 후 player schema4 /51개이며 기존 필드 offset은 유지한다. 네 필드는 `{finite:0, kind:UNBOUNDED}`이다.
- 기록 구조는 SUPER의 schema4 /40개를 유지한다. 장비 강화는 누적 경기 기록이 아니다.
- 원본 Option의 `+0x154 + isBatter*4 + part`는 signed byte이며 `AddEquipItemLevel`이 0..99로 제한한다. 이 저장 형식을 유지하고, 정확한 내 커리어에서 원본 코드에 전달하는 인덱스만 99로 투영한다. **99는 무한값이 아니라 기존 표/저장 형식의 어댑터이다.**
- `assets/data/XlsStrengthItem.zt1`은 정확히 100행이다. 마지막 행99의 값은 `(1865,25,35,10,1250)`이다. 다음 강화 미리보기에서도 실제 원본 `GetAddAbilByEQItemLevel`은 행99를 읽으며, 존재하지 않는 행100을 읽지 않는다.
- 원본의 finite 강화가 더해지거나 감소해도 typed Unbounded는 유지된다. 원본의 clamp/store 함수를 이용해 해당 저장 바이트만 99로 동기화하며 다른 Option 바이트는 바꾸지 않는다.
- 업그레이드 버튼은 typed 상태를 검사하여 원본 최대 레벨 안내 분기로 이동한다. 버튼을 눌러 유한한 상위 레벨이나 보너스를 구매하는 경로에 들어가지 않는다. 원본 가격·통화·보상 문구는 이 모듈에서 수정하지 않는다.
- 직접 강화 실행과 랜덤 강화 상자의 BuyCheck 진입도 같은 typed 판정을 사용한다. 이미 무한인 내 장비는 원본 MAX 문구를 표시하고 비용 처리나 네트워크 동기화에 들어가지 않는다. 랜덤 상자의 입력 플래그는 원본 잔액 부족 경로와 같은 값으로 복구한다.
- slot/결과 계산의 추가 5개 next-row 호출은 정확한 기존 callsite에서만 row100을 row99로 정규화한다. 원본 표를 일반적으로 바꾸거나 다른 GXL loader를 패치하지 않는다.

## 범위

원본 Option의 정확한 포인터, active mode3/4의 실제 커리어 저장 포인터, 정확한 own-team roster 안의 My RFID1000/1100, 유효한 부위0..3을 확인한다. mode3은 내 투수만, mode4는 내 타자와 실제 같은 roster의 투수를 지원한다. 다른 Option 객체·잘못된 팀 인덱스·잘못된 roster count·복제된 RFID 객체·관련 없는 모드에는 원본 함수가 적용된다.

메인 메뉴는 현재 gameMode가 0이어도 저장된 커리어를 표시한다. 이 경우 실제 own-team actor와 DataMgr의 정확한 해당 커리어 cache 및 저장 포인터가 일치할 때만 표시를 바꾼다.

## 원본 화면과 조건

| 소비자 | 변경 |
|---|---|
| 메인 메뉴 평균 강화 | 원래 `GetLevelStr`의 동일 글꼴/색상 인수를 사용해 `Lv. ∞` 표시 |
| 선수 정보의 평균 강화 | 기존 shared numeric formatter에 정확한 caller gate 하나를 추가. EntryList/rest/StrengthAll gate는 유지 |
| 부위별 강화 box의 생성·변경 | 현재 강화 레벨, 현재 능력 보너스, 다음 능력 보너스의 6개 원본 formatter 호출에 typed 값 연결 |
| 원래 강화 결과 문구 | 3개 decimal 값만 ∞로 교체. 로케일 문구와 `%s` 능력 이름 보존 |
| 강화 버튼·직접 실행·랜덤 강화 상자 | 원래 MAX 안내로 이어지는 3개 typed decision, 비용/동기화 경로 진입 전 처리 |
| 퀘스트·커리어 지도 | 각각 8개, 총16개 원본 강화조건 비교가 typed Unbounded를 소비. 유한 임계값100을 넘는 조건도 참 |

직접 표시 변경은 11개 호출(평균2개, box6개, 결과3개)이며, 별도로 MAX 판단3개, next-row 호출5개, 퀘스트 비교16개가 있다. 새 창·버튼·레이아웃은 추가하지 않는다. formatter는 검증된 `%d` 하나와 선택적인 기존 `%s` 하나만 변환하며, 예기치 않은 형식은 원본으로 돌아간다.

## 통합

SUPER 통합 이후 다음 함수를 순서대로 적용한다.

```python
from equipment_level_policy import integrate_source, integrate_builder, integrate_career_ui_source
c_text = integrate_source(c_text)
builder_text = integrate_builder(builder_text)
career_ui_text = integrate_career_ui_source(career_ui_text)
```

필수 파일은 `equipment_level_payload.inc`, `equipment_level_policy.py`, `equipment_level_ui.py`, `verify_equipment_level.py`이다. entry hook6개, 고유 호출/분기32개를 추가한다. 선수정보 평균은 이미 존재하는 shared formatter를 확장하므로 같은 바이트를 두 번 패치하지 않는다.

```sh
PYTHONPATH=analysis/native/tools \
YAGU_ZIG=/absolute/path/to/zig \
python3 build-work/native/verify_equipment_level.py
```

검증 보고서는 `equipment_level_verification.json`이다. 원본 signed-byte getter/clamped adder, 실제 GVXL decoder와 bonus consumer, typed 조건·원본 fallback, 기존 font/style 인수 보존을 두 ABI의 nonzero ASLR 환경에서 실행한다. Android 화면과 저장 후 재실행 관찰은 별도이며 이 보고서로 완료를 주장하지 않는다.
