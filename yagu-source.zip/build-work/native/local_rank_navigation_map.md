# Original local ranking navigation, two-way extension

The existing category field is UI+`0x70` on A64 and UI+`0x40` on Thumb. The existing
direction field is UI+`0x68` / UI+`0x38`. No extra button, screen or row is added.
Owned mode4 uses global categories0..14: BAT0..7 followed by PIT8..14. Other scopes
retain the original seven/eight-category behavior.

## C contracts

```c
int yagu_rank_next_tab(unsigned char *ui, int direction); // ±1, result0..14/-1
int yagu_rank_is_batter(unsigned char *ui, int *local_tab); //1/0/-1
int yagu_rank_local_tab(unsigned char *ui); //bounded local or original raw
const unsigned char *yagu_rank_hero_player(int is_batter); //actor or NULL
```

The next-tab helper does not write the field. The existing
`AddTableTabUIText(int)` stores the returned index and performs its normal event
chain. Navigation requires active owned mode4 and both actual role actors with
their stable active-career records. The role helper can normalize only the local
category argument; the UI field stays global.

## Nineteen narrow sites per ABI

| Purpose | A64 sites | Thumb sites |
|---|---|---|
| Swipe next, both original branches | `4f7b2c`, `4f7b3c` | `31cafc`, `31cb06` |
| Swipe previous, both branches | `4f7b70`, `4f7b8c` | `31cb22`, `31cb38` |
| Key next, both branches | `4f7c54`, `4f7c64` | `31cbae`, `31cbb8` |
| Key previous, both branches | `4f7ca8`, `4f7cc8` | `31cbdc`, `31cbf2` |
| Table role and normalized argument | `4f7d74` | `31cc5a` |
| Analyzer role | `4f8898` | `31d338` |
| Drawn header role | `4f7410` | `31c5cc` |
| Ordinary BAT metric switch index | `4f8010` | `31ce16` |
| Ordinary PIT metric switch index | `4f81dc` | `31cf14` |
| Hero BAT metric switch index | `4f83d8` | `31d040` |
| Hero PIT metric switch index | `4f85cc` | `31d16c` |
| Analyzer sort-array index | `4f8930` | `31d388` |
| Drawn header resource index | `4f7434` | `31c5e4` |
| Hero actor retrieval | `4f7eb8` | `31cd3e` |
| Metric decimal-role selection | `4f8f64` | `31d7b4` |

The six inline index sites preserve original GPR/SIMD/condition flags, stack,
link register and adjacent Thumb instruction effects. The signed A64 analyzer
load retains signed extension on fallback. No layout array receives global8..14.

The original analyzer sort arrays are BAT `[15,11,12,14,13,16,17,18]` and PIT
`[4,1,7,3,6,8,9]`. Header resource IDs remain the contiguous original `0x50..0x5e`.
Row9 uses the actual owned paired pitcher on pitching categories. The final
decimal-role selector is necessary even for opponents: original code selected
thousandths versus hundredths from career mode, which would otherwise format
pitching ratios with batting units inside mode4. This change is gated to the same
observed parent table caller.

`verify_local_rank_navigation.py` executes the original key handler, swipe
threshold/direction portion, sort-array dispatch and ratio formatter branch, plus
register/flag/SIMD differentials and invalid-ownership fallbacks. It does not
claim rendered graphics, gesture hitboxes or a completed Android game.
