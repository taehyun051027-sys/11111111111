"""Five original balance display callsites; no price or shared-format patches."""
from gameplay_hooks import A64_SAVE,A64_RESTORE,T32_SAVE,T32_RESTORE

SITES={
 'arm64-v8a':(
   ('frame_balance',0x376ce4,'23e30e94','digits','header'),
   ('charge_g',0x4c70c8,'2aa20994','digits',0),
   ('charge_star',0x4c71b0,'f0a10994','digits',1),
   ('popup_balance',0x403f74,'c3d10c94','popup','popup'),
   ('event_g_balance',0x429ccc,'e10d0c94','event',0),
 ),
 'armeabi-v7a':(
   ('frame_balance',0x22006a,'52f28ae9','digits','header'),
   ('charge_g',0x2fb96e,'76f108ed','digits',0),
   ('charge_star',0x2fba28,'76f1aaec','digits',1),
   ('popup_balance',0x27b208,'fff14aef','popup','popup'),
   ('event_g_balance',0x292d3e,'ddf178e8','event',0),
 ),
}


def _kind_source(b,kind):
    if b.is64:
        if kind=='header':return 'ldur w9, [x29, #-0x7c]'
        if kind=='popup':return '''ldr x9, [sp, #0xf8]
cbz x9, no_popup
ldrb w9, [x9, #0x248]
and w9, w9, #1
eor w9, w9, #1
b kind_ready
no_popup:
mov w9, #-1
kind_ready:'''
        return f'mov w9, #{kind}'
    if kind=='header':return 'ldr r12, [sp, #0xd8]'
    if kind=='popup':return '''ldr r12, [sp, #0x90]
cmp r12, #0
beq no_popup
ldrb r12, [r12, #0x238]
and r12, r12, #1
eor r12, r12, #1
b kind_ready
no_popup:
mvn r12, #0
kind_ready:'''
    return f'mov.w r12, #{kind}'


def _with_extra_kind(b,helper,kind,original_count):
    source_kind=_kind_source(b,kind)
    if b.is64:
        out=((original_count+1-8)*8+15)//16*16
        lines=[A64_SAVE,source_kind,f'sub sp, sp, #{out}']
        for index in range(8,original_count):
            lines += [f'ldr x8, [sp, #{out+80+(index-8)*8}]',f'str x8, [sp, #{(index-8)*8}]']
        lines += [f'str w9, [sp, #{(original_count-8)*8}]']
        for i in range(0,8,2):lines += [f'ldp x{i}, x{i+1}, [sp, #{out+i*8}]']
        lines += [f'bl #{helper}',f'add sp, sp, #{out}',A64_RESTORE,'ret']
    else:
        out=((original_count+1-4)*4+7)//8*8
        lines=[T32_SAVE,source_kind,f'sub sp, sp, #{out}']
        for index in range(4,original_count):
            lines += [f'ldr r0, [sp, #{out+24+(index-4)*4}]',f'str r0, [sp, #{(index-4)*4}]']
        lines += [f'str r12, [sp, #{(original_count-4)*4}]']
        for i in range(4):lines += [f'ldr r{i}, [sp, #{out+i*4}]']
        lines += [f'bl #{helper}',f'add sp, sp, #{out}',T32_RESTORE,'bx lr']
    return '\n'.join(lines)


def add_wallet_ui_hooks(b,symbols):
    exports=[]
    for label,site,expected,style,kind in SITES[b.abi]:
        name={'digits':'yagu_wallet_digits','popup':'yagu_wallet_popup_number','event':'yagu_wallet_event_balance'}[style]
        helper=symbols[name]&~int(not b.is64)
        if style!='event':source=_with_extra_kind(b,helper,kind,14 if style=='digits' else 11)
        elif b.is64:
            source=f'''{A64_SAVE}
mov w3, #0
bl #{helper}
str x0, [sp]
{A64_RESTORE}
ret'''
        else:
            source=f'''{T32_SAVE}
movs r3, #0
bl #{helper}
str r0, [sp]
{T32_RESTORE}
bx lr'''
        hook=b.append_asm('Existing wallet balance display: '+label,source)
        b.patch(site,b.branch(site,hook,True),'Unbounded owned local balance: '+label,expected)
        exports.append(dict(label=label,site=site,hook=hook,style=style,kind=kind))
    return exports
