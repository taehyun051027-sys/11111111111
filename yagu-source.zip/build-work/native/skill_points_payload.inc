/* Skill points are a separate career resource, not a player ability level.
 * The old u16 at mode+0x240 remains ordinary save data.  The exact owned
 * career obtains an immutable tagged stock; finite rewards and spending do
 * not change infinity.  Used SP at +0x242 remains the original finite ledger.
 */
static const Scalar my_skill_points = INF;
enum { SKILL_POINT_ADAPTER = 10000 };

API extern int original_skill_points(u8 *);
API extern void original_set_skill_points(u8 *, int);
API extern void original_add_skill_points(u8 *, int);
API extern u8 *original_sp_raise_mode(u8 *, int);

API const Scalar *yagu_skill_point_state(u8 *mode) {
    if (!own_mode(mode) || !owned_role_player(data_manager(), game_mode() == 3))
        return (const Scalar *)0;
    return &my_skill_points;
}

API int yagu_skill_points(u8 *mode) {
    const Scalar *state = yagu_skill_point_state(mode);
    return state && state->kind == UNBOUNDED ? SKILL_POINT_ADAPTER
                                            : original_skill_points(mode);
}
API void yagu_set_skill_points(u8 *mode, int value) {
    const Scalar *state = yagu_skill_point_state(mode);
    if (!state || state->kind != UNBOUNDED) original_set_skill_points(mode, value);
}
API void yagu_add_skill_points(u8 *mode, int delta) {
    const Scalar *state = yagu_skill_point_state(mode);
    if (!state || state->kind != UNBOUNDED) original_add_skill_points(mode, delta);
}

/* Exact affordability branches compare the kind, not the legacy projection.
 * The unused argument keeps the same four-argument decision-hook ABI as the
 * other resource comparisons.  -1 means replay the original instruction pair.
 */
API int yagu_skill_point_compare(u8 *mode, int unused, int threshold, int op) {
    (void)unused; (void)threshold;
    const Scalar *state = yagu_skill_point_state(mode);
    if (!state || state->kind != UNBOUNDED || op < RESOURCE_GE || op > RESOURCE_LE)
        return -1;
    return op == RESOURCE_GE || op == RESOURCE_GT;
}

API const char *yagu_skill_point_text(u8 *mode) {
    const Scalar *state = yagu_skill_point_state(mode);
    return state && state->kind == UNBOUNDED ? unbounded_text : (const char *)0;
}

/* Five original pitch-skill UI calls explicitly ask for career3.  They use
 * only common RaiseMode SP and pitch-level fields, both ABI-identical in BAT
 * and PIT saves.  The existing paired-pitcher getter supplies the actual
 * actor.  This adapter is called only at those five exact sites; it never
 * changes the global GetRaiseMode(3), inactive PIT saves, or other screens.
 */
API u8 *yagu_sp_pitch_mode(u8 *dm, int requested) {
    if (dm && dm == data_manager() && requested == 3 && game_mode() == TWO_WAY_MODE) {
        u8 *save = ptr(dm, DM_BAT_SAVE);
        if (save && yagu_skill_point_state(save + 8) && owned_role_player(dm, 1))
            return save + 8;
    }
    return original_sp_raise_mode(dm, requested);
}
