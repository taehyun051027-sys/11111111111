# Starting pitcher and record integration review

## Result

The reserved-pitcher initialization concern is not a blocker. One concrete
record-preservation bug was found: records must follow RFID when the physical
pitcher roster rotates. The parent payload now contains the narrow RFID-search
fix. No additional speculative activation or rotation hook was introduced.

## Current versus reserved pitcher

The original `GetCurPitcher` reads `entry[0]` and resolves that roster slot.
`GetRsvPitcher` tests byte `entry + 0x294`, not byte `entry + 0x28`.

- With `+0x294 == 0`, it calls `GetCurPitcher` directly.
- With `+0x294 != 0`, it takes `entry[0x296] - 1` as an extended pitcher index.
- The original derived initializer sets `+0x294..+0x297` to zero. The separate
  `+0x28 == -1` initialized by `CBBGEntryData::initialization` does not prevent
  current-pitcher lookup.
- Blocking a new reservation while owned My pitcher 1100 already occupies
  `entry[0]` leaves the current pitcher active. A reservation event is not
  required to activate the initial pitcher.

Observed code addresses:

| Method | ARM64 | ARMv7 Thumb body |
|---|---:|---:|
| `CBBGEntryMgr::initializion` | `0x5b16e0` | `0x396592` |
| `GetCurPitcher` | `0x5b1770` | `0x3965ec` |
| `GetRsvPitcher` | `0x5b18dc` | `0x3966c2` |
| `CBBGDataMgr::GetPitcherRec` | `0x370624` | `0x21bd22` |

## Pregame rotation and activation order

`CBBGEntryData::RotationPitcher` delegates to the team object. The team method
at ARM64 `0x58cb94` physically shifts the first four 52-byte pitcher objects;
it does not call `RsvChangePitcher` and does not rotate the separate record
array. `ChangePitcherOrder` similarly delegates to `ExchangePlayer` and can
change the physical roster independently of substitution reservations.

The normal career setup compensates for those earlier physical movements:

1. `CBBGPlayBallRun::SetRaiseGameInfo` initializes preview entries and may rotate
   the team afterward, including its mode-4 route at `0x3a95d0`.
2. `CBBGGameRun::InitGameData` mode 4 dispatches to `0x387a8c`.
3. Fresh normal-game setup initializes own/opponent entries at `0x387dc8` and
   `0x387de4`, then updates them at `0x387df4` and `0x387e04`.
4. The existing payload wrappers re-find My 1100 and reselect it after those
   initialization/update operations.

The `InitGameData` `ChangePitcherOrder` call at `0x38812c` belongs to the
separate strikeout-training branch, not the normal mode-4 career branch.
The resource-loading reservation at `0x3892a0` is gated to modes 12/13.
The set-player reservation at `0x38a9f8` is gated by `IsPitMode`; canonical
mode 4 instead takes the batter-specific branch.

Computer-only simulation initializers also rotate/change pitcher order after
entry initialization. Regular-season `Sim_Pennantrace` excludes either fixture
containing its supplied excluded team at `0x40d89c..0x40d8cc` before invoking
`InitializeComSimulation`. This review does not claim exhaustive validation of
all cup/postseason caller paths or arbitrary direct calls to those initializers.

## Record bug and narrow correction

Before the correction, the authored synchronizer chose a record slot using the
pitcher's current physical position. A rotation from slot 0 to slot 3 could
therefore leave the existing 1100 record in slot 0, clear another player's slot
3 record, and create a second 1100 record there. The original game would still
find the first record by RFID, while the authored My-record getter returned
the second one.

The payload now scans all eight own-team record slots for RFID 1100 first.
Only when none exists does it initialize a slot. The record getter uses the
same RFID search. The parent regression and the updated ASLR test both model
physical pitcher movement while leaving record storage in place, and require
the original unique record and statistics to survive.

## Mode-4 record compilation

The original `CBBGDataMgr::GetPitcherRec` explicitly supports mode 4. Its mode-4
branch at ARM64 `0x37073c` uses manager `+0x528`, then BAT save
`+0xe8c + team * 256`, and searches eight 32-byte slots by RFID. The Thumb
branch at `0x21bdc8` uses manager `+0x4e8` with the same save offsets. The PIT
save is used only by its separate mode-3 branch.

`AtPitch` and `AtResult` pass `skip My == false` to this original getter.
`ConditionCheck` handles modes 3 and 4 together and accepts a non-Ace My pitcher
for ordinary record updates. The inspected mode-4 pitch/result path does not
require a PIT save. `ProcJudge` intentionally passes `skip My == true` while
its simulator reports `IsRun`; that is distinct from ordinary manual own
turns. This review does not establish every career award or historical record
screen as converted to two-way presentation.

## Verification and evidence

`verify_starting_pitcher.py` executes the original initializer, current and
reserved getters, and record getter on both ABIs. Fourteen checks pass. It
leaves `+0x28` at -1, verifies reservation protection does not remove the
starter, moves the My pitcher object without moving records, and confirms a
mode-4 record lookup succeeds with a null PIT save. Low memory pages are
unmapped so an accidental null-PIT-plus-offset read would fault.

Selected roster leaves and PLT dispatch are mocked. The complete setup state
machine, nine-inning match and actual disk serialization are not executed by
these tests.

Evidence files: `starting_pitcher_activation.txt`, `start_record_thumb.txt`,
`pitcher_start_paths.txt`, `pitcher_rotation_xrefs.txt`, `pitch_record_routes.txt`,
`pitch_record_xrefs.txt`, `pitch_record_compilation.txt`,
`stat_condition_check.txt`, `com_sim_rotation.txt`, and
`starting_pitcher_verification.json`.
