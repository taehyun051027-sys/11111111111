"""Verify the existing CcPlayerRes wrapper selects only stock visual resources.

Actual original entry branches and compiled PIC adapters run. The texture
loader boundary records its six original arguments; rendering is not mocked
as successful. Actual item ownership and ability fields are never passed here.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks
from payload_builder import add_payload, HOOKS
from verify_relocation import RelocatedCase
from verify_gameplay_hooks import ROOT, HEAP, SP, STOP

WORK = Path(__file__).resolve().parent
RESOURCE = HEAP + 0x60000
ITEM_SENTINEL = HEAP + 0x70000
BLACK_LAYERS = {2, 3, 4, 6, 9, 10, 12, 14, 15, 16, 19, 20, 22, 24, 25, 26, 27, 29, 30}

def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'equipment_appearance_build' / abi)
    slide = 0x7843210000 if b.is64 else 0x98421000
    c = RelocatedCase(b, slide)
    seen = []
    def load_boundary():
        if b.is64:
            args = tuple(c.r(i) & 0xffffffff for i in range(6))
        else:
            stack = c.uc.reg_read(c.sp)
            args = tuple(c.r(i) & 0xffffffff for i in range(4)) + struct.unpack('<II', c.uc.mem_read(stack, 8))
        seen.append(args)
        c.ret(0)
    c.callbacks[payload['original_bindings']['original_load_equipment'] + slide] = load_boundary
    c.callbacks[payload['original_bindings']['original_uniform'] + slide] = lambda: c.ret(9)
    initial = bytes((i * 7 + 3) & 255 for i in range(0x500))
    c.uc.mem_write(RESOURCE, initial)
    c.uc.mem_write(ITEM_SENTINEL, initial)

    def call(alias, *args):
        c.stopped = None; c.stops = {STOP}
        c.uc.reg_write(c.sp, SP); c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        for i, arg in enumerate(args):
            if i < (8 if b.is64 else 4): c.r(i, arg & ((1 << (64 if b.is64 else 32)) - 1))
            else: c.uc.mem_write(SP + (i - 4) * 4, struct.pack('<I', arg & 0xffffffff))
        c.run_relative(b.sym(HOOKS[alias]))
        assert c.stopped == STOP and c.uc.reg_read(c.sp) == SP
        return c.r(0) & 0xffffffff

    total = 0
    ball_unchanged = 0
    for team in list(range(15)) + [-1, 15, 0x7fffffff]:
        for role in (0, 1):
            for kind in (-1, 0, 1, 2, 3, 4):
                for level in (-1, 0, 4, 7, 8, 14):
                    for force in (0, 1):
                        wanted = level
                        if 0 <= team < 15:
                            if kind == 0: wanted = 0
                            elif role == 1 and kind == 2: wanted = 7
                            elif role == 1 and kind == 3: wanted = 8
                            elif role == 0 and kind == 1: wanted = 0
                            elif role == 0 and kind == 3: wanted = 7
                        args = (RESOURCE, team, role, kind, level, force)
                        previous = len(seen)
                        call('load_equipment', *args)
                        expected = tuple(x & 0xffffffff for x in (RESOURCE, team, role, kind, wanted, force))
                        assert seen[previous:] == [expected], (abi, args, seen[previous:], expected)
                        if role == 0 and kind == 2:
                            assert seen[-1][4] == (level & 0xffffffff)
                            ball_unchanged += 1
                        total += 1
        for layer in list(range(32)) + [-1, 32]:
            expected = 0 if 0 <= team < 15 and layer in BLACK_LAYERS else 9
            assert call('uniform', RESOURCE, layer, team) == expected
            total += 1
    assert c.uc.mem_read(RESOURCE, len(initial)) == initial
    assert c.uc.mem_read(ITEM_SENTINEL, len(initial)) == initial
    return {'abi': abi, 'load_bias': hex(slide), 'passed_cases': total,
            'pitching_ball_selection_preserved_cases': ball_unchanged,
            'resource_and_item_guard_bytes_unchanged': True,
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'visual_limit': 'Stock level8 batting glove retains its original gold wrist trim.',
            'android_rendering_verified': False}

if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'equipment_appearance_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))
