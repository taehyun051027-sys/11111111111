"""Extend the existing personal-record swipe/key pages to both My roles.

The same three original metric pages are reused for each role. Page values
0..2 mean batting and 3..5 mean pitching. All observed consumers that index
the original three-page resource layout receive a normalized 0..2 value.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE


def checked_call(b, site, target, expected_target, reason):
    raw = b.original[b.offset(site):b.offset(site) + 4]
    ins = list(b.cs.disasm(raw, site))
    if len(ins) != 1 or ins[0].mnemonic not in ('bl', 'blx') or ins[0].op_str != f'#{hex(expected_target)}':
        raise ValueError('Unverified personal-record call at ' + hex(site))
    b.patch(site, b.branch(site, target, True), reason, raw.hex())


def add_personal_record_navigation_hooks(b, symbols):
    outputs = {'scroll_calls': [], 'role_calls': [], 'page_loads': []}
    scroll_sites = [0x4f4dd0, 0x4f4de0, 0x4f4e14, 0x4f4e24,
                    0x4f4ec8, 0x4f4ed8, 0x4f4f1c, 0x4f4f2c] if b.is64 else [
                    0x31acd6, 0x31ace0, 0x31acfc, 0x31ad06,
                    0x31ad68, 0x31ad72, 0x31ad96, 0x31ada0]
    for site in scroll_sites:
        checked_call(b, site, symbols['yagu_record_scroll'], 0x741ed0 if b.is64 else 0x485240,
                     'Cycle original personal-record gestures through both My roles')
        outputs['scroll_calls'].append(site)

    role_sites = [(0x4f4fd8, 'table'), (0x4f46f0, 'draw')] if b.is64 else [
                 (0x31ae08, 'table'), (0x31a7e4, 'draw')]
    original_role = b.sym('CBBGStatic::IsBatMode()')
    for site, context in role_sites:
        if b.is64:
            args = 'ldr x0, [sp, #0xc8]\nadd x1, sp, #0x124' if context == 'table' else 'ldr x0, [sp, #0x108]\nmov x1, #0'
            source = f'''{A64_SAVE}
{args}
bl #{symbols['yagu_record_is_batter']}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original_role}'''
        else:
            args = 'ldr r0, [sp, #0x5c]\nadd r1, sp, #0x98' if context == 'table' else 'ldr r0, [sp, #0x84]\nmovs r1, #0'
            source = f'''{T32_SAVE}
{args}
bl #{symbols['yagu_record_is_batter']}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original_role}'''
        hook = b.append_asm('Two-way personal-record role: ' + context, source)
        checked_call(b, site, hook, 0x72db90 if b.is64 else 0x470570,
                     'Select original batting or pitching personal-record layout')
        outputs['role_calls'].append({'site': site, 'hook': hook, 'context': context})

    if b.is64:
        sites = [(0x4f4714, 10, '0a7140b9'), (0x4f4728, 8, '087140b9')]
        save = '\n'.join(f'stp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0, 18, 2))
        restore = '\n'.join(f'ldp x{i}, x{i+1}, [sp, #{i*8}]' for i in range(0, 18, 2))
        qsave = '\n'.join(f'stp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0, 32, 2))
        qrestore = '\n'.join(f'ldp q{i}, q{i+1}, [sp, #{192+i*16}]' for i in range(0, 32, 2))
        for site, destination, expected in sites:
            source = f'''sub sp, sp, #704
{save}
stp x18, x30, [sp, #144]
mrs x8, nzcv
str x8, [sp, #160]
{qsave}
ldr x0, [sp, #64]
bl #{symbols['yagu_record_page']}
str x0, [sp, #168]
{qrestore}
ldr x8, [sp, #160]
msr nzcv, x8
{restore}
ldp x18, x30, [sp, #144]
ldr w{destination}, [sp, #168]
add sp, sp, #704
b #{site + 4}'''
            hook = b.append_asm('Normalize original record page load ' + hex(site), source)
            b.patch(site, b.branch(site, hook), 'Bound original record layout page index', expected)
            outputs['page_loads'].append({'site': site, 'hook': hook, 'destination': destination, 'size': 4})
    else:
        sites = [(0x31a7fe, 2, '026c02eb4202', 'add.w r2, r2, r2, lsl #1'),
                 (0x31a80a, 0, '006c0228', 'cmp r0, #2')]
        for site, destination, expected, replay in sites:
            size = len(bytes.fromhex(expected))
            source = f'''push.w {{r0-r3, r12, lr}}
sub sp, sp, #8
mrs r0, apsr
str r0, [sp]
vpush {{d0-d15}}
vpush {{d16-d31}}
ldr r0, [sp, #264]
bl #{symbols['yagu_record_page']}
str r0, [sp, #{264 + destination * 4}]
vpop {{d16-d31}}
vpop {{d0-d15}}
ldr r0, [sp]
msr APSR_nzcvq, r0
add sp, sp, #8
pop.w {{r0-r3, r12, lr}}
{replay}
b.w #{site + size}'''
            hook = b.append_asm('Normalize original record page load ' + hex(site), source)
            branch = b.branch(site, hook) + (bytes.fromhex('00bf') if size == 6 else b'')
            b.patch(site, branch, 'Bound original record layout page index', expected)
            outputs['page_loads'].append({'site': site, 'hook': hook, 'destination': destination, 'size': size})

    past = 0x4f52d0 if b.is64 else 0x31afee
    checked_call(b, past, symbols['yagu_personal_past_pitcher_record'], 0x72e020 if b.is64 else 0x470a00,
                 'Use owned Unbounded history projection without a separate PIT save')
    outputs['past_pitcher_call'] = past
    return outputs
