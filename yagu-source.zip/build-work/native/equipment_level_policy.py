"""Stage four typed enhancement fields after the SUPER append, without shared edits."""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
INCLUDE = '#include "equipment_level_payload.inc"'
HOOKS = {
    'equip_level': 'CBBGOption::GetEquipItemLevel(bool, int)',
    'add_equip_level': 'CBBGOption::AddEquipItemLevel(bool, int, int)',
    'equip_bonus': 'CBBGStatic::GetAddAbilByEQItemLevel(int, bool)',
    'equip_success_per': 'CBBGStrengthItemUI::GetSuccessPer(int)',
    'equipment_process': 'CBBGStrengthItemUI::ProcessStrengthItem()',
    'equipment_lunch_buy': 'CBBGStrengthLunchUI::BuyCheck()',
}
BINDINGS = {
    'equipment_sprint': 'MC_knlSprintk',
    'equipment_get_val': 'GVXLLoader::GetVal(int, int)',
    'equipment_resource_manager': 'CGsSingleton<CBBGCcMgrRes>::GetInstPtr()',
    'equipment_common_string': 'CBBGCcMgrRes::GetCommonStr(int)',
    'equipment_max_popup': 'CBBGStatic::CreateDefaultCCPopup(char const*, int, int, bool)',
}


def integrate_source(source):
    if INCLUDE in source:
        if source.count(INCLUDE) != 1 or 'Scalar equipment_level[4];' not in source:
            raise ValueError('Partial or repeated equipment integration')
        return source
    anchor = '    Scalar special_uses;\n} InfinitePlayer;'
    if source.count(anchor) != 1:
        raise ValueError('Integrate SUPER player schema3 first')
    source = source.replace(anchor, '    Scalar special_uses;\n'
                            '    /* Schema4 appends four equipment-enhancement levels. */\n'
                            '    Scalar equipment_level[4];\n} InfinitePlayer;')
    start = source.index('static const InfinitePlayer my_state = {')
    end = source.index('\n};', start)
    init = source[start:end]
    if init.count('    3, MY_BAT,') != 1:
        raise ValueError('Expected player schema3 /47 fields')
    init = init.replace('    3, MY_BAT,', '    4, MY_BAT,', 1)
    source = source[:start] + init + ', {INF, INF, INF, INF}' + source[end:]
    return source.rstrip() + '\n\n' + INCLUDE + '\n'


def integrate_builder(source):
    from special_uses_policy import once
    addition = ''.join('    ' + repr(k) + ': ' + repr(v) + ',\n' for k, v in HOOKS.items())
    source = once(source, 'HOOKS = {\n', 'HOOKS = {\n' + addition, 'equipment entry hooks')
    addition = ''.join('    ' + repr(k) + ': ' + repr(v) + ',\n' for k, v in BINDINGS.items())
    source = once(source, 'BINDINGS = {\n', 'BINDINGS = {\n' + addition, 'equipment formatter binding')
    source = once(source, '    from special_uses_hooks import add_special_uses_hooks',
                  '    from special_uses_hooks import add_special_uses_hooks\n'
                  '    from equipment_level_ui import add_equipment_level_ui_hooks',
                  'equipment UI import')
    source = once(source, "        add_special_uses_hooks(b,report['symbols'])",
                  "        add_special_uses_hooks(b,report['symbols'])\n"
                  "        add_equipment_level_ui_hooks(b,report['symbols'])",
                  'equipment UI hooks')
    source = once(source, "'semantic_player_schema': 3, 'semantic_player_scalars': 47,",
                  "'semantic_player_schema': 4, 'semantic_player_scalars': 51,",
                  'equipment schema metadata')
    return source


def integrate_career_ui_source(source):
    """Extend the one existing shared formatter, without patching it twice."""
    from special_uses_policy import once
    source = once(source, '    from roster_number_ui import roster_number_branches',
                  '    from roster_number_ui import roster_number_branches\n'
                  '    from equipment_level_ui import equipment_number_branches',
                  'equipment shared-number import')
    source = once(source, '    roster_gates, roster_body = roster_number_branches(b, symbols[\'yagu_state\'])',
                  '    roster_gates, roster_body = roster_number_branches(b, symbols[\'yagu_state\'])\n'
                  '    if \'yagu_equipment_player_text\' in symbols:\n'
                  '        equipment_gates, equipment_body = equipment_number_branches(b, symbols)\n'
                  '        roster_gates = roster_gates.removesuffix(\'b original\') + \'b equipment_gate\\n\' + equipment_gates\n'
                  '        roster_body += \'\\n\' + equipment_body',
                  'equipment shared-number branch')
    return source


def stage_payload(output_dir, source_dir=WORK):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    raw = (source_dir / 'yagu_payload.c').read_text()
    source = integrate_source(raw)
    (output_dir / 'yagu_payload.c').write_text(source)
    pending = re.findall(r'^\s*#\s*include\s*"([^"\n]+)"', source, re.MULTILINE)
    deps = {}
    while pending:
        name = pending.pop()
        if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*', name) or '..' in name:
            raise ValueError('Non-local include')
        if name in deps: continue
        path = (WORK if name == 'equipment_level_payload.inc' else source_dir) / name
        if path.is_symlink() or not path.is_file(): raise ValueError('Missing local include '+name)
        data = path.read_bytes()
        (output_dir / name).write_bytes(data)
        deps[name] = hashlib.sha256(data).hexdigest()
        pending.extend(re.findall(r'^\s*#\s*include\s*"([^"\n]+)"', data.decode(), re.MULTILINE))
    report = {'base_c_sha256': hashlib.sha256(raw.encode()).hexdigest(),
              'staged_c_sha256': hashlib.sha256(source.encode()).hexdigest(),
              'dependencies': deps, 'player_schema': 4, 'player_scalars': 51,
              'record_schema_changed': False, 'shared_source_modified': False}
    (output_dir / 'equipment_level_stage_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    return report
