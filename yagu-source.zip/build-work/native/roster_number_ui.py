"""Original EntryList and StrengthAll numeric cells for the reserved My roles.

The shared formatter is patched once, by career_ability_ui. This module adds
only verified caller gates and reuses the existing font, color and layout.
"""
from gameplay_hooks import A64_RESTORE, T32_RESTORE

SITE = {'arm64-v8a': 0x595094, 'armeabi-v7a': 0x384978}
CALLERS = {
    'arm64-v8a': {'entry': (0x3fa854, 0x3faa50), 'strength': (0x578c10, 0x578d84, 0x578df0)},
    'armeabi-v7a': {'entry': (0x2753bb, 0x275541), 'strength': (0x3720f7, 0x372221, 0x37227f)},
}
ACTOR_FP_OFFSET = {'arm64-v8a': {'entry': 0x138, 'strength': 0x128},
                   'armeabi-v7a': {'entry': 0xb4, 'strength': 0xb0}}


def roster_number_branches(b, state_addr):
    """Return gates/body for an already-saved shared sprintf call wrapper."""
    predicate = state_addr & ~int(not b.is64)
    gates = ['roster_gate:', 'ldr x8, [x29, #8]' if b.is64 else 'ldr r3, [r7, #4]']
    for group, callers in CALLERS[b.abi].items():
        for caller in callers:
            if b.is64:
                gates += [f'adrp x9, #{caller & ~0xfff}', f'add x9, x9, #{caller & 0xfff}',
                          'cmp x8, x9', f'b.eq roster_{group}']
            else:
                delta = (caller - (SITE[b.abi] + 5)) & 0xffffffff
                gates += [f'movw r2, #{delta & 0xffff}', f'movt r2, #{delta >> 16}',
                          'add r2, lr', 'cmp r3, r2', f'beq roster_{group}']
    gates += ['b original']
    body = []
    for group, offset in ACTOR_FP_OFFSET[b.abi].items():
        body += [f'roster_{group}:',
                 f'ldr x0, [x29, #{offset}]' if b.is64 else f'ldr.w r0, [r7, #{offset}]',
                 'b roster_check']
    body += ['roster_check:']
    if b.is64:
        body += ['cbz x0, original', f'bl #{predicate}', 'cbz x0, original', A64_RESTORE,
                 'movz w8, #0x88e2', 'movk w8, #0x009e, lsl #16',
                 'str w8, [x0]', 'mov w0, #3', 'ret']
    else:
        body += ['cmp r0, #0', 'beq original', f'bl #{predicate}', 'cmp r0, #0',
                 'beq original', T32_RESTORE, 'movw r1, #0x88e2', 'movt r1, #0x009e',
                 'str r1, [r0]', 'movs r0, #3', 'bx lr']
    return '\n'.join(gates), '\n'.join(body)
