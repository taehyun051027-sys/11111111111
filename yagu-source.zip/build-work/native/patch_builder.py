"""Hash-locked PIC binary instrumentation for the supplied private game copy.
No downloaded code is executed by this tool. Appended code is assembled, not run.
"""
from __future__ import annotations
import hashlib,io,json,struct,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path[:0]=[str(ROOT/'tools'),str(ROOT.parent.parent/'analysis/native/tools')]
from elftools.elf.elffile import ELFFile
from keystone import Ks,KS_ARCH_ARM64,KS_ARCH_ARM,KS_MODE_LITTLE_ENDIAN,KS_MODE_THUMB
from capstone import Cs,CS_ARCH_ARM64,CS_ARCH_ARM,CS_MODE_LITTLE_ENDIAN,CS_MODE_THUMB
EXPECTED={
'arm64-v8a':'83fd7f2d689e304b05d77c35885dc95e9b518b0b577a71cda5f2fadad81f78a5',
'armeabi-v7a':'71e99eaa3733002c466d04205d2ebfadf1285d72acf21e286500ad203d28b960',
}
def align(v,a=4096): return (v+a-1)//a*a
class PatchBuilder:
 def __init__(self,abi:str,original:bytes):
  self.abi=abi;self.original=original;self.sha=hashlib.sha256(original).hexdigest()
  if self.sha!=EXPECTED[abi]: raise ValueError('Unsupported source library SHA256: '+self.sha)
  self.image=bytearray(original);self.elf=ELFFile(io.BytesIO(original));self.is64=abi=='arm64-v8a'
  self.ks=Ks(KS_ARCH_ARM64,KS_MODE_LITTLE_ENDIAN) if self.is64 else Ks(KS_ARCH_ARM,KS_MODE_THUMB)
  self.cs=Cs(CS_ARCH_ARM64,CS_MODE_LITTLE_ENDIAN) if self.is64 else Cs(CS_ARCH_ARM,CS_MODE_THUMB)
  syms=list(self.elf.get_section_by_name('.dynsym').iter_symbols());names=subprocess.run(['c++filt'],input='\n'.join(s.name for s in syms),text=True,capture_output=True,check=True).stdout.splitlines()
  self.symbols={n:{'value':s['st_value'],'address':s['st_value'] if self.is64 else s['st_value']&~1,'size':s['st_size'],'mangled':s.name} for s,n in zip(syms,names) if s['st_value'] and s['st_info']['type']=='STT_FUNC'}
  self.base=align(max(s['p_vaddr']+s['p_memsz'] for s in self.elf.iter_segments() if s['p_type']=='PT_LOAD'))
  self.file_base=align(len(original));self.extra=bytearray();self.patches=[];self.blocks=[];self.used=set()
 def sym(self,name):
  if name not in self.symbols: raise KeyError(name)
  return self.symbols[name]['address']
 def offset(self,address):
  for s in self.elf.iter_segments():
   if s['p_type']=='PT_LOAD' and s['p_vaddr']<=address<s['p_vaddr']+s['p_filesz']:
    return s['p_offset']+address-s['p_vaddr']
  raise ValueError('Unmapped source address '+hex(address))
 def asm(self,source,address):
  b,count=self.ks.asm(source,address)
  if b is None: raise ValueError('Assembler returned no bytes')
  return bytes(b)
 def append(self,name,data,source=None):
  pad=(-len(self.extra))%4;self.extra.extend(b'\0'*pad)
  address=self.base+len(self.extra);self.extra.extend(data)
  self.blocks.append({'name':name,'address':address,'size':len(data),'hex':data.hex(),'source':source})
  return address
 def append_asm(self,name,source):
  address=align(self.base+len(self.extra),4)
  return self.append(name,self.asm(source,address),source)
 def patch(self,address,new,why,expected=None):
  off=self.offset(address);old=bytes(self.image[off:off+len(new)])
  if expected is not None and old!=bytes.fromhex(expected): raise ValueError('Prefix mismatch for '+why)
  if bytes(self.original[off:off+len(new)])!=old: raise ValueError('Overlapping patch for '+why)
  self.image[off:off+len(new)]=new
  self.patches.append({'address':address,'file_offset':off,'before':old.hex(),'after':new.hex(),'reason':why})
 def branch(self,from_address,to_address,link=False):
  op=('bl' if link else 'b') if self.is64 else ('bl' if link else 'b.w')
  b=self.asm(f'{op} #{to_address}',from_address)
  if len(b)!=4: raise ValueError('Expected four-byte branch')
  return b
 def trampoline(self,name):
  address=self.sym(name);off=self.offset(address);data=self.original[off:off+4]
  ins=list(self.cs.disasm(data,address))
  if sum(i.size for i in ins)!=4:raise ValueError('Prologue splits an instruction '+name)
  for i in ins:
   if 'pc' in i.op_str or i.mnemonic.startswith(('b','adr','ldr')):raise ValueError('Non-relocatable prologue '+name+': '+i.mnemonic+' '+i.op_str)
  at=align(self.base+len(self.extra),4)
  return self.append(name+' original prologue',data+self.branch(at+4,address+4),source='original first four bytes + branch back')
 def hook(self,name,source_factory):
  if name in self.used:raise ValueError('Duplicate hook '+name)
  self.used.add(name);tramp=self.trampoline(name)
  source=source_factory(tramp);hook=self.append_asm(name+' hook',source)
  self.patch(self.sym(name),self.branch(self.sym(name),hook),'entry hook '+name)
  return hook
 def replace_function(self,name,source):
  b=self.asm(source,self.sym(name));size=self.symbols[name]['size']
  if len(b)>size:raise ValueError('Replacement does not fit '+name)
  self.patch(self.sym(name),b,'replace '+name);self.used.add(name)
 def finish(self,out:Path):
  notes=[(i,s) for i,s in enumerate(self.elf.iter_segments()) if s['p_type']=='PT_NOTE']
  if len(notes)!=1:raise ValueError('Exactly one PT_NOTE required')
  i,old=notes[0];ph=self.elf['e_phoff']+i*self.elf['e_phentsize'];n=len(self.extra)
  if not n:raise ValueError('No instrumentation')
  # Notes stay present in the original RX segment and in their ELF sections.
  h=struct.pack('<IIQQQQQQ',1,5,self.file_base,self.base,self.base,n,n,4096) if self.is64 else struct.pack('<IIIIIIII',1,self.file_base,self.base,self.base,n,n,5,4096)
  self.image[ph:ph+len(h)]=h
  self.image.extend(b'\0'*(self.file_base-len(self.image)));self.image.extend(self.extra)
  check=ELFFile(io.BytesIO(self.image));loads=[s for s in check.iter_segments() if s['p_type']=='PT_LOAD']
  assert len(loads)==4
  for s in loads:assert s['p_offset']%s['p_align']==s['p_vaddr']%s['p_align']
  out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(self.image)
  result={'abi':self.abi,'input_sha256':self.sha,'output_sha256':hashlib.sha256(self.image).hexdigest(),'rx_segment':{'address':self.base,'file_offset':self.file_base,'size':n},'patches':self.patches,'blocks':self.blocks,'original_unmodified':True,'android_runtime_verified':False,'note':'Private mod engineering candidate; static and emulated-hook verification do not establish Android gameplay compatibility.'}
  out.with_suffix('.patch.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
  return result
