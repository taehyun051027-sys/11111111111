"""Pure integration of the exact two-strike original-contact rescue call."""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
INCLUDE = '#include "batting_rescue_payload.inc"'
BINDINGS = {
    'original_rescue_battable': 'CBBGBatter::IsBattable()',
    'original_rescue_swing': 'CBBGBatter::Swing(int)',
    'original_rescue_swing_position': 'CBBGGameRun::GetCurrentSwingPosition()',
    'original_rescue_at_swing': 'CBBGStatisticsMgr::AtSwing()',
    'original_rescue_current_batter': 'CBBGEntryMgr::GetCurBatter()',
    'original_rescue_play_data': 'CBBGStatic::GetPlayData()',
}


def integrate_source(source):
    if INCLUDE in source:
        if source.count(INCLUDE) != 1: raise ValueError('Repeated batting rescue include')
        return source
    if 'static u8 *owned_role_player(' not in source:
        raise ValueError('Missing exact roster ownership implementation')
    return source.rstrip() + '\n\n' + INCLUDE + '\n'


def integrate_builder(source):
    from special_uses_policy import once
    bindings = ''.join('    ' + repr(k) + ': ' + repr(v) + ',\n' for k, v in BINDINGS.items())
    source = once(source, 'BINDINGS = {\n', 'BINDINGS = {\n' + bindings, 'rescue bindings')
    source = once(source, '    from special_uses_hooks import add_special_uses_hooks',
                  '    from special_uses_hooks import add_special_uses_hooks\n'
                  '    from batting_rescue_hooks import add_batting_rescue_hook', 'rescue import')
    source = once(source, "        add_special_uses_hooks(b,report['symbols'])",
                  "        add_special_uses_hooks(b,report['symbols'])\n"
                  "        add_batting_rescue_hook(b,report['symbols'])", 'rescue hook')
    return source


def integrate_gameplay_source(source):
    from special_uses_policy import once
    old = "        exported[name] = b.hook('CBBGGameRun::'+name, lambda t, v=value: pitcher_bool(b, t, v, owned))"
    new = """        if name == 'IsHitByPitcher()':
            from batting_rescue_hooks import owned_batter_and_pitcher_hbp
            exported[name] = b.hook('CBBGGameRun::'+name,
                lambda t: owned_batter_and_pitcher_hbp(b, t, owned))
        else:
            exported[name] = b.hook('CBBGGameRun::'+name, lambda t, v=value: pitcher_bool(b, t, v, owned))"""
    return once(source, old, new, 'owned batter HBP extension')


def stage_payload(output_dir, source_dir):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    original = (source_dir / 'yagu_payload.c').read_text()
    source = integrate_source(original)
    (output_dir / 'yagu_payload.c').write_text(source)
    pending = re.findall(r'^#include "([^"]+)"', source, re.MULTILINE)
    dependencies = {}
    while pending:
        name = pending.pop()
        if name in dependencies: continue
        if '/' in name or '\\' in name: raise ValueError('Unexpected include ' + name)
        raw = ((WORK if name == 'batting_rescue_payload.inc' else source_dir) / name).read_bytes()
        (output_dir / name).write_bytes(raw)
        dependencies[name] = hashlib.sha256(raw).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"', raw.decode(), re.MULTILINE))
    manifest = dict(base_c_sha256=hashlib.sha256(original.encode()).hexdigest(),
                    staged_c_sha256=hashlib.sha256(source.encode()).hexdigest(),
                    dependencies=dependencies, shared_source_modified=False)
    (output_dir / 'batting_rescue_stage_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest
