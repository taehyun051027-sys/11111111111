"""Compiled semantic order, original winner consumers and colored text.

Both ELFs execute at nonzero ASLR with their zero-bias image unmapped. Only
singleton/roster getter services, finite GET_ABIL inputs and graphics/audio
boundaries are callbacks; original comparison consumers and winner stores run.
"""
import hashlib
import json
import struct
from pathlib import Path
import unicorn.arm64_const as a64
import unicorn.arm_const as arm

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR, GETBAT, GETPIT
from mental_duel_policy import stage_payload
from mental_duel_hooks import add_mental_duel_hooks
from verify_honors import configure, invoke
from verify_original_plt_cache import original_plt
from verify_relocation import BAT, PIT, TEAM, TEAMS, MODE
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP

WORK = Path(__file__).resolve().parent
ATT, DEF, UI, GAME, PLAY, PREFIX, BUFFER, FORMAT, FAKE = (HEAP+n for n in
    (0xb0000, 0xb1000, 0xb2000, 0xb3000, 0xb4000, 0xb5000, 0xb6000, 0xb7000, 0xb8000))
OPTEAM = TEAMS + 8 + 5 * 0x3b4
OPBAT, OPPIT = OPTEAM + 0x1a4, OPTEAM + 4
VALUES = ((3500, 2190), (2190, 3500), (3500, 3500), (0, 0),
          (0, 0x7fffffff), (0x7fffffff, 0), (-0x80000000, 0x7fffffff))
SCOPES = ('batter', 'pitcher', 'ordinary', 'opponent_reserved', 'detached',
          'same_team', 'null_player', 'null_entry', 'missing_save', 'missing_teams',
          'missing_manager', 'noncareer', 'bad_count', 'bad_team')


def verify(abi, source_dir):
    b = PatchBuilder(abi, (ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    old_root=payload_builder.ROOT; payload_builder.ROOT=source_dir
    try: payload=payload_builder.add_payload(b, workdir=WORK/'mental_duel_build'/abi)
    finally: payload_builder.ROOT=old_root
    symbols=payload['symbols']; sites=add_mental_duel_hooks(b,symbols)
    slide=0x7e65432000 if b.is64 else 0xb6543000
    count=dict(semantic_scope=0, decision_state=0, original_intro=0,
               original_next_pitch=0, formatter=0, unchanged_skill_effects=0)

    def setup(mode, scope):
        c,_,_=configure(b,slide,mode,payload);original_plt(c)
        c.uc.mem_write(OPTEAM, bytes([5,0,8,12]))
        for i in range(8): c.uc.mem_write(OPTEAM+4+52*i,struct.pack('<H',500+i))
        for i in range(12): c.uc.mem_write(OPTEAM+0x1a4+44*i,struct.pack('<H',600+i))
        bat,pit=(BAT,OPPIT) if scope!='pitcher' else (OPBAT,PIT)
        att,defense=ATT,DEF
        c.uc.mem_write(ATT+0x25,bytes([5 if scope=='pitcher' else 4]))
        c.uc.mem_write(DEF+0x25,bytes([4 if scope=='pitcher' else 5]))
        if scope=='ordinary':bat=TEAM+0x1a4
        elif scope=='opponent_reserved':
            bat=TEAM+0x1a4;c.uc.mem_write(OPPIT,struct.pack('<H',1100))
        elif scope=='detached':
            c.uc.mem_write(FAKE,struct.pack('<H',1000));bat=FAKE
        elif scope=='same_team':c.uc.mem_write(DEF+0x25,b'\x04')
        elif scope=='null_player':bat=0
        elif scope=='null_entry':att=0
        elif scope=='missing_save':c.ptr(MGR+((0x520 if mode==3 else 0x528)if b.is64 else(0x4e4 if mode==3 else 0x4e8)),0)
        elif scope=='missing_teams':c.ptr(MGR+(0x530 if b.is64 else 0x4ec),0)
        elif scope=='missing_manager':c.callbacks[b.sym(GETMGR)+slide]=lambda:c.ret(0)
        elif scope=='noncareer':c.callbacks[b.sym(GETMODE)+slide]=lambda:c.ret(1)
        elif scope=='bad_count':c.uc.mem_write(TEAM+3,b'\x0d')
        elif scope=='bad_team':c.uc.mem_write(ATT+0x25,b'\x0f')
        return c,(att,bat,defense,pit)

    flag=a64.UC_ARM64_REG_NZCV if b.is64 else arm.UC_ARM_REG_APSR
    vectors=[getattr(a64 if b.is64 else arm,('UC_ARM64_REG_Q'if b.is64 else'UC_ARM_REG_D')+str(i))for i in range(32)]
    def snap(c):
        return dict(regs=[c.r(i) for i in range(len(c.regs))], sp=c.uc.reg_read(c.sp),
                    lr=c.uc.reg_read(c.lr), flags=c.uc.reg_read(flag)&0xf8000000,
                    vectors=[c.uc.reg_read(r) for r in vectors])
    def init_pair(c,row,args,lhs,rhs):
        c.uc.reg_write(c.sp,SP)
        for i in range(len(c.regs)):c.r(i,0x12000000+i)
        c.uc.reg_write(c.lr,STOP if b.is64 else STOP|1)
        for i,r in enumerate(vectors):c.uc.reg_write(r,0x123456789abcdef+i)
        c.uc.reg_write(flag,0x58000000)
        if b.is64:
            c.r(9 if row['label']=='intro_winner' else 8,lhs&0xffffffff)
            c.r(10 if row['label']=='intro_winner' else 9,rhs&0xffffffff)
        else:
            c.r(1 if row['label']=='intro_winner' else 0,lhs&0xffffffff)
            c.r(2 if row['label']=='intro_winner' else 1,rhs&0xffffffff)
            if row['label']=='intro_winner':c.r(0,0)
        for slot,value in zip(row['slots'],args):c.ptr(SP+slot,value)
        c.stopped=None;c.stops={slide+row['destination']}
        if row['branch']:c.stops.add(slide+row['branch'])

    for mode in (3,4):
        for scope in SCOPES:
            c,args=setup(mode,scope)
            expected=1 if scope=='batter' else -1 if scope=='pitcher' else 2
            got=invoke(c,symbols['yagu_mental_order'],*args)
            assert got&0xffffffff==expected&0xffffffff,(abi,mode,scope,got)
            count['semantic_scope']+=1
            reference,_=setup(mode,scope)
            for row in (r for r in sites if r['kind']=='decision'):
                reference.uc.mem_write(row['site']+slide,bytes.fromhex(row['expected']))
                for lhs,rhs in VALUES:
                    init_pair(reference,row,args,lhs,rhs);reference.run_relative(row['site'])
                    finite=snap(reference);finite_stop=reference.stopped
                    init_pair(c,row,args,lhs,rhs);before=bytes(c.uc.mem_read(SP,0x750));c.run_relative(row['site'])
                    actual=snap(c)
                    if expected!=2:
                        finite['flags']=(finite['flags']&0x08000000)|(0x20000000 if expected==1 else 0x80000000)
                        if row['branch']:
                            taken=expected!=0 if row['label']=='next_pitch_tie' else expected<0
                            finite_stop=slide+(row['branch']if taken else row['destination'])
                    assert actual==finite,(abi,mode,scope,row['label'],lhs,rhs,actual,finite)
                    assert c.stopped==finite_stop
                    assert bytes(c.uc.mem_read(SP,0x750))==before
                    count['decision_state']+=1
    print(abi,'mental scope/state pass',flush=True)

    def live_setup(c,args,mode,lhs,rhs,userdef,left):
        att,bat,defense,pit=args
        c.callbacks[b.sym(GETBAT)+slide]=lambda:c.ret(bat)
        c.callbacks[b.sym(GETPIT)+slide]=lambda:c.ret(pit)
        c.callbacks[b.sym('CBBGGameRun::GetAttEntryMgr() const')+slide]=lambda:c.ret(att)
        c.callbacks[b.sym('CBBGGameRun::GetDefEntryMgr() const')+slide]=lambda:c.ret(defense)
        c.callbacks[b.sym('CBBGEntryData::GetTeamPtr()')+slide]=lambda:c.ret(TEAM if c.r(0)==ATT else OPTEAM)
        c.callbacks[b.sym('CBBGTeamData::GET_ABIL(EnumBodyPart, CBBGPlayerData*, unsigned char, int, unsigned char)')+slide]=lambda:c.ret(lhs if c.r(2)==bat else rhs)
        c.callbacks[b.sym('CBBGPlayerData::IsLeft()')+slide]=lambda:c.ret(left)
        c.callbacks[b.sym('CBBGStatic::GetPlayData()')+slide]=lambda:c.ret(PLAY)
        c.callbacks[b.sym('CBBGPlayData::IsUserDefense()')+slide]=lambda:c.ret(userdef)
        c.callbacks[b.sym('CBBGGameRun::IsUserDefense()')+slide]=lambda:c.ret(userdef)
        c.callbacks[b.sym('CBBGPlayData::GetPitchingCount() const')+slide]=lambda:c.ret(2)
        for name in ('CBBGGameRun::INIT_HANDLER_GSTATE_PLAYER_SKILL_VIEW()',
                     'CBBGGameRun::GetBatPsvSkill() const','CBBGGameRun::GetPitPsvSkill() const'):
            c.callbacks[b.sym(name)+slide]=lambda:c.ret(0)

    # Execute original intro setup through both semantic comparisons and all
    # user-defense/left-handed color/winner stores, before graphics starts.
    for mode in (3,4):
        for scope in ('batter','pitcher','ordinary'):
            for lhs,rhs in VALUES[:6]:
                for userdef,left in ((0,0),(0,1),(1,0),(1,1)):
                    c,args=setup(mode,scope);live_setup(c,args,mode,lhs,rhs,userdef,left)
                    c.ptr(UI+(0x408 if b.is64 else 0x2c0),GAME)
                    c.uc.mem_write(UI+(0x410 if b.is64 else 0x2c4),struct.pack('<I',25))
                    c.callbacks[b.sym('CBBGGameRun_TexMakerMgr::GetInstPtr()')+slide]=lambda:c.ret(HEAP+0xc1000)
                    c.callbacks[b.sym('CBBGGameRun_TexMakerMgr::GetPZXMgr(BBG_RES_PZC_ID)')+slide]=lambda:c.ret(HEAP+0xc2000)
                    c.r(0,UI);c.uc.reg_write(c.sp,SP);c.stopped=None;c.stops={slide+(0x3c7fb8 if b.is64 else 0x253f84)}
                    c.run_relative(b.sym('CBBGGameRun_Scene_PlayerInfo::VisitSkillView()'))
                    base=c.uc.reg_read(c.sp)
                    winner=scope=='batter' or(scope=='ordinary' and lhs>=rhs)
                    expected_user=bool(winner)!=bool(userdef)
                    expected_color=bool(winner)!=bool(left)
                    offsets=(0x6cc,0x6c8,0x6c0)if b.is64 else(0x4db,0x4da,0x4d8)
                    got=tuple(c.uc.mem_read(base+n,1)[0]for n in offsets)
                    assert got==(int(winner),int(expected_user),int(expected_color)),(abi,mode,scope,lhs,rhs,userdef,left,got)
                    count['original_intro']+=1
    print(abi,'mental original intro pass',flush=True)

    for mode in (3,4):
        for scope in ('batter','pitcher','ordinary'):
            for lhs,rhs in VALUES[:6]:
                c,args=setup(mode,scope);live_setup(c,args,mode,lhs,rhs,scope=='pitcher',0)
                c.ptr(UI+(0x368 if b.is64 else 0x2bc),GAME)
                c.uc.mem_write(UI+(0x210 if b.is64 else 0x174),b'\x7f\x7f\x7f')
                called=[]
                c.callbacks[b.sym('CBBGGameRun_Scene_SltBallType::AddSkillView()')+slide]=lambda:(called.append(1),c.ret(0))
                invoke(c,b.sym('CBBGGameRun_Scene_SltBallType::InitSkillView()'),UI)
                tie=scope=='ordinary' and lhs==rhs
                assert len(called)==int(not tie)
                if tie:assert c.uc.mem_read(UI+(0x210 if b.is64 else 0x174),1)==b'\0'
                else:
                    winner=scope=='batter' or(scope=='ordinary'and lhs>rhs)
                    assert c.uc.mem_read(UI+(0x212 if b.is64 else 0x176),1)==bytes([winner])
                count['original_next_pitch']+=1

    # Own formatter writes only the original24-byte cell and keeps color prefix.
    # Finite fallback enters the unchanged bounded formatter with all its args.
    for mode in (3,4):
        for row in (r for r in sites if r['kind']=='format'):
            for scope in ('batter','pitcher','ordinary','opponent_reserved','detached','null_player','missing_save','noncareer'):
                for prefix in (b'!c00ff00',b'!cff0000'):
                    c,args=setup(mode,scope);att,bat,defense,pit=args
                    c.uc.mem_write(PREFIX,prefix+b'\0')
                    c.uc.mem_write(FORMAT,b'%s%d\0')
                    c.uc.mem_write(BUFFER-8,b'\xaa'*40)
                    c.ptr(SP+row['entry_slot'],defense if row['role']else att)
                    c.ptr(SP+row['actor_slot'],pit if row['role']else bat)
                    callargs=(BUFFER,24,FORMAT,PREFIX,3500)
                    for i,value in enumerate(callargs):
                        if i<(8 if b.is64 else 4):c.r(i,value)
                        else:c.uc.mem_write(SP,struct.pack('<I',value))
                    seen=[]
                    def fallback():
                        actual=tuple(c.r(i)if i<(8 if b.is64 else 4)else struct.unpack('<I',c.uc.mem_read(SP,4))[0]for i in range(5))
                        assert actual==callargs
                        seen.append(1);c.uc.mem_write(BUFFER,prefix+b'3500\0');c.ret(12)
                    c.callbacks[row['original_formatter']+slide]=fallback
                    c.uc.reg_write(c.sp,SP);c.stopped=None;c.stops={row['site']+4+slide}
                    c.run_relative(row['site'])
                    owned=(scope=='batter'and row['role']==0)or(scope=='pitcher'and row['role']==1)
                    expected=prefix+('∞'.encode()if owned else b'3500')+b'\0'
                    assert bytes(c.uc.mem_read(BUFFER,len(expected)))==expected
                    assert c.uc.mem_read(BUFFER-8,8)==b'\xaa'*8
                    assert c.uc.mem_read(BUFFER+24,8)==b'\xaa'*8
                    assert len(seen)==int(not owned)and c.uc.reg_read(c.sp)==SP
                    count['formatter']+=1

    for name in ('CBBGLevelMgr::IsBatSkillCheck(EnumPassiveSkills, CBBGEntryMgr*, CBBGEntryMgr*, CBBGRunnerMgr*, CBBGPlayData*)',
                 'CBBGLevelMgr::IsPitSkillCheck(EnumPassiveSkills, CBBGEntryMgr*, CBBGEntryMgr*, CBBGRunnerMgr*, CBBGPlayData*)',
                 'CBBGGameRun::SetViewBatPsvSkill(unsigned char)','CBBGGameRun::SetViewPitPsvSkill(unsigned char)'):
        address=b.sym(name);off=b.offset(address);size=b.symbols[name]['size']
        assert b.image[off:off+size]==b.original[off:off+size];count['unchanged_skill_effects']+=1
    final=b.finish(WORK/'mental_duel_build'/abi/'libgameDSO.so')
    return dict(abi=abi,counts=count,passed=sum(count.values()),sites=sites,
                source_c_sha256=hashlib.sha256((source_dir/'yagu_payload.c').read_bytes()).hexdigest(),
                output_sha256=final['output_sha256'],slide=hex(slide),android_runtime_verified=False)


if __name__=='__main__':
    source=WORK/'mental_duel_build/source';stage=stage_payload(source)
    results=[verify(abi,source)for abi in('arm64-v8a','armeabi-v7a')]
    (WORK/'mental_duel_verification.json').write_text(json.dumps(dict(stage=stage,results=results),indent=2)+'\n')
    print(json.dumps(results,indent=2))
