"""Local mean adapter, two existing team-level cells and four quest decisions."""
from gameplay_hooks import A64_SAVE,A64_RESTORE,T32_SAVE,T32_RESTORE
from career_resource_ui import _a64_stack,_thumb_stack

NUMBER='DrawCCFitNumber(ccpzx::CCPZXFrame*, int, int, int, cocos2d::CCRect&, int, int, int, int, bool, bool, bool, bool, int)'
FONT='AddChildFitSystemFont(char const*, int, int, cocos2d::CCRect&, int, int, int, bool, bool, bool)'
SITES={
 'arm64-v8a':dict(adapter=(0x36e2c4,'cf010f94'),header=(0x37b090,'f0c80e94',0x50,0x8c),menu=(0x45f870,'40400b94',0x1f0,0x30c),
                quests=((0x45625c,'0800086bab000054',0xc8),(0x45693c,'0800086bab000054',0x40),(0x53e128,'0800086bab000054',0xc8),(0x53e808,'0800086bab000054',0x40))),
 'armeabi-v7a':dict(adapter=(0x21a6d6,'56f28cee'),header=(0x222ea4,'4cf2c4ef',0x4c,0x68),menu=(0x2b676e,'bbf108ee',0x104,0x184),
                 quests=((0x2b0294,'884204db',0x64),(0x2b06de,'884204db',0x20),(0x34abde,'884204db',0x60),(0x34b028,'884204db',0x1c)))
}


def add_team_mean_hooks(b,symbols):
    spec=SITES[b.abi];out=[]
    site,expected=spec['adapter']
    b.patch(site,b.branch(site,symbols['yagu_team_mean'],True),'Local owned team mean adapter',expected)
    out.append(dict(kind='adapter',site=site,expected=expected))
    site,expected,dm_slot,index_slot=spec['header']
    if b.is64:
        source=f'''{A64_SAVE}
ldr x1,[sp,#{80+dm_slot}]
ldr w2,[sp,#{80+index_slot}]
bl #{symbols['yagu_format_team_mean']}
tbnz w0,#31,original
str x0,[sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{b.sym('MC_knlSprintk')}'''
    else:
        source=f'''{T32_SAVE}
ldr r1,[sp,#{24+dm_slot}]
ldr r2,[sp,#{24+index_slot}]
bl #{symbols['yagu_format_team_mean']}
cmp r0,#0
blt original
str r0,[sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{b.sym('MC_knlSprintk')}'''
    hook=b.append_asm('Derived team mean header',source);b.patch(site,b.branch(site,hook,True),'Owned team mean header infinity',expected)
    out.append(dict(kind='header',site=site,expected=expected,hook=hook,dm_slot=dm_slot,index_slot=index_slot))
    site,expected,dm_slot,index_slot=spec['menu']
    if b.is64:
        def offset(i):return 32+i*8 if i<8 else 112+(i-8)*8
        source=f'''{A64_SAVE}
ldr x0,[sp,#{80+dm_slot}]
ldr w1,[sp,#{80+index_slot}]
bl #{symbols['yagu_team_mean_text']}
cbz x0,original
sub sp,sp,#32
ldr w8,[sp,#{offset(10)}]
str w8,[sp]
mov w8,#1
str w8,[sp,#8]
ldr w1,[sp,#{offset(2)}]
ldr w2,[sp,#{offset(3)}]
ldr x3,[sp,#{offset(4)}]
ldr w4,[sp,#{offset(8)}]
ldr w5,[sp,#{offset(5)}]
ldr w6,[sp,#{offset(6)}]
ldr w7,[sp,#{offset(9)}]
bl #{b.sym(FONT)}
add sp,sp,#32
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{b.sym(NUMBER)}'''
    else:
        def offset(i):return 32+i*4 if i<4 else 56+(i-4)*4
        source=f'''{T32_SAVE}
ldr.w r0,[sp,#{24+dm_slot}]
ldr.w r1,[sp,#{24+index_slot}]
bl #{symbols['yagu_team_mean_text']}
cmp r0,#0
beq original
sub sp,sp,#32
ldr r1,[sp,#{offset(8)}]
str r1,[sp]
ldr r1,[sp,#{offset(5)}]
str r1,[sp,#4]
ldr r1,[sp,#{offset(6)}]
str r1,[sp,#8]
ldr r1,[sp,#{offset(9)}]
str r1,[sp,#12]
ldr r1,[sp,#{offset(10)}]
str r1,[sp,#16]
movs r1,#1
str r1,[sp,#20]
ldr r1,[sp,#{offset(2)}]
ldr r2,[sp,#{offset(3)}]
ldr r3,[sp,#{offset(4)}]
bl #{b.sym(FONT)}
add sp,sp,#32
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{b.sym(NUMBER)}'''
    hook=b.append_asm('Derived team mean original menu cell',source);b.patch(site,b.branch(site,hook,True),'Owned team mean menu infinity',expected)
    out.append(dict(kind='menu',site=site,expected=expected,hook=hook,dm_slot=dm_slot,index_slot=index_slot))
    for index,(site,expected,dm_slot)in enumerate(spec['quests']):
        pair=list(b.cs.disasm(bytes.fromhex(expected),site))
        if len(pair)!=2 or pair[0].mnemonic not in('cmp','subs')or pair[1].mnemonic not in('b.lt','blt'):raise ValueError('Unexpected team quest compare')
        comparison=pair[0].mnemonic+' '+pair[0].op_str;taken=int(pair[1].op_str[1:],16);fallthrough=site+len(bytes.fromhex(expected))
        if b.is64:
            save,restore=_a64_stack();args=f'''ldr x0,[sp,#{704+dm_slot}]
mov w1,#0
ldr w2,[sp,#64]
mov w3,#0
bl #{symbols['yagu_team_mean_goal']}
tbnz w0,#31,original''';jump='b'
        else:
            save,restore=_thumb_stack();args=f'''ldr r0,[sp,#{288+dm_slot}]
movs r1,#0
ldr r2,[sp,#268]
movs r3,#0
bl #{symbols['yagu_team_mean_goal']}
cmp r0,#0
blt original''';jump='b.w'
        source=f'''{comparison}
{save}
{args}
{restore}
{jump} #{fallthrough}
original:
{restore}
{pair[1].mnemonic} taken
{jump} #{fallthrough}
taken:
{jump} #{taken}'''
        hook=b.append_asm('Derived team mean goal '+str(index),source)
        new=b.branch(site,hook)
        while len(new)<len(bytes.fromhex(expected)):new+=b.asm('nop',site+len(new))
        b.patch(site,new,'Owned unbounded team mean goal '+str(index),expected)
        out.append(dict(kind='quest',site=site,expected=expected,hook=hook,dm_slot=dm_slot,taken=taken,fallthrough=fallthrough))
    return out
