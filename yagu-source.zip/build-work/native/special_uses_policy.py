"""Pure source/builder integration for typed SUPER stock and cumulative uses."""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
INCLUDE = '#include "special_uses_payload.inc"'
BINDINGS = {
    'original_special_raise_mode': 'CBBGDataMgr::GetRaiseMode(eGameMode)',
    'original_special_count': 'CBBGRaiseMode::GetSpecialCnt()',
    'original_special_add': 'CBBGRaiseMode::AddSpecialCnt(int)',
}


def once(source, old, new, label):
    if new in source:
        if source.count(new) != 1: raise ValueError('Repeated ' + label)
        return source
    if source.count(old) != 1: raise ValueError('Missing unique ' + label)
    return source.replace(old, new)


def integrate_source(source):
    # Later independently integrated player fields may advance the schema.
    # Idempotence must preserve those append-only extensions verbatim.
    if INCLUDE in source:
        if source.count(INCLUDE) != 1 or source.count('    Scalar special_uses;') != 2:
            raise ValueError('Partial or repeated SUPER integration')
        if 'if (selector == 32) return yagu_special_event_check(role, threshold);' not in source:
            raise ValueError('SUPER event consumer is missing')
        return source
    source = once(source, '    Scalar popularity;\n} InfinitePlayer;',
                  '    Scalar popularity;\n    /* Schema3: available special-use inventory. */\n'
                  '    Scalar special_uses;\n} InfinitePlayer;', 'special stock field')
    source = once(source, '    Scalar cup_mvps;\n} InfiniteRecords;',
                  '    Scalar cup_mvps;\n    /* Schema4: cumulative special activations. */\n'
                  '    Scalar special_uses;\n} InfiniteRecords;', 'special total field')
    if 'static const InfinitePlayer my_state = {\n    2, MY_BAT,' in source:
        start = source.index('static const InfinitePlayer my_state = {')
        end = source.index('\n};', start)
        init = source[start:end]
        updated = init.replace('    2, MY_BAT,', '    3, MY_BAT,', 1) + ', INF'
        source = source[:start] + updated + source[end:]
    elif 'static const InfinitePlayer my_state = {\n    3, MY_BAT,' not in source:
        raise ValueError('Unexpected player initializer before SUPER append')
    if 'static const InfiniteRecords my_records = {\n    3, MY_BAT,' in source:
        start = source.index('static const InfiniteRecords my_records = {')
        end = source.index('\n};', start)
        init = source[start:end]
        updated = init.replace('    3, MY_BAT,', '    4, MY_BAT,', 1) + ', INF'
        source = source[:start] + updated + source[end:]
    elif 'static const InfiniteRecords my_records = {\n    4, MY_BAT,' not in source:
        raise ValueError('Unexpected record initializer before SUPER append')
    source = once(source, '#include "honors_payload.inc"',
                  '#include "honors_payload.inc"\n' + INCLUDE, 'special implementation')
    source = once(source,
                  '        return yagu_honor_event_check(role, selector, threshold);',
                  '        return yagu_honor_event_check(role, selector, threshold);\n'
                  '    /* Original selector32 is cumulative and period independent. */\n'
                  '    if (selector == 32) return yagu_special_event_check(role, threshold);',
                  'special event selector')
    return source


def integrate_builder(source):
    if "        add_special_uses_hooks(b,report['symbols'])" in source:
        if not all(repr(k) + ': ' + repr(v) in source for k, v in BINDINGS.items()):
            raise ValueError('Partial SUPER builder integration')
        return source
    addition = ''.join('    ' + repr(k) + ': ' + repr(v) + ',\n' for k, v in BINDINGS.items())
    source = once(source, 'BINDINGS = {\n', 'BINDINGS = {\n' + addition, 'special bindings')
    source = once(source, '    from award_record_ui import add_award_record_ui_hooks',
                  '    from award_record_ui import add_award_record_ui_hooks\n'
                  '    from special_uses_hooks import add_special_uses_hooks', 'special hook import')
    source = once(source, "        add_award_record_ui_hooks(b,report['symbols'])",
                  "        add_award_record_ui_hooks(b,report['symbols'])\n"
                  "        add_special_uses_hooks(b,report['symbols'])", 'special hooks')
    source = once(source, "'semantic_player_schema': 2, 'semantic_player_scalars': 46,",
                  "'semantic_player_schema': 3, 'semantic_player_scalars': 47,", 'special player metadata')
    source = once(source, "'semantic_record_schema': 3, 'semantic_record_scalars': 39,",
                  "'semantic_record_schema': 4, 'semantic_record_scalars': 40,", 'special record metadata')
    source = once(source, "'unbounded_record_scalars': 32,",
                  "'unbounded_record_scalars': 33,", 'special total metadata')
    return source


def stage_payload(output_dir, source_dir=WORK):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    original = (source_dir / 'yagu_payload.c').read_text()
    source = integrate_source(original)
    (output_dir / 'yagu_payload.c').write_text(source)
    pending = re.findall(r'^#include "([^"]+)"', source, re.MULTILINE)
    dependencies = {}
    while pending:
        name = pending.pop()
        if name in dependencies: continue
        if '/' in name or '\\' in name: raise ValueError('Unexpected include ' + name)
        raw = ((WORK if name == 'special_uses_payload.inc' else source_dir) / name).read_bytes()
        (output_dir / name).write_bytes(raw)
        dependencies[name] = hashlib.sha256(raw).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"', raw.decode(), re.MULTILINE))
    manifest = dict(base_c_sha256=hashlib.sha256(original.encode()).hexdigest(),
                    staged_c_sha256=hashlib.sha256(source.encode()).hexdigest(),
                    dependencies=dependencies, player_schema=3, player_scalars=47,
                    record_schema=4, record_scalars=40, shared_source_modified=False)
    (output_dir / 'special_uses_stage_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest
