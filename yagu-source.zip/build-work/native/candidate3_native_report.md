# Candidate 3 native implementation and evidence

## Frozen build

The packaging input is `candidate3-native/lib`, not the mutable `integrated`
directory. There are 98 original-library patch sites per ABI. The original APK
and extracted original libraries have not been modified.

| ABI | Frozen `libgameDSO.so` SHA-256 | Bytes |
|---|---|---:|
| arm64-v8a | `a483bc708451481eb85d32692f02c99fb45098738e77c1fa395e1caed0f1ef41` | 8,078,800 |
| armeabi-v7a | `0a815fad4f7ea79cb7eed34a24facd5f0cd377154c2bfa006f747b938cc7e7fe` | 5,044,708 |

The C source SHA-256 is
`94b7b34a8a2ea69d80abe0b868fd002c479a94232a3633355fbcd103451dc63f`.
The adjacent manifest records these hashes. Each ABI also has an integration
manifest and a complete original-byte patch report.

The complete native pipeline is `payload_builder.py`. `YAGU_ZIG` optionally
selects the Zig compiler. `YAGU_CERT_HASH` optionally selects the expected
Android `Signature.hashCode()` of the deliberate local signing certificate.
Candidate 3 was built with `YAGU_CERT_HASH=0x6de25a17`.

## Semantic state and game participation

The paired roles use persistent original player IDs 1000 and 1100 in the same
owned BAT career. The role synchronizer adds the pitching object to the own
team, gives it the same player name, and retains the unique pitching record
by RFID even when the original pregame rotation moves roster objects.
Original initialization and lineup updates select the paired player as both
the starting pitcher and first batter. Replacement protection applies to the
owned My pitcher, and the original manual-control selector permits both roles.

The semantic player state contains **43 tagged Unbounded scalars**: level,
four primary abilities, stamina, experience, condition, special level, passive
skill level, four training levels, 28 pitch levels, and derived pitch speed.
The tag has no finite maximum and arithmetic preserves it. Legacy engine
getters expose deliberately bounded compatibility projections where the
original game needs integer table indices, nibble fields, animation state or
finite physics. These projections are not the semantic infinity value.

The semantic personal-record state contains **31 metrics**. Twenty-five are
Unbounded. Six pitching metrics remain exactly zero: ERA, earned runs,
allowed hits, losses, walks and WHIP. Actual live innings, outs, scorekeeping,
original season records and normal save counters remain finite and follow
the original result events. The original personal history table displays the
canonical semantic history; the implementation does not invent a finite
sequence of past played games.

The gameplay wrappers return the original HR aggregate for the owned My
batter's accepted swing, and the original miss/strike result for opponents
facing the owned My pitcher. The original strike counter, strikeout event,
home-run event, scorekeeping, inning progression and record updates remain
downstream. The source does not overwrite a finished scorecard to simulate a
perfect game. Full nine-inning behavior still requires Android gameplay
observation.

## Implemented text coverage

| Existing UI location | Semantic display | Scope |
|---|---|---|
| Career frame level | ∞ | Actual My player pointer |
| Start-menu My player level | Lv. ∞ | Identified My player caller |
| Main player-info four abilities | ∞ | Actual My player, both role layouts |
| Main player-info experience | ∞ | Actual My player |
| Career condition | ∞ | Current owned career mode |
| Rest-menu condition, initial and animated | ∞ / ∞ | Current owned career mode; two numeric callers only |
| Equipped passive-skill box | Lv ∞ | Nonzero equipped skill and actual own-roster My player |
| Selected pitch-type level | Lv ∞ | Current owned mode on the existing pitch-selection screen |
| Post-pitch speed | ∞ km or ∞ mph | Current owned My pitcher |
| Live player-info batter and pitcher levels | ∞ | Owned entry and matching role ID |
| Live player-info AVG, HR, RBI and K | ∞ | Owned entry and matching role ID |
| Live pitcher ERA | 0 | Owned entry and matching role ID |
| Missing-record live player-info cells | Same semantic projection | Same owned-role checks |
| Personal batting/pitching record table | 13 fields for each role | Actual owned career/role and vetted table callers |

The personal record screen uses its existing arrow and swipe controls for
six pages: three batting pages followed by three pitching pages. Its original
three-page layout indices are normalized locally; no new UI system or asset
layout was added. The mode-4 pitching-history route resolves the stable
paired pitching record inside the BAT save and never dereferences a missing
PIT save. Original mode-3 behavior retains three pages.

The text hooks preserve the original font methods, color/size arguments,
node tags, rectangles, alignment and animation paths. The sibling font audit
found the Android Canvas/BBF rendering path, valid UTF-8 pass-through, and an
actual U+221E glyph in the Android 24 emulator's Roboto font. Those are font
availability facts; a displayed screenshot is separate runtime evidence.

## Signer compatibility

The input certificate hash is `0x29b34343`. The local signing certificate hash
is `0x6de25a17`, independently observed in Android package metadata. The
original consumed `circleConfig.conf` selects company 5.

Only the expected public-certificate value changes: the A64 immediate pair
at `0x6acba4` and the Thumb literal at `0x42cbc4`. Company selection, check
enable, actual-certificate retrieval, equality comparison and failure branch
remain intact. The hash lock and original-byte assertions guard both sites.
`verify_signer_pin.py` executes the original company selector for all 15
companies at a nonzero load bias. Only company 5 and 15 change. It then
executes the original enabled comparison: the local certificate succeeds;
the original certificate, zero and an off-by-one hash still reject.

This is configuration of the expected signer for this deliberately re-signed
build. No account, purchase, network authentication or server validation is
altered by the signer module.

## Verification boundaries

The following are instruction-level tests, not complete Android sessions:

| Report/script | Verified cases across both ABIs |
|---|---:|
| `verify_payload.py` | 50 core two-way/state/rotation checks |
| `verify_gameplay_hooks.py` | 70 gameplay/ownership/fallback checks |
| `verify_infinity_ui.py` | 28 original infinity UI cases |
| `verify_career_ability_ui.py` | 80 new career/condition/skill text cases |
| `verify_live_stats_ui.py` | 280 new live-player text cases |
| `verify_pitch_speed_ui.py` | 36 speed/unit/ownership cases |
| `verify_personal_records.py` | 208 table-font cases, plus semantic/scope checks |
| `verify_record_navigation.py` | 192 redirected scroll calls, 24 original key paths, 24 role selections, 24 layout loads, 14 past-record cases |
| `verify_relocation.py` | 48 checks, 208 native calls at four nonzero load biases |
| `verify_defender_hooks.py` | 576 defender-path and register-preservation cases |
| `verify_game_run_uniform_hooks.py` | 2,052 batter/pitcher clothing-path cases |
| `verify_starting_pitcher.py` | 14 original startup/record-resolution checks |
| `verify_signer_pin.py` | 54 original selection/comparison checks |

Each report carries its own source hash or boundary description. External
engine services are mocked at their ABI boundaries where stated. Complete
Android loader, real input, nine-inning play, saving/reloading, and rendered
page behavior are not established by these tests. The Android agent's
screenshots/logs supply that separate evidence when available.

## Known remaining coverage and compatibility limits

- This is not a claim that every numeric field in every original menu now
  displays infinity. Training reward/SP balances and finite economy values
  are distinct from personal abilities and were not relabeled blindly.
- Stamina/fitness use the original bounded gauges. They retain safe finite
  animation projections; there is no verified original numeric stamina label
  in the audited paths.
- Passive effect-description percentages, some skill-list/detail widgets,
  entry/lineup lists and rankings can still expose finite legacy projections.
  Equipped passive level and the specifically listed panels are covered.
- Unlearned passive skills remain unlearned. Membership and skill level are
  separate original fields; the payload promotes an owned learned skill's
  level without inventing membership.
- The existing pitch-selection menu has mode-3-specific reads in its draw
  path. The new two-way career does not expose a new route into that menu.
  Adding such a route requires a separate mode-4-safe access review.
- The 31 semantic record fields include five extended career counters whose
  dedicated numeric UI consumers have not all been identified. Live score,
  inning/out counters, rankings and team/season totals remain normal.
- The original ELF segments and appended segment use 4 KiB alignment.
  APK ZIP alignment alone does not prove 16 KiB native-loader support.
- A64 has instruction-level verification; an actual ARM64 Android gameplay
  session is still required. The working full-device test environment is
  ARMv7 Android 24.

