"""Pure integration of the explicit local-development catalog."""
from pathlib import Path
import hashlib
import re

WORK = Path(__file__).resolve().parent
INCLUDE = '#include "local_catalog_payload.inc"'
BINDINGS = {
    'catalog_define': 'CGsSingleton<CBBGMgrDefine>::GetInstPtr()',
    'catalog_loader': 'CBBGMgrDefine::GetXLData(EnumXlsData)',
    'catalog_x': 'GVXLLoader::GetX()',
    'catalog_y': 'GVXLLoader::GetY()',
    'catalog_value': 'GVXLLoader::GetVal(int, int)',
    'catalog_original_equip_price': 'CBBGStatic::GetNeedPriceBuyEquipItem(int, int, bool)',
    'catalog_original_equip_discount': 'CBBGStatic::GetDCPerBuyEquipItem(int, int, bool)',
    'catalog_original_equip_sale': 'CBBGStatic::GetSaleTypeBuyEquipItem(int, int, bool)',
    'catalog_original_costume_price': 'CBBGStatic::GetNeedPriceBuyCostumeItem(int, int)',
    'catalog_original_costume_discount': 'CBBGStatic::GetDCPerBuyCostumeItem(int, int)',
    'catalog_original_costume_sale': 'CBBGStatic::GetSaleTypeBuyCostumeItem(int, int)',
    'catalog_original_effect_price': 'CBBGStatic::GetNeedPriceBuyEffectItem(int, bool)',
    'catalog_original_effect_discount': 'CBBGStatic::GetDCPerBuyEffectItem(int, bool)',
    'catalog_original_effect_sale': 'CBBGStatic::GetSaleTypeBuyEffectItem(int, bool)',
    'catalog_original_effect_g': 'CBBGStatic::IsUseGpointBuyEffectItem(int, bool)',
    'catalog_rotate': 'CBBGModeData::SetEffectStoreListRotation(int)',
    'catalog_worldmap_popup': 'CBBGWorldmapBuylinkUI::AddBuyLinkPopup()',
    'catalog_gift_running': 'CBBGStrengthAllPlayerUI::GetRunningBegGiftPopup()',
    'catalog_gift_set_running': 'CBBGStrengthAllPlayerUI::SetRunningBegGiftPopup(bool)',
    'catalog_create_buy_popup': 'CBBGStatic::CreateBuyCCPopup(int, bool, int)',
}

def integrate_source(source):
    if INCLUDE in source:
        if source.count(INCLUDE) != 1: raise ValueError('Repeated catalog integration')
        return source
    if '#include "wallet_payload.inc"' not in source: raise ValueError('Local wallet must precede catalog')
    return source.rstrip() + '\n\n' + INCLUDE + '\n'

def integrate_builder(source):
    def once(old,new,label):
        nonlocal source
        if new in source:
            if source.count(new) != 1: raise ValueError('Repeated '+label)
            return
        if source.count(old) != 1: raise ValueError('Missing unique '+label)
        source=source.replace(old,new)
    once('BINDINGS = {\n', 'BINDINGS = {\n'+''.join('    '+repr(k)+': '+repr(v)+',\n' for k,v in BINDINGS.items()), 'catalog bindings')
    once('    from signer_pin import add_signer_pin_patch', '    from local_catalog_hooks import add_local_catalog_hooks\n    from signer_pin import add_signer_pin_patch', 'catalog import')
    once('        signer_pin = add_signer_pin_patch', "        local_catalog = add_local_catalog_hooks(b, report['symbols'])\n        signer_pin = add_signer_pin_patch", 'catalog installation')
    once("'defender_paths': defender_paths,", "'defender_paths': defender_paths,\n            'local_development_catalog': local_catalog,", 'catalog report')
    return source

def stage_payload(output_dir, source_dir=WORK):
    output_dir, source_dir=Path(output_dir),Path(source_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    raw=(source_dir/'yagu_payload.c').read_text();staged=integrate_source(raw)
    (output_dir/'yagu_payload.c').write_text(staged)
    pending=re.findall(r'^#include "([^"]+)"',staged,re.MULTILINE);dependencies={}
    while pending:
        name=pending.pop()
        if name in dependencies:continue
        if Path(name).name!=name or '\\' in name:raise ValueError('Unsafe include')
        path=(WORK if name=='local_catalog_payload.inc' else source_dir)/name
        if path.is_symlink():raise ValueError('Symlink include')
        value=path.read_bytes();(output_dir/name).write_bytes(value)
        dependencies[name]=hashlib.sha256(value).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"',value.decode(),re.MULTILINE))
    return {'base_c_sha256':hashlib.sha256(raw.encode()).hexdigest(),'staged_c_sha256':hashlib.sha256(staged.encode()).hexdigest(),'dependencies':dependencies}
