"""Pure, append-only integration of owned tagged skill-point availability."""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
INCLUDE = '#include "skill_points_payload.inc"'
HOOKS = {
    'skill_points': 'CBBGModeData::GetSpecialPoint()',
    'set_skill_points': 'CBBGModeData::SetSpecialPoint(int)',
    'add_skill_points': 'CBBGModeData::AddSpecialPoint(int)',
}
BINDINGS = {'original_sp_raise_mode': 'CBBGDataMgr::GetRaiseMode(eGameMode)'}


def once(source, old, new, label):
    if new in source:
        if source.count(new) != 1: raise ValueError('Repeated ' + label)
        return source
    if source.count(old) != 1: raise ValueError('Missing unique ' + label)
    return source.replace(old, new)


def integrate_source(source):
    return once(source, '#include "batting_rescue_payload.inc"',
                '#include "batting_rescue_payload.inc"\n' + INCLUDE, 'skill point implementation')


def integrate_builder(source):
    if "        add_skill_points_hooks(b,report['symbols'])" in source:
        if not all(repr(k) + ': ' + repr(v) in source for k, v in {**HOOKS, **BINDINGS}.items()):
            raise ValueError('Partial skill-point builder integration')
        return source
    addition = ''.join('    ' + repr(k) + ': ' + repr(v) + ',\n' for k, v in HOOKS.items())
    source = once(source, 'HOOKS = {\n', 'HOOKS = {\n' + addition, 'skill point entries')
    addition = ''.join('    ' + repr(k) + ': ' + repr(v) + ',\n' for k, v in BINDINGS.items())
    source = once(source, 'BINDINGS = {\n', 'BINDINGS = {\n' + addition, 'skill point binding')
    source = once(source, '    from batting_rescue_hooks import add_batting_rescue_hook',
                  '    from batting_rescue_hooks import add_batting_rescue_hook\n'
                  '    from skill_points_hooks import add_skill_points_hooks', 'skill point import')
    source = once(source, "        add_batting_rescue_hook(b,report['symbols'])",
                  "        add_batting_rescue_hook(b,report['symbols'])\n"
                  "        add_skill_points_hooks(b,report['symbols'])", 'skill point hooks')
    return source


def integrate_award_source(source):
    """Add exact SP callers to the existing one-owner integer styling hook."""
    if 'skill_point_number_branches' in source:
        if source.count('{skill_points}') != 2:
            raise ValueError('Partial shared skill-point styling integration')
        return source
    source = once(source,
                  'from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE',
                  'from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE\n'
                  'from skill_points_hooks import skill_point_number_branches', 'skill point style import')
    source = once(source,
                  '    for label, site, expected, current_caller, past_caller in SITES[b.abi]:',
                  '    for label, site, expected, current_caller, past_caller in SITES[b.abi]:\n'
                  "        skill_points = skill_point_number_branches(b, symbols, site) if label == 'integer' else ''",
                  'skill point style scope')
    source = once(source, "source = f'''{A64_SAVE}\nldr x8, [x29, #8]",
                  "source = f'''{A64_SAVE}\n{skill_points}\nldr x8, [x29, #8]", 'skill point A64 style')
    source = once(source, "source = f'''{T32_SAVE}\nldr r3, [r7, #4]",
                  "source = f'''{T32_SAVE}\n{skill_points}\nldr r3, [r7, #4]", 'skill point Thumb style')
    return source


def stage_payload(output_dir, source_dir=WORK):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    original = (source_dir / 'yagu_payload.c').read_text()
    source = integrate_source(original)
    (output_dir / 'yagu_payload.c').write_text(source)
    pending = re.findall(r'^#include "([^"]+)"', source, re.MULTILINE)
    dependencies = {}
    while pending:
        name = pending.pop()
        if name in dependencies: continue
        if '/' in name or '\\' in name: raise ValueError('Unexpected include ' + name)
        raw = ((WORK if name == 'skill_points_payload.inc' else source_dir) / name).read_bytes()
        (output_dir / name).write_bytes(raw)
        dependencies[name] = hashlib.sha256(raw).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"', raw.decode(), re.MULTILINE))
    manifest = dict(base_c_sha256=hashlib.sha256(original.encode()).hexdigest(),
                    staged_c_sha256=hashlib.sha256(source.encode()).hexdigest(),
                    dependencies=dependencies, shared_source_modified=False,
                    scalar_namespace='standalone owned career skill points; player/record layouts unchanged')
    (output_dir / 'skill_points_stage_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    return manifest
