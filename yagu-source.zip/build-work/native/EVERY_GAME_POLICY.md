# Every-game two-way participation

The requested career is the original mode-4 saved batting career with a paired
pitcher role in the same team and save. It is not a one-match exhibition mode.
The player supplies the original batting and pitching inputs in each game.

## Reapply on every fixture

`yagu_entry_init` and `yagu_entry_update` call the original initializer/updater,
then re-find the owned My pitcher and batter and swap them into starting-pitcher
and first-batter slots. The wrappers run every time those original methods run;
there is no first-game flag or consumed grant. Other roster indices are swapped,
not duplicated. The other eight batters retain ordinary play so innings finish.

The preview in `CBBGPlayBallRun::SetRaiseGameInfo` can rotate the physical pitcher
roster after constructing its entries, including ARM64 `0x3a95d0`. The actual
normal mode-4 game setup subsequently constructs fresh entries in
`CBBGGameRun::InitGameData` and invokes the hooked update methods. The existing
`starting_pitcher_review.md` and its 14 instruction tests cover this activation
ordering and the separate RFID-based pitching-record slot.

`my_turn` identifies the owned current pitching or batting role. On these turns
the existing simulator hooks select manual play. Opponents and the eight other
batters use the original simulation. The pitching policy prevents depletion,
wild pitches, hit-by-pitch and substitution while the owned My pitcher is active.
The original inning, strike, out, scoring, and game-result bookkeeping runs.

## Tournament routing

The original postseason and world-tournament menus compare **both** sides of
the upcoming fixture with `GetRaiseTeamIndex`. They invoke computer-only
simulation only when neither side is the owned team. An owned fixture produces
the normal playable-game result, which the career runner passes to
`DoNextGame` and the original play-ball runnable. These methods are unchanged.

`verify_every_game_routing.py` executes both original menu bodies on ARM64 and
Thumb with nonzero load addresses: all ten own-team indices, both home/away
positions, domestic and world-opponent fixtures, and unrelated-team controls.
The report contains 240 checks. Controlled table lookups supply the fixture;
the original comparisons, branch, result write and return execute. This is not
evidence of having played an entire season or tournament on Android.

## Keep the same batter through missions

One additional replacement path exists in the original game: a burst mission
can request an Ace batter, and the AI also supports a forced substitution.
`batter_presence_payload.inc` addresses only an active owned mode-4 batter:

- The entry must belong to the current saved team and have mode4.
- The active BAT save must be the owned mode object.
- The original current-batter lookup must resolve the exact owned actor pointer.
  A copied RFID on another team or detached object is insufficient.
- A replacement reservation is ignored for this actor; forced AI replacement
  returns false before it changes any reservation or AI state.
- The exact `IsAceChange` call in `EVENT_HANDLER_GSTATE_SET_PLAYER` returns false
  for that actor, letting the original normal-mission branch execute. It does
  not invent a completed mission or enter an empty player-change scene.

There are two entry hooks and one exact mission call per ABI. Other batters,
opponents, training/exhibition modes, and absent or mismatched saves use their
original paths. No schedule, score, completed result, or server state is written
by this module.

## Batting and pitching outcomes

The batting-result hook and contact rescue are applied to each owned appearance,
not to a game number. A received manual swing uses the original contact/event
path and the owned home-run result policy. The terminal-count rescue remains a
separate safeguard for delayed input. The player's intended flow remains a
manual swing at every appearance. Exact acceptance and animation behavior must
also be checked in the original Android screen.

On the `e4adc580…` earlier APK, an actual game completed with the same starter,
81 strikes on 81 pitches, 27 strikeouts, and an 8:0 score with opponent H0/R0.
The original result details independently displayed 27 three-pitch strikeouts.
That candidate had two late-input batting strikeouts; it does **not** prove the
later rescue or every-appearance home-run requirement. Subsequent APK identities,
manual batting results, save/reload observations and consecutive-game checks
belong in `build-work/android/current-runtime-public.json`.

## Remaining verification boundary

Native branch/ABI checks, actual single-game play, consecutive-game play, and a
complete season are distinct evidence. This policy does not label an unplayed
full season or world-tournament run as tested. Original finite inning counts,
season schedules and save layouts remain necessary for a playable game.
