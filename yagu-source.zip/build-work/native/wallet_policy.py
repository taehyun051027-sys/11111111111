"""Integrate the separate typed local wallet without altering player schemas."""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
INCLUDE = '#include "wallet_payload.inc"'
BINDINGS = {
    'wallet_get_option': 'CBBGDataMgr::GetOption()',
    'wallet_original_get_g': 'CBBGOption::GetGPoint()',
    'wallet_original_get_star': 'CBBGOption::GetStarPoint()',
    'wallet_original_add_g': 'CBBGOption::AddGPoint(int, unsigned char)',
    'wallet_original_add_star': 'CBBGOption::AddStarPoint(int, bool, int, int, int, int)',
    'wallet_worldmap_buy': 'CBBGWorldmapBuylinkUI::BuyProcess()',
    'wallet_lucky_buy': 'CBBGLuckyBoxUI::BuyProcess()',
    'wallet_lucky_animate': 'CBBGLuckyBoxUI::ResultAniProcess()',
    'wallet_camp_complete': 'CBBGSpringCampUI::CompleteOverseas()',
    'wallet_set_skill_slots': 'CBBGModeData::SetPsvSkillMax(int)',
    'wallet_skill_icon': 'CBBGSkillInfoUI::ChangeSlotIcon(bool, int, int)',
    'wallet_get_raise_mode': 'CBBGDataMgr::GetRaiseMode(eGameMode)',
}
SHOP_CLASSES = {'equip':'CBBGEquipStoreUI', 'costume':'CBBGCostumeStoreUI',
                'effect':'CBBGEffectStoreUI', 'frame':'CBBGFrameUI',
                'estimate':'CBBGGameEstimateUI', 'bundle':'CBBGBundleItemStoreUI'}
HOOKS = {}
for alias, cls in SHOP_CLASSES.items():
    HOOKS['wallet_'+alias+'_connect'] = cls + '::ConnectStarVC(' + ('int' if alias == 'bundle' else '') + ')'
    BINDINGS['wallet_'+alias+'_buy'] = cls + '::BuyProcess()'


def integrate_source(source):
    if INCLUDE in source:
        if source.count(INCLUDE) != 1: raise ValueError('Repeated wallet integration')
        return source
    return source.rstrip() + '\n\n' + INCLUDE + '\n'


def integrate_builder(source):
    def once(old, new, label):
        nonlocal source
        if new in source:
            if source.count(new) != 1: raise ValueError('Repeated ' + label)
            return
        if source.count(old) != 1: raise ValueError('Missing unique ' + label)
        source = source.replace(old, new)
    once('HOOKS = {\n', 'HOOKS = {\n' + ''.join('    '+repr(k)+': '+repr(v)+',\n' for k,v in HOOKS.items()), 'wallet shop entries')
    once('BINDINGS = {\n', 'BINDINGS = {\n' + ''.join('    '+repr(k)+': '+repr(v)+',\n' for k,v in BINDINGS.items()), 'wallet bindings')
    once('    from signer_pin import add_signer_pin_patch',
         '    from wallet_hooks import add_wallet_hooks\n    from signer_pin import add_signer_pin_patch', 'wallet hook import')
    once('        signer_pin = add_signer_pin_patch',
         "        wallet_calls = add_wallet_hooks(b, report['symbols'])\n        signer_pin = add_signer_pin_patch", 'wallet hook installation')
    once("'defender_paths': defender_paths,", "'defender_paths': defender_paths,\n            'local_wallet': {'schema': 1, 'typed_resources': ['G points', 'stars'], 'call_sites': wallet_calls},", 'wallet metadata')
    return source


def stage_payload(output_dir, source_dir=WORK):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    raw = (source_dir / 'yagu_payload.c').read_text()
    staged = integrate_source(raw)
    (output_dir / 'yagu_payload.c').write_text(staged)
    pending = re.findall(r'^#include "([^"]+)"', staged, re.MULTILINE)
    dependencies = {}
    while pending:
        name = pending.pop()
        if name in dependencies: continue
        if Path(name).name != name or '\\' in name: raise ValueError('Unsafe include')
        source = (WORK if name == 'wallet_payload.inc' else source_dir) / name
        if source.is_symlink(): raise ValueError('Symlink include')
        value = source.read_bytes()
        (output_dir / name).write_bytes(value)
        dependencies[name] = hashlib.sha256(value).hexdigest()
        pending.extend(re.findall(r'^#include "([^"]+)"', value.decode(), re.MULTILINE))
    return {'base_c_sha256': hashlib.sha256(raw.encode()).hexdigest(),
            'staged_c_sha256': hashlib.sha256(staged.encode()).hexdigest(),
            'dependencies': dependencies}
