"""Narrow integration for uninterrupted owned two-way batting appearances."""
from pathlib import Path
import hashlib,json,re

WORK=Path(__file__).resolve().parent
INCLUDE='#include "batter_presence_payload.inc"'
HOOKS={
 'keep_batter_reservation':'CBBGEntryMgr::RsvChangeBatter(int, unsigned char)',
 'keep_batter_ai':'CBBGLevelMgr::AIChangeBatterPlayer(CBBGEntryMgr*, CBBGRunnerMgr*, CBBGPlayData*, unsigned char)',
}
BINDINGS={'presence_original_ace_change':'CBBGGameRun_BurstMission::IsAceChange() const'}

def integrate_source(source):
 if INCLUDE in source:
  if source.count(INCLUDE)!=1:raise ValueError('Duplicate batter presence include')
  return source
 if '#include "batting_rescue_payload.inc"'not in source:raise ValueError('Integrate original contact rescue first')
 return source.rstrip()+'\n\n'+INCLUDE+'\n'

def integrate_builder(source):
 from special_uses_policy import once
 if "        add_batter_presence_hook(b,report['symbols'])"in source:
  if not all(repr(k)+': '+repr(v)in source for k,v in {**HOOKS,**BINDINGS}.items()):raise ValueError('Partial presence integration')
  return source
 for name,entries in (('HOOKS',HOOKS),('BINDINGS',BINDINGS)):
  addition=''.join('    '+repr(k)+': '+repr(v)+',\n'for k,v in entries.items())
  source=once(source,name+' = {\n',name+' = {\n'+addition,'batter presence '+name)
 source=once(source,'    from batting_rescue_hooks import add_batting_rescue_hook',
             '    from batting_rescue_hooks import add_batting_rescue_hook\n'
             '    from batter_presence_hooks import add_batter_presence_hook','batter presence import')
 return once(source,"        add_batting_rescue_hook(b,report['symbols'])",
             "        add_batting_rescue_hook(b,report['symbols'])\n"
             "        add_batter_presence_hook(b,report['symbols'])",'batter presence calls')

def stage_payload(output_dir,source_dir=WORK):
 output_dir,source_dir=Path(output_dir),Path(source_dir);output_dir.mkdir(parents=True,exist_ok=True)
 raw=(source_dir/'yagu_payload.c').read_text();source=integrate_source(raw)
 (output_dir/'yagu_payload.c').write_text(source)
 pending=re.findall(r'^\s*#\s*include\s*"([^"\n]+)"',source,re.M);deps={}
 while pending:
  name=pending.pop()
  if name in deps:continue
  if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*',name)or'..'in name:raise ValueError('Unsafe include')
  path=(WORK if name=='batter_presence_payload.inc'else source_dir)/name
  if path.is_symlink()or not path.is_file():raise ValueError('Missing include '+name)
  data=path.read_bytes();(output_dir/name).write_bytes(data);deps[name]=hashlib.sha256(data).hexdigest()
  pending.extend(re.findall(r'^\s*#\s*include\s*"([^"\n]+)"',data.decode(),re.M))
 report={'base_c_sha256':hashlib.sha256(raw.encode()).hexdigest(),'staged_c_sha256':hashlib.sha256(source.encode()).hexdigest(),'dependencies':deps}
 (output_dir/'batter_presence_stage_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
 return report
