"""Stage the narrow elite NPC delta for review/testing without shared edits.

This helper does not modify an APK or the given source. The parent may apply
integrate_source() after reviewing the compiled original-consumer verification.
"""
import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
ANCHOR = 'API int yagu_level(u8 *p) { return yagu_state(p) ? LEVEL_ADAPTER : original_level(p); }'
REPLACEMENT = '''#include "elite_world_policy.h"
API int yagu_level(u8 *p) {
    if (yagu_state(p)) return LEVEL_ADAPTER;
    if (yagu_elite_npc(p)) return ELITE_NPC_LEVEL;
    return original_level(p);
}'''

PURE_ANCHOR = '''API u16 yagu_pure_status(u8 *p, int part) {
    return yagu_state(p) && part >= 0 && part < 4 ? STAT_ADAPTER : original_pure_status(p, part);
}'''
PURE_REPLACEMENT = '''API u16 yagu_pure_status(u8 *p, int part) {
    if (part >= 0 && part < 4) {
        if (yagu_state(p)) return STAT_ADAPTER;
        if (yagu_elite_npc(p)) return ELITE_NPC_PURE_STATUS;
    }
    return original_pure_status(p, part);
}'''


def integrate_source(source):
    if REPLACEMENT in source:
        if source.count(REPLACEMENT) != 1: raise ValueError('Repeated elite integration')
        return source
    if source.count(ANCHOR) != 1 or 'elite_world_policy.h' in source:
        raise ValueError('The expected single original level adapter was not found')
    return source.replace(ANCHOR, REPLACEMENT)


def integrate_pure_source(source):
    """Apply only the reviewed finite pure-stat getter delta after level policy."""
    if REPLACEMENT not in source:
        raise ValueError('Integrate the level policy first')
    if PURE_REPLACEMENT in source:
        if source.count(PURE_REPLACEMENT) != 1: raise ValueError('Repeated pure-stat integration')
        return source
    if source.count(PURE_ANCHOR) != 1:
        raise ValueError('The expected single original pure-stat adapter was not found')
    return source.replace(PURE_ANCHOR, PURE_REPLACEMENT)


def stage_payload(output_dir, source_dir=WORK, *, include_pure=True):
    output_dir, source_dir = Path(output_dir), Path(source_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    raw = (source_dir/'yagu_payload.c').read_text()
    staged = integrate_source(raw)
    if include_pure: staged = integrate_pure_source(staged)
    (output_dir/'yagu_payload.c').write_text(staged)
    # Keep the test translation unit complete as additional policy fragments are
    # integrated. Only flat, local quoted includes are allowed: never traverse
    # a directory or follow a symlink while preparing a private test source.
    included = {}
    pending = re.findall(r'^\s*#\s*include\s*"([^"\n]+)"', staged, re.MULTILINE)
    while pending:
        name = pending.pop()
        if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*', name) or '..' in name:
            raise ValueError(f'Non-local quoted include is not allowed: {name!r}')
        if name in included:
            continue
        root = WORK if name == 'elite_world_policy.h' else source_dir
        dependency = root / name
        if dependency.is_symlink() or not dependency.is_file():
            raise ValueError(f'Missing or non-regular local include: {name!r}')
        data = dependency.read_bytes()
        included[name] = hashlib.sha256(data).hexdigest()
        (output_dir/name).write_bytes(data)
        pending.extend(re.findall(r'^\s*#\s*include\s*"([^"\n]+)"',
                                  data.decode('utf-8'), re.MULTILINE))
    manifest = {'base_c_sha256': hashlib.sha256(raw.encode()).hexdigest(),
                'staged_c_sha256': hashlib.sha256(staged.encode()).hexdigest(),
                'policy_header_sha256': hashlib.sha256((WORK/'elite_world_policy.h').read_bytes()).hexdigest(),
                'local_include_sha256': dict(sorted(included.items())),
                'shared_source_modified': False, 'finite_npc_level': 250,
                'finite_npc_pure_status': 1400 if PURE_REPLACEMENT in staged else None,
                'scope': 'active career3/4 exact first15-team roster NPC slots, excluding My1000/1100'}
    (output_dir/'elite_stage_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    return manifest
