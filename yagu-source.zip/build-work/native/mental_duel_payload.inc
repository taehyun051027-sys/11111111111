/* The live mental duel compares the owned tagged ability, not its bounded
 * physics projection. Only an actual active-roster My actor against an actual
 * opposing finite actor has a semantic order here. No result, score, passive
 * inventory, finite ability, or live counter is written. */
static int mental_roster_actor(u8 *dm, u8 *entry, const u8 *player, int role) {
    if (!dm || !entry || !player || (role != 0 && role != 1)) return 0;
    u8 *teams = ptr(dm, DM_TEAMS);
    int team_index = (signed char)entry[0x25];
    if (!teams || team_index < 0 || team_index >= 15) return 0;
    u8 *team = teams + 8 + team_index * 0x3b4;
    unsigned count = team[role ? 2 : 3];
    unsigned limit = role ? 8 : 12, size = role ? 52 : 44, start = role ? 4 : 0x1a4;
    if (!count || count > limit) return 0;
    for (unsigned i = 0; i < count; ++i)
        if (player == team + start + i * size) return 1;
    return 0;
}
static const Scalar *mental_owned_state(u8 *entry, const u8 *player, int role) {
    u8 *dm = data_manager();
    if (!owns_entry(dm, entry) || !mental_roster_actor(dm, entry, player, role)
            || player != owned_role_player(dm, role)) return (const Scalar *)0;
    return &my_state.ability[3];
}

/* -1=pitcher higher, +1=batter higher; 2 requests original finite comparison.
 * A malformed same-team pairing or both-owned pairing is not a real duel. */
API int yagu_mental_order(u8 *att, const u8 *bat, u8 *def, const u8 *pit) {
    u8 *dm = data_manager();
    if (!att || !def || att == def || att[0x25] == def[0x25]
            || !mental_roster_actor(dm, att, bat, 0)
            || !mental_roster_actor(dm, def, pit, 1)) return 2;
    const Scalar *left = mental_owned_state(att, bat, 0);
    const Scalar *right = mental_owned_state(def, pit, 1);
    int li = left && left->kind == UNBOUNDED;
    int ri = right && right->kind == UNBOUNDED;
    if (li == ri) return 2;
    return li ? 1 : -1;
}

/* Four original bounded formatter calls use exactly24 output bytes and an
 * eight-byte original color prefix. Preserve that prefix and let the existing
 * UTF8 system-font path render the tagged glyph. -1 keeps original formatting.
 */
API int yagu_format_mental(char *dst, const char *prefix, u8 *entry, const u8 *player) {
    if (!dst || !prefix || !player) return -1;
    int role = read16(player) == MY_PIT ? 1 : 0;
    const Scalar *state = mental_owned_state(entry, player, role);
    if (!state || state->kind != UNBOUNDED || prefix[0] != '!' || prefix[1] != 'c') return -1;
    for (int i = 2; i < 8; ++i) {
        char c = prefix[i];
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'))) return -1;
    }
    if (prefix[8]) return -1;
    for (int i = 0; i < 8; ++i) dst[i] = prefix[i];
    for (int i = 0; i < 4; ++i) dst[8 + i] = unbounded_text[i];
    return 11;
}
