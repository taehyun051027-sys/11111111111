"""Run the original company selector and enabled signer comparison instructions.

The Java certificate getter itself is outside this instruction-level test. Its
actual Android Signature.hashCode value was observed independently on device.
Only the expected public-certificate value is changed in the input image.
"""
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from signer_pin import add_signer_pin_patch, ORIGINAL_HASH
from verify_relocation import RelocatedCase
from verify_gameplay_hooks import HEAP

ROOT = Path(__file__).resolve().parents[2]
LOCAL_HASH = 0x6de25a17
EXPECTED = HEAP + 0x90000
ENABLED = EXPECTED + 8


def word(b, address):
    return struct.unpack_from('<I', b.image, b.offset(address))[0]


def setup(b, slide):
    c = RelocatedCase(b, slide)
    if b.is64:
        select_expected = compare_expected = 0x7790b8
        select_enable = compare_enable = 0x7790b0
    else:
        select_expected = (0x42cb78 + 4 + word(b, 0x42cbd0)) & 0xffffffff
        select_enable = (0x42cbb2 + 4 + word(b, 0x42cbd4)) & 0xffffffff
        compare_enable = (0x42b54c + 4 + word(b, 0x42b5c8)) & 0xffffffff
        compare_expected = (0x42b556 + 4 + word(b, 0x42b5cc)) & 0xffffffff
    assert select_expected == compare_expected
    assert select_enable == compare_enable
    c.ptr(slide + select_expected, EXPECTED)
    c.ptr(slide + select_enable, ENABLED)
    return c


def select(c, company):
    c.stopped = None
    c.uc.mem_write(EXPECTED, bytes(12))
    if c.b.is64:
        c.r(2, company)
        c.r(19, 1)
        c.r(20, 0)
        start, end = 0x6acb6c, 0x6acbe8
    else:
        c.r(2, company)
        c.r(4, 1)
        c.r(5, 0)
        start, end = 0x42cb72, 0x42cbb8
    c.stops = {end + c.slide}
    c.run_relative(start)
    assert c.stopped == end + c.slide
    assert c.uc.mem_read(ENABLED, 1) == b'\x01'
    return struct.unpack('<I', c.uc.mem_read(EXPECTED, 4))[0]


def compare(c, actual):
    if c.b.is64:
        start, accepted, rejected = 0x6a98f8, 0x6a999c, 0x6a991c
    else:
        start, accepted, rejected = 0x42b54a, 0x42b560, 0x42b566
    c.stopped = None
    c.r(0, actual & 0xffffffff)
    c.stops = {accepted + c.slide, rejected + c.slide}
    c.run_relative(start)
    return 'accepted' if c.stopped == accepted + c.slide else 'rejected'


def verify(abi):
    raw = (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes()
    original, patched = PatchBuilder(abi, raw), PatchBuilder(abi, raw)
    pin = add_signer_pin_patch(patched, LOCAL_HASH)
    changed = [i for i, (a, b) in enumerate(zip(original.image, patched.image)) if a != b]
    address = int(pin['address'], 16)
    assert changed and all(address <= i < address + pin['bytes_changed'] for i in changed)
    assert original.extra == patched.extra
    # Selection and comparison are run at a nonzero loader bias; no zero-base
    # executable image remains mapped in RelocatedCase.
    slide = 0x123450000 if patched.is64 else 0x10001000
    o, p = setup(original, slide), setup(patched, slide)
    selection = []
    for company in range(1, 16):
        before, after = select(o, company), select(p, company)
        if company in (5, 15):
            assert before == ORIGINAL_HASH and after == LOCAL_HASH
        else:
            assert before == after
        selection.append({'company': company, 'original': hex(before), 'patched': hex(after)})
    comparisons = []
    for company in (5, 15):
        assert select(p, company) == LOCAL_HASH
        for actual in (LOCAL_HASH, ORIGINAL_HASH, 0, LOCAL_HASH ^ 1):
            outcome = compare(p, actual)
            assert outcome == ('accepted' if actual == LOCAL_HASH else 'rejected')
            comparisons.append({'company': company, 'actual_hash': hex(actual), 'outcome': outcome})
        assert select(o, company) == ORIGINAL_HASH
        assert compare(o, ORIGINAL_HASH) == 'accepted'
        assert compare(o, LOCAL_HASH) == 'rejected'
    return {'abi': abi, 'pin': pin, 'slide': hex(slide),
            'original_sha256': original.sha, 'changed_byte_offsets': [hex(x) for x in changed],
            'company_selection': selection, 'enabled_comparisons': comparisons,
            'enabled_flag_preserved': True, 'all_check_and_failure_branch_bytes_unchanged': True,
            'passed': 27, 'android_runtime_verified': False}


if __name__ == '__main__':
    report = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    Path(__file__).with_name('signer_pin_verification.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
