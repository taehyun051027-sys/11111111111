/* Existing award tables display three own-player performance cells. Their
 * monetary rewards are separate call sites and do not use these predicates. */
static int award_record_metric(int role, int column, const u8 *player) {
    if (column < 0 || column > 2 || !player) return -1;
    if (column == 0) return 0; /* BAT average / PIT earned-run average. */
    if (column == 1) return role ? 8 : 6; /* Strikeouts / RBI. */
    if (!role) return 5; /* Home runs. */
    unsigned position = player[0x21] & 15;
    if (position == 0) return 4; /* Starter: wins. */
    if (position == 1) return 6; /* Reliever: holds. */
    if (position == 2) return 7; /* Closer: saves. */
    return -1;
}

static const char *award_scalar_text(const Scalar *value) {
    if (!value) return (const char *)0;
    if (value->kind == UNBOUNDED) return unbounded_text;
    if (value->kind == FINITE && value->finite == 0) return zero_text;
    return (const char *)0;
}

API const char *yagu_award_current_text(const u8 *bat_record,
                                       const u8 *pit_record, int column) {
    int mode = game_mode();
    if (mode != 3 && mode != TWO_WAY_MODE) return (const char *)0;
    int role = mode == 3;
    const u8 *actor = owned_role_player(data_manager(), role);
    int metric = award_record_metric(role, column, actor);
    if (metric < 0) return (const char *)0;
    return award_scalar_text(yagu_owned_record_metric(
        role ? pit_record : bat_record, role, metric));
}

API const char *yagu_award_past_text(const u8 *bat_record,
                                    const u8 *pit_record, int column, int year) {
    int mode = game_mode();
    if ((mode != 3 && mode != TWO_WAY_MODE) || year < 0)
        return (const char *)0;
    int role = mode == 3;
    u8 *dm = data_manager();
    const u8 *actor = owned_role_player(dm, role);
    int metric = award_record_metric(role, column, actor);
    if (metric < 0) return (const char *)0;
    const u8 *current = yagu_current_personal_record(role);
    if (!current) return (const char *)0;
    const u8 *save = ptr(dm, role ? DM_PIT_SAVE : DM_BAT_SAVE);
    if (!save) return (const char *)0;
    /* Match GetPastRaise{Batter,Pitcher}Rec's existing ten-slot window. A
     * negative year is rejected here; no widening or fabricated past season. */
    unsigned slot = year >= 9 ? 9 : (unsigned)year;
    const u8 *expected = save + 0x830 + slot * (role ? 32 : 24);
    const u8 *record = role ? pit_record : bat_record;
    if (!record || record != expected || read16(record) != (role ? MY_PIT : MY_BAT))
        return (const char *)0;
    return award_scalar_text(yagu_owned_record_metric(current, role, metric));
}
