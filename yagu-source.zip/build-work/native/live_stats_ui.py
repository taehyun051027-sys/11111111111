"""Project owned live player statistics into their existing display cells.

The original live player panel uses digit sprites for level/K/AVG/HR/RBI, and
AddChildFitSystemFont in those same cells when a record is absent. This module
reuses that existing font helper, node tag, rectangle, alignment, visibility and
coordinate convention for semantic Unbounded values. It neither changes a game
record nor adds a panel. Opponents, ordinary teammates and other modes keep the
original numeric or missing-record rendering call.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE


NUMBER = ('DrawCCFitNumberWithNode(cocos2d::CCNode*, ccpzx::CCPZXFrame*, '
          'int, int, int, cocos2d::CCRect&, int, int, int, int, bool, bool, bool, int)')
AVERAGE = ('DrawCCAVR1000WithNode(cocos2d::CCNode*, ccpzx::CCPZXFrame*, '
           'int, int, int, int, cocos2d::CCRect&, int, int, int, int, bool, bool, bool, int)')
FONT = ('AddChildFitSystemFont(cocos2d::CCNode*, char const*, int, int, '
        'cocos2d::CCRect&, int, int, int, bool, bool, bool)')

# Native record metric order: batting AVG=0, HR=5, RBI=6; pitching K=8.
# A metric of -1 requests the authoritative player level scalar.
SITES = {
    'arm64-v8a': [
        (0x3c62e8, '66bc0d94', 'pitcher_level', 'number', 1, -1, 0x1556b),
        (0x3c66a8, '76bb0d94', 'pitcher_strikeouts', 'number', 1, 8, 0x1556f),
        (0x3c66ec, 'a9bb0d94', 'pitcher_strikeouts_missing', 'font', 1, 8, 0x1556f),
        (0x3c6f30, '54b90d94', 'batter_level', 'number', 0, -1, 0x15579),
        (0x3c707c, 'fdbc0d94', 'batter_average', 'average', 0, 0, 0x1557b),
        (0x3c70c0, '34b90d94', 'batter_average_missing', 'font', 0, 0, 0x1557b),
        (0x3c73d8, '2ab80d94', 'batter_home_runs', 'number', 0, 5, 0x1557f),
        (0x3c741c, '5db80d94', 'batter_home_runs_missing', 'font', 0, 5, 0x1557f),
        (0x3c7568, 'c6b70d94', 'batter_rbi', 'number', 0, 6, 0x15581),
        (0x3c75ac, 'f9b70d94', 'batter_rbi_missing', 'font', 0, 6, 0x15581),
    ],
    'armeabi-v7a': [
        (0x25273a, '25f2f2ea', 'pitcher_level', 'number', 1, -1, 0x1556b),
        (0x252a96, '25f244e9', 'pitcher_strikeouts', 'number', 1, 8, 0x1556f),
        (0x252ac8, '25f2b2e9', 'pitcher_strikeouts_missing', 'font', 1, 8, 0x1556f),
        (0x2531f6, '24f294ed', 'batter_level', 'number', 0, -1, 0x15579),
        (0x253322, '25f226ed', 'batter_average', 'average', 0, 0, 0x1557b),
        (0x253354, '24f26ced', 'batter_average_missing', 'font', 0, 0, 0x1557b),
        (0x25362c, '24f278eb', 'batter_home_runs', 'number', 0, 5, 0x1557f),
        (0x25365e, '24f2e8eb', 'batter_home_runs_missing', 'font', 0, 5, 0x1557f),
        (0x25378c, '24f2c8ea', 'batter_rbi', 'number', 0, 6, 0x15581),
        (0x2537be, '24f238eb', 'batter_rbi_missing', 'font', 0, 6, 0x15581),
    ],
}

# Map the original function's arguments to the existing system-font ABI.
# The digit spacing argument disappears because a scalar is a single glyph.
# (z, tag, rectangle, alignment, x offset, y offset, visible, WIPI coordinates)
ARGUMENTS = {
    'number': (3, 4, 5, 9, 6, 7, 10, 11),
    'average': (4, 5, 6, 7, 8, 9, 11, 12),
    'font': (2, 3, 4, 5, 6, 7, 8, 9),
}


def _a64_source(resolver, original, font, role, metric, kind):
    # After SAVE and the 64-byte temporary outgoing-call frame, the original
    # register arguments begin at +64 and original SP is +144.
    def offset(index):
        return 64 + index * 8 if index < 8 else 144 + (index - 8) * 8

    z, tag, rect, alignment, dx, dy, visible, wipi = ARGUMENTS[kind]
    entry, actor = (0x410, 0x400) if role else (0x418, 0x408)
    return f'''{A64_SAVE}
ldr x0, [sp, #{entry + 80}]
ldr x1, [sp, #{actor + 80}]
mov w2, #{role}
mov w3, #{metric}
bl #{resolver}
cbz x0, original
sub sp, sp, #64
ldr w8, [x0]
str w8, [sp, #42]
movz w8, #0x6321
movk w8, #0x4646, lsl #16
str w8, [sp, #32]
movz w8, #0x4646
movk w8, #0x4646, lsl #16
str w8, [sp, #36]
mov w8, #0x4321
strh w8, [sp, #40]
ldr w8, [sp, #{offset(visible)}]
str w8, [sp]
ldr w8, [sp, #{offset(wipi)}]
str w8, [sp, #8]
mov w8, #1
str w8, [sp, #16]
ldr x0, [sp, #{offset(0)}]
add x1, sp, #32
ldr w2, [sp, #{offset(z)}]
ldr w3, [sp, #{offset(tag)}]
ldr x4, [sp, #{offset(rect)}]
ldr w5, [sp, #{offset(alignment)}]
ldr w6, [sp, #{offset(dx)}]
ldr w7, [sp, #{offset(dy)}]
bl #{font}
add sp, sp, #64
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original}'''


def _thumb_source(resolver, original, font, role, metric, kind):
    # T32 SAVE is 24 bytes. The 56-byte temporary frame keeps SP 8-aligned.
    def offset(index):
        return 56 + index * 4 if index < 4 else 80 + (index - 4) * 4

    z, tag, rect, alignment, dx, dy, visible, wipi = ARGUMENTS[kind]
    entry, actor = (0x324, 0x31c) if role else (0x328, 0x320)
    return f'''{T32_SAVE}
ldr.w r0, [sp, #{entry + 24}]
ldr.w r1, [sp, #{actor + 24}]
movs r2, #{role}
{'mvn r3, #0' if metric == -1 else f'movs r3, #{metric}'}
bl #{resolver}
cmp r0, #0
beq original
sub sp, sp, #56
ldr r1, [r0]
str.w r1, [sp, #42]
movw r1, #0x6321
movt r1, #0x4646
str r1, [sp, #32]
movw r1, #0x4646
movt r1, #0x4646
str r1, [sp, #36]
movw r1, #0x4321
strh.w r1, [sp, #40]
ldr r12, [sp, #{offset(rect)}]
str r12, [sp]
ldr r12, [sp, #{offset(alignment)}]
str r12, [sp, #4]
ldr r12, [sp, #{offset(dx)}]
str r12, [sp, #8]
ldr r12, [sp, #{offset(dy)}]
str r12, [sp, #12]
ldr r12, [sp, #{offset(visible)}]
str r12, [sp, #16]
ldr r12, [sp, #{offset(wipi)}]
str r12, [sp, #20]
movs r1, #1
str r1, [sp, #24]
ldr r0, [sp, #{offset(0)}]
add r1, sp, #32
ldr r2, [sp, #{offset(z)}]
ldr r3, [sp, #{offset(tag)}]
bl #{font}
add sp, sp, #56
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original}'''


def add_live_stats_ui_hooks(b, symbols):
    """Add ten call-site hooks; requires yagu_live_stat_text in the C payload."""
    resolver = symbols['yagu_live_stat_text']
    font = b.sym(FONT)
    exports = []
    for site, expected, name, kind, role, metric, tag in SITES[b.abi]:
        original = b.sym({'number': NUMBER, 'average': AVERAGE, 'font': FONT}[kind])
        make = _a64_source if b.is64 else _thumb_source
        source = make(resolver, original, font, role, metric, kind)
        hook = b.append_asm('Owned live player statistic: ' + name, source)
        b.patch(site, b.branch(site, hook, True), 'Render owned live statistic: ' + name, expected)
        exports.append({'site': site, 'hook': hook, 'name': name, 'kind': kind,
                        'role': role, 'metric': metric, 'tag': tag, 'original': original})
    return exports
