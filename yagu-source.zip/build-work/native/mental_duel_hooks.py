"""Owned mental-order decisions and four existing colored text cells.

The original comparison destination registers, SIMD state and stack survive.
Only signed comparison flags become the typed Unbounded ordering. Original
conditional branches, winner stores, skill animation ordering, fonts and layout
continue to run. Unscoped actors replay the original finite comparison.
"""
from career_resource_ui import _a64_stack, _thumb_stack
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

# label, compare site, original four bytes, original-SP slots for
# (attack entry, batter, defense entry, pitcher).
DECISIONS = {
    'arm64-v8a': (
        ('intro_winner', 0x3c7ef4, '29010a6b', (0x708, 0x6f8, 0x700, 0x6f0)),
        ('intro_color', 0x3c7f74, '0801096b', (0x708, 0x6f8, 0x700, 0x6f0)),
        ('intro_skill_order', 0x3c81b0, '0801096b', (0x708, 0x6f8, 0x700, 0x6f0)),
        ('intro_sound', 0x3c8dcc, '0801096b', (0x708, 0x6f8, 0x700, 0x6f0)),
        ('next_pitch_tie', 0x3bb1a4, '0801096b', (0x48, 0x38, 0x40, 0x30)),
        ('next_pitch_winner', 0x3bb1c8, '0801096b', (0x48, 0x38, 0x40, 0x30)),
    ),
    'armeabi-v7a': (
        ('intro_winner', 0x253eec, '91420146', (0x500, 0x4f8, 0x4fc, 0x4f4)),
        ('intro_color', 0x253f56, '88420adb', (0x500, 0x4f8, 0x4fc, 0x4f4)),
        ('intro_skill_order', 0x254112, '88425bdb', (0x500, 0x4f8, 0x4fc, 0x4f4)),
        ('intro_sound', 0x254b7e, '88420ddb', (0x500, 0x4f8, 0x4fc, 0x4f4)),
        ('next_pitch_tie', 0x24a8b4, '884205d1', (0x34, 0x2c, 0x30, 0x28)),
        ('next_pitch_winner', 0x24a8c8, '884205dd', (0x34, 0x2c, 0x30, 0x28)),
    ),
}

FORMATS = {
    'arm64-v8a': (
        ('pitcher_left', 0x3cb5d4, '25010094', 1),
        ('batter_right', 0x3cb620, '12010094', 0),
        ('pitcher_right', 0x3cb670, 'fe000094', 1),
        ('batter_left', 0x3cb6bc, 'eb000094', 0),
    ),
    'armeabi-v7a': (
        ('pitcher_left', 0x256d2e, '00f093f9', 1),
        ('batter_right', 0x256d68, '00f076f9', 0),
        ('pitcher_right', 0x256d9c, '00f05cf9', 1),
        ('batter_left', 0x256dce, '00f043f9', 0),
    ),
}


def add_mental_duel_hooks(b, symbols):
    out = []
    for label, site, expected, slots in DECISIONS[b.abi]:
        instructions = list(b.cs.disasm(bytes.fromhex(expected), site))
        compare = instructions[0]
        if compare.mnemonic not in ('subs', 'cmp'): raise ValueError('Mental comparison mismatch')
        prefix = compare.mnemonic + ' ' + compare.op_str
        destination, branch = site + 4, None
        if b.is64:
            if len(instructions) != 1: raise ValueError('Unexpected A64 mental pair')
            save, restore = _a64_stack()
            args = '\n'.join(f'ldr x{i}, [sp, #{704 + slot}]' for i, slot in enumerate(slots))
            source = f'''{prefix}
{save}
{args}
bl #{symbols['yagu_mental_order']}
cmp w0, #2
b.eq restore
mov w8, #0x20000000
tbz w0, #31, semantic_flags
mov w8, #0x80000000
semantic_flags:
str x8, [sp, #160]
restore:
{restore}
b #{destination}'''
        else:
            if len(instructions) != 2: raise ValueError('Unexpected Thumb mental pair')
            second = instructions[1]
            if second.mnemonic == 'mov':
                prefix += '\n' + second.mnemonic + ' ' + second.op_str
                suffix = f'b.w #{destination}'
            elif second.mnemonic in ('blt', 'bne', 'ble'):
                branch = int(second.op_str[1:], 16)
                suffix = f'{second.mnemonic} taken\nb.w #{destination}\ntaken:\nb.w #{branch}'
            else: raise ValueError('Unexpected Thumb mental consumer')
            save, restore = _thumb_stack()
            args = '\n'.join(f'ldr.w r{i}, [sp, #{288 + slot}]' for i, slot in enumerate(slots))
            source = f'''{prefix}
{save}
{args}
bl #{symbols['yagu_mental_order']}
cmp r0, #2
beq restore
ldr r1, [sp, #256]
bic r1, r1, #0xf0000000
cmp r0, #0
blt pitcher_higher
orr r1, r1, #0x20000000
b semantic_flags
pitcher_higher:
orr r1, r1, #0x80000000
semantic_flags:
str r1, [sp, #256]
restore:
{restore}
{suffix}'''
        hook = b.append_asm('Typed mental order: ' + label, source)
        b.patch(site, b.branch(site, hook), 'Owned mental duel order: ' + label, expected)
        out.append(dict(kind='decision', label=label, site=site, expected=expected,
                        slots=slots, hook=hook, destination=destination, branch=branch))
    original = 0x3cba68 if b.is64 else 0x257058
    for label, site, expected, role in FORMATS[b.abi]:
        if b.is64:
            entry, actor = (0x700, 0x6f0) if role else (0x708, 0x6f8)
            source = f'''{A64_SAVE}
cmp w1, #24
b.ne original
mov x1, x3
ldr x2, [sp, #{80 + entry}]
ldr x3, [sp, #{80 + actor}]
bl #{symbols['yagu_format_mental']}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original}'''
        else:
            entry, actor = (0x4fc, 0x4f4) if role else (0x500, 0x4f8)
            source = f'''{T32_SAVE}
cmp r1, #24
bne original
mov r1, r3
ldr.w r2, [sp, #{24 + entry}]
ldr.w r3, [sp, #{24 + actor}]
bl #{symbols['yagu_format_mental']}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Existing mental text: ' + label, source)
        b.patch(site, b.branch(site, hook, True), 'Render owned mental infinity: ' + label, expected)
        out.append(dict(kind='format', label=label, site=site, expected=expected,
                        role=role, entry_slot=entry, actor_slot=actor, hook=hook,
                        original_formatter=original))
    return out
