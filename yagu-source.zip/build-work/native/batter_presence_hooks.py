"""Use the original non-Ace mission arm for the owned current batter only."""
from gameplay_hooks import A64_SAVE,A64_RESTORE,T32_SAVE,T32_RESTORE

def add_batter_presence_hook(b,symbols):
 target=symbols['yagu_keep_batter_mission']
 if b.is64:
  site,expected=0x38a898,'c29c0e94'
  source=f'''{A64_SAVE}
ldr x1, [sp, #88]
bl #{target}
str x0, [sp]
{A64_RESTORE}
ret'''
 else:
  site,expected=0x22c776,'47f2b4ee'
  source=f'''{T32_SAVE}
ldr r1, [sp, #24]
bl #{target}
str r0, [sp]
{T32_RESTORE}
bx lr'''
 hook=b.append_asm('Keep owned batter during Ace burst mission',source)
 b.patch(site,b.branch(site,hook,True),'Owned two-way batter keeps original non-replacement mission path',expected)
 return {'site':site,'expected':expected,'hook':hook}
