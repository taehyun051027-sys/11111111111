# Finite elite NPC world — level and pure-stat policy

## Implemented scope

The policy gives effective level **250** and each of the four effective pure stats **1400** to ordinary players in the active career's exact first **15** team rosters. Both level and pure-stat parts are integrated into the shared candidate7 source. It covers Pumas teammates, the other nine regular-league clubs and all five world-tournament clubs. My Player RFID 1000 and 1100 retain the existing tagged Unbounded state and their separate compatibility adapters.

This changes two getters used by the original stat calculation. It does not write maxima into a save, increase the number of teams, change any grade or skill, replace an original stat formula, or create a new screen. Runtime substitutions and replacement players inherit the rule when they occupy a currently active roster slot.

The policy requires all of the following:

1. Current mode is pitcher career 3 or two-way/batter career 4.
2. DataMgr has the matching non-null career save and a team container whose own-team index is 0..14.
3. The own roster contains the relevant My role: 1100 in mode 3 or 1000 in mode 4.
4. The target pointer is exactly an active pitcher or batter slot in one of those 15 teams, with valid active counts no greater than 8 pitchers and 12 batters.
5. The target RFID is neither 1000 nor 1100.

Unrelated modes, copied actors, inactive slots, interior pointers, missing saves and the container's spare sixteenth team retain the original getter path. The getter adds no writable global or saved field.

## Original layout and consumer evidence

| Original structure or method | Observed behavior |
| --- | --- |
| `CBBGDataMgr::OpenRaiseTeam` / `sRaiseTeamInfo` | Allocates `0x3b48` bytes. Fifteen normal teams begin at container `+8`, each `0x3b4` bytes. A separate sixteenth storage team begins at `+0x3794`; it is excluded. |
| `CBBGTeamData` | Active pitcher count at `+2`, batter count at `+3`; 8 slots of 52 bytes begin at `+4`, and 12 slots of 44 bytes begin at `+0x1a4`. |
| `CBBGEntryMgr::GetCurBatter/GetCurPitcher` | Calls the original entry and team getters. In career modes, `GetTeamPtr` resolves the same active team container; the returned actor is the actual roster object. |
| `CBBGPlayerData::GetStatus` | Reads pure stat, effective level, and grade. For normal NPCs it adds `level × (grade + 3)` before the original clamps and optional item/passive effects. |
| `CBBGOption::SetRaiseTeamAddLv` | Original official opponent-level adjustment clamps to 0..250. This is the source of the finite level policy. It is not an encoding for infinity. |
| `CBBGPlayerData::SetStatus/AddStatus` | Original `DefineXL` enum0 is `XlsInitAbil`. It reads the part column and a role/style cap row before storing the original unsigned 16-bit field. Normal cap rows 2,3,6,7 are all 1400. |

The hash-gated original A64 methods are `GetLevel` at `0x587a44`, `GetStatus` at `0x5885d0`, `GetGrade` at `0x587d34`, and `GetStatusMidStoreItem` at `0x588920`. Original Thumb `GetLevel` is `0x37bf98`, `GetStatus` is `0x37c6e0`, and `GetStatusMidStoreItem` is `0x37c930`.

The normal original tables have 180 batters and 120 pitchers. All 300 have grade nibble 0. Their four stored pure stat values range 29..170 for batters and 68..167 for pitchers. The level-only checkpoint produced 779..920 and 818..917. With the normal pure-stat maximum 1400 projected by the scoped getter, executing original `GetStatus(part, 0, 0)` produces **2150 for every one of those 1,200 NPC stat cells**. The distinction between pure 1400 and final 3500 is deliberate: 3500 is a final modified-stat clamp, not the original pure-stat storage cap.

The original overall clamp remains 3500. The four relevant passive adjustment branches retain their separate 0..2100 clamps, and the original half-value passive remains active. Grade and skill bitfields remain unchanged. At level 250, every grade nibble 0..15 plus pure 1400 remains below the unsigned 16-bit intermediate wrap boundary before those original clamps. This arithmetic observation does not establish that grade 15 is a normal gameplay grade; the policy does not set it. The original HOF class still skips the level bonus, so its pure1400 remains1400 before other original effects.

`GetPureStatus` is directly consumed by original `GetStatus` and `AddStatus`, plus three ChooseCard calls and four effect-store/reset calls. The latter seven UI calls resolve My Player through `GetRaisePlayer`; they are outside the new NPC pointer guard. Invalid part indices preserve the original getter call and arguments. The new getter does not index a style table.

## Original style anomaly retained

Original styles are 0..3 for all 180 batters and 119 pitchers. Pitcher RFID471 has style5. Its original setter computes cap row `style/2+6 = 8`, beyond `XlsInitAbil`'s rows0..7. Executing the original `GVXLLoader::GetVal` returns0 and sets its existing error0x100, after which the original setter stores0. The mod does not change that original style or invent a row. Its effective pure-stat getter still returns1400 for this active NPC, and original `GetStatus` returns2150. The verification includes this exception instead of assuming all source rows are valid.

## Grade audit

Original `SetGrade` masks a four-bit field; it has no semantic max-grade clamp. The direct caller scan found no `SetGrade` callers in either ABI. `GetGrade` has only two direct consumers: the original stat growth calculation and StrengthPlayer's next-strength prediction. Neither is a separate displayed grade/rank field. Thus there is no evidence for declaring grade5 or grade15 a normal maximum, and no observed standalone My-grade UI to add to the46 scalar tags. This conclusion is bounded to the audited original direct call graph.

## Verification

`elite_world_verification.json` records **3,910 cases per ABI, 7,820 total**, for the combined policy, each with a nonzero ELF load bias and the zero-bias image unmapped. The earlier **5,134-case level-only** checkpoint is preserved separately as `elite_level_only_verification.json`.

| Check group | Cases per ABI |
| --- | ---: |
| Exact active roster slots in both career modes | 600 |
| Nonmember/header/interior/spare-team addresses | 14 |
| Active-count boundaries and corrupt counts | 140 |
| Missing/wrong save, wrong mode, own-role and container guards | 26 |
| The same guards at the new pure-stat getter | 26 |
| Reloaded roster and later original level writes | 7 |
| Original live batter/pitcher entry lookups for all 15 teams and both modes | 60 |
| All 300 original rows × four original stat calculations | 1,200 |
| All grade nibbles and original skill/clamp branches | 512 |
| Original item-add clamp consumer with explicit item boundary stub | 4 |
| Actual original GXL cap-table cells | 32 |
| Actual original setter for all300 rows × four parts | 1,200 |
| Actual original AddStatus, all observed styles and both delta signs | 72 |
| Pure getter invalid parts and nonmember pointers | 9 |
| My state and original nonmember stat behavior | 4 |
| Original special/HOF actor-class branches | 4 |

The main stat tests run the new pure-stat getter and original grade getter, role predicates, skill membership, stat formula and min/max functions. PLT entries redirect to their actual original symbol addresses. Singleton lookup is supplied by the test fixture. The original game-running option is false, so match consumable-store effects are not exercised; the report states this limit. Four separately counted item tests stub only the `GetAddStatus` boundary while executing the original addition and clamp.

The cap tests run the original `GVXLLoader::GetVal/GetSize`, `SetStatus`, and `AddStatus` against the actual decoded `XlsInitAbil` memory and its observed ABI layout. Only libc's checked memcpy is modeled, with its destination bound enforced. The original table's range and error branches execute. Getter checks are read-only; setter checks verify that only the original selected two-byte field changes.

This is instruction-level verification. It does not establish Android startup, visual appearance, stadium rendering, a completed nine-inning game, or an unbounded number of career seasons.

## Integration

The parent integrated both deltas after verification. The combined elite-only source was SHA256 `01168a903560b657ab3b0fc91c3adc2471e4d60fda34c8557ba54319bfdede35`. The full7,820-case verification was rerun after the six honor metrics were integrated, against unchanged shared C SHA256 `cb85fbc626c3daae5e34c93a8622ca1a0d967430790eca3ffc379b0467072136`. Its report SHA256 is `e80ae8f64e15694661f9e8d7987de10ef2b7efcde0812ea3bc652a685eadf389`. Later isolated award text changes have separate UI verification. The test stages a private translation unit and never edits shared C. Local quoted includes are copied recursively with basename and symlink guards, so included policy fragments are not silently omitted.

For a source tree that has not yet integrated this policy, place `elite_world_policy.h` beside `yagu_payload.c`, then call `elite_world_policy.integrate_source(source_text)` followed by `elite_world_policy.integrate_pure_source(source_text)` and write the returned text. Each helper checks the exact single existing getter definition and is idempotent after its expected replacement. No additional entry hook is needed: the existing level and pure-stat hooks call the new predicate between the My adapter and original fallback.

To reproduce verification from the engineering workspace:

```sh
python3 build-work/native/verify_elite_world.py
```

The verifier needs the hash-matching original APK and libraries, the existing Python/native compiler prerequisites, and `analysis/data/tools/zt1_codec.py`. It stages its own source copy under `build-work/native/elite_world_build`; it does not alter the APK or shared source.

## Remaining world limits

Only effective NPC level and the four pure stats are implemented here. There is no demonstrated normal upper grade beyond the observed original zero grades, and no new grade, skill or facility policy. The original Universal enum alone does not create a fully maximized roster.

The separate career audit identified an unsigned 16-bit stored year reached through a signed-char setter, two 32-entry year-indexed rank arrays, and ten rolling past-record slots. These are distinct long-career boundaries. The original retirement prompt offers continuing; it is not a proven forced final retirement. None of those year or record boundaries is changed by this level policy.

The current art policy preserves original stadiums, backgrounds, character art and UI geometry; only opposing logos and uniform/equipment palette selection are handled elsewhere.
