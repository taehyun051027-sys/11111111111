/* Original animation metadata points at matching PNG basenames. */
static const char defender_paths[15][6][40] = {
    {"defender/team_0/head.pzc", "defender/team_0/body.pzc", "defender/team_0/calves.pzc", "defender/team_0/stripes.pzc", "defender/team_0/arm.pzc", "defender/team_0/leg.pzc"},
    {"defender/team_1/head.pzc", "defender/team_1/body.pzc", "defender/team_1/calves.pzc", "defender/team_1/stripes.pzc", "defender/team_1/arm.pzc", "defender/team_1/leg.pzc"},
    {"defender/team_2/head.pzc", "defender/team_2/body.pzc", "defender/team_2/calves.pzc", "defender/team_2/stripes.pzc", "defender/team_2/arm.pzc", "defender/team_2/leg.pzc"},
    {"defender/team_3/head.pzc", "defender/team_3/body.pzc", "defender/team_3/calves.pzc", "defender/team_3/stripes.pzc", "defender/team_3/arm.pzc", "defender/team_3/leg.pzc"},
    {"defender/team_4/head.pzc", "defender/team_4/body.pzc", "defender/team_4/calves.pzc", "defender/team_4/stripes.pzc", "defender/team_4/arm.pzc", "defender/team_4/leg.pzc"},
    {"defender/team_5/head.pzc", "defender/team_5/body.pzc", "defender/team_5/calves.pzc", "defender/team_5/stripes.pzc", "defender/team_5/arm.pzc", "defender/team_5/leg.pzc"},
    {"defender/team_6/head.pzc", "defender/team_6/body.pzc", "defender/team_6/calves.pzc", "defender/team_6/stripes.pzc", "defender/team_6/arm.pzc", "defender/team_6/leg.pzc"},
    {"defender/team_7/head.pzc", "defender/team_7/body.pzc", "defender/team_7/calves.pzc", "defender/team_7/stripes.pzc", "defender/team_7/arm.pzc", "defender/team_7/leg.pzc"},
    {"defender/team_8/head.pzc", "defender/team_8/body.pzc", "defender/team_8/calves.pzc", "defender/team_8/stripes.pzc", "defender/team_8/arm.pzc", "defender/team_8/leg.pzc"},
    {"defender/team_9/head.pzc", "defender/team_9/body.pzc", "defender/team_9/calves.pzc", "defender/team_9/stripes.pzc", "defender/team_9/arm.pzc", "defender/team_9/leg.pzc"},
    {"defender/team_10/head.pzc", "defender/team_10/body.pzc", "defender/team_10/calves.pzc", "defender/team_10/stripes.pzc", "defender/team_10/arm.pzc", "defender/team_10/leg.pzc"},
    {"defender/team_11/head.pzc", "defender/team_11/body.pzc", "defender/team_11/calves.pzc", "defender/team_11/stripes.pzc", "defender/team_11/arm.pzc", "defender/team_11/leg.pzc"},
    {"defender/team_12/head.pzc", "defender/team_12/body.pzc", "defender/team_12/calves.pzc", "defender/team_12/stripes.pzc", "defender/team_12/arm.pzc", "defender/team_12/leg.pzc"},
    {"defender/team_13/head.pzc", "defender/team_13/body.pzc", "defender/team_13/calves.pzc", "defender/team_13/stripes.pzc", "defender/team_13/arm.pzc", "defender/team_13/leg.pzc"},
    {"defender/team_14/head.pzc", "defender/team_14/body.pzc", "defender/team_14/calves.pzc", "defender/team_14/stripes.pzc", "defender/team_14/arm.pzc", "defender/team_14/leg.pzc"},
};
