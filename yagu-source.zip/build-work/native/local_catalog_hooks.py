"""Exact local price/UI sites; no network result or catalog-BSS patch."""
import struct
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

METHODS = {
    'CBBGStatic::GetNeedPriceBuyEquipItem(int, int, bool)': 'yagu_catalog_equip_price',
    'CBBGStatic::GetDCPerBuyEquipItem(int, int, bool)': 'yagu_catalog_equip_discount',
    'CBBGStatic::GetSaleTypeBuyEquipItem(int, int, bool)': 'yagu_catalog_equip_sale',
    'CBBGStatic::GetNeedPriceBuyCostumeItem(int, int)': 'yagu_catalog_costume_price',
    'CBBGStatic::GetDCPerBuyCostumeItem(int, int)': 'yagu_catalog_costume_discount',
    'CBBGStatic::GetSaleTypeBuyCostumeItem(int, int)': 'yagu_catalog_costume_sale',
    'CBBGStatic::GetNeedPriceBuyEffectItem(int, bool)': 'yagu_catalog_effect_price',
    'CBBGStatic::GetDCPerBuyEffectItem(int, bool)': 'yagu_catalog_effect_discount',
    'CBBGStatic::GetSaleTypeBuyEffectItem(int, bool)': 'yagu_catalog_effect_sale',
    'CBBGStatic::IsUseGpointBuyEffectItem(int, bool)': 'yagu_catalog_effect_g',
}
LOCAL_CLASSES = {'CBBGFrameUI','CBBGCcPopup','CBBGGameEstimateUI','CBBGStrengthPlayerUI',
                 'CBBGEquipStoreUI','CBBGCostumeStoreUI','CBBGEffectStoreUI',
                 'CBBGStrengthItemUI','CBBGWorldmapBuylinkUI','CBBGStrengthAllPlayerUI'}
STATIC_CONNECT = 'CBBGStatic::ConnectNetwork(void*, int)'
RAISE_CONNECT = 'CBBGRaisePlayerRun::ConnectNetwork(int)'
# kind, original local continuation (or receiver stack slot), rotation.
REQUESTS = {
    'arm64-v8a': {
        0x51e2d0: ('worldmap',0x28,0),
        0x3752e4: ('branch',0x375358,0),
        0x48eb4c: ('branch',0x48ebcc,0),
        0x496850: ('branch',0x4965a8,0),
        0x4976e8: ('branch',0x497dfc,2),
        0x497708: ('branch',0x497dfc,1),
        0x49775c: ('branch',0x497dfc,2),
        0x499028: ('branch',0x4990b4,0),
        0x4992e0: ('branch',0x4993cc,0),
        0x575418: ('strength',0xb8,0),
        0x577a60: ('strength',0x20,0),
    },
    'armeabi-v7a': {
        0x33688a: ('worldmap',0xc,0),
        0x21ec6e: ('branch',0x21ecb6,0),
        0x2d5e6e: ('branch',0x2d5ec0,0),
        0x2db070: ('branch',0x2dae94,0),
        0x2dba8c: ('branch',0x2dbf2c,2),
        0x2dbaa2: ('branch',0x2dbf2c,1),
        0x2dbadc: ('branch',0x2dbf2c,2),
        0x2dca7c: ('branch',0x2dcad4,0),
        0x2dcc2c: ('branch',0x2dccbc,0),
        0x36fe76: ('strength',0xcc,0),
        0x3715f4: ('strength',0x28,0),
    },
}

def original_calls(b):
    names=set(METHODS)|{STATIC_CONNECT,RAISE_CONNECT}
    dyn=b.elf.get_section_by_name('.dynsym')
    selected={b.symbols[n]['mangled']:n for n in names}
    targets={b.sym(n):n for n in names}
    start=b.elf.get_section_by_name('.plt')['sh_addr']
    rels=b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
    for i,r in enumerate(rels.iter_relocations()):
        raw=dyn.get_symbol(r['r_info_sym']).name
        if raw in selected:targets[start+32+i*16]=selected[raw]
    rows=[];seen=set()
    for name,fn in b.symbols.items():
        if name.split('::')[0] not in LOCAL_CLASSES|{'CBBGRaisePlayerRun'} or fn['address'] in seen:continue
        seen.add(fn['address']);offset=b.offset(fn['address']);code=b.original[offset:offset+fn['size']]
        if b.is64:instructions=b.cs.disasm(code,fn['address'])
        else:
            instructions=[]
            for at in range(0,len(code)-3,2):
                a,c=struct.unpack_from('<HH',code,at)
                if a&0xf800!=0xf000 or c&0xc000!=0xc000:continue
                decoded=list(b.cs.disasm(code[at:at+4],fn['address']+at))
                if len(decoded)==1 and decoded[0].size==4:instructions.extend(decoded)
        for ins in instructions:
            if ins.mnemonic not in ('bl','blx') or not ins.op_str.startswith('#'):continue
            target=int(ins.op_str[1:],16)
            if target not in targets:continue
            method=targets[target]
            if method in METHODS and name.split('::')[0] in LOCAL_CLASSES:
                pass
            elif ins.address not in REQUESTS[b.abi]:continue
            assert ins.size==4
            rows.append(dict(site=ins.address,original=target,caller=name,target=method,expected=ins.bytes.hex()))
    return rows

def request_source(b,s,row,spec):
    kind,value,rotation=spec
    helper=s['yagu_catalog_request' if kind=='branch' else 'yagu_catalog_worldmap_ready' if kind=='worldmap' else 'yagu_catalog_strength_ready']
    if b.is64:
        extra=f'mov w2, #{rotation}' if kind=='branch' else f'ldr x0, [sp, #{value+80}]' if kind=='worldmap' else f'ldr x2, [sp, #{value+80}]'
        success=f'b #{value}' if kind=='branch' else 'ret'
        return f'''{A64_SAVE}
{extra}
bl #{helper}
cbz w0, fallback
{A64_RESTORE}
{success}
fallback:
{A64_RESTORE}
b #{row['original']}'''
    extra=f'movs r2, #{rotation}' if kind=='branch' else f'ldr.w r0, [sp, #{value+24}]' if kind=='worldmap' else f'ldr.w r2, [sp, #{value+24}]'
    success=f'b.w #{value}' if kind=='branch' else 'bx lr'
    return f'''{T32_SAVE}
{extra}
bl #{helper}
cmp r0, #0
beq fallback
{T32_RESTORE}
{success}
fallback:
{T32_RESTORE}
b.w #{row['original']}'''

def add_local_catalog_hooks(b,symbols):
    rows=original_calls(b);prices=[];requests=[]
    for row in rows:
        if row['site'] in REQUESTS[b.abi]:
            assert row['target'] in (STATIC_CONNECT,RAISE_CONNECT)
            spec=REQUESTS[b.abi][row['site']]
            hook=b.append_asm('Local catalog original UI continuation: '+row['caller'],request_source(b,symbols,row,spec))
            row['continuation']=spec;requests.append(row)
        else:
            hook=symbols[METHODS[row['target']]];prices.append(row)
        row['hook']=hook
        b.patch(row['site'],b.branch(row['site'],hook,True),'Local development catalog: '+row['caller']+' -> '+row['target'],row['expected'])
    if len(prices)!=41 or {r['site'] for r in requests}!=set(REQUESTS[b.abi]):
        raise ValueError('Catalog site inventory mismatch')
    return {'schema':1,'policy':'embedded-table development prices; absent cosmetics=1 original-currency unit',
            'price_sites':prices,'ui_request_sites':requests,
            'original_network_catalog_unchanged':True,'android_shop_verified':False}
