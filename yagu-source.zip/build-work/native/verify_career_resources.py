"""Execute owned AP/popularity semantics and original resource consumers.

Reconstructed after the transient executor reset. This is an instruction-level
test, not a claim about Android graphics or a complete season. Both ABIs execute
the compiled C helpers at nonzero load bias, original resource clamps/stores and
two original training subtraction paths. Only engine lookups, UI refresh and the
final variadic text formatter are intercepted.
"""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE, GETMGR
from payload_builder import add_payload, HOOKS
from career_resource_ui import add_career_resource_ui_hooks, add_career_resource_decisions
from verify_relocation import prepare_case, TEAMS, TEAM, SAVE, MODE, BAT, PIT
from verify_gameplay_hooks import ROOT, HEAP, MGR, SP, STOP
import unicorn.arm64_const as a64
import unicorn.arm_const as arm

WORK = Path(__file__).resolve().parent
OTHER = HEAP + 0x80000
CONTEXT = HEAP + 0x90000
BUFFER = HEAP + 0x94010
FAKE_UI = HEAP + 0x95000
NEW_SAVE = HEAP + 0x60000
THRESHOLDS = (-0x80000000, -1, 0, 1, 30, 31, 127, 32760, 32761, 0x7fffffff)
VALUES = (-0x80000000, -100, -1, 0, 1, 29, 30, 31, 127, 32760, 32761, 0x7fffffff)


def u32(value):
    return value & 0xffffffff


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'career_resource_build' / abi)
    symbols = payload['symbols']
    headers = add_career_resource_ui_hooks(b, symbols)
    decisions = add_career_resource_decisions(b, symbols)
    slide = 0x72b6543000 if b.is64 else 0x96543000
    c, reference = prepare_case(b, slide), prepare_case(b, slide)
    for row in decisions:
        reference.uc.mem_write(slide + row['site'], bytes.fromhex(row['expected']))
    mode_value = [4]
    manager_value = [MGR]
    formatted, refresh = [], []

    # Resolve internal PLT calls to their actual functions. We intentionally
    # execute GsMinMax and original setters instead of mocking their rules.
    syms = list(b.elf.get_section_by_name('.dynsym').iter_symbols())
    rels = b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
    plt = b.elf.get_section_by_name('.plt')['sh_addr']
    for i, rel in enumerate(rels.iter_relocations()):
        target = int(syms[rel['r_info_sym']]['st_value'])
        if target:
            c.callbacks[slide + plt + 32 + 16 * i] = (
                lambda target=target: c.uc.reg_write(c.pc, target + slide))
    c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(mode_value[0])
    c.callbacks[b.sym(GETMGR) + slide] = lambda: c.ret(manager_value[0])
    c.callbacks[b.sym('CGsSingleton<CBBGFrameUI>::GetInstPtr()') + slide] = lambda: c.ret(FAKE_UI)

    def change_ui():
        assert c.r(0) == FAKE_UI
        refresh.append(u32(c.r(1)))
        c.ret(0)

    c.callbacks[b.sym('CBBGFrameUI::ChangeUIValue(int)') + slide] = change_ui

    def sprint():
        args = tuple(c.r(i) for i in range(4))
        formatted.append(args)
        value = b'9/30' if args[1] == BUFFER + 200 else b'9'
        c.uc.mem_write(args[0], value + b'\0')
        c.ret(len(value))

    c.callbacks[b.sym('MC_knlSprintk') + slide] = sprint

    def call_address(address, *args):
        c.stopped = None
        c.stops = {STOP}
        c.uc.reg_write(c.sp, SP)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        mask = (1 << (64 if b.is64 else 32)) - 1
        for i, value in enumerate(args):
            if i < (8 if b.is64 else 4):
                c.r(i, value & mask)
            else:
                c.uc.mem_write(SP + (i - 4) * 4, struct.pack('<I', u32(value)))
        c.run_relative(address)
        assert c.stopped == STOP
        assert c.uc.reg_read(c.sp) == SP, (abi, 'unbalanced stack', hex(address))
        return c.r(0)

    def call(name, *args):
        return call_address(b.sym(HOOKS[name]) if name in HOOKS else symbols[name], *args)

    def own(mode):
        mode_value[0], manager_value[0] = mode, MGR
        c.ptr(MGR + (0x520 if b.is64 else 0x4e4), SAVE)
        c.ptr(MGR + (0x528 if b.is64 else 0x4e8), SAVE)
        c.ptr(MGR + (0x530 if b.is64 else 0x4ec), TEAMS)
        c.uc.mem_write(TEAMS + 4, struct.pack('<i', 4))
        c.uc.mem_write(TEAM, bytes([4, 0, 8, 12]))
        c.uc.mem_write(BAT, struct.pack('<H', 1000))
        c.uc.mem_write(PIT, struct.pack('<H', 1100))

    def reset_mode(ptr):
        c.uc.mem_write(ptr, bytes(0x600))
        c.uc.mem_write(ptr + 0x264, b'\x1e')

    def resource(index):
        return symbols['my_state'] + slide + 8 + (43 + index) * 16

    counts = {key: 0 for key in ('schema', 'typed_comparisons', 'ownership',
              'bounded_storage', 'original_training_spends', 'header_calls',
              'branch_differentials', 'semantic_branches', 'year_goals', 'reload')}
    own(4)
    reset_mode(MODE)
    state = call('yagu_state', BAT)
    raw = bytes(c.uc.mem_read(state, 8 + 46 * 16))
    assert struct.unpack_from('<II', raw) == (2, 1000)
    assert all(struct.unpack_from('<QII', raw, offset) == (0, 1, 0)
               for offset in range(8, len(raw), 16))
    for index in range(3):
        assert call('yagu_career_resource', MODE, index) == resource(index)
        counts['schema'] += 1

    for mode in (3, 4):
        own(mode)
        for index in range(3):
            for threshold in THRESHOLDS:
                for op in range(4):
                    result = call('yagu_career_resource_compare', MODE, index, threshold, op)
                    assert result == int(op in (0, 2)), (abi, mode, index, threshold, op, result)
                    counts['typed_comparisons'] += 1
        for threshold in THRESHOLDS:
            assert call('year_goal', MODE, 6, threshold) == 1
            counts['year_goals'] += 1
    for index, op in ((-1, 0), (3, 0), (0, -1), (0, 4)):
        assert u32(call('yagu_career_resource_compare', MODE, index, 0, op)) == 0xffffffff
        counts['typed_comparisons'] += 1

    invalid = ('wrong_mode_ptr', 'no_manager', 'no_save', 'no_teams', 'invalid_team',
               'missing_actor', 'opponent_duplicate', 'signed_count', 'not_career')
    for mode in (3, 4):
        for problem in invalid:
            own(mode)
            actor = PIT if mode == 3 else BAT
            target_mode = MODE
            if problem == 'wrong_mode_ptr': target_mode = OTHER
            elif problem == 'no_manager': manager_value[0] = 0
            elif problem == 'no_save': c.ptr(MGR + ((0x520 if b.is64 else 0x4e4) if mode == 3 else (0x528 if b.is64 else 0x4e8)), 0)
            elif problem == 'no_teams': c.ptr(MGR + (0x530 if b.is64 else 0x4ec), 0)
            elif problem == 'invalid_team': c.uc.mem_write(TEAMS + 4, struct.pack('<i', 15))
            elif problem in ('missing_actor', 'opponent_duplicate'):
                c.uc.mem_write(actor, struct.pack('<H', 22))
                if problem == 'opponent_duplicate':
                    c.uc.mem_write(actor + 0x3b4, struct.pack('<H', 1100 if mode == 3 else 1000))
            elif problem == 'signed_count': c.uc.mem_write(TEAM + (2 if mode == 3 else 3), b'\xff')
            elif problem == 'not_career': mode_value[0] = 1
            for index in range(3):
                assert call('yagu_career_resource', target_mode, index) == 0, (abi, mode, problem, index)
                assert u32(call('yagu_career_resource_compare', target_mode, index, 1, 0)) == 0xffffffff
                counts['ownership'] += 1

    for mode in (3, 4):
        own(mode)
        reset_mode(MODE)
        for value in VALUES:
            for method in ('set_active_gauge', 'add_active_gauge', 'set_popularity', 'add_popularity', 'set_max_active'):
                c.uc.mem_write(MODE + 0x64, b'\x09')
                c.uc.mem_write(MODE + 8, struct.pack('<i', 9))
                call(method, MODE, value)
                if method in ('set_active_gauge', 'add_active_gauge'):
                    assert bytes(c.uc.mem_read(MODE + 0x64, 1)) == b'\x1e'
                    assert call('active_gauge', MODE) == 30
                elif method in ('set_popularity', 'add_popularity'):
                    assert struct.unpack('<i', c.uc.mem_read(MODE + 8, 4))[0] == 32760
                    assert call('popularity', MODE) == 32760
                else:
                    assert bytes(c.uc.mem_read(MODE + 0x264, 1)) == b'\x1e'
                    assert call('max_active', MODE) == 30
                assert call('yagu_career_resource', MODE, 0) == resource(0)
                counts['bounded_storage'] += 1
    own(4)
    reset_mode(OTHER)
    for value in (-100, -1, 0, 1, 17, 30, 31, 127, 32760, 32761):
        for method in ('set_active_gauge', 'add_active_gauge', 'set_popularity', 'add_popularity'):
            c.uc.mem_write(OTHER + 0x64, b'\x09')
            c.uc.mem_write(OTHER + 8, struct.pack('<i', 9))
            call(method, OTHER, value)
            addition = 9 if method.startswith('add_') else 0
            limit = 30 if 'active' in method else 32760
            expected = min(max(value + addition, 0), limit)
            actual = c.uc.mem_read(OTHER + 0x64, 1)[0] if 'active' in method else struct.unpack('<i', c.uc.mem_read(OTHER + 8, 4))[0]
            assert actual == expected, (abi, method, value, actual, expected)
            counts['bounded_storage'] += 1
    for value in (1, 10, 30, 100):
        call('set_max_active', OTHER, value)
        assert c.uc.mem_read(OTHER + 0x264, 1)[0] == value
        counts['bounded_storage'] += 1
    assert set(refresh).issubset({8, 32}) and {8, 32}.issubset(refresh)

    spends = ((0x50fa00, 0x50fa40, -0x10, -0x1c), (0x50fb64, 0x50fba4, -0x10, -0x14)) if b.is64 else (
              (0x32ccea, 0x32cd10, 0x20, 0x18), (0x32cdbc, 0x32cde2, 0x20, 0x1c))
    for start, stop, mode_slot, cost_slot in spends:
        for ptr in (MODE, OTHER):
            for cost in (0, 1, 28, 30, 100):
                own(4)
                reset_mode(ptr)
                c.uc.mem_write(ptr + 0x64, b'\x09')
                c.uc.reg_write(c.sp, SP)
                frame = SP + 0x300 if b.is64 else SP
                if b.is64: c.uc.reg_write(a64.UC_ARM64_REG_X29, frame)
                c.ptr(frame + mode_slot, ptr)
                c.uc.mem_write(frame + cost_slot, struct.pack('<i', cost))
                c.stopped = None
                c.stops = {stop + slide}
                c.run_relative(start)
                assert c.stopped == stop + slide and c.uc.reg_read(c.sp) == SP
                assert c.uc.mem_read(ptr + 0x64, 1)[0] == (30 if ptr == MODE else max(0, 9 - cost - 2))
                counts['original_training_spends'] += 1

    for header in headers:
        for mode in (3, 4):
            for owned in (True, False):
                own(mode)
                c.uc.reg_write(c.sp, SP)
                c.uc.mem_write(BUFFER - 8, b'!' * 8 + b'?' * 128 + b'!' * 8)
                c.ptr(SP + header['mode_slot'], MODE if owned else OTHER)
                args = (BUFFER, BUFFER + (200 if header['pair'] else 300), 9, 30)
                for i, value in enumerate(args): c.r(i, value)
                formatted.clear()
                c.stopped = None
                c.stops = {slide + header['site'] + 4}
                c.run_relative(header['site'])
                value = ('∞/∞' if header['pair'] else '∞').encode() if owned else (b'9/30' if header['pair'] else b'9')
                assert c.stopped == slide + header['site'] + 4
                assert c.uc.reg_read(c.sp) == SP and c.r(0) == len(value)
                assert bytes(c.uc.mem_read(BUFFER, 128)) == value + b'\0' + b'?' * (127 - len(value))
                assert bytes(c.uc.mem_read(BUFFER - 8, 8)) == b'!' * 8
                assert bytes(c.uc.mem_read(BUFFER + 128, 8)) == b'!' * 8
                assert formatted == ([] if owned else [args])
                counts['header_calls'] += 1

    flags = a64.UC_ARM64_REG_NZCV if b.is64 else arm.UC_ARM_REG_APSR
    fpregs = [getattr(a64 if b.is64 else arm, ('UC_ARM64_REG_Q' if b.is64 else 'UC_ARM_REG_D') + str(i)) for i in range(32)]

    def branch_setup(case, row, ptr, lhs, rhs):
        case.uc.reg_write(case.sp, SP)
        for i in range(len(case.regs)):
            case.r(i, 0x12340000 + i)
        case.uc.reg_write(case.lr, STOP if b.is64 else STOP | 1)
        case.uc.reg_write(flags, 0xa0000000)
        for i, reg in enumerate(fpregs):
            case.uc.reg_write(reg, (0x123456789abcdef0123456789abcdef0 + i) if b.is64 else (0x123456789abcdef0 + i))
        case.r(8 if b.is64 else 0, u32(lhs))
        case.r(9 if b.is64 else 1, u32(rhs))
        if b.is64 and row['label'] == 'event_action_cost': case.r(0, u32(rhs))
        slot, field = row['mode']
        case.ptr(SP + slot, ptr if field is None else CONTEXT)
        if field is not None: case.ptr(CONTEXT + field, ptr)
        if row['threshold'][0] == 'stack':
            case.uc.mem_write(SP + row['threshold'][1], struct.pack('<i', 0x7fffffff))
        case.stopped = None
        case.stops = {slide + row[key] for key in ('original_true', 'original_false', 'semantic_true')}

    def register_state(case):
        return ([case.r(i) for i in range(len(case.regs))],
                case.uc.reg_read(case.sp), case.uc.reg_read(case.lr),
                case.uc.reg_read(flags) & 0xf8000000,
                [case.uc.reg_read(reg) for reg in fpregs])

    for row in decisions:
        for mode in (3, 4):
            own(mode)
            for lhs, rhs in ((0, 1), (1, 0), (1, 1), (-1, 1), (0x7fffffff, -1)):
                branch_setup(reference, row, OTHER, lhs, rhs)
                reference.run_relative(row['site'])
                expected_state = register_state(reference)
                branch_setup(c, row, OTHER, lhs, rhs)
                c.run_relative(row['site'])
                assert c.stopped == reference.stopped, (abi, row['label'], 'fallback destination')
                assert register_state(c) == expected_state, (abi, row['label'], 'fallback registers')
                counts['branch_differentials'] += 1
                branch_setup(c, row, MODE, lhs, rhs)
                c.run_relative(row['site'])
                expected = row['semantic_true'] if row['op'] in (0, 2) else row['original_false']
                assert c.stopped == slide + expected, (abi, row['label'], mode, hex(c.stopped or 0), hex(slide + expected))
                assert register_state(c) == expected_state, (abi, row['label'], 'semantic registers')
                counts['semantic_branches'] += 1

    own(4)
    call('set_active_gauge', MODE, -1)
    call('set_popularity', MODE, -1)
    c.uc.mem_write(NEW_SAVE, bytes(c.uc.mem_read(SAVE, 0x4000)))
    c.ptr(MGR + (0x528 if b.is64 else 0x4e8), NEW_SAVE)
    for index in range(3):
        assert call('yagu_career_resource', MODE, index) == 0
        assert call('yagu_career_resource', NEW_SAVE + 8, index) == resource(index)
        counts['reload'] += 1
    assert c.uc.mem_read(NEW_SAVE + 8 + 0x64, 1)[0] == 30
    assert struct.unpack('<i', c.uc.mem_read(NEW_SAVE + 16, 4))[0] == 32760

    return {'abi': abi, 'slide': hex(slide), 'passed': sum(counts.values()), 'counts': counts,
            'source_sha256': b.sha,
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'module_sha256': hashlib.sha256((WORK / 'career_resource_ui.py').read_bytes()).hexdigest(),
            'schema': 2, 'player_scalars': 46, 'header_sites': len(headers), 'decision_sites': len(decisions),
            'actual_original_clamps_and_stores': True, 'actual_original_training_subtractions': True,
            'unowned_compare_branch_register_differential': True,
            'limits': ['No Android font rendering or complete-game verification.',
                       'Reload is a copied save buffer with changed active pointer, not disk I/O.'],
            'android_runtime_verified': False}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'career_resources_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))
