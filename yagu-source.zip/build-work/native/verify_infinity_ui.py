"""Verify UI routing and UTF-8 output, without claiming glyph rasterization."""
import json,struct
from pathlib import Path
from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks
from infinity_ui import add_infinity_ui_hooks
from verify_gameplay_hooks import Case,ROOT,HEAP,SP,RESULT,BATTER,PITCHER
from unicorn.arm64_const import UC_ARM64_REG_X29
from unicorn.arm_const import UC_ARM_REG_R7

UI=HEAP+0xe000; STATE=HEAP+0xf000

def verify(abi):
 b=PatchBuilder(abi,(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
 add_gameplay_hooks(b)
 predicate=b.sym('CBBGPlayerData::IsRaise()')
 exports=add_infinity_ui_hooks(b,predicate)
 cases=[]
 for kind in exports:
  for rfid in [1000,1100,23]:
   c=Case(b);c.uc.mem_write(BATTER,struct.pack('<H',rfid));c.ptr(UI+(0x30 if b.is64 else 0x20),BATTER)
   if kind=='frame_level':
    site=0x377e7c if b.is64 else 0x220bd8;c.ptr(SP+(0x88 if b.is64 else 0x68),BATTER)
   elif kind=='player_experience':
    site=0x4cd0ec if b.is64 else 0x2ffc08;c.ptr(SP+(0x370 if b.is64 else 0x1a0),UI)
   elif kind=='player_abilities':
    site=0x59487c if b.is64 else 0x38432e
    if b.is64:
     frame=SP+0x130;c.uc.reg_write(UC_ARM64_REG_X29,frame);c.ptr(frame+8,0x4ccc88);c.ptr(frame+0x390,UI)
    else:
     frame=SP+0x118;c.uc.reg_write(UC_ARM_REG_R7,frame);c.ptr(frame+4,0x2ff93b);c.ptr(frame+0x1a8,UI)
   else:
    site=0x40f53c if b.is64 else 0x2827b0
    if b.is64:
     frame=SP+0x120;c.uc.reg_write(UC_ARM64_REG_X29,frame);c.ptr(frame+8,0x46132c);c.ptr(frame+0x198,BATTER)
    else:
     frame=SP+0x108;c.uc.reg_write(UC_ARM_REG_R7,frame);c.ptr(frame+4,0x2b7b03);c.ptr(frame+0xf0,BATTER)
   c.r(0,RESULT);c.r(1,HEAP+0x88);c.r(2,10000);c.r(3,250)
   original=[c.r(i) for i in range(4)];called=[]
   def state():
    p=c.r(0);assert p==BATTER
    c.ret(STATE if rfid in (1000,1100) else 0)
   def formatter():
    assert original==[c.r(i) for i in range(4)]
    called.append(True);c.uc.mem_write(RESULT,b'10000\0');c.ret(5)
   c.callbacks[predicate]=state;c.callbacks[b.sym('MC_knlSprintk')]=formatter
   c.stops.add(site+4);c.run(site);assert c.uc.reg_read(c.sp)==SP
   if rfid in (1000,1100):
    expected=(b'Lv. ' if kind=='menu_level' else b'')+bytes.fromhex('e2889e00')
    assert c.uc.mem_read(RESULT,len(expected))==expected and not called and c.r(0)==len(expected)-1
   else:assert c.uc.mem_read(RESULT,6)==b'10000\0' and called
   cases.append(f'{kind}: semantic player {rfid} -> '+('UTF-8 infinity' if rfid in (1000,1100) else 'original finite formatting'))
 # The shared number renderer is called in many unrelated menus. Even the
 # same numeric projection must stay finite when not at our verified callers.
 for caller in ([0x4ccce4,0x123456] if b.is64 else [0x2ff98f,0x123457]):
  c=Case(b);c.ptr(UI+(0x30 if b.is64 else 0x20),BATTER)
  if b.is64:
   site=0x59487c;frame=SP+0x130;c.uc.reg_write(UC_ARM64_REG_X29,frame);c.ptr(frame+8,caller);c.ptr(frame+0x390,UI)
  else:
   site=0x38432e;frame=SP+0x118;c.uc.reg_write(UC_ARM_REG_R7,frame);c.ptr(frame+4,caller);c.ptr(frame+0x1a8,UI)
  c.r(0,RESULT);c.callbacks[predicate]=lambda:c.ret(STATE);called=[]
  def formatter2():called.append(True);c.ret(9)
  c.callbacks[b.sym('MC_knlSprintk')]=formatter2;c.stops.add(site+4);c.run(site)
  scoped=caller in (0x4ccce4,0x2ff98f)
  assert bool(called)!=scoped
  if scoped:assert c.uc.mem_read(RESULT,4)==bytes.fromhex('e2889e00')
  cases.append(f'shared number widget caller {hex(caller)} -> '+('infinity' if scoped else 'original'))
 return {'abi':abi,'passed':len(cases),'checks':cases,'glyph_rasterization_verified':False,'android_runtime_verified':False}

if __name__=='__main__':
 results=[verify(abi) for abi in ['arm64-v8a','armeabi-v7a']]
 Path(__file__).with_name('infinity_ui_verification.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results,indent=2))
