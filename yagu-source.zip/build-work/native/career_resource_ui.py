"""Original career AP/popularity text and local typed decisions.

The three header calls keep the existing string buffers, font styling and
geometry. Thirteen exact comparison sites replace a local branch decision,
using the active owned save's tagged resource. They do not replace a value
with a numeric infinity sentinel. Unowned calls replay the original compare
and conditional branch with all registers, vectors and flags preserved.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE


HEADERS = {
    'arm64-v8a': (
        ('action_points_and_capacity', 0x3780c0, 'e4d40e94', 0, 1, 0x78),
        ('popularity_cap_branch', 0x378644, '83d30e94', 2, 0, 0x78),
        ('popularity_finite_branch', 0x378678, '76d30e94', 2, 0, 0x78),
    ),
    'armeabi-v7a': (
        ('action_points_and_capacity', 0x220d78, '4ff25ae8', 0, 1, 0x60),
        ('popularity_cap_branch', 0x221160, '4ef266ee', 2, 0, 0x60),
        ('popularity_finite_branch', 0x22117c, '4ef258ee', 2, 0, 0x60),
    ),
}


def add_career_resource_ui_hooks(b, symbols):
    output = []
    formatter, original = symbols['yagu_format_resource'], b.sym('MC_knlSprintk')
    for label, site, expected, resource, pair, mode_slot in HEADERS[b.abi]:
        if b.is64:
            source = f'''{A64_SAVE}
ldr x1, [sp, #{mode_slot + 80}]
mov w2, #{resource}
mov w3, #{pair}
bl #{formatter}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original}'''
        else:
            source = f'''{T32_SAVE}
ldr r1, [sp, #{mode_slot + 24}]
movs r2, #{resource}
movs r3, #{pair}
bl #{formatter}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Owned career resource header: ' + label, source)
        b.patch(site, b.branch(site, hook, True), 'Render tagged ' + label, expected)
        output.append({'label': label, 'site': site, 'hook': hook,
                       'resource': resource, 'pair': pair, 'mode_slot': mode_slot})
    return output


# mode=(originalSP slot, optional object field); threshold=('reg',register)
# or ('stack',originalSP offset), or ('literal',value). Comparison op0 is >=,
# op1 is strict <, op2 is strict >. All thresholds are original signed fields.
def _decisions():
    result = {'arm64-v8a': [], 'armeabi-v7a': []}
    for abi, sites, expected, mode, threshold in (
        ('arm64-v8a', (0x4a2cf0, 0x4a2ec4, 0x4a3030, 0x4a31ac, 0x4a3418),
         '0801096b8a010054', (0xb8, 0xc8), ('reg', 9)),
        ('armeabi-v7a', (0x2e2f96, 0x2e30a8, 0x2e319a, 0x2e329e, 0x2e3438),
         '88420eda', (0x5c, 0xa4), ('reg', 1)),
    ):
        for index, site in enumerate(sites):
            result[abi].append(dict(label='career_action_cost_' + str(index), site=site,
                                    expected=expected, resource=0, op=0, mode=mode,
                                    threshold=threshold))
    for abi, rows in (
        ('arm64-v8a', (
            ('event_action_cost', 0x4249e8, '0881206b8d020054', 0, 0, (0x70, 0x128), ('stack', 4)),
            ('event_popularity_min', 0x4241e8, '0801096b8d000054', 2, 0, (0x70, 0x128), ('stack', 0x10c)),
            ('event_popularity_max', 0x424210, '0801096b8c000054', 2, 1, (0x70, 0x128), ('stack', 0x108)),
            ('event_season_popularity_min', 0x424278, '0801096b8d000054', 2, 0, (0x70, 0x128), ('stack', 0x10c)),
            ('event_season_popularity_max', 0x4242a0, '0801096b8c000054', 2, 1, (0x70, 0x128), ('stack', 0x108)),
            ('popularity_tier', 0x42d100, '08210371ac000054', 2, 2, (0x168, None), ('literal', 1200)),
            ('story_popularity_1', 0x42d2ac, '0801096bea010054', 2, 0, (0x168, None), ('reg', 9)),
            ('story_popularity_3', 0x42d400, '0801096bea010054', 2, 0, (0x168, None), ('reg', 9)),
        )),
        ('armeabi-v7a', (
            ('event_action_cost', 0x28f90a, '884212dd', 0, 0, (0x1fc, None), ('stack', 4)),
            ('event_popularity_min', 0x28f45e, '884204dd', 2, 0, (0x1fc, None), ('stack', 0xdc)),
            ('event_popularity_max', 0x28f476, '884204dc', 2, 1, (0x1fc, None), ('stack', 0xd8)),
            ('event_season_popularity_min', 0x28f4ae, '884204dd', 2, 0, (0x1fc, None), ('stack', 0xdc)),
            ('event_season_popularity_max', 0x28f4c6, '884204dc', 2, 1, (0x1fc, None), ('stack', 0xd8)),
            ('popularity_tier', 0x294e50, 'c82803dc', 2, 2, (0xf4, None), ('literal', 1200)),
            ('story_popularity_1', 0x294f38, '88420cda', 2, 0, (0xf4, None), ('reg', 1)),
            ('story_popularity_3', 0x294fe4, '88420cda', 2, 0, (0xf4, None), ('reg', 1)),
        )),
    ):
        for label, site, expected, resource, op, mode, threshold in rows:
            result[abi].append(dict(label=label, site=site, expected=expected,
                                    resource=resource, op=op, mode=mode, threshold=threshold))
    for abi, target in (('arm64-v8a', 0x42d1a4), ('armeabi-v7a', 0x294eac)):
        tier = next(row for row in result[abi] if row['label'] == 'popularity_tier')
        tier['semantic_true'] = target
        tier['false_original'] = True
    return result


DECISIONS = _decisions()


def _a64_stack():
    save = ['sub sp, sp, #704']
    save += [f'stp x{i}, x{i + 1}, [sp, #{i * 8}]' for i in range(0, 18, 2)]
    save += ['stp x18, x30, [sp, #144]', 'mrs x8, nzcv', 'str x8, [sp, #160]']
    save += [f'stp q{i}, q{i + 1}, [sp, #{192 + i * 16}]' for i in range(0, 32, 2)]
    restore = [f'ldp q{i}, q{i + 1}, [sp, #{192 + i * 16}]' for i in range(0, 32, 2)]
    restore += ['ldr x8, [sp, #160]', 'msr nzcv, x8']
    restore += [f'ldp x{i}, x{i + 1}, [sp, #{i * 8}]' for i in range(0, 18, 2)]
    restore += ['ldp x18, x30, [sp, #144]', 'add sp, sp, #704']
    return '\n'.join(save), '\n'.join(restore)


def _thumb_stack():
    return ('''push.w {r0-r3, r12, lr}
sub sp, sp, #8
mrs r0, apsr
str r0, [sp]
vpush {d0-d15}
vpush {d16-d31}''', '''vpop {d16-d31}
vpop {d0-d15}
ldr r0, [sp]
msr APSR_nzcvq, r0
add sp, sp, #8
pop.w {r0-r3, r12, lr}''')


def add_career_resource_decisions(b, symbols):
    """Patch13 local compare+branch pairs; never a global condition helper."""
    output = []
    for row in DECISIONS[b.abi]:
        row = dict(row)
        site, expected = row['site'], row['expected']
        original = bytes.fromhex(expected)
        instructions = list(b.cs.disasm(original, site))
        if len(instructions) != 2 or instructions[0].mnemonic not in ('cmp', 'subs'):
            raise ValueError('Unexpected career comparison at ' + hex(site))
        compare, branch = instructions
        if branch.mnemonic not in ('b.ge', 'b.le', 'b.gt', 'bge', 'ble', 'bgt'):
            raise ValueError('Unexpected career condition at ' + hex(site))
        original_true = int(branch.op_str[1:], 16)
        original_false = site + len(original)
        semantic_true = row.get('semantic_true', original_true)
        op = 'b' if b.is64 else 'b.w'
        compare_source = compare.mnemonic + ' ' + compare.op_str
        mode_slot, mode_field = row['mode']
        threshold_kind, threshold_value = row['threshold']
        if b.is64:
            save, restore = _a64_stack()
            args = f'ldr x0, [sp, #{704 + mode_slot}]'
            if mode_field is not None:
                args += f'\ncbz x0, original\nldr x0, [x0, #{mode_field}]'
            if threshold_kind == 'reg': args += f'\nldr w2, [sp, #{threshold_value * 8}]'
            elif threshold_kind == 'stack': args += f'\nldr w2, [sp, #{704 + threshold_value}]'
            else: args += f'\nmov w2, #{threshold_value}'
            args += f'\nmov w1, #{row["resource"]}\nmov w3, #{row["op"]}'
            guard = f'''bl #{symbols['yagu_career_resource_compare']}
tbnz w0, #31, original
cbz w0, {'original' if row.get('false_original') else 'semantic_false'}'''
        else:
            save, restore = _thumb_stack()
            args = f'ldr.w r0, [sp, #{288 + mode_slot}]'
            if mode_field is not None:
                args += f'\ncmp r0, #0\nbeq original\nldr.w r0, [r0, #{mode_field}]'
            if threshold_kind == 'reg': args += f'\nldr r2, [sp, #{264 + threshold_value * 4}]'
            elif threshold_kind == 'stack': args += f'\nldr.w r2, [sp, #{288 + threshold_value}]'
            else: args += f'\nmovw r2, #{threshold_value}'
            args += f'\nmovs r1, #{row["resource"]}\nmovs r3, #{row["op"]}'
            guard = f'''bl #{symbols['yagu_career_resource_compare']}
cmp r0, #0
blt original
beq {'original' if row.get('false_original') else 'semantic_false'}'''
        source = f'''{compare_source}
{save}
{args}
{guard}
{restore}
{op} #{semantic_true}
semantic_false:
{restore}
{op} #{original_false}
original:
{restore}
{branch.mnemonic} original_taken
{op} #{original_false}
original_taken:
{op} #{original_true}'''
        hook = b.append_asm('Typed career decision: ' + row['label'], source)
        new = b.branch(site, hook)
        if len(original) > len(new):
            new += b.asm('nop', site + len(new))
        if len(new) != len(original): raise ValueError('Career decision patch size mismatch')
        b.patch(site, new, 'Use tagged resource for ' + row['label'], expected)
        row.update(hook=hook, original_true=original_true, original_false=original_false,
                   semantic_true=semantic_true, compare=compare_source,
                   condition=branch.mnemonic, size=len(original))
        output.append(row)
    return output
