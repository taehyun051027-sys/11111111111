"""Pure local-wallet UI integration, independent of the wallet spending policy."""
import hashlib
import json
import re
from pathlib import Path

WORK=Path(__file__).resolve().parent
INCLUDE='#include "wallet_ui_payload.inc"'
FRAME='CBBGFrameUI::AddGFNumber(eGameFrameNum, int, int, int, bool)'
DIGITS='DrawCCFitNumber(ccpzx::CCPZXFrame*, int, int, int, cocos2d::CCRect&, int, int, int, int, bool, bool, bool, bool, int)'
NUMBER='AddChildFitNumberSystemFont(int, int, cocos2d::_ccColor4B&, int, int, cocos2d::CCRect&, int, int, int, bool, bool)'
FONT='AddChildFitSystemFont(char const*, int, int, cocos2d::CCRect&, int, int, int, bool, bool, bool)'
STYLE='CBBGStatic::GetChangeFont(CBBStringBuffer&, char const*, int, int, short, short, short, short)'
HOOKS={'wallet_frame_numbers':FRAME}
BINDINGS={
 'wallet_ui_original_digits':DIGITS,'wallet_ui_original_number':NUMBER,
 'wallet_ui_string_init':'CBBStringBuffer::CBBStringBuffer(char const*)',
 'wallet_ui_string_destroy':'CBBStringBuffer::~CBBStringBuffer()',
 'wallet_ui_string_get':'CBBStringBuffer::Get()',
 'wallet_ui_change_font':STYLE,'wallet_ui_fit_font':FONT,'wallet_ui_sprint':'MC_knlSprintk',
}


def integrate_source(source):
    if INCLUDE in source:
        if source.count(INCLUDE)!=1:raise ValueError('Repeated wallet UI integration')
        return source
    if '#include "wallet_payload.inc"' not in source:raise ValueError('Integrate local wallet first')
    return source.rstrip()+'\n\n'+INCLUDE+'\n'


def integrate_builder(source):
    from special_uses_policy import once
    for name,entries in (('HOOKS',HOOKS),('BINDINGS',BINDINGS)):
        addition=''.join('    '+repr(k)+': '+repr(v)+',\n' for k,v in entries.items())
        source=once(source,name+' = {\n',name+' = {\n'+addition,'wallet UI '+name)
    source=once(source,'    from equipment_level_ui import add_equipment_level_ui_hooks',
                '    from equipment_level_ui import add_equipment_level_ui_hooks\n'
                '    from wallet_ui import add_wallet_ui_hooks','wallet UI import')
    source=once(source,"        add_equipment_level_ui_hooks(b,report['symbols'])",
                "        add_equipment_level_ui_hooks(b,report['symbols'])\n"
                "        add_wallet_ui_hooks(b,report['symbols'])",'wallet UI calls')
    return source


def stage_payload(output_dir,source_dir=WORK):
    output_dir,source_dir=Path(output_dir),Path(source_dir)
    output_dir.mkdir(parents=True,exist_ok=True)
    raw=(source_dir/'yagu_payload.c').read_text();staged=integrate_source(raw)
    (output_dir/'yagu_payload.c').write_text(staged)
    pending=re.findall(r'^\s*#\s*include\s*"([^"\n]+)"',staged,re.MULTILINE)
    dependencies={}
    while pending:
        name=pending.pop()
        if name in dependencies:continue
        if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*',name) or '..' in name:raise ValueError('Unsafe include')
        path=(WORK if name=='wallet_ui_payload.inc' else source_dir)/name
        if path.is_symlink() or not path.is_file():raise ValueError('Missing include '+name)
        data=path.read_bytes();(output_dir/name).write_bytes(data)
        dependencies[name]=hashlib.sha256(data).hexdigest()
        pending.extend(re.findall(r'^\s*#\s*include\s*"([^"\n]+)"',data.decode(),re.MULTILINE))
    report={'base_c_sha256':hashlib.sha256(raw.encode()).hexdigest(),
            'staged_c_sha256':hashlib.sha256(staged.encode()).hexdigest(),
            'dependencies':dependencies,'shared_source_modified':False}
    (output_dir/'wallet_ui_stage_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    return report
