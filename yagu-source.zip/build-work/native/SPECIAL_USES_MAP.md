# Available SUPER stock and cumulative special uses

The old native effect-item byte is a bounded compatibility field. The new authoritative available quantity is `InfinitePlayer.special_uses` (player schema3, scalar46 after46 existing scalars). The new cumulative personal quantity is `InfiniteRecords.special_uses` (record schema4, scalar39 after39 existing scalars). Both are typed `UNBOUNDED`, with no finite sentinel value. Existing field offsets remain stable.

## Exact local integration

| Path | A64 call | Thumb call | Behavior |
|---|---:|---:|---|
| Pitch scene's career pointer | 0x3bad30 | 0x24a59a | Use active BAT RaiseMode only for the actual owned paired pitcher |
| Pitch use's career pointer | 0x3bed3c | 0x24d49a | Same scoped bridge; common stock/total fields only |
| Pitch stock eligibility/cache | 0x3bad48 | 0x24a5a8 | Typed availability for one real activation |
| Bat live stock cache | 0x3e7214 | 0x268d64 | Boolean availability adapter for the existing refresh cache |
| Bat activation stock test | 0x3e9d18 | 0x26aa56 | Typed one-use availability feeds the original branch |
| Pitch spend | 0x3bed4c | 0x24d4a6 | Finite subtraction leaves tagged infinity unchanged |
| Bat spend | 0x3e9e28 | 0x26ab04 | Same typed spend policy |
| Bat SUPER label | 0x3e7248 | 0x268d84 | Existing bounded text buffer receives UTF-8 infinity |
| Pitch SUPER label | 0x3bc5b0 | 0x24b764 | Existing white font markup plus UTF-8 infinity |

The live predicate requires career3/4, the exact active save, the own-team entry, and the exact role actor pointer resolved in that roster. A reserved RFID copied into an opponent or another allocation does not receive this resource. The mode4 pointer bridge changes neither ball type nor PIT-only skill tables. The two original callers use only the common stock and cumulative-use fields.

Original selectors32 in both event record switches read cumulative special uses independently of the period argument. The existing typed event wrapper now maps32 to the new personal metric. Nonnegative thresholds retain the original `>=` interpretation; negative thresholds retain strict upper-bound semantics, so unbounded values fail those upper-bound tests. Unowned or incomplete record contexts retain the original event handler.

## Original actions and finite state

An activation still executes the original selected-special type, effect queue, `AddUseSpecialCnt`, and `AddTotalSpecialSkillCnt` calls. The per-match count remains the actual finite number of uses, and the old cumulative u16 remains a finite serialized event history; neither is the authoritative unbounded personal total. Global stock getters, setters, item inventory and the original network/security serialization callers are unchanged.

Verification ran the compiled C and all nine actual hooks under nonzero ASLR in both ABIs. The2,376 cases include the complete original PIT selection-button function, repeated real activations with finite count increments, missing PIT save in mode4, the original BAT stock branch, original negative record comparisons, bounded original setters, and scope/fallback argument preservation. This is native instruction verification. Android activation and visual review are separate gates.

The separate training and spring-camp stock-before/after cells still use their original finite presentation in this nine-site extension. They have been identified in `analysis/world-career/long-career/special-stock-menu-contexts.txt`; the extension must not be described as covering every SUPER menu.
