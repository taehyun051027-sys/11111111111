#!/usr/bin/env python3
"""Compatibility repair for one exact official Android emulator renderer.

The game APK, libcocos2d, the original renderer, and its error/status functions
are never modified. This creates a separate renderer copy. The original GLES1
translator's FBO capability gate does not recognize GLES2+ core functionality
when the desktop EXT spelling is absent. All fifteen core functions must exist
before any missing EXT dispatch slot is assigned its ABI-identical core entry.

The actual FBO result must still be checked by probe_emulator_fbo.py. This
builder does not claim a successful render or Android gameplay verification.
"""
import argparse
import hashlib
import io
import json
from pathlib import Path
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent.parent / 'analysis/native/tools'))
from elftools.elf.elffile import ELFFile

EXPECTED_SHA256 = '82359d64c4ff035ea44c8aef3bf8b0e5b692f2931473f4f4698d9af94a7da44d'
GATE_CALL = 0x55df4a
IS_GLES = 0x56d120
IS_CORE = 0x56d140
GET_STRING = 0x5c7660
ALIASES = [
    ('GenRenderbuffers', 0x5c8018, 0x5c7770),
    ('DeleteRenderbuffers', 0x5c8010, 0x5c7768),
    ('BindRenderbuffer', 0x5c8008, 0x5c7760),
    ('IsRenderbuffer', 0x5c8000, 0x5c7758),
    ('RenderbufferStorage', 0x5c8020, 0x5c7778),
    ('GetRenderbufferParameteriv', 0x5c8028, 0x5c7780),
    ('GenFramebuffers', 0x5c7fd8, 0x5c77a0),
    ('DeleteFramebuffers', 0x5c7ff8, 0x5c7798),
    ('BindFramebuffer', 0x5c7fd0, 0x5c7790),
    ('IsFramebuffer', 0x5c7ff0, 0x5c7788),
    ('FramebufferTexture2D', 0x5c7fe0, 0x5c77b8),
    ('FramebufferRenderbuffer', 0x5c8030, 0x5c77c8),
    ('GetFramebufferAttachmentParameteriv', 0x5c8038, 0x5c77d0),
    ('CheckFramebufferStatus', 0x5c7fe8, 0x5c77a8),
    ('GenerateMipmap', 0x5c8040, 0x5c77d8),
]

def align(n, a=4096):
    return (n + a - 1) // a * a

def build(source, destination):
    original = source.read_bytes()
    digest = hashlib.sha256(original).hexdigest()
    if digest != EXPECTED_SHA256:
        raise ValueError('Unsupported renderer SHA256: ' + digest)
    elf = ELFFile(io.BytesIO(original))
    if elf.elfclass != 64 or not elf.little_endian or elf['e_machine'] != 'EM_X86_64':
        raise ValueError('Expected original x86-64 little-endian ELF')
    segments = list(elf.iter_segments())
    if len(segments) != 10 or elf['e_phentsize'] != 56:
        raise ValueError('Unexpected program-header layout')

    def offset(address):
        for segment in segments:
            if segment['p_type'] == 'PT_LOAD' and segment['p_vaddr'] <= address < segment['p_vaddr'] + segment['p_filesz']:
                return segment['p_offset'] + address - segment['p_vaddr']
        raise ValueError('Not file-backed: ' + hex(address))

    for address, expected in ((GATE_CALL, 'e8f1f10000'),
                              (IS_GLES, '8b053ab6050085c00f95c0c3'),
                              (IS_CORE, '8b051eb6050085c00f95c0c3')):
        data = bytes.fromhex(expected)
        if original[offset(address):offset(address) + len(data)] != data:
            raise ValueError('Original code mismatch at ' + hex(address))
    dispatch_symbols = {s.name: int(s['st_value']) for s in elf.get_section_by_name('.dynsym').iter_symbols()}
    for name, core, ext in ALIASES:
        for suffix, address in (('', core), ('EXT', ext)):
            method = 'gl' + name + suffix
            symbol = '_ZN10GLDispatch' + str(len(method)) + method + 'E'
            if dispatch_symbols.get(symbol) != address:
                raise ValueError('Dispatch slot mismatch: ' + symbol)

    destination.parent.mkdir(parents=True, exist_ok=True)
    wd = destination.parent
    file_base = align(len(original))
    segment_base = align(max(s['p_vaddr'] + s['p_memsz'] for s in segments if s['p_type'] == 'PT_LOAD'))
    phnum, phsize = len(segments) + 1, 56
    table_size = phnum * phsize
    entry = segment_base + align(table_size, 64)
    pair_text = ',\n'.join('    {0x%x, 0x%x}' % (core, ext) for _, core, ext in ALIASES)
    c = f'''typedef unsigned long uptr;
typedef unsigned int u32;
extern int yagu_fbo_gate_entry(void);
static const u32 pairs[][2] = {{
{pair_text}
}};
__attribute__((visibility("hidden"))) int yagu_fbo_core_gate(void) {{
    uptr base;
    /* A static ELF linker may relax a C function-address GOT reference into an
     * absolute immediate. Explicit RIP-relative LEA remains valid under ASLR. */
    __asm__("lea yagu_fbo_gate_entry(%%rip), %0" : "=r" (base));
    base -= 0x{entry:x}UL;
    if (((int (*)(void))(base + 0x{IS_CORE:x}))()) return 1;
    if (!((int (*)(void))(base + 0x{IS_GLES:x}))()) return 0;
    const unsigned char *(*get_string)(u32) = *(void **)(base + 0x{GET_STRING:x});
    if (!get_string) return 0;
    const unsigned char *version = get_string(0x1f02);
    if (!version) return 0;
    const char prefix[] = "OpenGL ES ";
    for (u32 i = 0; i != 10; ++i) if (version[i] != (unsigned char)prefix[i]) return 0;
    if (version[10] < '2' || version[10] > '9' || version[11] != '.') return 0;
    for (u32 i = 0; i != 15; ++i) if (!*(uptr *)(base + pairs[i][0])) return 0;
    for (u32 i = 0; i != 15; ++i) {{
        uptr *extended = (uptr *)(base + pairs[i][1]);
        if (!*extended) *extended = *(uptr *)(base + pairs[i][0]);
    }}
    return 1;
}}
'''
    asm = '''.text
.section .text.entry,"ax",@progbits
.global yagu_fbo_gate_entry
.hidden yagu_fbo_gate_entry
.type yagu_fbo_gate_entry,@function
yagu_fbo_gate_entry:
    push %rcx
    push %rdx
    push %rsi
    push %rdi
    push %r8
    push %r9
    push %r10
    push %r11
    sub $520, %rsp
    fxsave64 (%rsp)
    call yagu_fbo_core_gate
    fxrstor64 (%rsp)
    add $520, %rsp
    pop %r11
    pop %r10
    pop %r9
    pop %r8
    pop %rdi
    pop %rsi
    pop %rdx
    pop %rcx
    ret
.size yagu_fbo_gate_entry, .-yagu_fbo_gate_entry
.section .note.GNU-stack,"",@progbits
'''
    linker = f'''SECTIONS {{
  . = 0x{entry:x};
  .payload : {{ *(.text.entry) *(.text .text.*) *(.rodata .rodata.*) }}
  .data : {{ *(.data .data.*) *(.bss .bss.*) *(COMMON) }}
  /DISCARD/ : {{ *(.note*) *(.eh_frame*) *(.comment) }}
}}
'''
    (wd / 'fbo_gate.c').write_text(c)
    (wd / 'fbo_gate.S').write_text(asm)
    (wd / 'fbo_gate.ld').write_text(linker)
    commands = [
        ['gcc', '-O2', '-ffreestanding', '-fPIC', '-fno-builtin', '-fno-stack-protector',
         '-fno-asynchronous-unwind-tables', '-fno-unwind-tables', '-mgeneral-regs-only',
         '-c', str(wd / 'fbo_gate.c'), '-o', str(wd / 'fbo_gate.o')],
        ['gcc', '-c', str(wd / 'fbo_gate.S'), '-o', str(wd / 'fbo_entry.o')],
        ['ld', '-nostdlib', '-T', str(wd / 'fbo_gate.ld'), '-o', str(wd / 'fbo_gate.elf'),
         str(wd / 'fbo_entry.o'), str(wd / 'fbo_gate.o')],
    ]
    for command in commands:
        subprocess.run(command, check=True, capture_output=True, text=True)
    payload_elf = ELFFile(io.BytesIO((wd / 'fbo_gate.elf').read_bytes()))
    for section in payload_elf.iter_sections():
        if section['sh_type'] in ('SHT_REL', 'SHT_RELA') and section['sh_size']:
            raise ValueError('Payload contains unresolved relocations')
    data_section = payload_elf.get_section_by_name('.data')
    if data_section and data_section['sh_size']:
        raise ValueError('Payload unexpectedly contains writable state')
    payload = payload_elf.get_section_by_name('.payload')
    if payload['sh_addr'] != entry:
        raise ValueError('Entry address mismatch')
    appended_size = entry - segment_base + payload['sh_size']
    new_header = struct.pack('<IIQQQQQQ', 1, 5, file_base, segment_base, segment_base,
                             appended_size, appended_size, 4096)
    old_table = original[elf['e_phoff']:elf['e_phoff'] + len(segments) * phsize]
    new_table = bytearray(old_table)
    phdr_count = 0
    for index, segment in enumerate(segments):
        if segment['p_type'] == 'PT_PHDR':
            phdr_count += 1
            new_table[index * phsize:(index + 1) * phsize] = struct.pack(
                '<IIQQQQQQ', 6, segment['p_flags'], file_base, segment_base, segment_base,
                table_size, table_size, segment['p_align'])
    if phdr_count != 1:
        raise ValueError('Expected exactly one PT_PHDR')
    new_table.extend(new_header)
    output = bytearray(original)
    struct.pack_into('<Q', output, 32, file_base)
    struct.pack_into('<H', output, 56, phnum)
    call_offset = offset(GATE_CALL)
    output[call_offset:call_offset + 5] = b'\xe8' + struct.pack('<i', entry - GATE_CALL - 5)
    output.extend(bytes(file_base - len(output)))
    output.extend(new_table)
    output.extend(bytes(entry - segment_base - len(new_table)))
    output.extend(payload.data())
    if len(output) != file_base + appended_size:
        raise ValueError('Segment size mismatch')
    check = ELFFile(io.BytesIO(output))
    for segment in check.iter_segments():
        if segment['p_type'] == 'PT_LOAD':
            assert segment['p_offset'] % segment['p_align'] == segment['p_vaddr'] % segment['p_align']
    allowed_changes = set(range(32, 40)) | set(range(56, 58)) | set(range(call_offset, call_offset + 5))
    changes = [i for i, (a, z) in enumerate(zip(original, output)) if a != z]
    if any(i not in allowed_changes for i in changes):
        raise ValueError('Unexpected original-file change')
    destination.write_bytes(output)
    result = {'input': str(source.resolve()), 'output': str(destination.resolve()),
              'input_sha256': digest, 'output_sha256': hashlib.sha256(output).hexdigest(),
              'input_unchanged': hashlib.sha256(source.read_bytes()).hexdigest() == digest,
              'original_changed_offsets': changes, 'entry': hex(entry),
              'segment': {'file_offset': hex(file_base), 'virtual_address': hex(segment_base), 'bytes': appended_size},
              'aliases': [{'name': 'gl' + name, 'core': hex(core), 'ext': hex(ext)} for name, core, ext in ALIASES],
              'real_fbo_runtime_verified': False,
              'scope': 'local emulator renderer compatibility; no APK or Cocos changes; real GL errors/status preserved'}
    destination.with_suffix('.repair.json').write_text(json.dumps(result, indent=2) + '\n')
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('source', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    print(json.dumps(build(args.source, args.destination), indent=2))
