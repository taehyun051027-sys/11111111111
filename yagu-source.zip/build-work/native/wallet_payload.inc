/* Local development wallet. Original account balances, server serialization,
 * billing and receipt handlers are not changed. These typed resources are
 * consumed only by the explicitly selected local game/UI call sites. */
typedef struct { u32 schema; u32 reserved; Scalar g_points; Scalar stars; } InfiniteWallet;
static const InfiniteWallet local_wallet = {1, 0, INF, INF};
enum { WALLET_G = 0, WALLET_STAR = 1, WALLET_G_ADAPTER = 9999999,
       WALLET_STAR_ADAPTER = 200000 };
API extern u8 *wallet_get_option(u8 *);
API extern int wallet_original_get_g(u8 *);
API extern int wallet_original_get_star(u8 *);
API extern void wallet_original_add_g(u8 *, int, u8);
API extern void wallet_original_add_star(u8 *, int, u8, int, int, int, int);

API const InfiniteWallet *yagu_wallet_state(const u8 *option) {
    u8 *dm = data_manager();
    if (!option || !dm || wallet_get_option(dm) != option) return (const InfiniteWallet *)0;
    int mode = game_mode();
    if (mode == 0 || ((mode == 3 || mode == TWO_WAY_MODE) && owned_role_player(dm, mode == 3)))
        return &local_wallet;
    return (const InfiniteWallet *)0;
}
API const Scalar *yagu_wallet_scalar(const u8 *option, int kind) {
    const InfiniteWallet *state = yagu_wallet_state(option);
    if (!state || kind < 0 || kind > 1) return (const Scalar *)0;
    return kind ? &state->stars : &state->g_points;
}
API int yagu_wallet_can_spend(const u8 *option, int kind, u64 cost) {
    const Scalar *value = yagu_wallet_scalar(option, kind);
    return value && yagu_at_least(*value, cost);
}
API int yagu_wallet_g_range(const u8 *option, int lower, int upper) {
    if (!yagu_wallet_scalar(option, WALLET_G)) return -1;
    /* Original event schema: zero disables a bound; upper is exclusive.
     * Unbounded satisfies every finite lower bound and no finite upper bound. */
    (void)lower;
    return upper == 0;
}
API const char *yagu_wallet_text(int kind) {
    u8 *dm = data_manager();
    if (!dm) return (const char *)0;
    const Scalar *value = yagu_wallet_scalar(wallet_get_option(dm), kind);
    return value && value->kind == UNBOUNDED ? unbounded_text : (const char *)0;
}
API int yagu_wallet_get_g(u8 *option) {
    return yagu_wallet_scalar(option, WALLET_G) ? WALLET_G_ADAPTER : wallet_original_get_g(option);
}
API int yagu_wallet_get_star(u8 *option) {
    return yagu_wallet_scalar(option, WALLET_STAR) ? WALLET_STAR_ADAPTER : wallet_original_get_star(option);
}
API void yagu_wallet_add_g(u8 *option, int amount, u8 flag) {
    const Scalar *value = yagu_wallet_scalar(option, WALLET_G);
    if (!value) { wallet_original_add_g(option, amount, flag); return; }
    /* No finite debit/credit changes an Unbounded resource. In particular,
     * there is no counter to exhaust after repeated purchases or a reload. */
    if (amount < 0) (void)yagu_consume_finite(*value, (u64)(-(long long)amount));
    else (void)yagu_add_finite(*value, (unsigned)amount);
}
API void yagu_wallet_add_star(u8 *option, int amount, u8 sync,
                              int a, int b, int c, int d) {
    const Scalar *value = yagu_wallet_scalar(option, WALLET_STAR);
    if (!value) { wallet_original_add_star(option, amount, sync, a, b, c, d); return; }
    if (amount < 0) (void)yagu_consume_finite(*value, (u64)(-(long long)amount));
    else (void)yagu_add_finite(*value, (unsigned)amount);
}

static int local_wallet_career(void) {
    int mode = game_mode();
    return (mode == 3 || mode == TWO_WAY_MODE) &&
        owned_role_player(data_manager(), mode == 3) && yagu_wallet_text(WALLET_STAR);
}
API int yagu_wallet_local_enabled(const u8 *option) {
    return yagu_wallet_state(option) && local_wallet_career();
}
/* The caller has already validated a local purchase and its original selection.
 * These are local game effects, not a replacement for any payment response. */
API extern void wallet_worldmap_buy(u8 *);
API extern void wallet_lucky_buy(u8 *);
API extern void wallet_lucky_animate(u8 *);
API extern void wallet_camp_complete(u8 *);
API extern void wallet_set_skill_slots(u8 *, int);
API extern void wallet_skill_icon(u8 *, u8, int, int);
API extern u8 *wallet_get_raise_mode(u8 *, int);
API int yagu_wallet_local_action(u8 *option, u8 *ui, int action) {
    if (!ui || !yagu_wallet_local_enabled(option)) return 0;
    if (action == 0) wallet_worldmap_buy(ui);
    else if (action == 1) { wallet_lucky_buy(ui); wallet_lucky_animate(ui); }
    else if (action == 2) {
        u8 *mode = wallet_get_raise_mode(data_manager(), game_mode());
        if (!own_mode(mode)) return 0;
        wallet_set_skill_slots(mode, 2);
        wallet_skill_icon(ui, 1, 3, -1);
        wallet_skill_icon(ui, 1, 4, -1);
    } else if (action == 3) wallet_camp_complete(ui);
    else return 0;
    return 1;
}
/* The original shop already has a local BuyProcess path. Calling it from the
 * confirmed shop selection grants the original item and saves normally. No
 * server success code, transaction, receipt or purchased balance is invented. */
#define LOCAL_SHOP(name) \
API extern void original_wallet_##name##_connect(u8 *); \
API extern void wallet_##name##_buy(u8 *); \
API void yagu_wallet_##name##_connect(u8 *ui) { \
    if (ui && local_wallet_career()) wallet_##name##_buy(ui); \
    else original_wallet_##name##_connect(ui); \
}
LOCAL_SHOP(equip)
LOCAL_SHOP(costume)
LOCAL_SHOP(effect)
LOCAL_SHOP(frame)
LOCAL_SHOP(estimate)
#undef LOCAL_SHOP

API extern void original_wallet_bundle_connect(u8 *, int);
API extern void wallet_bundle_buy(u8 *);
API void yagu_wallet_bundle_connect(u8 *ui, int index) {
    if (ui && local_wallet_career()) wallet_bundle_buy(ui);
    else original_wallet_bundle_connect(ui, index);
}
