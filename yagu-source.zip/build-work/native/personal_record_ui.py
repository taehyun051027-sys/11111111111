"""Use semantic personal records at the original table's font calls only.

No ranking, opponent record, inning, out or score formatting is changed.
The two observed AddData callers supply the original metric page; the loop
column supplies its exact metric. The native helper also verifies that the
active career contains the appropriate My role in the owned team.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

FONT = 'CBBGStatic::GetChangeFont(CBBStringBuffer&, char const*, int, int, short, short, short, short)'


def add_personal_record_ui_hooks(b, symbols):
    resolver = symbols['yagu_personal_record_text']
    original = b.sym(FONT)
    sites = [0x4f5934, 0x4f5960] if b.is64 else [0x31b3f4, 0x31b412]
    expected = ['63e80894', '58e80894'] if b.is64 else ['57f16ce8', '57f15ee8']
    exports = []
    for site, source_bytes in zip(sites, expected):
        if b.is64:
            source = f'''{A64_SAVE}
ldr x8, [x29, #8]
adrp x9, #0x4f5000
add x9, x9, #0x5e0
cmp x8, x9
b.eq personal_context
add x9, x9, #0x3c
cmp x8, x9
b.ne original
personal_context:
ldr x8, [x29]
cbz x8, original
sub x8, x8, #0x290
ldrb w0, [x8, #0xc0]
and w0, w0, #1
eor w0, w0, #1
ldr w1, [x8, #0xd4]
mov w9, #6
mul w1, w1, w9
ldr w9, [sp, #0x104]
add w1, w1, w9
bl #{resolver}
cbz x0, original
str x0, [sp, #8]
original:
{A64_RESTORE}
b #{original}'''
        else:
            delta = (0x31b1bf - (site + 5)) & 0xffffffff
            source = f'''{T32_SAVE}
ldr r3, [r7, #4]
movw r2, #{delta & 0xffff}
movt r2, #{delta >> 16}
add r2, lr
cmp r3, r2
beq personal_context
add.w r2, r2, #0x22
cmp r3, r2
bne original
personal_context:
ldr r2, [r7]
cmp r2, #0
beq original
sub.w r2, r2, #0x1d8
ldrb r0, [r2, #0x77]
and r0, r0, #1
eor r0, r0, #1
ldr r1, [r2, #0x80]
movs r3, #6
mul r1, r1, r3
ldr r3, [sp, #0x9c]
add r1, r1, r3
bl #{resolver}
cmp r0, #0
beq original
str r0, [sp, #4]
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Unbounded personal record font ' + hex(site), source)
        b.patch(site, b.branch(site, hook, True), 'Render semantic My career record', source_bytes)
        exports.append({'site': site, 'hook': hook})
    return exports
