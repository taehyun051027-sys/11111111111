/* Yagu's semantic state and two-way roster integration.
 *
 * The original save ABI is retained. Its uint8/uint16 fields are ONLY adapters
 * for the old renderer, animation and lookup tables. Infinity is a distinct
 * kind, reconstructed from the two persistent My Player role IDs; it is never
 * serialized as 0xff/0xffff or inferred from a large finite number.
 *
 * This file is freestanding C. It has no writable globals, allocator, imports
 * from another library, networking, or Android framework dependencies.
 */
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned long long u64;
typedef __UINTPTR_TYPE__ uptr;

#define API __attribute__((visibility("hidden")))
#if __SIZEOF_POINTER__ == 8
#define DM_BAT_SAVE 0x528
#define DM_PIT_SAVE 0x520
#define DM_TEAMS 0x530
#define DM_BAT_CACHE 0x38
#define DM_PIT_CACHE 0x40
#define SIM_ENTRIES 0x78
#else
#define DM_BAT_SAVE 0x4e8
#define DM_PIT_SAVE 0x4e4
#define DM_TEAMS 0x4ec
#define DM_BAT_CACHE 0x30
#define DM_PIT_CACHE 0x34
#define SIM_ENTRIES 0x6c
#endif

enum { MY_BAT = 1000, MY_PIT = 1100, TWO_WAY_MODE = 4 };
enum { FINITE = 0, UNBOUNDED = 1, FINITE_OVERFLOW = 2 };
enum { STAT_ADAPTER = 10000, LEVEL_ADAPTER = 250 };

typedef struct { u64 finite; u32 kind; u32 reserved; } Scalar;
typedef struct {
    u32 schema;
    u32 canonical_id;
    Scalar level;
    Scalar ability[4];
    Scalar stamina;
    Scalar experience;
    Scalar condition;
    Scalar special_level;
    Scalar passive_skill_level;
    Scalar training_level[4];
    Scalar pitch_level[28];
    Scalar pitch_speed;
} InfinitePlayer;

/* Order follows the original GetPlayerRec{Bat,Pit}YearData switch tables.
 * Live match counters remain in their original structures. These are the
 * canonical personal career metrics, not an integer sentinel in those fields. */
typedef struct {
    u32 schema;
    u32 canonical_id;
    Scalar batting[13];
    Scalar pitching[13];
    Scalar games;
    Scalar starts;
    Scalar complete_games;
    Scalar shutouts;
    Scalar perfect_games;
    Scalar quality_starts;
    Scalar fielding_errors;
} InfiniteRecords;

#define INF {0, UNBOUNDED, 0}
#include "defender_paths.h"
#include "game_run_paths.h"
static const InfinitePlayer my_state = {
    1, MY_BAT, INF, {INF, INF, INF, INF}, INF, INF, INF, INF, INF,
    {INF, INF, INF, INF},
    {INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF,
     INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF}, INF
};
#define ZERO {0, FINITE, 0}
static const InfiniteRecords my_records = {
    2, MY_BAT,
    {INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF, INF},
    {ZERO, INF, ZERO, ZERO, INF, ZERO, INF, INF, INF, INF, ZERO, ZERO, INF},
    INF, INF, INF, INF, INF, INF, ZERO
};
static const char unbounded_text[] = "\xe2\x88\x9e";
static const char zero_text[] = "0";

API extern int game_mode(void);
API extern u8 *data_manager(void);
API extern u8 *original_get_pitcher(u8 *);
API extern u8 *original_my_team(u8 *);
API extern u8 *original_pitcher_record(u8 *);
API extern void original_entry_init(u8 *, int, int, int);
API extern void original_entry_update(u8 *);
API extern int original_auto_simulate(u8 *);
API extern int original_is_raise_player(u8 *);
API extern u8 *get_reserved_pitcher(u8 *);
API extern u8 *get_reserved_batter(u8 *);
API extern int original_level(u8 *);
API extern void original_set_level(u8 *, int);
API extern void original_add_level(u8 *);
API extern u16 original_pure_status(u8 *, int);
API extern u16 original_status(u8 *, int, u8, u8);
API extern void original_set_status(u8 *, int, int);
API extern void original_add_status(u8 *, int, int);
API extern int original_special_level(u8 *);
API extern void original_set_special_level(u8 *, int);
API extern int original_condition(u8 *);
API extern void original_set_condition(u8 *, int);
API extern void original_add_condition(u8 *, int);
API extern int original_exp(u8 *);
API extern void original_set_exp(u8 *, int);
API extern void original_add_exp(u8 *, int);
API extern int original_level_popup(u8 *);
API extern int original_training_level(u8 *, int);
API extern void original_set_training_level(u8 *, int, int);
API extern int original_pitch_level(u8 *, int);
API extern void original_set_pitch_level(u8 *, int, int);
API extern int original_passive_level(u8 *, int);
API extern void original_set_passive_level(u8 *, int, int, u8);
API extern int original_uniform(u8 *, int, int);
API extern int original_emblem(u8 *, int, int);
API extern void original_load_uniform(u8 *, int, u8, int, u8);
API extern void original_load_equipment(u8 *, int, u8, int, int, u8);
API extern void original_personal_record_table(u8 *, int);
API extern u8 *original_past_pitcher_record(u8 *, int);
API extern int original_year_goal(u8 *, int, int);
API extern int original_record_check_bat(u8 *, int, int, int);
API extern int original_record_check_pit(u8 *, int, int, int);

static u16 read16(const u8 *p) { return (u16)(p[0] | ((u16)p[1] << 8)); }
static void write16(u8 *p, u16 v) { p[0] = (u8)v; p[1] = (u8)(v >> 8); }
static u32 read32(const u8 *p) {
    return (u32)p[0] | ((u32)p[1] << 8) | ((u32)p[2] << 16) | ((u32)p[3] << 24);
}
static void write32(u8 *p, u32 v) {
    for (int i = 0; i < 4; ++i) p[i] = (u8)(v >> (i * 8));
}
static u8 *ptr(u8 *p, unsigned offset) { return *(u8 **)(p + offset); }
static void setptr(u8 *p, unsigned offset, u8 *value) { *(u8 **)(p + offset) = value; }
static int my_id(const u8 *p) {
    if (!p) return 0;
    u16 id = read16(p);
    return id == MY_BAT || id == MY_PIT;
}

/* No operation on an unbounded scalar passes through finite arithmetic. */
API Scalar yagu_add_finite(Scalar a, u64 amount) {
    if (a.kind != FINITE) return a;
    if (~(u64)0 - a.finite < amount) { a.kind = FINITE_OVERFLOW; a.finite = 0; }
    else a.finite += amount;
    return a;
}
API Scalar yagu_consume_finite(Scalar a, u64 amount) {
    if (a.kind != FINITE) return a;
    a.finite = a.finite > amount ? a.finite - amount : 0;
    return a;
}
API int yagu_at_least(Scalar a, u64 finite_requirement) {
    return a.kind == UNBOUNDED || (a.kind == FINITE && a.finite >= finite_requirement);
}
API const InfinitePlayer *yagu_state(const u8 *player) {
    return my_id(player) ? &my_state : (const InfinitePlayer *)0;
}
API const Scalar *yagu_pitch_speed(const u8 *player) {
    return my_id(player) ? &my_state.pitch_speed : (const Scalar *)0;
}
API const InfiniteRecords *yagu_record_state(const u8 *player) {
    return my_id(player) ? &my_records : (const InfiniteRecords *)0;
}
API const Scalar *yagu_record_scalar(const u8 *player, int role, int metric) {
    if (!my_id(player) || metric < 0 || metric >= 13) return (const Scalar *)0;
    if (role == 0) return &my_records.batting[metric];
    if (role == 1) return &my_records.pitching[metric];
    return (const Scalar *)0;
}

static int own_team_index(u8 *dm) {
    if (!dm) return -1;
    u8 *teams = ptr(dm, DM_TEAMS);
    if (!teams) return -1;
    int index = (int)read32(teams + 4);
    return index >= 0 && index < 15 ? index : -1;
}
static u8 *own_team(u8 *dm) {
    int n = own_team_index(dm);
    return n < 0 ? (u8 *)0 : ptr(dm, DM_TEAMS) + 8 + n * 0x3b4;
}
static u8 *my_batter(u8 *team) {
    if (!team || team[3] > 12) return (u8 *)0;
    for (int i = 0; i < team[3]; ++i) {
        u8 *p = team + 0x1a4 + 44 * i;
        if (read16(p) == MY_BAT) return p;
    }
    return (u8 *)0;
}
API const char *yagu_personal_record_text(int role, int metric) {
    int mode = game_mode();
    u8 *dm = data_manager();
    if (!dm || (mode != 3 && mode != TWO_WAY_MODE) || role < 0 || role > 1)
        return (const char *)0;
    if (!ptr(dm, mode == 3 ? DM_PIT_SAVE : DM_BAT_SAVE)) return (const char *)0;
    u8 *team = own_team(dm);
    u8 *player = role == 0 ? my_batter(team) : (u8 *)0;
    if (role == 1 && team && team[2] <= 8) {
        for (int i = 0; i < team[2]; ++i) {
            u8 *p = team + 4 + i * 52;
            if (read16(p) == MY_PIT) { player = p; break; }
        }
    }
    const Scalar *metric_state = yagu_record_scalar(player, role, metric);
    if (!metric_state) return (const char *)0;
    return metric_state->kind == UNBOUNDED ? unbounded_text : zero_text;
}
static int pitcher_index(u8 *team, const u8 *pitcher) {
    if (!team || !pitcher || team[2] > 8) return -1;
    for (int i = 0; i < team[2]; ++i)
        if (team + 4 + 52 * i == pitcher) return i;
    return -1;
}
static u8 *existing_pitcher_record(u8 *dm) {
    int t = own_team_index(dm);
    if (t < 0 || !ptr(dm, DM_BAT_SAVE)) return (u8 *)0;
    u8 *records = ptr(dm, DM_BAT_SAVE) + 0xe8c + t * 256;
    for (int i = 0; i < 8; ++i)
        if (read16(records + i * 32) == MY_PIT) return records + i * 32;
    return (u8 *)0;
}

/* Keep the 44-byte and 52-byte role objects separate. Both live in the SAME
 * saved team; no pointer aliasing, out-of-bounds extension or second career. */
API u8 *yagu_ensure_two_way(u8 *dm) {
    if (!dm || game_mode() != TWO_WAY_MODE || !ptr(dm, DM_BAT_SAVE)) return (u8 *)0;
    u8 *team = own_team(dm);
    u8 *bat = my_batter(team);
    if (!bat || !team[2] || team[2] > 8) return (u8 *)0;
    u8 *pit = (u8 *)0;
    for (int i = 0; i < team[2]; ++i) {
        u8 *p = team + 4 + 52 * i;
        if (read16(p) == MY_PIT) { pit = p; break; }
    }
    if (!pit) {
        /* Retain a structurally valid pitcher template, including pitch types.
         * A fixed-capacity roster cannot be extended past its eight slots. */
        pit = team + 4;
        write16(pit, MY_PIT);
    }
    for (int i = 2; i < 19; ++i) pit[i] = bat[i];
    pit[18] = 0;
    pit[0x20] = bat[0x20];                   /* uniform */
    pit[0x2b] = bat[0x2b];                   /* hair + hair color */
    pit[0x22] = (pit[0x22] & ~12u) | (bat[0x22] & 12u); /* skin */
    pit[0x21] &= 0xf0;                      /* starting-pitcher position */
    pit[0x13] = (u8)pitcher_index(team, pit); /* real roster order */
    pit[0x16] = LEVEL_ADAPTER;
    for (int i = 0; i < 4; ++i) write16(pit + 0x18 + 2 * i, STAT_ADAPTER);
    write32(pit + 0x30, STAT_ADAPTER);
    setptr(dm, DM_BAT_CACHE, bat);
    setptr(dm, DM_PIT_CACHE, pit);

    /* Records use a pre-existing 32-byte pitcher slot in this BAT save.
     * Initialize only if its RFID changes; repeated sync must preserve totals. */
    int t = own_team_index(dm), p = pitcher_index(team, pit);
    u8 *record = existing_pitcher_record(dm);
    if (!record) {
        record = ptr(dm, DM_BAT_SAVE) + 0xe8c + t * 256 + p * 32;
        for (int i = 0; i < 32; ++i) record[i] = 0;
        write16(record, MY_PIT);
    }
    return pit;
}

API u8 *yagu_get_pitcher(u8 *dm) {
    u8 *p = yagu_ensure_two_way(dm);
    return p ? p : original_get_pitcher(dm);
}
API u8 *yagu_my_team(u8 *dm) {
    yagu_ensure_two_way(dm);
    return original_my_team(dm);
}
API u8 *yagu_pitcher_record(u8 *dm) {
    u8 *pit = yagu_ensure_two_way(dm);
    if (!pit) return original_pitcher_record(dm);
    return existing_pitcher_record(dm);
}

static int owns_entry(u8 *dm, u8 *entry) {
    return dm && entry && own_team_index(dm) >= 0
        && (signed char)entry[0x25] == own_team_index(dm);
}
API const char *yagu_live_stat_text(u8 *entry, const u8 *player, int role, int metric) {
    int mode = game_mode();
    u8 *dm = data_manager();
    if (!dm || (mode != 3 && mode != TWO_WAY_MODE) || !owns_entry(dm, entry))
        return (const char *)0;
    if (!ptr(dm, mode == 3 ? DM_PIT_SAVE : DM_BAT_SAVE) || !player)
        return (const char *)0;
    if ((role != 0 && role != 1) || read16(player) != (role ? MY_PIT : MY_BAT))
        return (const char *)0;
    if (metric == -1) return unbounded_text;
    const Scalar *value = yagu_record_scalar(player, role, metric);
    return !value ? (const char *)0 : value->kind == UNBOUNDED ? unbounded_text : zero_text;
}
static void make_starter(u8 *entry, u8 *dm) {
    if (!entry || entry[0x24] != TWO_WAY_MODE || !owns_entry(dm, entry)) return;
    u8 *pit = yagu_ensure_two_way(dm);
    u8 *team = own_team(dm);
    if (!pit) return;
    int p = pitcher_index(team, pit);
    /* Swap, never duplicate lineup indices. */
    for (int i = 0; i < entry[0x26] && i < 14; ++i) {
        if (entry[i] == p) { u8 old = entry[0]; entry[0] = (u8)p; entry[i] = old; break; }
    }
    u8 *bat = my_batter(team);
    if (!bat) return;
    int b = (int)(bat - (team + 0x1a4)) / 44;
    /* A guaranteed first lineup spot. The other eight batters still get outs,
     * so an inning and a nine-inning game can actually finish. */
    for (int i = 0; i < entry[0x27] && i < 22; ++i) {
        if (entry[0xe + i] == b) {
            u8 old = entry[0xe]; entry[0xe] = (u8)b; entry[0xe + i] = old; break;
        }
    }
}
API void yagu_entry_init(u8 *entry, int mode, int team, int arg) {
    u8 *dm = data_manager();
    if (mode == TWO_WAY_MODE) yagu_ensure_two_way(dm);
    original_entry_init(entry, mode, team, arg);
    make_starter(entry, dm);
}
API void yagu_entry_update(u8 *entry) {
    original_entry_update(entry);
    make_starter(entry, data_manager());
}

static int my_turn(u8 *sim) {
    if (!sim || game_mode() != TWO_WAY_MODE) return 0;
    u8 *play = ptr(sim, 0x60);
    u8 *dm = data_manager();
    if (!play || play[1] != TWO_WAY_MODE || !dm) return 0;
    int at = (signed char)play[9], df = (signed char)play[10];
    if (at < 0 || at > 1 || df < 0 || df > 1) return 0;
    u8 *att = ptr(sim, SIM_ENTRIES + at * sizeof(void *));
    u8 *def = ptr(sim, SIM_ENTRIES + df * sizeof(void *));
    if (owns_entry(dm, def)) {
        u8 *pit = get_reserved_pitcher(def);
        if (pit && read16(pit) == MY_PIT) return 1;
    }
    if (owns_entry(dm, att)) {
        u8 *bat = get_reserved_batter(att);
        if (bat && read16(bat) == MY_BAT) return 1;
    }
    return 0;
}
API int yagu_auto_simulate(u8 *sim) {
    return my_turn(sim) ? 0 : original_auto_simulate(sim);
}
API int yagu_is_raise_player(u8 *sim) {
    return my_turn(sim) ? 1 : original_is_raise_player(sim);
}

/* Explicit bounded adapters. They are deliberately not maximum integer values
 * and MUST NOT be described as the semantic ability/level itself. */
API int yagu_level(u8 *p) { return yagu_state(p) ? LEVEL_ADAPTER : original_level(p); }
API void yagu_set_level(u8 *p, int n) {
    if (yagu_state(p)) p[0x16] = LEVEL_ADAPTER; else original_set_level(p, n);
}
API void yagu_add_level(u8 *p) {
    if (yagu_state(p)) p[0x16] = LEVEL_ADAPTER; else original_add_level(p);
}
API u16 yagu_pure_status(u8 *p, int part) {
    return yagu_state(p) && part >= 0 && part < 4 ? STAT_ADAPTER : original_pure_status(p, part);
}
API u16 yagu_status(u8 *p, int part, u8 a, u8 b) {
    return yagu_state(p) && part >= 0 && part < 4 ? STAT_ADAPTER : original_status(p, part, a, b);
}
API void yagu_set_status(u8 *p, int part, int n) {
    if (yagu_state(p) && part >= 0 && part < 4) write16(p + 0x18 + part * 2, STAT_ADAPTER);
    else original_set_status(p, part, n);
}
API void yagu_add_status(u8 *p, int part, int n) {
    if (yagu_state(p) && part >= 0 && part < 4) write16(p + 0x18 + part * 2, STAT_ADAPTER);
    else original_add_status(p, part, n);
}
API int yagu_special_level(u8 *p) {
    return yagu_state(p) ? 10 : original_special_level(p);
}
API void yagu_set_special_level(u8 *p, int n) {
    original_set_special_level(p, yagu_state(p) ? 10 : n);
}

static int own_mode(u8 *mode) {
    int g = game_mode();
    u8 *dm = data_manager();
    if (!dm || (g != 3 && g != TWO_WAY_MODE)) return 0;
    u8 *save = ptr(dm, g == 3 ? DM_PIT_SAVE : DM_BAT_SAVE);
    return save && mode == save + 8;
}

/* A record ID by itself does not establish ownership. Resolve the role actor
 * in the active own-team roster, then its exact record in the same active
 * career save. The PIT and BAT save record arrays have different offsets.
 * No lookup creates records, mutates a save, or consults a second career. */
API const u8 *yagu_current_personal_record(int role) {
    int g = game_mode();
    u8 *dm = data_manager();
    if (!dm || (g != 3 && g != TWO_WAY_MODE) || role < 0 || role > 1)
        return (const u8 *)0;
    u8 *save = ptr(dm, g == 3 ? DM_PIT_SAVE : DM_BAT_SAVE);
    int team_index = own_team_index(dm);
    u8 *team = own_team(dm);
    if (!save || !team || team_index < 0) return (const u8 *)0;
    int owned = role == 0 && my_batter(team) != (u8 *)0;
    if (role == 1 && team[2] <= 8) {
        for (int i = 0; i < team[2]; ++i)
            if (read16(team + 4 + i * 52) == MY_PIT) owned = 1;
    }
    if (!owned) return (const u8 *)0;
    unsigned offset = role ? (g == 3 ? 0xee4 : 0xe8c)
                           : (g == 3 ? 0x1de4 : 0x1d8c);
    unsigned count = role ? 8 : 12;
    unsigned stride = role ? 32 : 24;
    const u8 *records = save + offset + team_index * count * stride;
    for (unsigned i = 0; i < count; ++i) {
        const u8 *record = records + i * stride;
        if (read16(record) == (role ? MY_PIT : MY_BAT)) return record;
    }
    return (const u8 *)0;
}
API const InfiniteRecords *yagu_owned_records(const u8 *record, int role) {
    if (!record || record != yagu_current_personal_record(role))
        return (const InfiniteRecords *)0;
    return &my_records;
}
/* Metrics 0..12 retain the personal-table order. Metric 13 is fielding errors
 * for the batter or quality starts for the pitcher. Metric 14 is appearances;
 * 15..18 are pitcher starts, complete games, shutouts, and perfect games.
 * Pitching outs derive from the same unbounded quantity as innings. */
API const Scalar *yagu_owned_record_metric(const u8 *record, int role, int metric) {
    const InfiniteRecords *s = yagu_owned_records(record, role);
    if (!s || metric < 0) return (const Scalar *)0;
    if (metric < 13) return role ? &s->pitching[metric] : &s->batting[metric];
    if (metric == 13) return role ? &s->quality_starts : &s->fielding_errors;
    if (metric == 14) return &s->games;
    if (!role || metric > 18) return (const Scalar *)0;
    /* Uniform Scalar fields are consecutive. Byte addressing avoids an
     * absolute pointer switch table in Thumb's otherwise PIC code. */
    return (const Scalar *)((const u8 *)&s->starts + (metric - 15) * sizeof(Scalar));
}

/* CBBGEvent::IsCheckVal encodes >= with a nonnegative threshold and strict
 * < abs(threshold) with a negative threshold. Keep the original signed
 * INT_MIN behavior: GsAbs(INT_MIN) remains negative, so a nonnegative record
 * cannot pass that upper bound. There is no large finite infinity sentinel. */
API int yagu_record_event_compare(const Scalar *value, int threshold) {
    if (!value || value->kind == FINITE_OVERFLOW) return -1;
    if (value->kind == UNBOUNDED) return threshold >= 0;
    if (value->kind != FINITE) return -1;
    if (threshold >= 0) return value->finite >= (u32)threshold;
    if (threshold == (-2147483647 - 1)) return 0;
    return value->finite < (u32)(-threshold);
}
API int yagu_record_goal_compare(const Scalar *value, int threshold, int upper_bound) {
    if (!value || value->kind == FINITE_OVERFLOW) return -1;
    if (value->kind == UNBOUNDED) return !upper_bound;
    if (value->kind != FINITE) return -1;
    if (upper_bound) return threshold >= 0 && value->finite <= (u32)threshold;
    return threshold < 0 || value->finite >= (u32)threshold;
}
API int yagu_year_goal(u8 *mode, int goal, int threshold) {
    static const signed char bat_metric[6] = {0, 2, 5, 6, 10, 12};
    static const signed char pit_metric[8] = {0, 4, 6, 7, 8, 11, -1, 13};
    if (own_mode(mode)) {
        int role = game_mode() == 3;
        int metric = -1;
        if (role && goal >= 0 && goal < 8) metric = pit_metric[goal];
        if (!role && goal >= 0 && goal < 6) metric = bat_metric[goal];
        if (metric >= 0) {
            const u8 *record = yagu_current_personal_record(role);
            const Scalar *value = yagu_owned_record_metric(record, role, metric);
            int result = yagu_record_goal_compare(value, threshold, role && (goal == 0 || goal == 5));
            if (result >= 0) return result;
        }
    }
    /* Popularity and the unnamed batting goal retain the original rule. */
    return original_year_goal(mode, goal, threshold);
}
static int personal_event_check(int role, int selector, int period, int threshold) {
    static const signed char bat_metric[14] = {0, 1, 2, 3, 4, 5, 6, -1, 7, 13, 9, 10, 11, 12};
    static const signed char pit_metric[15] = {0, 1, 2, 4, 5, 6, 7, 1, 8, 9, 10, -1, 3, 11, 12};
    /* Both flags are present in shipped event assets. Flag 1 reads cumulative
     * records; flag 2 reads the current season. Match-local flag 4, observed
     * flag 7, unknown flags, team achievements, and economy remain untouched. */
    if (period != 1 && period != 2) return -1;
    int metric = -1;
    if (!role && selector >= 1 && selector <= 14) metric = bat_metric[selector - 1];
    if (role && selector >= 1 && selector <= 15) metric = pit_metric[selector - 1];
    if (metric < 0) return -1;
    const u8 *record = yagu_current_personal_record(role);
    return yagu_record_event_compare(yagu_owned_record_metric(record, role, metric), threshold);
}
API int yagu_record_check_bat(u8 *event, int selector, int period, int threshold) {
    int result = event ? personal_event_check(0, selector, period, threshold) : -1;
    return result >= 0 ? result : original_record_check_bat(event, selector, period, threshold);
}
API int yagu_record_check_pit(u8 *event, int selector, int period, int threshold) {
    int result = event ? personal_event_check(1, selector, period, threshold) : -1;
    return result >= 0 ? result : original_record_check_pit(event, selector, period, threshold);
}

API int yagu_format_ability(char *dst, const u8 *player, u8 *mode, int style) {
    if (!dst) return -1;
    if (player) {
        int g = game_mode();
        u8 *dm = data_manager();
        if (!dm || (g != 3 && g != TWO_WAY_MODE) || !my_id(player)) return -1;
        if (!ptr(dm, g == 3 ? DM_PIT_SAVE : DM_BAT_SAVE)) return -1;
        u8 *team = own_team(dm);
        int owned = team && my_batter(team) == player;
        if (team && team[2] <= 8 && read16(player) == MY_PIT)
            for (int i = 0; i < team[2]; ++i)
                if (player == team + 4 + i * 52) owned = 1;
        if (!owned) return -1;
    } else if (!own_mode(mode)) return -1;
    int n = 0;
    if (style == 1) { dst[0] = 'L'; dst[1] = 'v'; dst[2] = ' '; n = 3; }
    else if (style == 2) { dst[0] = ' '; dst[1] = '/'; dst[2] = ' '; n = 3; }
    else if (style != 0) return -1;
    dst[n] = (char)0xe2; dst[n + 1] = (char)0x88; dst[n + 2] = (char)0x9e; dst[n + 3] = 0;
    return n + 3;
}
API int yagu_condition(u8 *mode) { return own_mode(mode) ? 100 : original_condition(mode); }
API void yagu_set_condition(u8 *mode, int n) {
    original_set_condition(mode, own_mode(mode) ? 100 : n);
}
API void yagu_add_condition(u8 *mode, int n) {
    if (own_mode(mode)) original_set_condition(mode, 100); else original_add_condition(mode, n);
}
API int yagu_exp(u8 *mode) { return own_mode(mode) ? 0 : original_exp(mode); }
API void yagu_set_exp(u8 *mode, int n) {
    if (!own_mode(mode)) original_set_exp(mode, n);
}
API void yagu_add_exp(u8 *mode, int n) {
    if (!own_mode(mode)) original_add_exp(mode, n);
}
API int yagu_level_popup(u8 *mode) { return own_mode(mode) ? 0 : original_level_popup(mode); }
API int yagu_training_level(u8 *mode, int part) {
    if (own_mode(mode) && part >= 0 && part < 4) return 7;
    return original_training_level(mode, part);
}
API void yagu_set_training_level(u8 *mode, int part, int n) {
    original_set_training_level(mode, part, own_mode(mode) && part >= 0 && part < 4 ? 7 : n);
}
API int yagu_pitch_level(u8 *mode, int pitch) {
    if (own_mode(mode) && pitch >= 0 && pitch < 28) return 10;
    return original_pitch_level(mode, pitch);
}
API void yagu_set_pitch_level(u8 *mode, int pitch, int n) {
    original_set_pitch_level(mode, pitch, own_mode(mode) && pitch >= 0 && pitch < 28 ? 10 : n);
}
API int yagu_passive_level(u8 *mode, int skill) {
    int finite = original_passive_level(mode, skill);
    return own_mode(mode) && finite > 0 ? 10 : finite;
}
API void yagu_set_passive_level(u8 *mode, int skill, int n, u8 check) {
    original_set_passive_level(mode, skill, own_mode(mode) && skill >= 0 ? 10 : n, check);
}

/* Art mapping is shared by newly created games and previously edited teams. */
API int yagu_emblem(u8 *mgr, int layer, int team) {
    if (team >= 0 && team < 15 && team != 4) {
        if (layer == 0) return 55 + team;
        if (layer >= 1 && layer <= 3) return -128;
        if (layer == 4) return 0;
    }
    return original_emblem(mgr, layer, team);
}
API int yagu_uniform(u8 *mgr, int layer, int team) {
    const u32 mask = (1u<<3)|(1u<<4)|(1u<<6)|(1u<<9)|(1u<<10)|(1u<<12)
        |(1u<<14)|(1u<<15)|(1u<<16)|(1u<<19)|(1u<<20)|(1u<<22)
        |(1u<<24)|(1u<<25)|(1u<<26)|(1u<<27)|(1u<<29)|(1u<<30);
    if (team >= 0 && team < 15 && team != 4 && layer >= 0 && layer < 32 && (mask & (1u << layer)))
        return 10 + team;
    return original_uniform(mgr, layer, team);
}
API void yagu_load_uniform(u8 *res, int team, u8 is_batter, int costume_level, u8 force) {
    if (team >= 0 && team < 15 && team != 4) costume_level = 0;
    original_load_uniform(res, team, is_batter, costume_level, force);
}
API void yagu_load_equipment(u8 *res, int team, u8 is_batter, int kind, int level, u8 force) {
    if (team >= 0 && team < 15 && team != 4 && kind == 0) level = 0;
    original_load_equipment(res, team, is_batter, kind, level, force);
}
API const char *yagu_defender_path(const char *const *original_table, int index) {
    int offset = index - 0xd08;
    if (offset >= 80 && offset < 200) {
        int team = offset / 8 - 10;
        int part = offset % 8;
        if (team != 4 && part < 6) return defender_paths[team][part];
    }
    return original_table[index];
}

/* These two legacy GameRun loaders consume fixed original path tables rather
 * than the dynamic CcPlayerRes paths. Resolve clothing by the observed actor
 * team and loop part before touching the extended palette's table index. */
API const char *yagu_bat_clothing_path(const char *const *original_table, int index, int team, int part) {
    if (team >= 0 && team < 15 && team != 4 && part >= 0 && part < 26) {
        int slot = bat_clothing_slot[part];
        if (slot >= 0) return bat_clothing_paths[team][slot];
    }
    return original_table[index];
}
API const char *yagu_pit_clothing_path(const char *const *original_table, int index, int team, int part) {
    if (team >= 0 && team < 15 && team != 4 && part >= 0 && part < 25) {
        int slot = pit_clothing_slot[part];
        if (slot >= 0) return pit_clothing_paths[team][slot];
    }
    return original_table[index];
}

API int yagu_format_pitch_speed(char *dst, u8 *game, int english) {
    if (!dst || !game) return -1;
    int mode = game_mode();
    if (mode != 3 && mode != TWO_WAY_MODE) return -1;
    u8 *dm = data_manager();
    u8 *entry = ptr(game, __SIZEOF_POINTER__ == 8 ? 0x418 : 0x2cc);
    if (!owns_entry(dm, entry)) return -1;
    u8 *pitcher = get_reserved_pitcher(entry);
    if (!pitcher || read16(pitcher) != MY_PIT) return -1;
    const Scalar *speed = yagu_pitch_speed(pitcher);
    if (!speed || speed->kind != UNBOUNDED) return -1;
    /* Preserve the original font markup and locale-specific unit spelling.
     * No coordinate, velocity, animation or live score field receives Inf. */
    const char *text = english ? "!S14!xFFFFFFFF\xe2\x88\x9e mph" : "!S14!xFFFFFFFF\xe2\x88\x9e km";
    int length = 0;
    do { dst[length] = text[length]; } while (text[length++]);
    return length - 1;
}

static int two_way_record_view(void) {
    if (game_mode() != TWO_WAY_MODE) return 0;
    return yagu_ensure_two_way(data_manager()) != (u8 *)0;
}
API void yagu_record_scroll(u8 *ui, int original_page) {
    if (ui && two_way_record_view()) {
        int page = (int)read32(ui + (__SIZEOF_POINTER__ == 8 ? 0x70 : 0x40));
        int direction = (int)read32(ui + (__SIZEOF_POINTER__ == 8 ? 0x68 : 0x38));
        if (page < 0 || page >= 6) page = 0;
        if (direction == 1) original_page = page == 5 ? 0 : page + 1;
        else if (direction == 2) original_page = page == 0 ? 5 : page - 1;
    }
    original_personal_record_table(ui, original_page);
}
API int yagu_record_is_batter(u8 *ui, int *local_page) {
    if (!ui || !two_way_record_view()) return -1;
    int page = (int)read32(ui + (__SIZEOF_POINTER__ == 8 ? 0x70 : 0x40));
    if (page < 0 || page >= 6) return -1;
    if (local_page) *local_page = page >= 3 ? page - 3 : page;
    return page < 3;
}
API int yagu_record_page(u8 *ui) {
    int page = (int)read32(ui + (__SIZEOF_POINTER__ == 8 ? 0x70 : 0x40));
    if (two_way_record_view() && page >= 3 && page < 6) return page - 3;
    return page;
}
API u8 *yagu_personal_past_pitcher_record(u8 *dm, int year) {
    if (game_mode() == TWO_WAY_MODE) {
        /* The two-way career has no separate PIT save. The personal view
         * projects its immutable Unbounded history from its stable own record;
         * it does not manufacture finite historic games or alter team history. */
        if (year < 0 || year > 9 || !yagu_ensure_two_way(dm)) return (u8 *)0;
        return existing_pitcher_record(dm);
    }
    return original_past_pitcher_record(dm, year);
}
