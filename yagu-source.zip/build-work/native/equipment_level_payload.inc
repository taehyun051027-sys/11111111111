/* The four equipment-enhancement levels are semantic quantities. Original
 * Option bytes remain signed-byte table adapters in0..99. They are not infinity.
 * This fragment requires the schema append in equipment_level_policy.py. */
enum { EQUIPMENT_LEVEL_ADAPTER = 99 };
static const char equipment_level_text[] = "Lv. \xe2\x88\x9e";
static const char equipment_short_level_text[] = "Lv \xe2\x88\x9e";

API extern int original_equip_level(u8 *, u8, int);
API extern void original_add_equip_level(u8 *, u8, int, int);
API extern int original_equip_bonus(int, u8);
API extern int original_equip_success_per(u8 *, int);
API extern int equipment_sprint(char *, const char *, ...);
API extern int equipment_get_val(u8 *, int, int);
API extern u8 *equipment_resource_manager(void);
API extern const char *equipment_common_string(u8 *, int);
API extern void equipment_max_popup(const char *, int, int, u8);
API extern void original_equipment_process(u8 *);
API extern void original_equipment_lunch_buy(u8 *);

static u8 *equipment_option(u8 *dm) {
    return dm ? ptr(dm, sizeof(void *) == 8 ? 0x518 : 0x4e0) : (u8 *)0;
}

static u8 *equipment_roster_actor(u8 *dm, int is_batter) {
    if (!dm || (is_batter != 0 && is_batter != 1)) return (u8 *)0;
    u8 *team = own_team(dm);
    if (!team || team[2] > 8 || team[3] > 12) return (u8 *)0;
    if (is_batter) return my_batter(team);
    for (int i = 0; i < team[2]; ++i) {
        u8 *p = team + 4 + 52 * i;
        if (read16(p) == MY_PIT) return p;
    }
    return (u8 *)0;
}

API const Scalar *yagu_equipment_scalar(const u8 *option, int is_batter, int part) {
    if (!option || part < 0 || part >= 4 || (is_batter != 0 && is_batter != 1))
        return (const Scalar *)0;
    int mode = game_mode();
    u8 *dm = data_manager();
    if (!dm || (mode != 3 && mode != TWO_WAY_MODE)
        || option != equipment_option(dm)
        || !ptr(dm, mode == 3 ? DM_PIT_SAVE : DM_BAT_SAVE)
        || (mode == 3 && is_batter)) return (const Scalar *)0;
    if (mode == TWO_WAY_MODE && !equipment_roster_actor(dm, 1))
        return (const Scalar *)0;
    if (!equipment_roster_actor(dm, is_batter)) return (const Scalar *)0;
    return &my_state.equipment_level[part];
}

/* Menu/profiles pass the actual displayed actor. A mere copied RFID is not
 * enough. In the entry menu a saved inactive career can be displayed, while a
 * paired pitcher in the active two-way career belongs to the BAT save. */
API const Scalar *yagu_equipment_player_scalar(const u8 *player, int part) {
    if (!player || part < 0 || part >= 4) return (const Scalar *)0;
    int is_batter = read16(player) == MY_BAT ? 1 : read16(player) == MY_PIT ? 0 : -1;
    if (is_batter < 0) return (const Scalar *)0;
    u8 *dm = data_manager();
    if (!dm || player != equipment_roster_actor(dm, is_batter)) return (const Scalar *)0;
    if (yagu_equipment_scalar(equipment_option(dm), is_batter, part))
        return &my_state.equipment_level[part];
    if (!ptr(dm, is_batter ? DM_BAT_SAVE : DM_PIT_SAVE)
        || player != ptr(dm, is_batter ? DM_BAT_CACHE : DM_PIT_CACHE))
        return (const Scalar *)0;
    return &my_state.equipment_level[part];
}

API const char *yagu_equipment_menu_text(const u8 *player, int is_batter) {
    if (!player || (is_batter != 0 && is_batter != 1)
        || read16(player) != (is_batter ? MY_BAT : MY_PIT)) return (const char *)0;
    const Scalar *value = yagu_equipment_player_scalar(player, 0);
    return value && value->kind == UNBOUNDED ? equipment_level_text : (const char *)0;
}

API const char *yagu_equipment_player_text(const u8 *player) {
    const Scalar *value = yagu_equipment_player_scalar(player, 0);
    return value && value->kind == UNBOUNDED ? unbounded_text : (const char *)0;
}

API const Scalar *yagu_equipment_current(int part) {
    int mode = game_mode();
    if (mode != 3 && mode != TWO_WAY_MODE) return (const Scalar *)0;
    return yagu_equipment_scalar(equipment_option(data_manager()), mode == TWO_WAY_MODE, part);
}

API const char *yagu_equipment_ui_text(int part, int level_prefix) {
    const Scalar *value = yagu_equipment_current(part);
    if (!value || value->kind != UNBOUNDED) return (const char *)0;
    return level_prefix ? equipment_short_level_text : unbounded_text;
}

API int yagu_equipment_no_upgrade(int part) {
    const Scalar *value = yagu_equipment_current(part);
    if (!value) return -1;
    return value->kind == UNBOUNDED;
}

API int yagu_equipment_at_least(const u8 *option, int is_batter, int part, u64 threshold) {
    const Scalar *value = yagu_equipment_scalar(option, is_batter, part);
    return value ? yagu_at_least(*value, threshold) : -1;
}

API int yagu_equipment_meets_goal(const u8 *option, int is_batter, int part, int displayed_level) {
    const Scalar *value = yagu_equipment_scalar(option, is_batter, part);
    if (!value) return -1;
    if (value->kind == UNBOUNDED || displayed_level <= 1) return 1;
    return value->finite >= (u64)(displayed_level - 1);
}

API int yagu_equip_level(u8 *option, u8 is_batter, int part) {
    const Scalar *value = yagu_equipment_scalar(option, is_batter, part);
    return value && value->kind == UNBOUNDED ? EQUIPMENT_LEVEL_ADAPTER
                                           : original_equip_level(option, is_batter, part);
}

API void yagu_add_equip_level(u8 *option, u8 is_batter, int part, int delta) {
    const Scalar *value = yagu_equipment_scalar(option, is_batter, part);
    if (value && value->kind == UNBOUNDED) {
        /* Infinite +/- finite is unchanged. Only the original bounded storage
         * adapter is synchronized, using its original clamp/store operation. */
        int old = original_equip_level(option, is_batter, part);
        original_add_equip_level(option, is_batter, part, EQUIPMENT_LEVEL_ADAPTER - old);
        return;
    }
    original_add_equip_level(option, is_batter, part, delta);
}

API int yagu_equip_bonus(int part, u8 next_level) {
    const Scalar *value = yagu_equipment_current(part);
    /* Both current and hypothetical next infinity use the last real table row.
     * The original function still reads the original table; row100 is avoided. */
    return original_equip_bonus(part, value && value->kind == UNBOUNDED ? 0 : next_level);
}

API int yagu_equip_success_per(u8 *ui, int part) {
    const Scalar *value = yagu_equipment_current(part);
    /* There is no higher finite enhancement to purchase. This safe probability
     * projection is only for legacy preview calls; the typed MAX decision keeps
     * those owned purchases out of the original debit/upgrade path. */
    return value && value->kind == UNBOUNDED ? 100 : original_equip_success_per(ui, part);
}

API int yagu_equipment_table_value(u8 *loader, int column, int row, int part) {
    const Scalar *value = yagu_equipment_current(part);
    if (value && value->kind == UNBOUNDED && row == 100) row = EQUIPMENT_LEVEL_ADAPTER;
    return equipment_get_val(loader, column, row);
}

static void equipment_show_max(void) {
    u8 *resources = equipment_resource_manager();
    if (resources) equipment_max_popup(equipment_common_string(resources, 546), 2, 1, 1);
}

API void yagu_equipment_process(u8 *ui) {
    int part = ui ? (int)read32(ui + (sizeof(void *) == 8 ? 0xb8 : 0x6c)) : -1;
    if (yagu_equipment_no_upgrade(part) == 1) { equipment_show_max(); return; }
    original_equipment_process(ui);
}

API void yagu_equipment_lunch_buy(u8 *ui) {
    int part = ui ? (int)read32(ui + (sizeof(void *) == 8 ? 0x9c : 0x58)) : -1;
    if (yagu_equipment_no_upgrade(part) == 1) {
        equipment_show_max();
        /* Original insufficient-Star path restores this same input flag. */
        ui[sizeof(void *) == 8 ? 0xa6 : 0x62] = 1;
        return;
    }
    original_equipment_lunch_buy(ui);
}

/* These callers contain one decimal enhancement quantity, with an optional
 * already-localized ability name. Retain the original format and renderer,
 * replacing its one %d conversion only. Unexpected formats fall back. */
API int yagu_format_equipment(char *dest, const char *format,
                              const char *label, int part) {
    const Scalar *value = yagu_equipment_current(part);
    if (!dest || !format || !value || value->kind != UNBOUNDED) return -1;
    char translated[256];
    int decimal = 0, strings = 0, previous_string = 0;
    int i;
    for (i = 0; i < 255 && format[i]; ++i) {
        translated[i] = format[i];
        if (format[i] != '%') continue;
        if (i >= 254 || !format[i + 1]) return -1;
        ++i;
        char conversion = format[i];
        if (conversion == '%') translated[i] = conversion;
        else if (conversion == 's') {
            if (decimal || ++strings > 1) return -1;
            previous_string = 1;
            translated[i] = conversion;
        } else if (conversion == 'd') {
            if (++decimal > 1) return -1;
            translated[i] = 's';
        } else return -1;
    }
    if (format[i] || decimal != 1 || (previous_string && !label)) return -1;
    translated[i] = 0;
    return previous_string ? equipment_sprint(dest, translated, label, unbounded_text)
                           : equipment_sprint(dest, translated, unbounded_text);
}
