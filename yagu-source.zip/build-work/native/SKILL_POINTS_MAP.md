# Owned skill points: typed stock, real learning, original UI

## Contract

Skill points are a separate immutable `Scalar { finite=0, kind=UNBOUNDED }`, not an added player-level field. The active career must have its current save, valid team index/counts, and actual owned My actor. Detached mode pointers, absent saves/teams/manager, noncareer contexts and ordinary players do not receive the policy.

The original `mode+0x240` u16 remains saved finite data. The owned getter returns 10,000 only as a safe legacy adapter. **Four real affordability comparisons consult the tagged kind**, so even a signed finite cost above 10,000 does not exhaust this stock. Owned Set/Add absorbs finite rewards/spending; it does not store an infinity sentinel. Other modes execute the original getter/setter/add, including the original 0..60,000 clamp.

The distinct `mode+0x242` **used SP ledger remains finite**. The original learn/upgrade confirmation routines still debit SP, add used SP, set a learned passive skill bit, and increment the bounded passive or pitch-level storage. Original storage, item prices, registry/disk calls, skill slot limits and network/store/receipt code are retained.

## Two-way pitch menu

Five original `CBBGSelectBallTypeUI` calls explicitly request PIT career3. In canonical two-way career4 these exact callers receive the active BAT save's RaiseMode only when both owned role actors are present. Their consumed fields are common-layout SP at +0x240 and pitch-type levels at +0x3f0 (bounded0..10). The global `GetRaiseMode(3)`, inactive saves and all other callers are unchanged.

| Caller | ARM64 | Thumb |
|---|---:|---:|
| Learn/upgrade commit | 0x52cee0 | 0x33fc6c |
| Page header | 0x52ef7c | 0x34132a |
| Details | 0x52f058 | 0x3413be |
| Alternate details | 0x52f5c8 | 0x3417f0 |
| Touch decisions | 0x52fd74 | 0x341da6 |

## Actual affordability decisions

| Original decision | ARM64 comparison | Thumb comparison |
|---|---:|---:|
| Passive learn | 0x4f1cd0 | 0x318cc0 |
| Passive upgrade | 0x4f2120 | 0x318f96 |
| Pitch learn | 0x5300bc | 0x341fc6 |
| Pitch upgrade | 0x530140 | 0x342016 |

Unowned execution replays the exact compare and branch. Both success and fallback preserve GPR/SIMD state, stack and the original comparison result flags; the semantic branch selection is separate from the finite projection.

## Existing display cells

Nine available-SP number-widget callers are merged into the already-owned award `GetChangeFont` hook (ARM64 0x5950d0, Thumb 0x3849b6). No second patch is applied at that shared site. Each caller is selected by its exact saved return address and local mode pointer. The original raw font styling, color, size, rectangle, tag and number-widget layout remain. Costs are not replaced.

| Available SP cell | ARM64 original number call | Thumb original number call |
|---|---:|---:|
| Passive after learning | 0x4ee47c | 0x3165e4 |
| Passive after upgrade | 0x4ee61c | 0x3166f8 |
| Passive page | 0x4ef264 | 0x316f82 |
| Passive table | 0x4efda8 | 0x3177d6 |
| Pitch page | 0x52f004 | 0x34138a |
| Pitch detail | 0x52d6c4 | 0x3401aa |
| Normal training | 0x50d3c0 | 0x32b1bc |
| Skill training | 0x50deb8 | 0x32ba12 |
| Spring camp | 0x55caa4 | 0x35ee70 |

## Integration

Apply these idempotent pure transformations, then build the ordinary full pipeline:

```python
from pathlib import Path
from skill_points_policy import integrate_source, integrate_builder, integrate_award_source
root = Path('build-work/native')
for filename, transform in (
    ('yagu_payload.c', integrate_source),
    ('payload_builder.py', integrate_builder),
    ('award_record_ui.py', integrate_award_source),
):
    path = root / filename
    path.write_text(transform(path.read_text()))
```

New dependencies: `skill_points_payload.inc`, `skill_points_hooks.py`, `skill_points_policy.py`. The verifier is `verify_skill_points.py`; its source manifest and final JSON identify the exact staged C and include hashes. This delta does not change the current player schema4/51 or record schema4/40.

## Evidence and limits

`verify_skill_points.py` executes the compiled policy at nonzero ASLR on both ABIs, the original popup dispatch and passive/pitch learning stores, used-SP clamps, exact comparison branches, nine text caller scopes, invalid ownership cases, save reload and shared award-hook coexistence. Cost-table lookup, popup selection, registry/disk and graphics are explicit service boundaries. Instruction tests do not establish Android visual rendering or a completed Android skill purchase.

Training/camp post-animation increment labels and other finite resources are not claimed covered by this nine-cell update. This patch addresses SP stock and the enumerated existing UI/decision paths; it is not a claim that every numeric menu in the game has been reviewed.
