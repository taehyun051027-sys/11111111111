"""Existing career condition, passive-skill and pitch-level text consumers.

These narrowly replace only the numeric text after an owned-career predicate.
Rendering, font styling, boxes, menu access and original finite fallback remain
in the original functions. This does not claim coverage of every old UI menu.
"""
from gameplay_hooks import A64_SAVE, A64_RESTORE, T32_SAVE, T32_RESTORE

SITES = {
    'arm64-v8a': (
        ('career_condition', 0x3782d8, '5ed40e94', 0, 'mov x1, xzr\nldr x2, [sp, #0xf8]'),
        ('equipped_passive_level', 0x4cfc30, '08760994', 1, 'ldr x1, [sp, #0x330]\nmov x2, xzr'),
        ('selected_pitch_level', 0x52d848, '02ff0794', 1, 'mov x1, xzr\nldr x2, [sp, #0x228]'),
        ('rest_capacity_initial', 0x5016ec, '59af0894', 2, 'mov x1, xzr\nldur x2, [x29, #-0xa8]'),
        ('rest_capacity_animated', 0x502208, '92ac0894', 2, 'mov x1, xzr\nldr x2, [sp, #0x290]'),
    ),
    'armeabi-v7a': (
        ('career_condition', 0x220f02, '4ef296ef', 0, 'movs r1, #0\nldr r2, [sp, #0x88]'),
        ('equipped_passive_level', 0x30182a, '6ef102eb', 1, 'ldr r1, [r7, #0x10]\nmovs r2, #0'),
        ('selected_pitch_level', 0x3402a4, '2ff1c4ed', 1, 'movs r1, #0\nldr r2, [sp, #0x128]'),
        ('rest_capacity_initial', 0x322f76, '4cf15cef', 2, 'movs r1, #0\nldr r2, [sp, #0x12c]'),
        ('rest_capacity_animated', 0x32375c, '4cf168eb', 2, 'movs r1, #0\nldr r2, [sp, #0x188]'),
    ),
}


def add_career_ability_ui_hooks(b, symbols):
    formatter = symbols['yagu_format_ability']
    original = b.sym('MC_knlSprintk')
    exports = {}
    for label, site, expected, style, arguments in SITES[b.abi]:
        if b.is64:
            source = f'''{A64_SAVE}
{arguments}
mov w3, #{style}
bl #{formatter}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
original:
{A64_RESTORE}
b #{original}'''
        else:
            source = f'''{T32_SAVE}
{arguments}
movs r3, #{style}
bl #{formatter}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
original:
{T32_RESTORE}
b.w #{original}'''
        hook = b.append_asm('Owned career ability text: ' + label, source)
        b.patch(site, b.branch(site, hook, True), 'Render unbounded ' + label, expected)
        exports[label] = {'site': site, 'hook': hook, 'style': style}
    return exports


def add_rest_current_condition_hook(b, symbols):
    """Single shared-number patch for rest, EntryList and StrengthAll cells."""
    from roster_number_ui import roster_number_branches
    from equipment_level_ui import equipment_number_branches
    formatter, original = symbols['yagu_format_ability'], b.sym('MC_knlSprintk')
    roster_gates, roster_body = roster_number_branches(b, symbols['yagu_state'])
    if 'yagu_equipment_player_text' in symbols:
        equipment_gates, equipment_body = equipment_number_branches(b, symbols)
        roster_gates = roster_gates.removesuffix('b original') + 'b equipment_gate\n' + equipment_gates
        roster_body += '\n' + equipment_body
    if b.is64:
        site, expected = 0x595094, 'ef600694'
        callers = (0x501698, 0x5021d8)
        select = '''ldr x8, [x29, #8]
adrp x9, #0x501000
add x9, x9, #0x698
cmp x8, x9
b.eq initial
adrp x9, #0x502000
add x9, x9, #0x1d8
cmp x8, x9
b.ne roster_gate
ldr x2, [x29]
sub x2, x2, #0x140
ldr x2, [x2]
b selected
initial:
ldr x2, [x29]
ldur x2, [x2, #-0xa8]
selected:
mov x1, xzr
mov w3, #0'''
        source = f'''{A64_SAVE}
{select}
bl #{formatter}
tbnz w0, #31, original
str x0, [sp]
{A64_RESTORE}
ret
{roster_gates}
{roster_body}
original:
{A64_RESTORE}
b #{original}'''
    else:
        site, expected = 0x384978, 'ebf05aea'
        callers = (0x322f43, 0x32373d)
        first = (callers[0] - (site + 5)) & 0xffffffff
        second = (callers[1] - (site + 5)) & 0xffffffff
        select = f'''ldr r3, [r7, #4]
movw r2, #{first & 0xffff}
movt r2, #{first >> 16}
add r2, lr
cmp r3, r2
beq initial
movw r2, #{second & 0xffff}
movt r2, #{second >> 16}
add r2, lr
cmp r3, r2
bne roster_gate
ldr r2, [r7]
ldr r2, [r2, #-0xf8]
b selected
initial:
ldr r2, [r7]
ldr r2, [r2, #-0x8c]
selected:
movs r1, #0
movs r3, #0'''
        source = f'''{T32_SAVE}
{select}
bl #{formatter}
cmp r0, #0
blt original
str r0, [sp]
{T32_RESTORE}
bx lr
{roster_gates}
{roster_body}
original:
{T32_RESTORE}
b.w #{original}'''
    hook = b.append_asm('Rest condition number: two verified callers only', source)
    b.patch(site, b.branch(site, hook, True), 'Render unbounded current condition at rest menu', expected)
    return {'site': site, 'hook': hook, 'callers': callers}
