"""Exercise original starting/reserved-pitcher and BAT-save record methods.

The engine's roster leaf and PLT dispatch are modeled at their ABI boundaries;
the original GetCurPitcher, GetRsvPitcher, initializion and GetPitcherRec execute.
This is a narrow native integration check, not a full game setup test.
"""
import json
import struct
from pathlib import Path
from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETPIT
from verify_gameplay_hooks import Case, ROOT, HEAP, MGR, PITM, RAISE, SP, STOP

TEAM = HEAP + 0x20000
SAVE = HEAP + 0x40000
RECORD = SAVE + 0xe8c + 4 * 256


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    c = Case(b)
    # No legitimate instruction in these selected functions accesses low pages.
    # A mistaken PIT-save + constant read must fault, not see zero-filled memory.
    c.uc.mem_unmap(0, 0x10000)
    c.ptr(MGR + (0x528 if b.is64 else 0x4e8), SAVE)
    c.ptr(MGR + (0x520 if b.is64 else 0x4e4), 0)
    c.uc.mem_write(RAISE + 4, struct.pack('<i', 4))
    c.uc.mem_write(PITM, bytes(range(14)))
    c.uc.mem_write(PITM + 0x25, b'\x04')
    c.uc.mem_write(PITM + 0x28, b'\xff')
    for index in range(8):
        c.uc.mem_write(TEAM + 4 + index * 52, struct.pack('<H', 400 + index))
        c.uc.mem_write(RECORD + index * 32, struct.pack('<H', 400 + index) + bytes(30))
    c.uc.mem_write(TEAM + 4, struct.pack('<H', 1100))
    c.uc.mem_write(RECORD, struct.pack('<H', 1100))
    c.uc.mem_write(RECORD + 8, struct.pack('<I', 7654321))
    c.callbacks.pop(b.sym(GETPIT))
    sites = {'get_pitcher': 0x7313b0, 'get_current': 0x730b20,
             'get_ext': 0x7316f0, 'get_mode': 0x72d850,
             'get_id': 0x72e960, 'get_record_id': 0x72ed00,
             'is_raise': 0x72e560} if b.is64 else {
             'get_pitcher': 0x473cf0, 'get_current': 0x473460,
             'get_ext': 0x474030, 'get_mode': 0x470230,
             'get_id': 0x471350, 'get_record_id': 0x4716f0,
             'is_raise': 0x470f50}

    def get_pitcher():
        assert c.r(0) == PITM
        index = c.r(1)
        assert index < 8
        c.ret(TEAM + 4 + 52 * index)
    def get_ext():
        assert c.r(0) == PITM
        index = c.r(1)
        assert index < 7
        slot = c.uc.mem_read(PITM + index + 1, 1)[0]
        c.ret(TEAM + 4 + 52 * slot)
    def get_id():
        c.ret(struct.unpack('<H', c.uc.mem_read(c.r(0), 2))[0])
    def current_dispatch():
        c.uc.reg_write(c.pc, b.sym(GETPIT) | (0 if b.is64 else 1))
    c.callbacks[sites['get_pitcher']] = get_pitcher
    c.callbacks[sites['get_current']] = current_dispatch
    c.callbacks[sites['get_ext']] = get_ext
    c.callbacks[sites['get_mode']] = lambda: c.ret(4)
    c.callbacks[sites['get_id']] = get_id
    c.callbacks[sites['get_record_id']] = get_id
    c.callbacks[sites['is_raise']] = lambda: c.ret(1)

    def call(name, *args):
        c.stopped = None
        c.uc.reg_write(c.sp, SP)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        for index, arg in enumerate(args):
            c.r(index, arg)
        c.run(b.sym(name))
        assert c.uc.reg_read(c.sp) == SP
        return c.r(0)

    checks = []
    call('CBBGEntryMgr::initializion()', PITM)
    assert c.uc.mem_read(PITM + 0x294, 4) == bytes(4)
    assert c.uc.mem_read(PITM + 0x28, 1) == b'\xff'
    checks.append('original derived initializer clears reservation flags while +0x28 stays -1')
    assert call(GETPIT, PITM) == TEAM + 4
    assert call('CBBGEntryMgr::GetRsvPitcher()', PITM) == TEAM + 4
    checks.append('original current and reserved getters both select entry[0] without activation')
    call('CBBGEntryMgr::RsvChangePitcher(int, unsigned char)', PITM, 0, 0)
    assert c.uc.mem_read(PITM + 0x294, 1) == b'\0'
    assert call('CBBGEntryMgr::GetRsvPitcher()', PITM) == TEAM + 4
    checks.append('owned-My substitution rejection leaves already active pitcher available')
    c.uc.mem_write(PITM + 0x294, b'\x01')
    c.uc.mem_write(PITM + 0x296, b'\x01')
    assert call('CBBGEntryMgr::GetRsvPitcher()', PITM) == TEAM + 4 + 52
    c.uc.mem_write(PITM + 0x294, b'\0')
    checks.append('original pending-reservation branch uses +0x296 extended index')

    # Match the effect of a pregame physical move, while the record remains
    # keyed by RFID at its original slot. The real lookup must find that slot.
    c.uc.mem_write(TEAM + 4, struct.pack('<H', 401))
    c.uc.mem_write(TEAM + 4 + 3 * 52, struct.pack('<H', 1100))
    c.uc.mem_write(PITM, b'\x03')
    assert call('CBBGEntryMgr::GetRsvPitcher()', PITM) == TEAM + 4 + 3 * 52
    found = call('CBBGDataMgr::GetPitcherRec(int, CBBGPlayerData*, bool)',
                 MGR, 4, TEAM + 4 + 3 * 52, 0)
    assert found == RECORD
    assert struct.unpack('<I', c.uc.mem_read(found + 8, 4))[0] == 7654321
    checks.append('mode4 original record lookup follows RFID after physical pitcher movement')
    checks.append('BAT-save record path succeeds with null PIT-save and unmapped null-offset pages')
    assert call('CBBGDataMgr::GetPitcherRec(int, CBBGPlayerData*, bool)',
                MGR, 4, TEAM + 4 + 3 * 52, 1) == 0
    checks.append('original skip-My boolean excludes My record only when explicitly true')
    return {'abi': abi, 'passed': len(checks), 'checks': checks,
            'source_sha256': b.sha, 'android_runtime_verified': False,
            'limits': ['Pregame whole state machine, record serialization and full game not executed.',
                       'Roster leaf and selected PLT dispatch are mocked.']}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    Path(__file__).with_name('starting_pitcher_verification.json').write_text(
        json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))
