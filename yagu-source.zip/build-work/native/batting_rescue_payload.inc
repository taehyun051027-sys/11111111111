/* Input-delay protection at the original contact gate. This invokes the
 * original swing and statistics methods, then lets the original caller emit
 * event0x6aa and set its once flag. It never writes score/out/record results. */
API extern int original_rescue_battable(u8 *);
API extern int original_rescue_swing(u8 *, int);
API extern int original_rescue_swing_position(u8 *);
API extern void original_rescue_at_swing(u8 *);
API extern u8 *original_rescue_current_batter(u8 *);
API extern u8 *original_rescue_play_data(void);

API int yagu_rescue_batting(u8 *batter, u8 *game, int frame, int contact) {
    int original = original_rescue_battable(batter);
    int g = game_mode();
    u8 *dm = data_manager();
    if (!batter || !game || !dm || (g != 3 && g != TWO_WAY_MODE)
            || frame < 0 || contact < 0 || frame < contact) return original;
    u8 *save = ptr(dm, g == 3 ? DM_PIT_SAVE : DM_BAT_SAVE);
    if (!save || !own_mode(save + 8)) return original;
    unsigned bat_object = __SIZEOF_POINTER__ == 8 ? 0x4e0 : 0x334;
    unsigned once_flag = __SIZEOF_POINTER__ == 8 ? 0x531 : 0x379;
    if (ptr(game, bat_object) != batter || game[once_flag])
        return original;
    u8 *entry = ptr(game, __SIZEOF_POINTER__ == 8 ? 0x410 : 0x2c8);
    if (!owns_entry(dm, entry)) return original;
    u8 *actor = original_rescue_current_batter(entry);
    if (!actor || actor != owned_role_player(dm, 0)) return original;
    /* A received manual swing can arrive between animation samples. It still
     * reaches the normal contact arm once the ball reaches its contact frame;
     * its original input handler already called AtSwing. */
    if (batter[0x12]) return 0;
    u8 *play = original_rescue_play_data();
    if (!play || ((signed char)play[4] != 2 && (signed char)play[5] != 3))
        return original;
    u8 *statistics = ptr(game, __SIZEOF_POINTER__ == 8 ? 0x430 : 0x2d8);
    if (!statistics) return original;
    int position = original_rescue_swing_position(game);
    if (!original_rescue_swing(batter, position)) return original;
    original_rescue_at_swing(statistics);
    /* IsBattable is an integer distance: zero takes the normal contact arm.
     * The existing owned timing hook then selects the normal batting event. */
    return 0;
}
