"""Validate six-page navigation and bounded legacy layout/history consumers."""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE
from payload_builder import add_payload, BINDINGS
from infinity_ui import add_infinity_ui_hooks
from defender_hooks import add_defender_hooks
from game_run_uniform_hooks import add_game_run_uniform_hooks
from personal_record_ui import add_personal_record_ui_hooks
from pitch_speed_ui import add_pitch_speed_ui_hooks
from personal_record_navigation import add_personal_record_navigation_hooks
from verify_relocation import prepare_case, RECORD
from verify_gameplay_hooks import ROOT, HEAP, SP, STOP, MGR
import unicorn.arm64_const as arm64
import unicorn.arm_const as arm

WORK = Path(__file__).resolve().parent
UI = HEAP + 0xe000


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'record_navigation_build' / abi)
    symbols = payload['symbols']
    add_infinity_ui_hooks(b, symbols['yagu_state'])
    add_defender_hooks(b, symbols['yagu_defender_path'])
    add_game_run_uniform_hooks(b, symbols)
    add_personal_record_ui_hooks(b, symbols)
    add_pitch_speed_ui_hooks(b, symbols)
    nav = add_personal_record_navigation_hooks(b, symbols)
    slide = 0x7765432000 if b.is64 else 0x96543000
    page_offset = 0x70 if b.is64 else 0x40
    direction_offset = 0x68 if b.is64 else 0x38
    c = prepare_case(b, slide)
    observed = []

    def renderer():
        assert c.r(0) == UI
        observed.append(c.r(1))
        c.uc.mem_write(UI + page_offset, struct.pack('<I', c.r(1)))
        c.ret(0)
    c.callbacks[b.sym(BINDINGS['original_personal_record_table']) + slide] = renderer

    def run(address, args, continuation=STOP):
        c.stopped = None
        c.stops = {continuation}
        c.uc.reg_write(c.sp, SP)
        c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
        for index, value in enumerate(args):
            c.r(index, value & ((1 << (64 if b.is64 else 32)) - 1))
        c.run_relative(address)
        assert c.stopped == continuation and c.uc.reg_read(c.sp) == SP

    scroll_cases = 0
    for site in nav['scroll_calls']:
        for page in range(6):
            for direction in (1, 2):
                c.uc.mem_write(UI + page_offset, struct.pack('<I', page))
                c.uc.mem_write(UI + direction_offset, struct.pack('<I', direction))
                run(site, (UI, 2), site + 4 + slide)
                assert observed[-1] == (page + (1 if direction == 1 else -1)) % 6
                scroll_cases += 1
    key_cases = 0
    for page in range(6):
        for key in (-3, -4):
            c.uc.mem_write(UI + page_offset, struct.pack('<I', page))
            run(b.sym('CBBGRecordPersonalUI::OnKeyPressed(int)'), (UI, key))
            assert observed[-1] == (page + (1 if key == -3 else -1)) % 6
            key_cases += 1
    c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(3)
    for page in range(3):
        c.uc.mem_write(UI + page_offset, struct.pack('<I', page))
        run(b.sym('CBBGRecordPersonalUI::OnKeyPressed(int)'), (UI, -3))
        assert observed[-1] == (page + 1) % 3
    c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(4)

    role_cases = 0
    for site in nav['role_calls']:
        for page in range(6):
            c.uc.mem_write(UI + page_offset, struct.pack('<I', page))
            if site['context'] == 'table':
                c.ptr(SP + (0x78 if b.is64 else 0x44), UI)
                local_page = SP + (0xd4 if b.is64 else 0x80)
                c.uc.mem_write(local_page, struct.pack('<i', page))
            else:
                c.ptr(SP + (0xb8 if b.is64 else 0x6c), UI)
                local_page = None
            run(site['site'], (), site['site'] + 4 + slide)
            assert c.r(0) == int(page < 3)
            if local_page:
                assert struct.unpack('<i', c.uc.mem_read(local_page, 4))[0] == page % 3
            assert struct.unpack('<I', c.uc.mem_read(UI + page_offset, 4))[0] == page
            role_cases += 1

    flags = arm64.UC_ARM64_REG_NZCV if b.is64 else arm.UC_ARM_REG_APSR
    fregs = [getattr(arm64 if b.is64 else arm,
                     f'UC_ARM64_REG_Q{i}' if b.is64 else f'UC_ARM_REG_D{i}') for i in range(32)]
    fvalues = [((0x1234567800000000 + i) << 64 | (0xfedcba9800000000 + i))
               if b.is64 else 0x1234567800000000 + i for i in range(32)]
    layout_cases = 0
    for site in nav['page_loads']:
        for page in range(6):
            c.uc.mem_write(UI + page_offset, struct.pack('<I', page))
            for position, register in enumerate(c.regs):
                if register != c.lr: c.uc.reg_write(register, 0x12340000 + position)
            c.uc.reg_write(c.sp, SP)
            c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
            c.r(8 if b.is64 else 0, UI)
            c.uc.reg_write(flags, 0xa0000000)
            for register, value in zip(fregs, fvalues): c.uc.reg_write(register, value)
            before = [c.uc.reg_read(register) for register in c.regs]
            c.stopped = None
            c.stops = {site['site'] + site['size'] + slide}
            c.run_relative(site['site'])
            expected = page % 3
            if not b.is64 and site['destination'] == 2: expected *= 3
            before[site['destination']] = expected
            assert [c.uc.reg_read(register) for register in c.regs] == before
            assert [c.uc.reg_read(register) for register in fregs] == fvalues
            assert c.uc.reg_read(c.sp) == SP
            if b.is64 or site['destination'] == 2:
                assert c.uc.reg_read(flags) & 0xf0000000 == 0xa0000000
            else:
                expected_flags = 0x60000000 if page % 3 == 2 else 0x80000000
                assert c.uc.reg_read(flags) & 0xf0000000 == expected_flags
            layout_cases += 1

    # Keep the PIT save null while resolving all supported personal history years.
    c.ptr(MGR + (0x520 if b.is64 else 0x4e4), 0)
    original_calls = []
    def original_past():
        original_calls.append((c.r(0), c.r(1)))
        c.ret(HEAP + 0xee000)
    c.callbacks[b.sym(BINDINGS['original_past_pitcher_record']) + slide] = original_past
    past_cases = 0
    for year in (-1, 0, 1, 8, 9, 10):
        run(nav['past_pitcher_call'], (MGR, year), nav['past_pitcher_call'] + 4 + slide)
        assert c.r(0) == (RECORD if 0 <= year <= 9 else 0)
        assert not original_calls
        past_cases += 1
    c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(3)
    run(nav['past_pitcher_call'], (MGR, 2), nav['past_pitcher_call'] + 4 + slide)
    assert c.r(0) == HEAP + 0xee000 and original_calls == [(MGR, 2)]
    return {'abi': abi, 'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'slide': hex(slide), 'scroll_call_cases': scroll_cases, 'original_key_path_cases': key_cases,
            'original_three_page_mode_preserved': True, 'role_cases': role_cases,
            'layout_index_cases': layout_cases, 'past_record_cases': past_cases + 1,
            'past_record_dereferences_pit_save_in_mode4': False,
            'all_inline_gpr_fp_flags_preserved': True,
            'limits': ['Original swipe collision detection and rendered page layout are not exercised.',
                       'Mode4 history uses semantic Unbounded projections, not fabricated finite historical games.',
                       'This instruction test does not establish Android startup or full gameplay compatibility.'],
            'android_runtime_verified': False}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'record_navigation_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps(results, indent=2))
