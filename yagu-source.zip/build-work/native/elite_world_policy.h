/* Finite elite NPC level in the active career's exact fifteen-team roster.
 *
 * This header is included after own_team()/my_batter() and before yagu_level.
 * It adds no saved field, writable global, UI or extra team. In particular the
 * sixteenth sRaiseTeamInfo storage team at +0x3794 is outside this policy.
 * 250 is the original SetRaiseTeamAddLv bound, not an infinity encoding.
 */
#ifndef YAGU_ELITE_WORLD_POLICY_H
#define YAGU_ELITE_WORLD_POLICY_H

enum { ELITE_NPC_LEVEL = 250, ELITE_NPC_PURE_STATUS = 1400,
       ELITE_TEAM_COUNT = 15, ELITE_TEAM_STRIDE = 0x3b4 };

API int yagu_elite_npc(const u8 *player) {
    if (!player) return 0;
    int mode = game_mode();
    if (mode != 3 && mode != TWO_WAY_MODE) return 0;
    u8 *dm = data_manager();
    if (!dm || !ptr(dm, mode == 3 ? DM_PIT_SAVE : DM_BAT_SAVE)) return 0;
    u8 *teams = ptr(dm, DM_TEAMS);
    int own = own_team_index(dm);
    if (!teams || own < 0) return 0;

    /* The active career must actually contain its My role. A selected menu
     * mode plus an unrelated/stale roster container is not sufficient. */
    u8 *home = teams + 8 + (unsigned)own * ELITE_TEAM_STRIDE;
    if (home[2] > 8 || home[3] > 12) return 0;
    if (mode == TWO_WAY_MODE) {
        if (!my_batter(home)) return 0;
    } else {
        int found = 0;
        for (unsigned i = 0; i < home[2]; ++i)
            if (read16(home + 4 + i * 52) == MY_PIT) found = 1;
        if (!found) return 0;
    }

    /* Integer address arithmetic avoids subtracting unrelated C pointers.
     * No actor memory is read before exact bounded slot membership is proven. */
    uptr first = (uptr)teams + 8;
    uptr address = (uptr)player;
    if (address < first) return 0;
    uptr delta = address - first;
    if (delta >= (uptr)ELITE_TEAM_COUNT * ELITE_TEAM_STRIDE) return 0;
    unsigned team_index = (unsigned)(delta / ELITE_TEAM_STRIDE);
    unsigned offset = (unsigned)(delta % ELITE_TEAM_STRIDE);
    const u8 *team = teams + 8 + team_index * ELITE_TEAM_STRIDE;
    if (team[2] > 8 || team[3] > 12) return 0;
    int present = 0;
    if (offset >= 4 && offset < 0x1a4) {
        unsigned within = offset - 4;
        present = within % 52 == 0 && within / 52 < team[2];
    } else if (offset >= 0x1a4) {
        unsigned within = offset - 0x1a4;
        present = within % 44 == 0 && within / 44 < team[3];
    }
    if (!present) return 0;
    u16 id = read16(player);
    return id != MY_BAT && id != MY_PIT;
}

#endif
