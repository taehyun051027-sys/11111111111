"""Execute exact patched career-format sites and compiled ownership predicates."""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE
from payload_builder import add_payload
from career_ability_ui import add_career_ability_ui_hooks, add_rest_current_condition_hook
from verify_relocation import prepare_case, BAT, TEAM, TEAMS, SAVE, MODE
from verify_gameplay_hooks import ROOT, HEAP, SP, MGR
from unicorn.arm_const import UC_ARM_REG_R7
from unicorn.arm64_const import UC_ARM64_REG_X29

WORK = Path(__file__).resolve().parent
OUTPUT = HEAP + 0xf010


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'career_ability_build' / abi)
    contexts = add_career_ability_ui_hooks(b, payload['symbols'])
    rest = add_rest_current_condition_hook(b, payload['symbols'])
    slide = 0x456780000 if b.is64 else 0x84567000
    cases = []
    for label, context in contexts.items():
        for kind in ('owned', 'other_actor_or_mode', 'duplicate_id_outside_own_team',
                     'not_career', 'no_save', 'null_context'):
            c = prepare_case(b, slide)
            actor = BAT
            mode = MODE
            if kind == 'other_actor_or_mode':
                c.uc.mem_write(BAT, struct.pack('<H', 22))
                mode += 0x1000
            if kind == 'duplicate_id_outside_own_team':
                actor = HEAP + 0xa000
                c.uc.mem_write(actor, struct.pack('<H', 1000))
                mode += 0x1000
            if kind == 'not_career':
                c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            if kind == 'no_save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
            if kind == 'null_context': actor = mode = 0
            if label == 'career_condition':
                c.ptr(SP + (0xa8 if b.is64 else 0x70), mode)
            elif label == 'selected_pitch_level':
                c.ptr(SP + (0x1d8 if b.is64 else 0x110), mode)
            elif label == 'rest_capacity_initial':
                if b.is64:
                    c.uc.reg_write(UC_ARM64_REG_X29, SP + 0x240)
                    c.ptr(SP + 0x240 - 0xa8, mode)
                else: c.ptr(SP + 0x114, mode)
            elif label == 'rest_capacity_animated':
                c.ptr(SP + (0x240 if b.is64 else 0x170), mode)
            elif b.is64:
                c.ptr(SP + 0x2e0, actor)
            else:
                c.uc.reg_write(UC_ARM_REG_R7, SP + 0x400)
                c.ptr(SP + 0x410, actor)
            before = bytes(c.uc.mem_read(TEAM, 0x3b4))
            c.uc.mem_write(OUTPUT - 8, bytes([0xa5]) * 48)
            for i, value in enumerate((OUTPUT, HEAP + 0x100, 10, 0xabcdef)):
                c.r(i, value)
            arguments = [c.r(i) for i in range(4)]
            original_called = []
            def fallback():
                assert [c.r(i) for i in range(4)] == arguments
                original_called.append(True)
                c.uc.mem_write(OUTPUT, b'10\0')
                c.ret(2)
            c.callbacks[b.sym('MC_knlSprintk') + slide] = fallback
            c.stops = {context['site'] + 4 + slide}
            c.run_relative(context['site'])
            expected = ('Lv \u221e' if context['style'] == 1 else ' / \u221e' if context['style'] == 2 else '\u221e').encode() if kind == 'owned' else b'10'
            assert bytes(c.uc.mem_read(OUTPUT, len(expected) + 1)) == expected + b'\0', (abi, label, kind)
            assert c.r(0) == len(expected)
            assert c.uc.reg_read(c.sp) == SP
            assert bool(original_called) == (kind != 'owned')
            assert bytes(c.uc.mem_read(TEAM, 0x3b4)) == before
            assert c.uc.mem_read(OUTPUT - 8, 8) == bytes([0xa5]) * 8
            assert c.uc.mem_read(OUTPUT + len(expected) + 1, 16) == bytes([0xa5]) * 16
            cases.append({'label': label, 'site': hex(context['site']), 'context': kind,
                          'text': expected.decode()})
    for caller_index, caller in enumerate(rest['callers']):
        for kind in ('owned', 'wrong_mode', 'wrong_caller', 'not_career', 'no_save'):
            c = prepare_case(b, slide)
            child_fp, parent_fp = SP + 0x500, SP + 0x1000
            c.uc.reg_write(UC_ARM64_REG_X29 if b.is64 else UC_ARM_REG_R7, child_fp)
            c.ptr(child_fp, parent_fp)
            c.ptr(child_fp + (8 if b.is64 else 4), caller + slide + (8 if kind == 'wrong_caller' else 0))
            offset = (0xa8 if caller_index == 0 else 0x140) if b.is64 else (0x8c if caller_index == 0 else 0xf8)
            c.ptr(parent_fp - offset, MODE + (0x1000 if kind == 'wrong_mode' else 0))
            if kind == 'not_career': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            if kind == 'no_save': c.ptr(MGR + (0x528 if b.is64 else 0x4e8), 0)
            c.uc.mem_write(OUTPUT - 8, bytes([0xa5]) * 48)
            for i, value in enumerate((OUTPUT, HEAP + 0x100, 100, 0xabcdef)): c.r(i, value)
            arguments = [c.r(i) for i in range(4)]
            called = []
            def fallback():
                assert [c.r(i) for i in range(4)] == arguments
                called.append(True)
                c.uc.mem_write(OUTPUT, b'100\0')
                c.ret(3)
            c.callbacks[b.sym('MC_knlSprintk') + slide] = fallback
            c.stops = {rest['site'] + 4 + slide}
            c.run_relative(rest['site'])
            expected = '\u221e'.encode() if kind == 'owned' else b'100'
            assert bytes(c.uc.mem_read(OUTPUT, len(expected) + 1)) == expected + b'\0'
            assert c.uc.reg_read(c.sp) == SP
            assert bool(called) == (kind != 'owned')
            assert c.uc.mem_read(OUTPUT - 8, 8) == bytes([0xa5]) * 8
            assert c.uc.mem_read(OUTPUT + len(expected) + 1, 16) == bytes([0xa5]) * 16
            cases.append({'label': 'rest_current_condition', 'caller': hex(caller), 'context': kind,
                          'text': expected.decode()})
    return {'abi': abi, 'passed': len(cases), 'slide': hex(slide), 'cases': cases,
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'buffer_bounds_preserved': True, 'roster_memory_unchanged': True,
            'original_font_and_layout_retained': True, 'android_runtime_verified': False}


if __name__ == '__main__':
    report = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'career_ability_ui_verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps([{'abi': x['abi'], 'passed': x['passed']} for x in report]))
