"""Verify every authored defender lookup site with the real compiled resolver.

The tests stop immediately after the overwritten load, before the engine's
texture loader. They establish path routing and caller-state preservation,
not image decoding, visual appearance, or a completed Android game.
"""
import hashlib
import json
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks
from payload_builder import add_payload
from defender_hooks import add_defender_hooks
from verify_relocation import RelocatedCase
from verify_gameplay_hooks import ROOT, HEAP, SP, STOP
from unicorn.arm64_const import UC_ARM64_REG_NZCV
from unicorn.arm_const import UC_ARM_REG_APSR
import unicorn.arm64_const as arm64
import unicorn.arm_const as arm

WORK = Path(__file__).resolve().parent
TABLE = HEAP + 0x20000
STRINGS = HEAP + 0x50000
MAKER = HEAP + 0x80000
PARTS = ('head', 'body', 'calves', 'stripes', 'arm', 'leg')


def read_c_string(c, address, maximum=128):
    value = bytes(c.uc.mem_read(address, maximum)).split(b'\0', 1)[0]
    assert len(value) < maximum, 'unterminated path'
    return value.decode('ascii')


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'defender_build' / abi)
    sites = add_defender_hooks(b, payload['symbols']['yagu_defender_path'])
    slide = 0x7123450000 if b.is64 else 0xb3450000
    c = RelocatedCase(b, slide)
    scalar_flags = UC_ARM64_REG_NZCV if b.is64 else UC_ARM_REG_APSR
    fregs = [getattr(arm64 if b.is64 else arm,
                     f'UC_ARM64_REG_Q{i}' if b.is64 else f'UC_ARM_REG_D{i}')
             for i in range(32)]
    fvalues = [((0x1234567800000000 + i) << 64 | (0xfedcba9800000000 + i))
               if b.is64 else 0x1234567800000000 + i for i in range(32)]
    legacy_strings = {}
    for palette in range(10):
        for part in range(6):
            index = 0xd08 + palette * 8 + part
            path = f'original/palette_{palette}/{PARTS[part]}.pzc'
            pointer = STRINGS + (palette * 6 + part) * 128
            c.uc.mem_write(pointer, path.encode('ascii') + b'\0')
            c.ptr(TABLE + index * (8 if b.is64 else 4), pointer)
            legacy_strings[(palette, part)] = (pointer, path)

    passed = []
    instruction_cases = 0
    for number, site in enumerate(sites):
        part = number % 6
        results = []
        for palette in list(range(10)) + [value for value in range(10, 25) if value != 14]:
            index = 0xd08 + palette * 8 + part
            for position, register in enumerate(c.regs):
                if register != c.lr:
                    c.uc.reg_write(register, 0x12340000 + position)
            c.uc.reg_write(c.sp, SP)
            c.uc.reg_write(c.lr, STOP if b.is64 else STOP | 1)
            c.r(0, MAKER)
            if b.is64:
                c.r(8, TABLE)
                c.r(9, index)
            else:
                c.r(1, TABLE)
                c.r(2, index)
            c.uc.reg_write(scalar_flags, 0xa0000000)
            for register, value in zip(fregs, fvalues):
                c.uc.reg_write(register, value)
            before = [c.uc.reg_read(register) for register in c.regs]
            c.stopped = None
            c.stops = {site['site'] + 4 + slide}
            c.run_relative(site['site'])
            assert c.stopped == site['site'] + 4 + slide
            assert c.uc.reg_read(c.sp) == SP
            path_pointer = c.r(1)
            path = read_c_string(c, path_pointer)
            if palette < 10:
                expected_pointer, expected_path = legacy_strings[(palette, part)]
                assert path_pointer == expected_pointer
            else:
                expected_path = f'defender/team_{palette - 10}/{PARTS[part]}.pzc'
                assert path_pointer >= payload['base'] + slide
                assert path_pointer < payload['base'] + payload['size'] + slide
            assert path == expected_path, (abi, hex(site['site']), palette, path, expected_path)
            before[1] = path_pointer
            after = [c.uc.reg_read(register) for register in c.regs]
            assert after == before, (abi, hex(site['site']), palette, 'GPR corruption')
            assert c.r(0) == MAKER
            assert c.uc.reg_read(scalar_flags) & 0xf0000000 == 0xa0000000
            assert [c.uc.reg_read(register) for register in fregs] == fvalues
            results.append(palette)
            instruction_cases += 1
        assert len(results) == 24
        passed.append({'site': hex(site['site']), 'continuation': hex(site['site'] + 4),
                       'part': PARTS[part], 'legacy_palettes': list(range(10)),
                       'new_palettes': [value for value in range(10, 25) if value != 14],
                       'path_and_state_cases': len(results)})

    # Common resources use their untouched original loads. Verify every patch
    # owned by this module is exactly one of the 12 hash-locked color sites.
    module_patches = [patch for patch in b.patches
                      if patch['reason'] == 'Safe extended defender path lookup']
    assert len(module_patches) == 12
    assert {patch['address'] for patch in module_patches} == {site['site'] for site in sites}
    return {'abi': abi, 'source_sha256': b.sha,
            'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'source_header_sha256': hashlib.sha256((WORK / 'defender_paths.h').read_bytes()).hexdigest(),
            'payload_sha256': hashlib.sha256((WORK / 'defender_build' / abi / 'payload.elf').read_bytes()).hexdigest(),
            'slide': hex(slide), 'sites_passed': len(passed),
            'instruction_cases_passed': instruction_cases, 'sites': passed,
            'preservation_verified': ['texture-maker first argument', 'all GPRs except intended path result',
                                      'stack and return address', 'condition flags', 'all 32 SIMD/FP registers'],
            'limits': ['Texture decoding, frame geometry and rendered appearance are not exercised.',
                       'Palette 14 is excluded by the Pumas mapping; no new Pumas path is asserted.',
                       'No Android loader or complete gameplay verification.'],
            'android_runtime_verified': False}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'defender_hook_verification.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps([{'abi': result['abi'], 'sites_passed': result['sites_passed'],
                       'instruction_cases_passed': result['instruction_cases_passed'],
                       'slide': result['slide']} for result in results], indent=2))
