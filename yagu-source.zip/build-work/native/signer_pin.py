"""Update only the expected signer value for this deliberately re-signed app.

The original componentID company selection, enable flag, getGL comparison and
failure path remain intact. The value is Android Signature.hashCode() for the
public signing certificate selected by the packager; this is not a bypass.
"""
import struct

ORIGINAL_HASH = 0x29b34343


def add_signer_pin_patch(b, certificate_hash):
    value = int(certificate_hash, 0) if isinstance(certificate_hash, str) else int(certificate_hash)
    if value < -(1 << 31) or value > 0xffffffff:
        raise ValueError('YAGU_CERT_HASH must be a 32-bit Android Signature.hashCode value')
    value &= 0xffffffff
    if b.is64:
        address = 0x6acba4
        expected = '696888526936a572'
        replacement = b.asm(f'movz w9, #{value & 0xffff}\nmovk w9, #{value >> 16}, lsl #16', address)
        if len(replacement) != 8: raise ValueError('Unexpected signer immediate width')
    else:
        address = 0x42cbc4
        expected = '4343b329'
        replacement = struct.pack('<I', value)
    b.patch(address, replacement, 'Expected public signer hash for this re-signed build', expected)
    return {'address': hex(address), 'bytes_changed': len(replacement),
            'original_android_signature_hash': hex(ORIGINAL_HASH),
            'expected_android_signature_hash': hex(value),
            'affected_company_ids': [5, 15],
            'original_selection_enable_compare_and_failure_paths_preserved': True}
