/* Personal career honors are a tagged quantity, not the one-byte counters
 * used by the original end-of-season/save procedure. Keep those finite
 * counters and award animations intact. Their canonical own-player consumer
 * is CBBGEvent::IsRecordCheck{Bat,Pit}, selectors26..31 in both original ABIs.
 */
API const Scalar *yagu_owned_honor_metric(const u8 *record, int role, int honor) {
    const InfiniteRecords *state = yagu_owned_records(record, role);
    if (!state || honor < 0 || honor >= 6) return (const Scalar *)0;
    /* The six appended Scalar fields preserve all earlier record offsets.
     * Byte addressing avoids an absolute pointer jump table in Thumb PIC. */
    return (const Scalar *)((const u8 *)&state->pennant_titles
                           + (unsigned)honor * sizeof(Scalar));
}

API int yagu_honor_event_check(int role, int selector, int threshold) {
    if (selector < 26 || selector > 31) return -1;
    const u8 *record = yagu_current_personal_record(role);
    return yagu_record_event_compare(
        yagu_owned_honor_metric(record, role, selector - 26), threshold);
}
