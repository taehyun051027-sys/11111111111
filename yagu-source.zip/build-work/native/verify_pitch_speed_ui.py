"""Check real compiled speed formatting, ownership, units and buffer bounds."""
import hashlib
import json
import struct
from pathlib import Path

from patch_builder import PatchBuilder
from gameplay_hooks import add_gameplay_hooks, GETMODE
from payload_builder import add_payload, BINDINGS
from infinity_ui import add_infinity_ui_hooks
from defender_hooks import verify_original_defender_lookups
from game_run_uniform_hooks import add_game_run_uniform_hooks
from personal_record_ui import add_personal_record_ui_hooks
from pitch_speed_ui import add_pitch_speed_ui_hooks
from verify_relocation import prepare_case, TEAMS
from verify_gameplay_hooks import ROOT, HEAP, SP, GAME, PITM, PITCHER

WORK = Path(__file__).resolve().parent
SCENE = HEAP + 0xe000
OUTPUT = HEAP + 0xf010


def verify(abi):
    b = PatchBuilder(abi, (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    payload = add_payload(b, workdir=WORK / 'pitch_speed_build' / abi)
    symbols = payload['symbols']
    add_infinity_ui_hooks(b, symbols['yagu_state'])
    verify_original_defender_lookups(b)
    add_game_run_uniform_hooks(b, symbols)
    add_personal_record_ui_hooks(b, symbols)
    sites = add_pitch_speed_ui_hooks(b, symbols)
    slide = 0x7654321000 if b.is64 else 0x84567000
    cases = []
    for context in sites:
        for kind in ('my_owned', 'ordinary_owned', 'my_opponent', 'ordinary_opponent',
                     'not_career', 'no_scene', 'no_game', 'no_teams', 'no_pitcher'):
            c = prepare_case(b, slide)
            c.uc.mem_write(PITCHER, struct.pack('<H', 23 if kind.startswith('ordinary') else 1100))
            c.uc.mem_write(PITM + 0x25, bytes([5 if 'opponent' in kind else 4]))
            c.ptr(SCENE + (0x1a8 if b.is64 else 0x140), 0 if kind == 'no_game' else GAME)
            c.ptr(SP + (0x48 if b.is64 else 0x44), 0 if kind == 'no_scene' else SCENE)
            if kind == 'not_career': c.callbacks[b.sym(GETMODE) + slide] = lambda: c.ret(1)
            if kind == 'no_teams': c.ptr(HEAP + 0xb000 + (0x530 if b.is64 else 0x4ec), 0)
            c.callbacks[b.sym(BINDINGS['get_reserved_pitcher']) + slide] = lambda: c.ret(0 if kind == 'no_pitcher' else PITCHER)
            c.uc.mem_write(OUTPUT - 16, bytes([0xa5]) * 64)
            speed_offset = 0x814 if b.is64 else 0x580
            c.uc.mem_write(GAME + speed_offset, struct.pack('<I', 167))
            before_game = bytes(c.uc.mem_read(GAME, 0x1000))
            for index, value in enumerate((OUTPUT, HEAP + 0x100, 167, 0xabcdef)):
                c.r(index, value)
            original_args = [c.r(index) for index in range(4)]
            called = []

            def formatter():
                assert [c.r(index) for index in range(4)] == original_args
                called.append(True)
                c.uc.mem_write(OUTPUT, b'167\0')
                c.ret(3)

            c.callbacks[b.sym('MC_knlSprintk') + slide] = formatter
            c.stops = {context['site'] + 4 + slide}
            c.run_relative(context['site'])
            assert c.uc.reg_read(c.sp) == SP
            expected = ('!S14!xFFFFFFFF\u221e ' + ('mph' if context['english'] else 'km')).encode('utf-8') if kind == 'my_owned' else b'167'
            assert bytes(c.uc.mem_read(OUTPUT, len(expected) + 1)) == expected + b'\0'
            assert c.r(0) == len(expected)
            assert bool(called) == (kind != 'my_owned')
            assert bytes(c.uc.mem_read(OUTPUT - 16, 16)) == bytes([0xa5]) * 16
            assert bytes(c.uc.mem_read(OUTPUT + len(expected) + 1, 32 - len(expected) - 1)) == bytes([0xa5]) * (32 - len(expected) - 1)
            assert bytes(c.uc.mem_read(GAME, 0x1000)) == before_game
            cases.append({'site': hex(context['site']), 'unit': 'mph' if context['english'] else 'km',
                          'context': kind, 'text': expected.decode('utf-8')})
    return {'abi': abi, 'source_c_sha256': hashlib.sha256((WORK / 'yagu_payload.c').read_bytes()).hexdigest(),
            'slide': hex(slide), 'passed': len(cases), 'cases': cases,
            'original_game_memory_unchanged': True, 'buffer_bounds_preserved': True,
            'normal_formatter_abi_preserved': True,
            'limits': ['Native font glyph rasterization is not tested.',
                       'This projects semantic speed into display text; finite physics/animation fields remain finite.'],
            'android_runtime_verified': False}


if __name__ == '__main__':
    results = [verify(abi) for abi in ('arm64-v8a', 'armeabi-v7a')]
    (WORK / 'pitch_speed_ui_verification.json').write_text(json.dumps(results, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps([{'abi': result['abi'], 'passed': result['passed']} for result in results], indent=2))
