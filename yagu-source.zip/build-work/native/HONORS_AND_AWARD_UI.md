# Personal honors and existing award tables

## Implemented semantic scope

`honors_payload.inc` appends six immutable `Scalar` fields to `InfiniteRecords`: pennant titles, pennant MVPs, postseason titles, postseason MVPs, cup titles and cup MVPs. Record schema3 contains39 scalars:32 tagged Unbounded and7 exact-zero adverse metrics. The previous33 field offsets are unchanged. Player-state schema2 and its46 ability/resource scalars are unchanged.

The six quantities are consumed by the original local career event entry points, through the existing `yagu_record_check_bat` and `yagu_record_check_pit` wrappers. They are not merely labels. Both original switch tables map selectors26..31 to these six counters, in that order. These branches do not consult the supplied period; their original full event paths were executed with periods1,2,4,7 and−1 to verify that fact. Ordinary personal-record selectors retain their separate audited period1/2 policy.

An exact record pointer in the active owned career is required. A matching RFID on an opponent, a copied record, a missing actor/save, an invalid roster count or an unrelated mode does not acquire Unbounded semantics. Positive/nonnegative thresholds retain the original `>=` meaning; negative thresholds retain strict `< abs(threshold)`. Consequently every finite lower threshold passes for an Unbounded honor count, and every finite upper threshold fails. INT_MIN remains false. The original comparator and absolute-value implementation were included in the native control.

| Personal honor | Selector in both roles | A64 BAT getter call | A64 PIT getter call | Thumb BAT/PIT branch starts |
|---|---:|---|---|---|
| Pennant title |26|0x425684|0x4261cc|0x29009c /0x2907a2|
| Pennant MVP |27|0x4256c0|0x426208|0x2900c0 /0x2907c6|
| Postseason title |28|0x4256fc|0x426244|0x2900e4 /0x2907ea|
| Postseason MVP |29|0x425738|0x426280|0x290108 /0x29080e|
| Cup title |30|0x425774|0x4262bc|0x29012c /0x290832|
| Cup MVP |31|0x4257b0|0x4262f8|0x290150 /0x290856|

The actual season-completion process still increments its original finite bookkeeping bytes. Those bytes are at RaiseMode+0x418..0x41b and+0x529..0x52a. The first four original increment methods clamp at250; the last two originally wrap one byte. No raw getter or increment method is replaced, and no fictitious completed game or season is serialized. The semantic personal-honor consumer does not depend on those finite adapters.

## Existing award UI integration

The original `CBBGUIPostAward::AddTableRanker` displays three own-player performance cells. `AddTableBonus` displays the same three metrics from the original past-record window. The new `award_record_ui.py` uses their existing number widgets and exact caller return addresses:

| Widget | A64 GetChangeFont site | Thumb GetChangeFont site | Current / past metric |
|---|---|---|---|
| Integer |0x5950d0|0x3849b6|BAT RBI/HR; PIT K and position-specific W/HLD/SV|
| Average×1000 |0x594bd8|0x3845f2|BAT batting average|
| Average×100 |0x594da0|0x384758|PIT ERA|

The integer/average cells show the owned typed Unbounded value as U+221E. ERA shows the exact semantic zero. Original `GetChangeFont` typeface, size, RGBA and subsequent layout/rendering remain intact. This hook is distinct from the existing career/roster sprintf hook, so no shared instruction is patched twice.

Current records must equal `yagu_current_personal_record(role)`. Past records must belong to the active original career role, equal `save+0x830+min(year,9)*stride`, contain that role's My RFID, and have a valid current owned role record. A negative year is rejected. This matches the original ten-slot past-record getter; it does not manufacture historical seasons, extend the history array or resolve the separate long-career year limitations.

The original MVP table's numbers are award rewards, not accumulated MVP counts. Its fixed A64 table at0x28f41a contains `[1250,10,5]`, `[1250,10,7]`, `[1250,10,10]`. Its number call at0x46a708 is excluded. The two year-end monetary cells in `AddTableBonus` are also excluded. Original award decision, monetary calculation and presentation methods are byte-for-byte unchanged.

No dedicated original screen showing the six cumulative trophy counts was found in this bounded audit. Their verified direct getter consumers are the two event-check methods. This work does not add a new trophy page or claim that every UI in the old game has been audited.

## Verification and source boundaries

`verify_honors.py` passed18,532 checks across ARM64 and ARMv7 at nonzero load biases:5,760 patched event cases,11,520 original full selector/getter/comparison cases,528 ownership exclusions,96 original increment cases,56 complete preserved getter/increment/award code ranges, plus schema/metric/fallback checks. Its staged C hash is `cb85fbc626c3daae5e34c93a8622ca1a0d967430790eca3ffc379b0467072136`.

`verify_award_record_ui.py` passed906 checks on the complete140-site final combination:54 current cells,432 past cells, ownership/caller/index failures, exact original past-pointer parity, preserved award methods, and24 executions of the entire original integer widget. The last cases execute the shared rest formatter and new award styling together, preserving ordinary numbers, MVP gifts and year-end money. The extra ARMv7 cases cover both original stack alignments. Both reconstructed libraries are byte-identical to the final CLI outputs. Its staged C hash is `a90d623f2157aab6eccceefc052e281280bd8d97bb9da838b12cf6250cb807ad`.

The shared honors C also passed payload50, record-core2,934, personal-table font208 and relocation48 regression checks. These are instruction-level tests with documented service/font boundaries. They do not establish Android end-of-season rendering, a complete nine-inning game, or all-menu coverage. Actual Android observations must be reported separately against the installed APK hash.

Integration is explicit: `honors_policy.integrate_source` and `integrate_builder`, followed by `award_record_policy.integrate_source`; include both `.inc` files and call `add_award_record_ui_hooks` in the final builder. Staging helpers preserve unrelated source and reject unexpected structural anchors rather than overwriting them.
