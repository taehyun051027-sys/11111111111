/* A two-way career keeps its owned batter for every plate appearance.
 * Do not let a forced AI or burst-mission Ace replacement remove that actor.
 * Opponent substitutions, other batters and all other modes stay original. */
API extern void original_keep_batter_reservation(u8 *, int, u8);
API extern u8 original_keep_batter_ai(u8 *, u8 *, u8 *, u8 *, u8);
API extern int presence_original_ace_change(u8 *);

API int yagu_keep_owned_batter(u8 *entry) {
    u8 *dm = data_manager();
    if (!entry || !dm || game_mode() != TWO_WAY_MODE ||
            entry[0x24] != TWO_WAY_MODE || !owns_entry(dm, entry)) return 0;
    u8 *save = ptr(dm, DM_BAT_SAVE);
    if (!save || !own_mode(save + 8)) return 0;
    u8 *actor = owned_role_player(dm, 0);
    return actor && original_rescue_current_batter(entry) == actor;
}
API void yagu_keep_batter_reservation(u8 *entry, int index, u8 immediate) {
    if (!yagu_keep_owned_batter(entry))
        original_keep_batter_reservation(entry, index, immediate);
}
API u8 yagu_keep_batter_ai(u8 *level, u8 *entry, u8 *runners,
                          u8 *play, u8 force) {
    return yagu_keep_owned_batter(entry) ? 0 :
        original_keep_batter_ai(level, entry, runners, play, force);
}
API int yagu_keep_batter_mission(u8 *mission, u8 *game) {
    if (game && yagu_keep_owned_batter(
            ptr(game, __SIZEOF_POINTER__ == 8 ? 0x410 : 0x2c8))) return 0;
    return presence_original_ace_change(mission);
}
