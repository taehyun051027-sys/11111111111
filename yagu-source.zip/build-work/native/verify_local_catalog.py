"""Execute actual catalog tables/getters and exact local UI routes on ARM ABIs.

Native GVXLLoader::GetX/GetY/GetVal and selected original UI continuations run.
OS drawing, singleton acquisition, and popup animation are explicit boundaries.
This is instruction-level verification, not an Android purchase claim.
"""
import hashlib
import json
import struct
import sys
from pathlib import Path
from zipfile import ZipFile

from patch_builder import PatchBuilder
import payload_builder
from gameplay_hooks import add_gameplay_hooks
from local_catalog_policy import BINDINGS, stage_payload
from local_catalog_hooks import METHODS, REQUESTS, add_local_catalog_hooks
from verify_honors import configure
from verify_original_plt_cache import original_plt
from verify_wallet import invoke, args
from verify_relocation import BAT, PIT, MODE
from verify_gameplay_hooks import HEAP, MGR, SP, STOP

ROOT=Path(__file__).resolve().parents[2]
WORK=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'analysis/data/tools'))
from zt1_codec import unpack_zt1,RecordTable

OPTION,DEFMGR,UI,RUN,MAP,POPUP=(HEAP+n for n in (0x61000,0x62000,0x63000,0x64000,0x65000,0x66000))
LOADERS={i:HEAP+0x68000+(i-4)*0x4000 for i in (4,5,6)}
APK_SHA='2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484'

def load_tables():
    path=ROOT/'upload/baseball-superstars-2013-1-2-9.apk'
    if hashlib.sha256(path.read_bytes()).hexdigest()!=APK_SHA:raise ValueError('Wrong original APK')
    out={}
    with ZipFile(path) as apk:
        for ident,name in ((4,'EquipItem'),(5,'EffectItem'),(6,'CostumeItem')):
            blob=apk.read('assets/data/Xls'+name+'.zt1');raw=unpack_zt1(blob);t=RecordTable.parse(raw)
            values=[[struct.unpack({0:'<b',1:'<B',2:'<h',3:'<H',4:'<i'}[kind],t.row(row)[off:off+width])[0]
                     for kind,off,width in zip(t.types,t.offsets,t.widths)] for row in range(t.row_count)]
            out[ident]=(t,values,hashlib.sha256(blob).hexdigest())
    return out

def verify(abi,stage,tables):
    b=PatchBuilder(abi,(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes())
    add_gameplay_hooks(b)
    oldroot,oldbind=payload_builder.ROOT,dict(payload_builder.BINDINGS)
    payload_builder.ROOT=stage;payload_builder.BINDINGS.update(BINDINGS)
    try:payload=payload_builder.add_payload(b,workdir=WORK/'local_catalog_build'/abi)
    finally:payload_builder.ROOT=oldroot;payload_builder.BINDINGS.clear();payload_builder.BINDINGS.update(oldbind)
    s,bind=payload['symbols'],payload['original_bindings']
    report=add_local_catalog_hooks(b,s)
    slide=0x7c65432000 if b.is64 else 0xa8432000
    counts={'embedded_rows':0,'prices':0,'discounts':0,'scopes':0,'invalid':0,'call_sites':0,
            'request_routes':0,'original_ui':0,'untouched':0}
    dyn=b.elf.get_section_by_name('.dynsym');p=b.elf.get_section_by_name('.plt')['sh_addr']
    rels=b.elf.get_section_by_name('.rela.plt' if b.is64 else '.rel.plt')
    plt={dyn.get_symbol(r['r_info_sym']).name:p+32+i*16 for i,r in enumerate(rels.iter_relocations())}

    def setup(mode=4):
        c,_,_=configure(b,slide,mode,payload);original_plt(c)
        c.ptr(MGR+(0x518 if b.is64 else 0x4e0),OPTION)
        for a,size in ((OPTION,0x400),(DEFMGR,0x200),(UI,0x400),(RUN,0x400),(MAP,0x400),(POPUP,0x400)):
            c.uc.mem_write(a,bytes(size))
        c.callbacks[bind['catalog_define']+slide]=lambda:c.ret(DEFMGR)
        for ident,(t,_,_) in tables.items():
            loader=LOADERS[ident];data=loader+0x100;offsets=loader+0x80
            c.uc.mem_write(loader,bytes(0x80));c.uc.mem_write(data,t.raw)
            c.uc.mem_write(offsets,struct.pack('<'+'H'*len(t.offsets),*t.offsets))
            c.ptr(loader,data);c.ptr(loader+(8 if b.is64 else 4),offsets)
            c.uc.mem_write(loader+(0x10 if b.is64 else 8),struct.pack('<HHH',t.row_stride,t.row_count,len(t.types)))
            c.uc.mem_write(loader+(0x2c if b.is64 else 0x24),struct.pack('<i',2 if t.format_version==2 else 0))
            c.ptr(DEFMGR+(8 if b.is64 else 4)+ident*(8 if b.is64 else 4),loader)
        def copy():
            dst,src,n,limit=args(c,4);assert n<=limit
            c.uc.mem_write(dst,bytes(c.uc.mem_read(src,n)));c.ret(dst)
        c.callbacks[plt['__memcpy_chk']+slide]=copy
        c.callbacks[b.sym('CBBGStatic::IsBatMode()')+slide]=lambda:c.ret(mode==4)
        return c

    # The real GVXLLoader value routine must match every decoded source cell.
    c=setup()
    for ident,(t,values,_) in tables.items():
        for row,values_row in enumerate(values):
            for col,value in enumerate(values_row):
                result=invoke(c,bind['catalog_value'],LOADERS[ident],col,row)&0xffffffff
                assert result==value&0xffffffff,(abi,ident,row,col,result,value)
                counts['embedded_rows']+=1
    print(abi,'original GVXL table values passed',flush=True)

    for mode in (3,4):
        c=setup(mode)
        assert invoke(c,s['yagu_catalog_enabled'])==1
        snapshot=bytes(c.uc.mem_read(OPTION,0x400))
        for batter in (0,1):
            for part in range(5):
                for item in range(10 if part==4 else 15):
                    expected=tables[6][1][item+1][0 if batter else 1] if part==4 else tables[4][1][part*15+item][(0 if batter else 5)+(item>=5)]
                    assert expected>=0
                    assert invoke(c,s['yagu_catalog_equip_price'],part,item,batter)==expected
                    counts['prices']+=1
                    for suffix in ('discount','sale'):
                        assert invoke(c,s['yagu_catalog_equip_'+suffix],part,item,batter)==0;counts['discounts']+=1
            for item in range(29 if batter else 28):
                expected=tables[5][1][item][0 if batter else 5]
                assert invoke(c,s['yagu_catalog_effect_price'],item,batter)==expected
                assert invoke(c,s['yagu_catalog_effect_g'],item,batter)==int(item<(7 if batter else 6))
                counts['prices']+=2
                for suffix in ('discount','sale'):
                    assert invoke(c,s['yagu_catalog_effect_'+suffix],item,batter)==0;counts['discounts']+=1
        for part,limit in enumerate((11,10,10,5)):
            for item in range(limit):
                expected=tables[6][1][item][mode==3] if part==0 else 1
                assert invoke(c,s['yagu_catalog_costume_price'],part,item)==expected;counts['prices']+=1
                for suffix in ('discount','sale'):
                    assert invoke(c,s['yagu_catalog_costume_'+suffix],part,item)==0;counts['discounts']+=1
        assert bytes(c.uc.mem_read(OPTION,0x400))==snapshot
    print(abi,'all development prices/currencies passed',flush=True)

    samples={'equip':(1,8,1),'costume':(0,6),'effect':(8,1)}
    fallback_alias={value:'catalog_original_'+value.removeprefix('yagu_catalog_') for value in METHODS.values()}
    for mode,owned,table_ok,option_ok in ((0,True,True,True),(1,True,True,True),(2,True,True,True),(4,False,True,True),(3,False,True,True),(4,True,False,True),(4,True,True,False)):
        c=setup(mode)
        if not owned:c.uc.mem_write(PIT if mode==3 else BAT,b'\x01\0')
        if not table_ok:c.uc.mem_write(LOADERS[5]+(0x12 if b.is64 else 0xa),struct.pack('<H',28))
        if not option_ok:c.ptr(MGR+(0x518 if b.is64 else 0x4e0),0)
        assert invoke(c,s['yagu_catalog_enabled'])==0;counts['scopes']+=1
        for helper,alias in fallback_alias.items():
            vals=samples[helper.split('_')[2]];seen=[]
            def fallback():seen.append(args(c,len(vals)));c.ret(73)
            c.callbacks[bind[alias]+slide]=fallback
            assert invoke(c,s[helper],*vals)==73
            assert seen==[vals],(abi,helper,seen,vals);counts['scopes']+=1
    for category,invalids in {'equip':[(-1,0,1),(5,0,1),(0,-1,1),(0,15,1),(4,10,1)],
                              'costume':[(-1,0),(4,0),(1,10),(3,5)],
                              'effect':[(-1,1),(29,1),(28,0)]}.items():
        c=setup()
        for helper,alias in fallback_alias.items():
            if helper.split('_')[2]!=category:continue
            for vals in invalids:
                seen=[]
                def fallback():seen.append(tuple(v&0xffffffff for v in args(c,len(vals))));c.ret(71)
                c.callbacks[bind[alias]+slide]=fallback
                assert invoke(c,s[helper],*vals)==71
                assert seen==[tuple(v&0xffffffff for v in vals)];counts['invalid']+=1
    print(abi,'exact ownership/schema/bounds fallbacks passed',flush=True)

    for row in report['price_sites']:
        c=setup();helper=METHODS[row['target']];vals=samples[helper.split('_')[2]]
        expected=invoke(c,s[helper],*vals)
        assert invoke(c,row['hook'],*vals)==expected
        assert b.image[b.offset(row['site']):b.offset(row['site'])+4]==b.branch(row['site'],row['hook'],True)
        counts['call_sites']+=1

    for row in report['ui_request_sites']:
        kind,value,rotation=row['continuation']
        for mode in (0,3,4):
            c=setup(mode);seen=[]
            c.ptr(RUN+(0xc8 if b.is64 else 0xa4),MODE)
            c.ptr(RUN+(0x160 if b.is64 else 0xf0),UI)
            c.uc.mem_write(UI+(0x110 if b.is64 else 0xa0),b'\x01')
            c.callbacks[bind['catalog_rotate']+slide]=lambda:(seen.append(('rotate',args(c,2))),c.ret(0))[-1]
            c.callbacks[bind['catalog_worldmap_popup']+slide]=lambda:(seen.append(('worldmap',(c.r(0),))),c.ret(0))[-1]
            c.callbacks[bind['catalog_create_buy_popup']+slide]=lambda:(seen.append(('popup',args(c,3))),c.ret(0))[-1]
            c.callbacks[row['original']+slide]=lambda:(seen.append(('network',args(c,2))),c.ret(0))[-1]
            if kind in ('worldmap','strength'):c.ptr(SP+value,UI)
            if mode in (3,4) and kind=='branch':
                invoke(c,row['hook'],RUN,6,stops={value+slide})
                assert seen==([('rotate',(MODE,rotation))] if rotation else [])
            else:
                invoke(c,row['hook'],RUN,6)
                if mode==0:assert seen==[('network',(RUN,6))]
                elif kind=='worldmap':
                    assert seen==[('worldmap',(UI,))]
                    assert bytes(c.uc.mem_read(UI+(0x38 if b.is64 else 0x24),1))==b'\x01'
                else:
                    assert seen==[('popup',(0,1,0x4d))]
                    assert bytes(c.uc.mem_read(UI+(0x110 if b.is64 else 0xa0),1))==b'\0'
            counts['request_routes']+=1
        # An unexpected request mode always reaches exactly the original call.
        c=setup();seen=[]
        c.callbacks[row['original']+slide]=lambda:(seen.append(args(c,2)),c.ret(0))[-1]
        if kind in ('worldmap','strength'):c.ptr(SP+value,UI)
        invoke(c,row['hook'],RUN,0x22)
        assert seen==[(RUN,0x22)];counts['request_routes']+=1

    # In-memory original UI flags/role selectors and original state transitions.
    for mode in (3,4):
        for label,site in [('world',0x496850 if b.is64 else 0x2db070),('sub',0x497708 if b.is64 else 0x2dbaa2)]:
            c=setup(mode);seen=[];row=next(r for r in report['ui_request_sites'] if r['site']==site)
            slot=(0xb0 if label=='world' else 0xd0) if b.is64 else (0x68 if label=='world' else 0x88)
            c.ptr(SP+slot,RUN);c.ptr(RUN+(0xc8 if b.is64 else 0xa4),MODE)
            c.ptr(RUN+(0xf8 if b.is64 else 0xbc),MAP)
            c.callbacks[bind['catalog_rotate']+slide]=lambda:(seen.append(('rotation',args(c,2))),c.ret(0))[-1]
            methods=[('CBBState::ReserveState(int)',2),('CBBGRaiseMapUI::SetCurSubmapIdx(int)',2),
                     ('CBBGRaiseMapUI::ChangeMap(EnumRaiseMap, bool)',3),('CBBGRaiseMapUI::SetMapDarkness(bool, int)',3),
                     ('CBBGRaiseMapUI::RemoveCommandUI()',1),('CBBGFrameUI::SetGameKeyInfo(int)',2)]
            for name,n in methods:
                def callback(name=name,n=n):seen.append((name,args(c,n)));c.ret(0)
                c.callbacks[b.sym(name)+slide]=callback
            c.callbacks[b.sym('CGsSingleton<CBBGFrameUI>::GetInstPtr()')+slide]=lambda:c.ret(UI)
            stop=(0x497110 if label=='world' else 0x4982e0) if b.is64 else (0x2db668 if label=='world' else 0x2dc24e)
            invoke(c,row['hook'],RUN,6,stops={stop+slide})
            reserve=[x for x in seen if x[0]=='CBBState::ReserveState(int)']
            assert reserve==[('CBBState::ReserveState(int)',(RUN+(0x68 if b.is64 else 0x48),0x4f if label=='world' else 0x54))],seen
            if label=='sub':
                assert ('CBBGRaiseMapUI::SetCurSubmapIdx(int)',(MAP,0)) in seen
                assert ('CBBGRaiseMapUI::ChangeMap(EnumRaiseMap, bool)',(MAP,1,0)) in seen
                assert ('CBBGRaiseMapUI::SetMapDarkness(bool, int)',(MAP,1,1)) in seen
                assert ('CBBGRaiseMapUI::RemoveCommandUI()',(MAP,)) in seen
            counts['original_ui']+=1

    popup_routes = [
        (0x3752e4,0x21ec6e,0x50,0x48,0,0x37538c,0x21ecd4,17,18,0),
        (0x48eb4c,0x2d5e6e,0x60,0x48,0,0x48ec00,0x2d5ede,19,20,0),
        (0x499028,0x2dca7c,0x30,0x20,0xc1,0x4990f8,0x2dcb00,11,12,0),
        (0x499028,0x2dca7c,0x30,0x20,0xc2,0x499134,0x2dcb26,12,13,0),
        (0x4992e0,0x2dcc2c,0x80,0x48,0xc3,0x4993f4,0x2dccd4,0,0,1),
    ]
    for mode in (3,4):
        for a,t,afp,tfp,old_popup,astop,tstop,pit_item,bat_item,currency_g in popup_routes:
            c=setup(mode);seen=[];site=a if b.is64 else t
            row=next(r for r in report['ui_request_sites'] if r['site']==site)
            c.r(29 if b.is64 else 7,SP+(afp if b.is64 else tfp))
            c.uc.mem_write(POPUP+(0x28 if b.is64 else 0x18),struct.pack('<I',old_popup))
            c.callbacks[b.sym('CGsSingleton<CBBGCcPopup>::GetInstPtr()')+slide]=lambda:c.ret(POPUP)
            c.callbacks[b.sym('CBBGCcPopup::AddPopupAni(bool)')+slide]=lambda:(seen.append(args(c,2)),c.ret(0))[-1]
            invoke(c,row['hook'],RUN,6,stops={(astop if b.is64 else tstop)+slide})
            assert seen==[(POPUP,1)],(abi,site,seen)
            assert bytes(c.uc.mem_read(POPUP+(0x24 if b.is64 else 0x14),1))==b'\x01'
            assert struct.unpack('<I',c.uc.mem_read(POPUP+(0x28 if b.is64 else 0x18),4))[0]==0x4d
            assert struct.unpack('<I',c.uc.mem_read(POPUP+(0x240 if b.is64 else 0x230),4))[0]==(bat_item if mode==4 else pit_item)
            assert struct.unpack('<I',c.uc.mem_read(POPUP+(0x244 if b.is64 else 0x234),4))[0]==1
            assert bytes(c.uc.mem_read(POPUP+(0x248 if b.is64 else 0x238),1))==bytes([currency_g])
            counts['original_ui']+=1

    # Wrong frame receivers, gift flags, and role-save links never become a
    # local UI continuation. The original request retains its ABI arguments.
    for row in report['ui_request_sites']:
        kind,value,rotation=row['continuation']
        variants=['wrong_actor']
        if kind=='strength':variants+=['wrong_ui','missing_gift']
        if rotation:variants+=['wrong_mode_pointer']
        if kind=='worldmap':variants+=['missing_ui']
        for variant in variants:
            c=setup();seen=[]
            c.ptr(RUN+(0xc8 if b.is64 else 0xa4),MODE)
            c.ptr(RUN+(0x160 if b.is64 else 0xf0),UI)
            c.uc.mem_write(UI+(0x110 if b.is64 else 0xa0),b'\x01')
            if kind in ('worldmap','strength'):c.ptr(SP+value,UI)
            if variant=='wrong_actor':c.uc.mem_write(BAT,b'\x01\0')
            elif variant=='wrong_ui':c.ptr(RUN+(0x160 if b.is64 else 0xf0),UI+4)
            elif variant=='missing_gift':c.uc.mem_write(UI+(0x110 if b.is64 else 0xa0),b'\0')
            elif variant=='wrong_mode_pointer':c.ptr(RUN+(0xc8 if b.is64 else 0xa4),MODE+4)
            elif variant=='missing_ui':c.ptr(SP+value,0)
            c.callbacks[row['original']+slide]=lambda:(seen.append(args(c,2)),c.ret(0))[-1]
            invoke(c,row['hook'],RUN,6)
            assert seen==[(RUN,6)],(abi,variant,row,seen);counts['request_routes']+=1

    for name,fn in b.symbols.items():
        if name.startswith(('CBBGMgrNetwork::','CBBGOption::Get','CBBGOption::Set','CBBGOption::Add')) or name in (
            'CBBGStatic::SetNetworkStorePriceInfo()','CBBGStatic::ConnectNetwork(void*, int)',
            'CBBGRaisePlayerRun::ConnectNetwork(int)','CBBGStatic::InitNetwork()') or name in METHODS:
            if name.startswith('CBBGOption::') and not any(t in name for t in ('GPoint','StarPoint')):continue
            a=b.offset(fn['address']);assert b.image[a:a+fn['size']]==b.original[a:a+fn['size']],name
            counts['untouched']+=1
    return {'abi':abi,'passed':True,'counts':counts,'total':sum(counts.values()),'patch_inventory':report,
            'payload_sha256':hashlib.sha256((stage/'yagu_payload.c').read_bytes()).hexdigest(),
            'mocked_boundaries':['singleton acquisition','__memcpy_chk copy service','popup drawing/animation','map/UI transition service observations'],
            'native_GVXL_values_executed':True,'original_price_tables_unchanged':True,'android_shop_verified':False}

def main():
    stage=WORK/'local_catalog_stage';source=stage_payload(stage);tables=load_tables();reports=[]
    for abi in ('arm64-v8a','armeabi-v7a'):
        result=verify(abi,stage,tables);reports.append(result);print(abi,result['total'],'checks passed',flush=True)
    report={'passed':True,'source':source,'table_sources':{str(i):{'rows':t.row_count,'columns':len(t.types),'sha256':sha} for i,(t,v,sha) in tables.items()},
            'total':sum(r['total'] for r in reports),'architectures':reports,'android_shop_verified':False}
    out=WORK/'local_catalog_verification.json';out.write_text(json.dumps(report,indent=2)+'\n');print(out)

if __name__=='__main__':main()
