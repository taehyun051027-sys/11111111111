#!/usr/bin/env python3
"""Check the final APK against original art and the exact native build outputs."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def digest(value):
    return hashlib.sha256(value).hexdigest()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--original',type=Path,required=True)
    parser.add_argument('--apk',type=Path,required=True)
    parser.add_argument('--native-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert digest(args.original.read_bytes())=='2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484'
    with zipfile.ZipFile(args.original) as original, zipfile.ZipFile(args.apk) as apk:
        assert apk.testzip() is None
        assert len(apk.namelist())==len(set(apk.namelist()))
        prefixes=('assets/bat/','assets/pit/','assets/defender/','assets/stadium/')
        preserved=[name for name in original.namelist() if name.startswith(prefixes)]
        assert len(preserved)==2818
        changed=[name for name in preserved if original.read(name)!=apk.read(name)]
        assert not changed,changed
        cocos=[name for name in original.namelist() if name.startswith('lib/') and '/libcocos' in name]
        assert len(cocos)==4
        assert all(original.read(name)==apk.read(name) for name in cocos)
        natives={}
        for abi in ('arm64-v8a','armeabi-v7a'):
            manifest=json.loads((args.native_root/abi/'integration_manifest.json').read_text())
            raw=apk.read('lib/'+abi+'/libgameDSO.so')
            assert digest(raw)==manifest['output_sha256']
            assert raw==(args.native_root/abi/'libgameDSO.so').read_bytes()
            natives[abi]={key:manifest[key] for key in ('output_sha256','patch_count','semantic_player_schema','semantic_player_scalars','semantic_record_schema','semantic_record_scalars')}
    result={'apk':args.apk.name,'apk_bytes':args.apk.stat().st_size,'apk_sha256':digest(args.apk.read_bytes()),
            'original_player_stadium_resources_preserved':len(preserved),
            'changed_player_stadium_resources':changed,'original_cocos_libraries_unchanged':True,
            'cocos':cocos,'native':natives,'apk_zip_crc_and_unique_names':True,
            'android_gameplay_verified_by_this_script':False}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
