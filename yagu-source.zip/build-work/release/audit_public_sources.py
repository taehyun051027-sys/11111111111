#!/usr/bin/env python3
"""Read-only audit of the release packager's exact public source selection.

No credential contents or matched text are printed. This audits selected source
inputs, not an unpublished archive or gameplay success.
"""
import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from package_project import GENERATED, source_files

PATTERNS = {
    'private_key_pem': re.compile(rb'-----BEGIN (?:RSA |EC |DSA |OPENSSH |ENCRYPTED )?PRIVATE KEY-----'),
    'github_token': re.compile(rb'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b'),
    'openai_key': re.compile(rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}\b'),
    'aws_access_key': re.compile(rb'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
    'literal_bearer': re.compile(rb'(?i)\bbearer[ \t]+[A-Za-z0-9._~+/-]{24,}'),
    'jwt': re.compile(rb'\beyJ[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\b'),
    'signed_url': re.compile(rb'https?://[^\s\x22\x27]{0,1000}[?&](?:sig|X-Amz-Signature)=[A-Za-z0-9%+/=_-]{16,}',re.I),
}
QUOTED_INCLUDE = re.compile(rb'^\s*#\s*include\s*"([^"\n]+)"',re.M)
FORBIDDEN_PARTS = {'private-signing','private-runtime','grpc-runtime','sdk','avd',
                   'node_modules','__pycache__','.git','.sites-runtime','stream'}
FORBIDDEN_SUFFIXES = {'.apk','.so','.elf','.o','.a','.jks','.keystore','.pem','.p12','.pfx'}
PUBLIC_CERT = 'build-work/android/yagu-local-public-certificate.der'
RUNTIME_LOGS = {'intro-gated-actions.json','nickname-gated-actions.json','gameplay_candidate7_trace.json'}


def sha(value):
    return hashlib.sha256(value).hexdigest()


def audit(root,web):
    files=source_files(root,web)
    findings=[]
    for name,raw in files.items():
        path=Path(name)
        if set(path.parts)&FORBIDDEN_PARTS or path.suffix in FORBIDDEN_SUFFIXES or path.name in RUNTIME_LOGS:
            findings.append({'file':name,'category':'forbidden_path'})
        if path.suffix=='.der' and name!=PUBLIC_CERT:
            findings.append({'file':name,'category':'unexpected_der'})
        physical=(web/name.removeprefix('web/')) if name.startswith('web/') else root/name
        boundary=web if name.startswith('web/') else root
        if not physical.resolve().is_relative_to(boundary.resolve()):
            findings.append({'file':name,'category':'source_outside_allowed_root'})
        for category,pattern in PATTERNS.items():
            if pattern.search(raw):findings.append({'file':name,'category':category})
    dependencies={}
    pending=['build-work/native/yagu_payload.c']
    while pending:
        name=pending.pop()
        if name in dependencies:continue
        if name not in files:
            findings.append({'file':name,'category':'missing_quoted_include'});continue
        dependencies[name]=sha(files[name])
        for match in QUOTED_INCLUDE.finditer(files[name]):
            child=match.group(1).decode('utf-8')
            if not re.fullmatch(r'[A-Za-z0-9_][A-Za-z0-9_.-]*',child) or '..' in child:
                findings.append({'file':name,'category':'unsafe_quoted_include'});continue
            pending.append('build-work/native/'+child)
    from cryptography import x509
    cert=x509.load_der_x509_certificate(files[PUBLIC_CERT])
    # Confirm that it is an actual public X.509 object without serializing its
    # public key or any certificate contents into this report.
    assert cert.public_key() is not None
    generated=sorted(n for n in files if n.startswith('build-work/art/generated/'))
    expected=sorted('build-work/art/generated/'+name for name in GENERATED)
    if generated!=expected:findings.append({'category':'unexpected_generated_asset_set'})
    hosting=json.loads(files['web/.openai/hosting.json'])
    def inspect_keys(value):
        if isinstance(value,dict):
            for key,child in value.items():
                if re.search(r'(?:^|_)(?:password|secret|token|authorization|credential|api_key)(?:$|_)',key,re.I):
                    findings.append({'file':'web/.openai/hosting.json','category':'sensitive_manifest_key'})
                inspect_keys(child)
        elif isinstance(value,list):
            for child in value:inspect_keys(child)
    inspect_keys(hosting)
    return {
        'status':'pass' if not findings else 'fail',
        'audited_at_utc':datetime.now(timezone.utc).isoformat(),
        'scope':'current selected public source inputs; not final ZIP or runtime certification',
        'selected_files':len(files),'selected_bytes_at_read':sum(map(len,files.values())),
        'packager_sha256':sha((root/'build-work/release/package_project.py').read_bytes()),
        'auditor_sha256':sha(Path(__file__).read_bytes()),
        'public_certificate_sha256':sha(files[PUBLIC_CERT]),
        'generated_sources':generated,
        'c_quoted_dependencies':dependencies,
        'sensitive_patterns_checked':list(PATTERNS),
        'forbidden_runtime_logs_selected':sorted(n for n in files if Path(n).name in RUNTIME_LOGS),
        'findings':findings,
        'secret_values_printed':False,'private_files_read':False,
        'final_archive_audit_required':True,
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,required=True)
    parser.add_argument('--web-root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    report=audit(args.source_root.resolve(),args.web_root.resolve())
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='c_quoted_dependencies'},ensure_ascii=False,indent=2))
    if report['findings']:raise SystemExit(1)


if __name__=='__main__':main()
