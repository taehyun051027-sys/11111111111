#!/usr/bin/env python3
"""Package reviewed source and art using explicit public-file allowlists.

Original APK/native binaries, signing secrets, SDKs and device state are never
selected. The installed APK is a separate release asset. Archive paths and
checksums are recorded so the web upload can be verified without credentials.
"""
import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath

TEXT_SUFFIXES = {'.py', '.c', '.h', '.inc', '.json', '.md', '.sh'}
GENERATED = ('crests.png', 'extra_crests.png', 'title_logo.png', 'launcher_icon.png')
SECRET_PATTERNS = (
    re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |ENCRYPTED )?PRIVATE KEY-----'),
    re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b'),
    re.compile(rb'\bgithub_pat_[A-Za-z0-9_]{40,}\b'),
)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def add_file(files, path, relative):
    relative_path = PurePosixPath(relative)
    if relative_path.is_absolute() or '..' in relative_path.parts or '\\' in relative:
        raise ValueError('Unsafe archive path: ' + relative)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Expected a regular public source file: ' + str(path))
    if relative in files:
        raise ValueError('Repeated archive path: ' + relative)
    raw = path.read_bytes()
    if any(pattern.search(raw) for pattern in SECRET_PATTERNS):
        raise ValueError('Possible credential in public file: ' + relative)
    files[relative] = raw


def source_files(root, web):
    files = {}
    for name in ('README.md', 'BUILD.md', 'build.py', 'requirements.txt',
                 'requirements-art.txt', '.gitignore'):
        add_file(files, root / name, name)
    groups = (
        ('build-work/native', TEXT_SUFFIXES, False),
        ('build-work/android', {'.py', '.json', '.md', '.sh'}, False),
        ('build-work/art', {'.json', '.md'}, False),
        ('build-work/art/tools', {'.py'}, False),
        ('build-work/release', {'.py'}, False),
        ('analysis/data/tools', {'.py'}, False),
        ('analysis/world-career/docs', {'.md', '.json'}, True),
        ('analysis/world-career/tools', {'.py'}, False),
        ('analysis/black-uniform', {'.md', '.json'}, False),
        ('build-work/native/emulator-gles-repair', {'.json'}, False),
        ('docs', {'.md', '.json'}, True),
    )
    for folder, suffixes, recursive in groups:
        base = root / folder
        if not base.exists():
            continue
        for path in sorted(base.rglob('*') if recursive else base.iterdir()):
            if path.is_file() and path.suffix in suffixes:
                if path.name in {'intro-gated-actions.json', 'nickname-gated-actions.json',
                                 'gameplay_candidate7_trace.json',
                                 'prepare_defender_reference.py'}:
                    continue
                if path.name.startswith('gameplay_') and path.name.endswith('_trace.json'):
                    continue
                add_file(files, path, path.relative_to(root).as_posix())
    certificate = root / 'build-work/android/yagu-local-public-certificate.der'
    from cryptography import x509
    x509.load_der_x509_certificate(certificate.read_bytes())
    add_file(files, certificate, certificate.relative_to(root).as_posix())
    for name in GENERATED:
        path = root / 'build-work/art/generated' / name
        add_file(files, path, path.relative_to(root).as_posix())
    for name in ('client.html', 'package.json', 'CLIENT_CONTRACT.md',
                 '.openai/hosting.json'):
        add_file(files, web / name, 'web/' + name)
    for folder in ('worker', 'scripts', 'tests'):
        for path in sorted((web / folder).rglob('*')):
            if path.is_file() and path.suffix in {'.js', '.mjs', '.py', '.md'}:
                add_file(files, path, 'web/' + path.relative_to(web).as_posix())
    # No permissive recursive copy is used for runtime or build directories.
    forbidden = ('private-signing', 'private-runtime', '/avd/', '/sdk/',
                 '/grpc-python/', '/grpc-generated/', '/node_modules/')
    if any(any(part in name for part in forbidden) for name in files):
        raise ValueError('Private/runtime path in allowlist')
    return files


def write_zip(path, files):
    manifest = [{'path': name, 'bytes': len(raw), 'sha256': digest(raw)}
                for name, raw in sorted(files.items())]
    with zipfile.ZipFile(path, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, raw in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, raw)
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == sorted(files)
        for row in manifest:
            assert digest(archive.read(row['path'])) == row['sha256']
    return {'filename': path.name, 'bytes': path.stat().st_size,
            'sha256': digest(path.read_bytes()), 'entries': manifest}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--web-root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    root, web = args.source_root.resolve(), args.web_root.resolve()
    args.out.mkdir(parents=True, exist_ok=False)
    source = source_files(root, web)
    art = {}
    expected = json.loads((root / 'docs/art/art_overlay_manifest.json').read_text())
    overlay = root / 'overlays/art'
    actual = {p.relative_to(overlay).as_posix() for p in overlay.rglob('*') if p.is_file()}
    assert actual == {row['path'] for row in expected['files']}
    for row in expected['files']:
        path = overlay / row['path']
        assert path.stat().st_size == row['bytes'] and digest(path.read_bytes()) == row['sha256']
        add_file(art, path, 'overlays/art/' + row['path'])
    add_file(art, root / 'docs/art/art_overlay_manifest.json', 'docs/art/art_overlay_manifest.json')
    original_art = {}
    for name in GENERATED:
        add_file(original_art, root / 'build-work/art/generated' / name, name)
    bundles = [write_zip(args.out / name, files) for name, files in (
        ('yagu-source.zip', source), ('yagu-art-overlay.zip', art),
        ('yagu-original-art.zip', original_art))]
    report = {'source_c_sha256': digest((root / 'build-work/native/yagu_payload.c').read_bytes()),
              'art_overlay_version': expected['version'], 'art_overlay_entries': len(expected['files']),
              'private_material_selected': False, 'bundles': bundles}
    (args.out / 'yagu-bundle-report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    for name in ('README.md', 'BUILD.md'):
        (args.out / name).write_bytes((root / name).read_bytes())
    print(json.dumps({**{k:v for k,v in report.items() if k != 'bundles'},
                      'bundles': [{k:v for k,v in b.items() if k != 'entries'} for b in bundles]}, indent=2))


if __name__ == '__main__':
    main()
