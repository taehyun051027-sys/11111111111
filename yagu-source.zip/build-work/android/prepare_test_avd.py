#!/usr/bin/env python3
"""Create the disposable API24 ARMv7 test AVD without touching user devices."""
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
name = "Yagu_API24_ARM"
root = BASE / "avd"
directory = root / (name + ".avd")
if directory.exists():
    raise SystemExit("Test AVD already exists; refusing to replace its data")
directory.mkdir(parents=True)
values = {
    "AvdId": name, "avd.ini.displayname": name, "avd.ini.encoding": "UTF-8",
    "abi.type": "armeabi-v7a", "tag.id": "default", "tag.display": "Default",
    "image.sysdir.1": "system-images/android-24/default/armeabi-v7a/",
    "hw.cpu.arch": "arm", "hw.cpu.model": "cortex-a8", "hw.cpu.ncore": "1",
    "hw.ramSize": "2048", "vm.heapSize": "256",
    "hw.lcd.width": "800", "hw.lcd.height": "480", "hw.lcd.density": "160",
    "hw.lcd.depth": "16", "hw.initialOrientation": "landscape",
    "hw.gpu.enabled": "yes", "hw.gpu.mode": "software",
    "hw.keyboard": "yes", "hw.mainKeys": "yes", "hw.sdCard": "yes",
    "hw.audioInput": "no", "hw.audioOutput": "yes",
    "hw.camera.back": "none", "hw.camera.front": "none",
    "disk.dataPartition.size": "2G", "disk.cachePartition.size": "64M",
    "sdcard.path": str(directory / "sdcard.img"), "sdcard.size": "128M",
    "skin.name": "800x480", "skin.path": "800x480", "skin.dynamic": "yes",
    "showDeviceFrame": "no", "PlayStore.enabled": "false",
    "fastboot.forceColdBoot": "yes", "fastboot.forceFastBoot": "no",
}
(directory / "config.ini").write_text("".join(f"{key}={value}\n" for key, value in values.items()))
(root / (name + ".ini")).write_text(f"avd.ini.encoding=UTF-8\npath={directory}\ntarget=android-24\n")
subprocess.run([str(BASE / "sdk/emulator/mksdcard"), "128M", str(directory / "sdcard.img")], check=True)
print(directory)
