#!/usr/bin/env python3
"""Local-loopback-only policy tests. No external DNS or service is contacted."""
import json
import socket
import socketserver
import threading
from pathlib import Path
from publisher_proxy import PublisherProxy, _header


class Dummy(socketserver.BaseRequestHandler):
    def handle(self):
        self.server.connections += 1
        self.request.settimeout(3)
        raw, extra = _header(self.request)
        if raw.startswith(b"CONNECT "):
            self.request.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            data = extra or self.request.recv(100)
            if data:
                self.request.sendall(data)
        else:
            self.request.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK")


def connect(port, target, host=None):
    sock = socket.create_connection(("127.0.0.1", port), timeout=3)
    sock.sendall(f"CONNECT {target} HTTP/1.1\r\nHost: {host or target}\r\n\r\n".encode())
    response, extra = _header(sock)
    return sock, int(response.split()[1]), extra


def main():
    server = socketserver.ThreadingTCPServer(("127.0.0.1", 0), Dummy)
    server.daemon_threads = True
    server.connections = 0
    threading.Thread(target=server.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{server.server_address[1]}"
    empty = PublisherProxy(url, ())
    allowed = PublisherProxy(url, ("functional.example",))
    guard = PublisherProxy(local_tunnel_port=allowed.port)
    results = {}
    try:
        for target in ("firebaselogging.googleapis.com:443", "advance-service.gamevil.com:443", "functional.example:443"):
            sock, code, _ = connect(empty.port, target)
            sock.close()
            assert code == 403
        assert server.connections == 0
        results["empty_policy_denies_all_without_upstream_connections"] = True
        sock, code, _ = connect(allowed.port, "functional.example:443")
        assert code == 200
        sock.sendall(b"local-test")
        assert sock.recv(100) == b"local-test"
        sock.close()
        assert server.connections == 1
        results["reviewed_host_uses_only_configured_local_dummy_upstream"] = True
        sock, code, _ = connect(allowed.port, "functional.example:443", "telemetry.example:443")
        sock.close()
        assert code >= 400 and server.connections == 1
        results["host_mismatch_rejected_before_upstream"] = True
        for target in ("functional.example:443", f"127.0.0.1:{server.server_address[1]}", "192.0.2.123:443"):
            sock, code, _ = connect(guard.port, target)
            sock.close()
            assert code == 403
        assert server.connections == 1
        results["native_guard_denies_all_nonlocal_proxy_tunnels"] = True
        sock, code, _ = connect(guard.port, f"10.0.2.2:{allowed.port}")
        assert code == 200
        sock.sendall(b"CONNECT functional.example:443 HTTP/1.1\r\nHost: functional.example:443\r\n\r\n")
        response, extra = _header(sock)
        assert response.split()[1] == b"200"
        sock.sendall(b"nested-test")
        assert (extra or sock.recv(100)) == b"nested-test"
        sock.close()
        assert server.connections == 2
        results["nested_local_tunnel_keeps_publisher_filter_in_path"] = True
        sock = socket.create_connection(("127.0.0.1", allowed.port), timeout=3)
        sock.sendall(b"GET http://functional.example/ HTTP/1.1\r\nHost: functional.example\r\n\r\nGET http://telemetry.example/ HTTP/1.1\r\nHost: telemetry.example\r\n\r\n")
        response, _ = _header(sock)
        sock.close()
        assert int(response.split()[1]) >= 400 and server.connections == 2
        results["plain_http_pipeline_escape_rejected"] = True
        results["external_network_requests"] = 0
        result = {"passed": True, "checks": results}
        Path(__file__).with_name("publisher-proxy-tests.json").write_text(json.dumps(result, indent=2))
        print(json.dumps(result, indent=2))
    finally:
        guard.close(); allowed.close(); empty.close()
        server.shutdown(); server.server_close()


if __name__ == "__main__":
    main()
