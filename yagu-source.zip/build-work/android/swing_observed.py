#!/usr/bin/env python3
"""A bounded normal-button batting input after a verified MyPlayer batting card."""
import argparse
import io
import json
import time
import uuid
from pathlib import Path
from PIL import Image,ImageChops,ImageStat

BASE=Path(__file__).resolve().parent
STREAM=BASE/"stream"
SCREENS=BASE/"screens"
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--tag",required=True)
args=parser.parse_args()
if not args.tag.replace("-","").replace("_","").isalnum(): raise SystemExit("Invalid tag")
templates={
 "own_batter":("final7-top2-batter-intro.png",(532,353,674,410)),
 "swing_button":("final7-top2-batter-controls.png",(695,364,744,422))
}
refs={k:Image.open(SCREENS/n).convert("RGB").crop(r) for k,(n,r) in templates.items()}
events=[]
def frame():
 s=json.loads((STREAM/"status.json").read_text())
 if not s.get("online") or time.time()*1000-s["updatedAt"]>5000: raise RuntimeError("Stale stream")
 p=(STREAM/"frame.png").read_bytes();return s,p,Image.open(io.BytesIO(p)).convert("RGB")
def score(im,key):
 return sum(ImageStat.Stat(ImageChops.difference(im.crop(templates[key][1]),refs[key])).mean)/3
def tap(x,y,label):
 now=int(time.time()*1000);n=f"{now}-bat-{uuid.uuid4().hex[:8]}";p=STREAM/"commands"/(n+".tmp")
 p.write_text(json.dumps({"kind":"tap","x":x,"y":y,"createdAt":now}));p.rename(p.with_suffix(".json"))
 ack=STREAM/"acks"/(n+".json");deadline=time.monotonic()+10
 while not ack.exists():
  if time.monotonic()>deadline:raise TimeoutError("No acknowledgment")
  time.sleep(.05)
 r=json.loads(ack.read_text())
 if not r.get("ok"):raise RuntimeError("Input rejected")
 events.append({"action":label,"at_ms":r["completedAt"]});return r["completedAt"]
def save(png,suffix):
 n=f"{args.tag}-{suffix}.png";(SCREENS/n).write_bytes(png);return "screens/"+n
r={"tag":args.tag,"actions":events}
try:
 s,p,im=frame()
 if score(im,"own_batter")>=8:raise RuntimeError("MyPlayer batter card not observed")
 r['before']=save(p,'before')
 t=tap(600,220,"dismiss_batter_card")
 until=time.monotonic()+5
 while time.monotonic()<until:
  s,p,im=frame()
  if s['updatedAt']>t+300 and score(im,'swing_button')<10:break
  time.sleep(.1)
 else:raise RuntimeError('Swing button not observed')
 r['controls']=save(p,'controls')
 # Inputs stay on the visible original batting control, for at most four seconds.
 until=time.monotonic()+4
 while time.monotonic()<until:
  s,p,im=frame()
  if score(im,'swing_button')>=12:break
  t=tap(716,400,'swing_button')
  time.sleep(.25)
 r['after_inputs']=save(frame()[1],'after-inputs')
 until=time.monotonic()+35;next_ms=0;index=0
 while time.monotonic()<until:
  s,p,im=frame()
  if s['updatedAt']>=next_ms:
   save(p,f'flight-{index:02d}');index+=1;next_ms=s['updatedAt']+1000
  time.sleep(.1)
 r['after']=save(frame()[1],'after');r['ok']=True
except Exception as e:
 r.update(ok=False,error=str(e))
 try:r['after']=save(frame()[1],'stopped')
 except Exception:pass
finally:
 with (BASE/'swing-observations.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
 print(json.dumps(r))
