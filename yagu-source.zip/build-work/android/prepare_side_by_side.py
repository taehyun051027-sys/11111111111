#!/usr/bin/env python3
"""Prepare side-by-side Android identity and title resources on an APK copy.

Keeps every Java/JNI component class name intact. Does not change entitlements,
DRM, SDK credentials, network APIs, game saves or native gameplay code.
"""
import argparse
import hashlib
import json
import re
import struct
import zipfile
from pathlib import Path

from apk_android_inspect import EXPECTED_SHA256, chunks, manifest, strings, u16, u32
from prepare_android_labels import rename_table

OLD_PACKAGE = "com.gamevil.bb2013.global"


def pool_with_appended_strings(b, p, additions):
    header, size = u16(b, p + 2), u32(b, p + 4)
    count, styles, flags, start, style_start = struct.unpack_from("<IIIII", b, p + 8)
    if header != 28 or styles or style_start or start != header + 4 * count:
        raise ValueError("Unexpected string pool format; refusing to guess")
    payload = bytes(b[p + start:p + size])
    offsets = bytearray(b[p + header:p + start])
    def encoded_length(n, width):
        limit = 1 << (width * 8 - 1)
        if n < limit:
            return n.to_bytes(width, "little")
        if n >= (limit << (width * 8)):
            raise ValueError("String too long")
        return ((n >> (width * 8)) | limit).to_bytes(width, "little") + (n & ((1 << (width * 8)) - 1)).to_bytes(width, "little")
    for value in additions:
        offsets += struct.pack("<I", len(payload))
        utf16 = value.encode("utf-16le")
        if flags & 256:
            utf8 = value.encode("utf-8")
            encoded = encoded_length(len(utf16) // 2, 1) + encoded_length(len(utf8), 1) + utf8 + b"\0"
        else:
            encoded = encoded_length(len(utf16) // 2, 2) + utf16 + b"\0\0"
        payload += encoded
    payload += b"\0" * ((-len(payload)) % 4)
    new_start = header + len(offsets)
    return struct.pack("<HHIIIIII", 1, header, new_start + len(payload), count + len(additions), 0, flags & ~1, new_start, 0) + offsets + payload


def rewrite_manifest(original, new_package):
    b = bytearray(original)
    pools = [(p, size) for p, kind, _, size in chunks(b, u16(b, 2), len(b)) if kind == 1]
    if len(pools) != 1:
        raise ValueError("Expected one manifest string pool")
    pool_start, pool_size = pools[0]
    pool = strings(b, pool_start)
    additions, new_indices, changes = [], {}, []
    for p, kind, _, _ in chunks(b, u16(b, 2), len(b)):
        if kind != 0x102:
            continue
        tag = pool[u32(b, p + 20)]
        attr_start, attr_size, count = struct.unpack_from("<HHH", b, p + 24)
        for i in range(count):
            q = p + 16 + attr_start + i * attr_size
            key, raw = pool[u32(b, q + 4)], u32(b, q + 8)
            typ, data = b[q + 15], u32(b, q + 16)
            if typ != 3:
                continue
            value = pool[raw if raw != 0xffffffff else data]
            replace = tag == "manifest" and key == "package" and value == OLD_PACKAGE
            replace |= tag in ("permission", "uses-permission", "uses-permission-sdk-23") and key == "name" and value.startswith(OLD_PACKAGE + ".")
            replace |= key in ("authorities", "permission", "readPermission", "writePermission", "taskAffinity", "targetPackage") and (value == OLD_PACKAGE or value.startswith(OLD_PACKAGE + "."))
            if not replace:
                continue
            updated = new_package + value[len(OLD_PACKAGE):]
            if updated not in new_indices:
                new_indices[updated] = len(pool) + len(additions)
                additions.append(updated)
            index = new_indices[updated]
            if raw != 0xffffffff:
                struct.pack_into("<I", b, q + 8, index)
            struct.pack_into("<I", b, q + 16, index)
            changes.append({"tag": tag, "attribute": key, "before": value, "after": updated})
    if not any(x["tag"] == "manifest" and x["attribute"] == "package" for x in changes):
        raise ValueError("Expected source package not found")
    new_pool = pool_with_appended_strings(b, pool_start, additions)
    result = bytearray(b[:pool_start] + new_pool + b[pool_start + pool_size:])
    struct.pack_into("<I", result, 4, len(result))
    before, after = manifest(original), manifest(result)
    if len(before) != len(after):
        raise ValueError("Manifest element count changed")
    for a, z in zip(before, after):
        if a["name"] != z["name"]:
            raise ValueError("Manifest element changed")
        if a["name"] in ("application", "activity", "activity-alias", "receiver", "service", "provider"):
            if a["attrs"].get("android:name") != z["attrs"].get("android:name"):
                raise ValueError("Java component namespace must remain unchanged")
    return bytes(result), changes


def rewrite_resource_package(original, new_package):
    b = bytearray(original)
    updated = 0
    for p, kind, _, _ in chunks(b, u16(b, 2), len(b)):
        if kind == 0x200:
            name = b[p + 12:p + 268].decode("utf-16le").rstrip("\0")
            if name != OLD_PACKAGE:
                raise ValueError("Unexpected resource package")
            encoded = new_package.encode("utf-16le")
            if len(encoded) > 254:
                raise ValueError("Package name too long")
            b[p + 12:p + 268] = encoded + b"\0" * (256 - len(encoded))
            updated += 1
    if updated != 1:
        raise ValueError("Expected one resource package")
    return bytes(b)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("--overlay", type=Path, required=True)
    parser.add_argument("--package", default="com.taehyun.yagu")
    parser.add_argument("--title", default="야구")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]*(?:\.[a-zA-Z][a-zA-Z0-9_]*)+", args.package) or args.package == OLD_PACKAGE:
        raise ValueError("Expected a distinct valid Android application ID")
    raw = args.apk.read_bytes()
    if hashlib.sha256(raw).hexdigest() != EXPECTED_SHA256:
        raise ValueError("APK fingerprint mismatch")
    with zipfile.ZipFile(args.apk) as archive:
        new_manifest, changes = rewrite_manifest(archive.read("AndroidManifest.xml"), args.package)
        new_resources, labels = rename_table(archive.read("resources.arsc"), args.title)
        new_resources = rewrite_resource_package(new_resources, args.package)
    args.overlay.mkdir(parents=True, exist_ok=True)
    (args.overlay / "AndroidManifest.xml").write_bytes(new_manifest)
    (args.overlay / "resources.arsc").write_bytes(new_resources)
    report = {"package": args.package, "title": args.title, "manifest_changes": changes, "label_entries_changed": len(labels),
              "components_and_jni_namespaces_preserved": True,
              "manifest_sha256": hashlib.sha256(new_manifest).hexdigest(), "resources_sha256": hashlib.sha256(new_resources).hexdigest(),
              "runtime_status": "Not installed or launched; hardcoded SDK/package assumptions require runtime validation."}
    (args.overlay.parent / "side_by_side_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
