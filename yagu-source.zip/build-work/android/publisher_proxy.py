#!/usr/bin/env python3
"""Default-deny local test-device egress over the existing managed HTTP proxy.

Publisher mode accepts only exact reviewed hostnames and ports80/443. Guard
mode accepts only a tunnel to the publisher proxy's own loopback port. Neither
mode logs paths, queries, headers, credentials, request bodies or response bodies.
"""
import collections
import json
import select
import socket
import socketserver
import threading
import time
from urllib.parse import urlsplit


def _header(sock):
    data = bytearray()
    while b"\r\n\r\n" not in data:
        part = sock.recv(4096)
        if not part:
            raise ValueError("Incomplete HTTP header")
        data.extend(part)
        if len(data) > 32768:
            raise ValueError("HTTP header too large")
    raw, extra = bytes(data).split(b"\r\n\r\n", 1)
    return raw + b"\r\n\r\n", extra


def _authority(value):
    parsed = urlsplit("//" + value)
    if parsed.username or parsed.password or not parsed.hostname:
        raise ValueError("Invalid proxy authority")
    return parsed.hostname.lower().rstrip("."), parsed.port


class _Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class _Handler(socketserver.BaseRequestHandler):
    def handle(self):
        owner = self.server.owner
        if not owner.slots.acquire(blocking=False):
            return
        upstream = None
        host, method, port = "invalid", "invalid", 0
        try:
            self.request.settimeout(15)
            raw, extra = _header(self.request)
            lines = raw[:-4].decode("iso-8859-1").split("\r\n")
            method, target, version = lines[0].split(" ")
            if version not in ("HTTP/1.0", "HTTP/1.1"):
                raise ValueError("Unsupported HTTP version")
            fields = []
            host_fields = []
            content_lengths = []
            transfer_encoding = False
            for line in lines[1:]:
                if line[:1] in (" ", "\t") or ":" not in line:
                    raise ValueError("Malformed HTTP header")
                key, value = line.split(":", 1)
                if key.lower() == "host":
                    host_fields.append(value.strip())
                if key.lower() == "content-length":
                    content_lengths.append(value.strip())
                transfer_encoding |= key.lower() == "transfer-encoding"
                if key.lower() not in ("proxy-authorization", "proxy-connection", "connection"):
                    fields.append(line)
            if method == "CONNECT":
                host, port = _authority(target)
                if port is None:
                    raise ValueError("CONNECT requires an explicit port")
            else:
                if method not in ("GET", "HEAD", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"):
                    raise ValueError("Unsupported method")
                url = urlsplit(target)
                if url.scheme != "http" or url.username or url.password or not url.hostname:
                    raise ValueError("Expected an absolute HTTP proxy URI")
                host, port = url.hostname.lower().rstrip("."), url.port or 80
            if len(host_fields) > 1:
                raise ValueError("Duplicate Host header")
            if host_fields:
                hh, hp = _authority(host_fields[0])
                if hh != host or (hp is not None and hp != port):
                    raise ValueError("Host and proxy target disagree")

            if owner.local_tunnel_port is not None:
                allowed = method == "CONNECT" and host in ("127.0.0.1", "localhost", "10.0.2.2") and port == owner.local_tunnel_port
            else:
                allowed = host in owner.allowed_hosts and port in (80, 443) and (method == "CONNECT" or port == 80)
            if not allowed:
                owner.record(method, host, port, False, 403)
                self.request.sendall(b"HTTP/1.1 403 Forbidden\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
                return

            if owner.local_tunnel_port is not None:
                upstream = socket.create_connection(("127.0.0.1", owner.local_tunnel_port), timeout=15)
                self.request.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                if extra:
                    upstream.sendall(extra)
                owner.record(method, host, port, True, 200)
            else:
                if method != "CONNECT":
                    if transfer_encoding or len(content_lengths) > 1:
                        raise ValueError("Streaming or ambiguous request bodies are not allowed")
                    length = int(content_lengths[0]) if content_lengths else 0
                    if not 0 <= length <= 8 * 1024 * 1024 or len(extra) > length:
                        raise ValueError("Invalid body length or pipelined request")
                    body = bytearray(extra)
                    while len(body) < length:
                        block = self.request.recv(min(65536, length - len(body)))
                        if not block:
                            raise ValueError("Incomplete request body")
                        body.extend(block)
                    extra = bytes(body)
                    fields.append("Connection: close")
                upstream = socket.create_connection(owner.upstream, timeout=15)
                clean = ("\r\n".join([lines[0], *fields]) + "\r\n\r\n").encode("iso-8859-1")
                upstream.sendall(clean + extra)
                response, response_extra = _header(upstream)
                status = int(response.split(b"\r\n", 1)[0].split(b" ")[1])
                owner.record(method, host, port, True, status)
                self.request.sendall(response + response_extra)
                if method == "CONNECT" and not 200 <= status < 300:
                    return

            last_data = time.monotonic()
            total = 0
            while not owner.stopped.is_set() and time.monotonic() - last_data < 90:
                # A plain HTTP connection handles exactly one reviewed request;
                # never tunnel a later request to an unreviewed host.
                readable = (self.request, upstream) if method == "CONNECT" else (upstream,)
                ready, _, _ = select.select(readable, (), (), 1)
                for source in ready:
                    data = source.recv(65536)
                    if not data:
                        return
                    total += len(data)
                    if total > 64 * 1024 * 1024:
                        raise ValueError("Connection transfer limit reached")
                    (upstream if source is self.request else self.request).sendall(data)
                    last_data = time.monotonic()
        except Exception:
            owner.record(method, host, port, False, 502)
            try:
                self.request.sendall(b"HTTP/1.1 502 Bad Gateway\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
            except OSError:
                pass
        finally:
            if upstream is not None:
                upstream.close()
            owner.slots.release()


class PublisherProxy:
    def __init__(self, managed_proxy_url=None, allowed_hosts=(), local_tunnel_port=None):
        self.local_tunnel_port = local_tunnel_port
        self.allowed_hosts = frozenset(h.lower().rstrip(".") for h in allowed_hosts)
        self.upstream = None
        if local_tunnel_port is None:
            parsed = urlsplit(managed_proxy_url or "")
            if parsed.scheme != "http" or parsed.hostname not in ("127.0.0.1", "localhost") or not parsed.port or parsed.username or parsed.password:
                raise ValueError("Expected the existing credential-free local managed proxy")
            self.upstream = (parsed.hostname, parsed.port)
        elif not isinstance(local_tunnel_port, int) or not 1024 <= local_tunnel_port < 65536:
            raise ValueError("Invalid local publisher-proxy port")
        self.stopped = threading.Event()
        self.slots = threading.BoundedSemaphore(16)
        self.audit = collections.deque(maxlen=128)
        self.audit_lock = threading.Lock()
        self.server = _Server(("127.0.0.1", 0), _Handler)
        self.server.owner = self
        self.port = self.server.server_address[1]
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def record(self, method, host, port, allowed, status):
        with self.audit_lock:
            self.audit.append({"time": int(time.time() * 1000), "method": method, "host": host,
                               "port": port, "allowed": allowed, "status": status})

    def snapshot(self):
        with self.audit_lock:
            return {"bind": "127.0.0.1", "port": self.port, "allowed_hosts": sorted(self.allowed_hosts),
                    "local_tunnel_port": self.local_tunnel_port, "recent": list(self.audit)}

    def close(self):
        self.stopped.set()
        self.server.shutdown()
        self.server.server_close()


class ClosedLoopbackDns:
    """Use a verified closed loopback DNS address, with no external resolver."""
    def __init__(self):
        import errno
        self.address, self.port = "127.0.0.2", 53
        # No privileged port binding is needed. This namespace must explicitly
        # reject the harmless .invalid probe; silence or a DNS response fails
        # closed rather than trusting an unknown local resolver.
        query = b"\x12\x34\x01\x00\x00\x01" + b"\0" * 6 + b"\x07example\x07invalid\0\0\x01\0\x01"
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.settimeout(2)
            sock.connect((self.address, self.port))
            sock.send(query)
            try:
                sock.recv(4096)
            except OSError as error:
                if error.errno == errno.ECONNREFUSED:
                    self.verified_closed = True
                    return
                raise RuntimeError("Could not verify the closed loopback DNS endpoint") from None
        raise RuntimeError("Unexpected DNS service at the configured loopback endpoint")

    def close(self):
        pass
