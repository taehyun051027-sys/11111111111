#!/usr/bin/env python3
"""Exercise the actual emulator file bridge and save a fresh evidence frame."""
import argparse
import json
import time
import uuid
from pathlib import Path

BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("kind", choices=("capture", "tap", "swipe", "back"))
parser.add_argument("coordinates", type=int, nargs="*")
parser.add_argument("--output", required=True, help="Evidence PNG filename under the local screens directory")
parser.add_argument("--settle", type=float, default=0.5, help="Require a frame captured this many seconds after input completion")
args = parser.parse_args()
filename = Path(args.output)
if filename.name != args.output or filename.suffix.lower() != ".png":
    raise ValueError("Output must be a PNG filename, not a path")
stream = BASE / "stream"
deadline = time.monotonic() + 40
min_frame_time = int(time.time() * 1000)
ack = None
if args.kind != "capture":
    command = {"kind": args.kind, "createdAt": min_frame_time}
    if args.kind == "tap" and len(args.coordinates) == 2:
        command.update(zip(("x", "y"), args.coordinates))
    elif args.kind == "swipe" and len(args.coordinates) in (4, 5):
        command.update(zip(("x", "y", "x2", "y2", "duration"), args.coordinates))
    elif args.kind == "back" and not args.coordinates:
        command.update(kind="key", key="back")
    else:
        raise ValueError("Invalid coordinate count")
    name = f"{min_frame_time}-probe-{uuid.uuid4().hex[:8]}"
    tmp = stream / "commands" / (name + ".tmp")
    tmp.write_text(json.dumps(command))
    tmp.rename(tmp.with_suffix(".json"))
    ack_path = stream / "acks" / (name + ".json")
    while not ack_path.exists():
        if time.monotonic() > deadline:
            raise TimeoutError("No input acknowledgment received")
        time.sleep(0.1)
    ack = json.loads(ack_path.read_text())
    if not ack["ok"]:
        raise RuntimeError(ack["error"])
    min_frame_time = ack["completedAt"] + max(0, args.settle) * 1000
while True:
    status = json.loads((stream / "status.json").read_text())
    if status["online"] and status["updatedAt"] >= min_frame_time:
        image = (stream / "frame.png").read_bytes()
        output = BASE / "screens" / filename
        output.parent.mkdir(exist_ok=True)
        output.write_bytes(image)
        print(json.dumps({"screenshot": str(output), "status": status, "ack": ack}))
        break
    if time.monotonic() > deadline:
        raise TimeoutError("No fresh Android frame received")
    time.sleep(0.1)
