#!/usr/bin/env python3
"""Read-only Android package metadata, resources and DEX inventory (stdlib only).

No APK code is executed. Binary offsets are file-relative evidence, not runtime
addresses. This parser targets the ordinary resource and DEX formats observed
in the supplied 1.2.9 APK; unsupported sparse/compact resource types fail closed.
"""
import argparse
import hashlib
import json
import struct
import zipfile
from pathlib import Path

EXPECTED_SHA256 = "2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484"


def u16(b, p):
    return struct.unpack_from("<H", b, p)[0]


def u32(b, p):
    return struct.unpack_from("<I", b, p)[0]


def length(b, p, width):
    value = b[p] if width == 1 else u16(b, p)
    mask = 1 << (8 * width - 1)
    if value & mask:
        extra = b[p + width] if width == 1 else u16(b, p + width)
        return ((value & (mask - 1)) << (8 * width)) + extra, p + 2 * width
    return value, p + width


def strings(b, p):
    if u16(b, p) != 1:
        raise ValueError("Expected string pool")
    count, flags, start = u32(b, p + 8), u32(b, p + 16), u32(b, p + 20)
    result = []
    for i in range(count):
        q = p + start + u32(b, p + u16(b, p + 2) + 4 * i)
        if flags & 256:
            _, q = length(b, q, 1)
            size, q = length(b, q, 1)
            value = b[q:q + size].decode("utf-8", "strict")
        else:
            size, q = length(b, q, 2)
            value = b[q:q + size * 2].decode("utf-16le", "strict")
        result.append(value)
    return result


def chunks(b, start, end):
    p = start
    while p < end:
        kind, header, size = struct.unpack_from("<HHI", b, p)
        if size < header or size == 0 or p + size > end:
            raise ValueError(f"Invalid chunk at {p:#x}")
        yield p, kind, header, size
        p += size
    if p != end:
        raise ValueError("Unaligned chunk boundary")


def manifest(b):
    result, pool, depth = [], [], 0
    for p, kind, header, size in chunks(b, u16(b, 2), len(b)):
        if kind == 1:
            pool = strings(b, p)
        elif kind == 0x102:
            name = pool[u32(b, p + 20)]
            attr_start, attr_size, count = struct.unpack_from("<HHH", b, p + 24)
            attrs = {}
            for i in range(count):
                q = p + 16 + attr_start + attr_size * i
                ns, key, raw = struct.unpack_from("<III", b, q)
                kind_value, value = b[q + 15], u32(b, q + 16)
                prefix = "android:" if ns != 0xffffffff and pool[ns] == "http://schemas.android.com/apk/res/android" else ""
                if raw != 0xffffffff:
                    value = pool[raw]
                elif kind_value == 3:
                    value = pool[value]
                elif kind_value == 1:
                    value = f"@0x{value:08x}"
                elif kind_value == 0x12:
                    value = bool(value)
                attrs[prefix + pool[key]] = value
            result.append({"name": name, "attrs": attrs, "depth": depth})
            depth += 1
        elif kind == 0x103:
            depth -= 1
    return result


def resources(b):
    result, global_strings = [], []
    for p, kind, header, size in chunks(b, u16(b, 2), len(b)):
        if kind == 1:
            global_strings = strings(b, p)
        elif kind == 0x200:
            package_id = u32(b, p + 8)
            type_strings = strings(b, p + u32(b, p + 268))
            key_strings = strings(b, p + u32(b, p + 276))
            for q, subkind, subheader, subsize in chunks(b, p + header, p + size):
                if subkind != 0x201:
                    continue
                type_id, flags = b[q + 8:q + 10]
                if flags:
                    raise ValueError(f"Unsupported resource type flags {flags:#x}")
                count, entries_start = u32(b, q + 12), u32(b, q + 16)
                language = b[q + 28:q + 30].decode("ascii", "replace").strip("\0")
                region = b[q + 30:q + 32].decode("ascii", "replace").strip("\0")
                for i in range(count):
                    off = u32(b, q + subheader + 4 * i)
                    if off == 0xffffffff:
                        continue
                    entry = q + entries_start + off
                    esize, eflags, key_id = struct.unpack_from("<HHI", b, entry)
                    if eflags & 1:
                        continue  # Complex bags are not string labels.
                    value_type = b[entry + esize + 3]
                    value_offset = entry + esize + 4
                    value = u32(b, value_offset)
                    result.append({
                        "id": f"0x{((package_id << 24) | (type_id << 16) | i):08x}",
                        "type": type_strings[type_id - 1],
                        "key": key_strings[key_id],
                        "language": language or "default", "region": region,
                        "value_type": value_type, "value_data": value,
                        "value_data_offset": value_offset,
                        "value": global_strings[value] if value_type == 3 else value,
                    })
    return result


def leb(b, p):
    value = shift = 0
    while True:
        byte = b[p]
        p += 1
        value |= (byte & 127) << shift
        if not byte & 128:
            return value, p
        shift += 7
        if shift > 35:
            raise ValueError("Invalid ULEB128")


def dex(b):
    if not b.startswith(b"dex\n"):
        raise ValueError("Not DEX")
    count, start = u32(b, 56), u32(b, 60)
    ss = []
    for i in range(count):
        _, p = leb(b, u32(b, start + i * 4))
        end = b.index(0, p)
        # Modified UTF-8 differences are immaterial for ASCII class names;
        # replacement decoding avoids assuming all app prose is ordinary UTF-8.
        ss.append(b[p:end].decode("utf-8", "replace"))
    count, start = u32(b, 64), u32(b, 68)
    types = [ss[u32(b, start + i * 4)] for i in range(count)]
    count, start = u32(b, 72), u32(b, 76)
    protos = []
    for i in range(count):
        p = start + i * 12
        args_offset = u32(b, p + 8)
        args = [types[u16(b, args_offset + 4 + j * 2)] for j in range(u32(b, args_offset))] if args_offset else []
        protos.append("(" + "".join(args) + ")" + types[u32(b, p + 4)])
    count, start = u32(b, 88), u32(b, 92)
    methods = []
    for i in range(count):
        p = start + i * 8
        methods.append({"class": types[u16(b, p)], "name": ss[u32(b, p + 4)], "proto": protos[u16(b, p + 2)]})
    count, start = u32(b, 96), u32(b, 100)
    natives, game_methods, game_classes = [], [], []
    for i in range(count):
        p = start + i * 32
        name, superclass, cd = types[u32(b, p)], u32(b, p + 8), u32(b, p + 24)
        is_game = name.startswith(("Lcom/gamevil/bb2013/", "Lcom/gamevil/nexus2/", "Lorg/cocos2dx/")) or name == "Lw8/a;"
        if is_game:
            game_classes.append({"name": name, "superclass": types[superclass] if superclass != 0xffffffff else None})
        if not cd:
            continue
        sf, cd = leb(b, cd)
        instance_fields, cd = leb(b, cd)
        direct_methods, cd = leb(b, cd)
        virtual_methods, cd = leb(b, cd)
        for _ in range(sf + instance_fields):
            _, cd = leb(b, cd)
            _, cd = leb(b, cd)
        for num in (direct_methods, virtual_methods):
            method_id = 0
            for _ in range(num):
                diff, cd = leb(b, cd)
                method_id += diff
                access, cd = leb(b, cd)
                code, cd = leb(b, cd)
                item = {**methods[method_id], "method_idx": method_id, "access_flags": hex(access), "code_off": code}
                if access & 0x100:
                    natives.append(item)
                if is_game:
                    game_methods.append(item)
    return {"magic": b[:8].hex(), "string_count": len(ss), "type_count": len(types), "method_count": len(methods), "class_count": count,
            "native_methods": natives, "game_classes": game_classes, "game_methods": game_methods}


def signing_block_ids(b):
    end = b.rfind(b"PK\x05\x06")
    if end < 0:
        raise ValueError("No ZIP end record")
    central = u32(b, end + 16)
    if b[central - 16:central] != b"APK Sig Block 42":
        return []
    size = struct.unpack_from("<Q", b, central - 24)[0]
    p, finish = central - size, central - 24
    ids = []
    while p < finish:
        pair_size = struct.unpack_from("<Q", b, p)[0]
        if pair_size < 4 or p + 8 + pair_size > finish:
            raise ValueError("Invalid APK signature pair")
        ids.append(f"0x{u32(b, p + 8):08x}")
        p += 8 + pair_size
    return ids


def inspect(apk):
    raw = Path(apk).read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    with zipfile.ZipFile(apk) as archive:
        labels = [row for row in resources(archive.read("resources.arsc")) if row["key"].startswith(("app_label", "app_name"))]
        entries = archive.infolist()
        return {"apk_filename": Path(apk).name, "apk_sha256": sha, "matches_analyzed_input": sha == EXPECTED_SHA256,
                "size_bytes": len(raw), "entry_count": len(entries),
                "manifest": manifest(archive.read("AndroidManifest.xml")), "labels": labels,
                "dex_files": [{"path": x.filename, "size_bytes": x.file_size, "sha256": hashlib.sha256(archive.read(x.filename)).hexdigest(), **dex(archive.read(x.filename))} for x in entries if x.filename.startswith("classes") and x.filename.endswith(".dex") and "/" not in x.filename],
                "native_libraries": [{"path": x.filename, "size_bytes": x.file_size, "sha256": hashlib.sha256(archive.read(x.filename)).hexdigest()} for x in entries if x.filename.startswith("lib/") and x.filename.endswith(".so")],
                "signature_block_ids": signing_block_ids(raw),
                "signature_verification": "Not performed; IDs report block presence only.",
                "execution": "Static inspection only. APK was not installed or executed."}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = inspect(args.apk)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(args.out.resolve()), "matches_analyzed_input": result["matches_analyzed_input"], "apk_sha256": result["apk_sha256"]}))


if __name__ == "__main__":
    main()
