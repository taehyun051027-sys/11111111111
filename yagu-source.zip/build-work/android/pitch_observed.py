#!/usr/bin/env python3
"""One bounded pitch through previously observed, visually gated game controls."""
import argparse
import io
import json
import time
import uuid
from pathlib import Path
from PIL import Image, ImageChops, ImageStat

BASE = Path(__file__).resolve().parent
STREAM = BASE / "stream"
SCREENS = BASE / "screens"
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--tag", required=True)
args = parser.parse_args()
if not args.tag.replace("-", "").replace("_", "").isalnum():
    raise SystemExit("Invalid tag")
templates = {
    "selection": ("final7-first-pitch-result.png", (540,250,600,274)),
    "selected": ("final7-fastball-selected.png", (650,350,720,410)),
    "aim": ("final7-first-pitch-aim.png", (116,351,162,397)),
    "intro": ("final7-pitcher-live.png", (174,356,280,406)),
    "intro_right": ("final7-second-batter-intro.png", (671,356,779,406)),
}
references = {key:Image.open(SCREENS/name).convert("RGB").crop(rect)
              for key,(name,rect) in templates.items()}
events=[]

def frame():
    status=json.loads((STREAM/"status.json").read_text())
    if not status.get("online") or time.time()*1000-status["updatedAt"]>5000:
        raise RuntimeError("Stream is offline or stale")
    png=(STREAM/"frame.png").read_bytes()
    return status,png,Image.open(io.BytesIO(png)).convert("RGB")

def score(im,key):
    diff=ImageChops.difference(im.crop(templates[key][1]),references[key])
    return sum(ImageStat.Stat(diff).mean)/3

def wait_state(key,min_ms=0,timeout=5):
    until=time.monotonic()+timeout
    while time.monotonic()<until:
        status,png,im=frame()
        if status['updatedAt']>=min_ms and score(im,key)<8:
            return status,png,im
        time.sleep(.1)
    raise RuntimeError("Expected observed state not reached: "+key)

def tap(x,y,label):
    timestamp=int(time.time()*1000)
    name=f"{timestamp}-pitch-{uuid.uuid4().hex[:8]}"
    tmp=STREAM/"commands"/(name+".tmp")
    tmp.write_text(json.dumps({"kind":"tap","x":x,"y":y,"createdAt":timestamp}))
    tmp.rename(tmp.with_suffix(".json"))
    ack=STREAM/"acks"/(name+".json")
    until=time.monotonic()+10
    while not ack.exists():
        if time.monotonic()>until: raise TimeoutError("Input not acknowledged")
        time.sleep(.05)
    result=json.loads(ack.read_text())
    if not result.get("ok"): raise RuntimeError("Input rejected")
    events.append({"action":label,"at_ms":result["completedAt"]})
    return result["completedAt"]

def save(png,suffix):
    name=f"{args.tag}-{suffix}.png"
    (SCREENS/name).write_bytes(png)
    return "screens/"+name

result={"tag":args.tag,"actions":events}
try:
    status,png,im=wait_state("selection",timeout=3)
    result["before"]=save(png,"before")
    t=tap(562,260,"select_fastball")
    wait_state("aim",min_ms=t+350)
    t=tap(400,333,"aim_center")
    wait_state("aim",min_ms=t+350)
    t=tap(690,386,"release_pitch")
    until=time.monotonic()+30
    next_capture=t+500
    index=0
    while time.monotonic()<until:
        status,png,im=frame()
        if status["updatedAt"]>=next_capture:
            save(png,f"flight-{index:02d}")
            index+=1
            next_capture=status["updatedAt"]+1000
        if status["updatedAt"]>t+3000:
            found=next((key for key in ("selection","intro","intro_right") if score(im,key)<8),None)
            if found:
                result.update(outcome_state=found,after=save(png,"after"),
                              outcome_at_ms=status["updatedAt"])
                break
        time.sleep(.1)
    else:
        result.update(outcome_state="unknown",after=save(frame()[1],"after"))
    result["ok"]=True
except Exception as e:
    result.update(ok=False,error=str(e))
    try: result["after"]=save(frame()[1],"stopped")
    except Exception: pass
finally:
    log=BASE/"pitch-observations.jsonl"
    with log.open("a") as f: f.write(json.dumps(result)+"\n")
    print(json.dumps(result))
