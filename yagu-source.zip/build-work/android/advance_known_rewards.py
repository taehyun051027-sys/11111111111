#!/usr/bin/env python3
"""Advance only the two observed postgame story/reward screens, with strict bounds."""
import argparse
import io
import json
import time
import uuid
from pathlib import Path
from PIL import Image, ImageChops, ImageStat

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--tag", required=True)
args = parser.parse_args()
if not args.tag.replace("-", "").isalnum():
    raise SystemExit("Invalid tag")
base = Path(__file__).resolve().parent
stream = base / "stream"
screens = base / "screens"
specs = {
    "skip": ("final7-after-bounded-story.png", (714,1,790,24)),
    "nickname": ("final7-postgame-milestone-reward.png", (310,190,493,214)),
}
refs = {key: (Image.open(screens/name).convert("RGB").crop(rect), rect)
        for key,(name,rect) in specs.items()}
actions = []
deadline = time.monotonic() + 45
unknown_since = None
last_ms = 0
while len(actions) < 24 and time.monotonic() < deadline:
    status = json.loads((stream/"status.json").read_text())
    if not status.get("online") or time.time()*1000-status["updatedAt"] > 5000:
        break
    if status["updatedAt"] < last_ms + 900:
        time.sleep(.1)
        continue
    png = (stream/"frame.png").read_bytes()
    im = Image.open(io.BytesIO(png)).convert("RGB")
    kind = next((key for key,(ref,rect) in refs.items()
                 if sum(ImageStat.Stat(ImageChops.difference(im.crop(rect),ref)).mean)/3 < 7), None)
    if kind is None:
        unknown_since = unknown_since or time.monotonic()
        if time.monotonic()-unknown_since > 7:
            break
        time.sleep(.2)
        continue
    unknown_since = None
    x,y = (748,13) if kind == "skip" else (400,292)
    now = int(time.time()*1000)
    name = f"{now}-reward-{uuid.uuid4().hex[:8]}"
    path = stream/"commands"/(name+".tmp")
    path.write_text(json.dumps({"kind":"tap","x":x,"y":y,"createdAt":now}))
    path.rename(path.with_suffix(".json"))
    ack = stream/"acks"/(name+".json")
    until = time.monotonic()+8
    while not ack.exists() and time.monotonic()<until:
        time.sleep(.05)
    if not ack.exists():
        break
    result = json.loads(ack.read_text())
    if not result.get("ok"):
        break
    (screens/f"{args.tag}-{len(actions):02d}.png").write_bytes(png)
    last_ms = result["completedAt"]
    actions.append({"action":kind,"at_ms":last_ms})
    time.sleep(.9)
(base/(args.tag+".json")).write_text(json.dumps(actions,indent=2)+"\n")
(screens/(args.tag+"-after.png")).write_bytes((stream/"frame.png").read_bytes())
print(json.dumps({"actions":len(actions),"tag":args.tag}))
