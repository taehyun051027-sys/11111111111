# Actual Android stream bridge

This bridge captures the running APK's Android framebuffer. It contains no replacement game logic. The game runs in the official ARMv7 Android24 image under the official Android emulator, using software CPU translation and SwiftShader graphics.

## Start

Run the persistent controller in one tool process namespace:

```sh
python3 -u build-work/android/emulator_session.py \
  --avd Yagu_API24_ARM --machine ranchu --arch arm \
  --emulator-root build-work/android/emulator32/emulator --legacy-emulator \
  --bridge-dir build-work/android/stream --bridge-package com.taehyun.yagu
```

Do not start a second emulator against the same AVD. Individual tool processes do not share the running controller's adb server. Apps and data persist in the AVD across orderly controller restarts.

## Shared files

The controller atomically replaces `stream/frame.png` and `stream/status.json`. Status fields are:

```json
{"online":true,"updatedAt":0,"width":800,"height":480,"packageName":"com.taehyun.yagu","note":"Live Android emulator; software rendering, delayed video, no audio","frameSeconds":0.0,"inputSeconds":null,"audio":false}
```

`updatedAt` is Unix epoch milliseconds at completion of the captured frame. A relay must mark old frames offline rather than imply a current connection. `frameSeconds` is capture cost including any adb-lock contention; it is not end-to-end network latency. The `packageName` is the configured intended package, not an assertion about the currently foreground activity.

Write one JSON file per command under `stream/commands/`. Write a temporary file then rename to a unique `.json` filename so the controller never reads a partial command. An optional `createdAt` uses Unix epoch milliseconds; otherwise the file modification time is used. Inputs older than15seconds, future timestamps, out-of-range coordinates or unsupported operations are rejected. Maximum file size is4KB. Commands are processed in filename order, at most16 per frame iteration. Use a sortable timestamp plus random suffix when ordering matters.

Accepted inputs:

```json
{"kind":"tap","x":400,"y":300,"createdAt":0}
{"kind":"swipe","x":400,"y":300,"x2":500,"y2":300,"duration":250,"createdAt":0}
{"kind":"key","key":"back","createdAt":0}
```

Coordinates are intrinsic screenshot pixels, currently800×480. Swipe duration is50–2000milliseconds. No text, shell command, file access, app launch or arbitrary keycode is exposed through this bridge. The authenticated web relay is responsible for owner access and rate limits.

Completion records are written to `stream/acks/<same-filename>.json`, with `ok`, `completedAt`, and `inputSeconds` or an error. The latest128 acknowledgment files are retained. The input file is removed after acknowledgment. The local controller and remote browser share a single device: coordinate UI ownership to avoid conflicting input.

## Limitations

This is a temporary software-emulated dev session. It has no audio stream and no promise of realtime frame rate. The bridge does not remove publisher error dialogs, modify licensing/account code, or fake offline server responses. Network errors must be handled through the game’s existing UI. APK behavior must be evaluated separately from successful streaming.
