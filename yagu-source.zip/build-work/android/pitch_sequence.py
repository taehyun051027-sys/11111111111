#!/usr/bin/env python3
"""Run at most three individually frame-gated pitches, stopping on any new UI."""
import argparse
import json
import subprocess
import sys
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--inning",type=int,required=True)
parser.add_argument("--start",type=int,required=True)
parser.add_argument("--count",type=int,default=3)
args=parser.parse_args()
if not 1<=args.inning<=12 or not 1<=args.start<=150 or not 1<=args.count<=3:
    raise SystemExit("Invalid bounded pitch range")
script=Path(__file__).with_name("pitch_observed.py")
for number in range(args.start,args.start+args.count):
    process=subprocess.run([sys.executable,str(script),"--tag",
        f"final7-b{args.inning}-p{number:02d}"],capture_output=True,text=True,timeout=45)
    if process.returncode:
        print(json.dumps({"stopped":True,"reason":"pitch helper failed"}),flush=True)
        break
    data=json.loads(process.stdout)
    print(json.dumps(data),flush=True)
    if not data.get("ok") or data.get("outcome_state")!="selection":
        break
