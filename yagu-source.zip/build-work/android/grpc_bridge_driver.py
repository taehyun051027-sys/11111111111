"""Optional, local-only official emulator controller adapter.

The emulator's discovery credential is read only into process memory. Nothing
in this module logs or persists that credential. Screenshot, touch, clipboard
write, and actual speaker PCM are the only exposed controller operations.
"""
from pathlib import Path
import re
import threading
import time


class BridgeGrpcDriver:
    def __init__(self, port, xdg_runtime_dir, emulator_pid):
        if type(port) is not int or not 1024 <= port <= 65535:
            raise ValueError('Invalid local emulator controller port')
        if type(emulator_pid) is not int or emulator_pid <= 0:
            raise ValueError('Invalid emulator process identifier')
        self.port = port
        directory = Path(xdg_runtime_dir) / 'avd/running'
        # Actual emulator32 uses pid_N.ini; its help advertises pid_N_info.ini.
        # Read only those two filenames for the explicitly selected process.
        self.discovery_candidates = (directory / f'pid_{emulator_pid}.ini',
                                     directory / f'pid_{emulator_pid}_info.ini')
        self.lock = threading.RLock()
        self.device = None
        self.closed = False
        self.audio_thread = None
        self.audio_stop = threading.Event()
        self.last_packet_ms = 0
        self.last_nonzero_ms = 0
        self.last_chunk_ms = 0

    def _connect(self):
        with self.lock:
            if self.closed:
                raise RuntimeError('Emulator controller is closed')
            if self.device is not None:
                return self.device
            text = None
            for path in self.discovery_candidates:
                try:
                    text = path.read_text(encoding='utf-8')
                    break
                except FileNotFoundError:
                    continue
                except (OSError, UnicodeError):
                    raise RuntimeError('Local emulator controller discovery is not ready') from None
            if text is None:
                raise RuntimeError('Local emulator controller discovery is not ready')
            match = re.search(r'^\s*grpc\.token\s*=\s*([^\r\n]+)', text, re.MULTILINE)
            if not match:
                raise RuntimeError('Local emulator controller credential is not ready')
            token = match.group(1).strip()
            if token[:1] in ('"', "'") and token[-1:] == token[:1]:
                token = token[1:-1]
            if not token or len(token) > 16384 or '\x00' in token:
                raise RuntimeError('Invalid local emulator controller discovery')
            from grpc_device import GrpcDevice
            self.device = GrpcDevice(port=self.port, token=token)
            return self.device

    def screenshot(self):
        png = self._connect().screenshot()['png']
        if not isinstance(png, bytes) or not png.startswith(b'\x89PNG\r\n\x1a\n'):
            raise RuntimeError('Emulator controller returned no PNG frame')
        return png

    def input(self, command):
        if not isinstance(command, dict):
            raise ValueError('Invalid emulator input')
        device = self._connect()
        if command.get('kind') == 'key' and command.get('key') == 'back':
            device.input({'kind': 'key', 'key': 'back'})
            return
        kind = command.get('kind')
        if kind not in ('tap', 'swipe'):
            raise ValueError('Only tap, swipe and back inputs are accepted')
        names = ('x', 'y', 'x2', 'y2') if kind == 'swipe' else ('x', 'y')
        for name in names:
            value = command.get(name)
            limit = device.width if name.startswith('x') else device.height
            if type(value) is not int or not 0 <= value < limit:
                raise ValueError('Emulator input is outside the current frame')
        if kind == 'swipe' and (type(command.get('duration')) is not int or not 50 <= command['duration'] <= 2000):
            raise ValueError('Swipe duration must be 50 through 2000 ms')
        device.input({key: command[key] for key in ('kind', *names, *(['duration'] if kind == 'swipe' else []))})

    def set_clipboard(self, text):
        if not isinstance(text, str) or '\x00' in text or len(text.encode('utf-8')) > 4096:
            raise ValueError('Invalid clipboard text')
        device = self._connect()
        # Writes a caller-provided value only; never reads the system clipboard.
        import emulator_controller_pb2 as pb
        device.stub.setClipboard(pb.ClipData(text=text), metadata=device.metadata, timeout=3)

    def audio_status(self):
        now = int(time.time() * 1000)
        with self.lock:
            recent = not self.closed and 0 <= now - self.last_packet_ms <= 3000
            nonzero = recent and 0 <= now - self.last_nonzero_ms <= 3000
            return {'audio': recent, 'lastPacketMs': self.last_packet_ms,
                    'nonzeroRecent': nonzero}

    def _write_chunk(self, directory, pcm):
        if not pcm or len(pcm) % 2 or len(pcm) > 48000:
            raise ValueError('Invalid mono S16 speaker chunk')
        # Chunk names are immutable; distinct packets never overwrite a file.
        stamp = max(int(time.time() * 1000), self.last_chunk_ms + 1)
        self.last_chunk_ms = stamp
        target = directory / f'{stamp}.pcm'
        temporary = directory / f'{stamp}.tmp'
        temporary.write_bytes(pcm)
        temporary.replace(target)
        for old in sorted(directory.glob('*.pcm'))[:-16]:
            old.unlink(missing_ok=True)

    def start_audio(self, streamdir, stop_event):
        with self.lock:
            if self.closed:
                raise RuntimeError('Emulator controller is closed')
            if self.audio_thread is not None and self.audio_thread.is_alive():
                return
            directory = Path(streamdir) / 'audio'
            directory.mkdir(parents=True, exist_ok=True)
            self.audio_stop.clear()

            def stopped():
                return stop_event.is_set() or self.audio_stop.is_set()

            def capture():
                while not stopped():
                    pending = bytearray()
                    try:
                        for packet in self._connect().audio():
                            if stopped():
                                break
                            pcm = packet.get('pcm')
                            if packet.get('rate') != 24000 or packet.get('channels') != 1:
                                raise ValueError('Unexpected speaker format')
                            if not isinstance(pcm, bytes) or not pcm or len(pcm) % 2 or len(pcm) > 1048576:
                                raise ValueError('Invalid speaker packet')
                            now = int(time.time() * 1000)
                            with self.lock:
                                self.last_packet_ms = now
                                if any(pcm):
                                    self.last_nonzero_ms = now
                            pending.extend(pcm)
                            # 500 ms * 24,000 samples/s * two bytes/sample.
                            while len(pending) >= 24000:
                                self._write_chunk(directory, bytes(pending[:24000]))
                                del pending[:24000]
                        if pending:
                            self._write_chunk(directory, bytes(pending))
                    except Exception:
                        # Errors may include gRPC metadata; never print them.
                        pass
                    self.audio_stop.wait(0.5)

            self.audio_thread = threading.Thread(target=capture, name='yagu-emulator-speaker', daemon=True)
            self.audio_thread.start()

    def close(self):
        with self.lock:
            if self.closed:
                return
            self.closed = True
            self.audio_stop.set()
            device, self.device = self.device, None
        if device is not None:
            device.close()
        if self.audio_thread is not None:
            self.audio_thread.join(timeout=2)
