#!/usr/bin/env python3
"""Set supported bundled Firebase collection opt-outs in compiled manifest only.

Preserves every other element/attribute and all code, permissions and game checks.
The disposable test device also uses default-deny egress; manifest flags alone
do not override preferences saved by prior SDK versions.
"""
import argparse
import hashlib
import json
import struct
from pathlib import Path
from apk_android_inspect import chunks, manifest, strings, u16, u32
from prepare_side_by_side import pool_with_appended_strings

FLAGS = {
    "firebase_analytics_collection_deactivated": True,
    "firebase_analytics_collection_enabled": False,
    "google_analytics_adid_collection_enabled": False,
    "firebase_crashlytics_collection_enabled": False,
    "firebase_data_collection_default_enabled": False,
    "firebase_messaging_auto_init_enabled": False,
}


def prepare(original):
    b = bytearray(original)
    parts = list(chunks(b, u16(b, 2), len(b)))
    p, _, _, pool_size = next(row for row in parts if row[1] == 1)
    pool = strings(b, p)
    additions = []
    lookup = {value: i for i, value in enumerate(pool)}
    def index(value):
        if value not in lookup:
            lookup[value] = len(pool) + len(additions)
            additions.append(value)
        return lookup[value]
    ns = index("http://schemas.android.com/apk/res/android")
    name_key, value_key, tag_index = index("name"), index("value"), index("meta-data")
    for key in FLAGS:
        index(key)
    seen = set()
    depth = 0
    application_child_depth = None
    insert_before = None
    for off, kind, _, _ in parts:
        if kind == 0x102:
            tag = pool[u32(b, off + 20)]
            if tag == "application":
                application_child_depth = depth + 1
            if tag == "meta-data" and depth == application_child_depth:
                start, size, count = struct.unpack_from("<HHH", b, off + 24)
                attrs = {pool[u32(b, off + 16 + start + i * size + 4)]: off + 16 + start + i * size for i in range(count)}
                nq = attrs.get("name")
                if nq is not None and b[nq + 15] == 3:
                    key = pool[u32(b, nq + 16)]
                    if key in FLAGS:
                        if key in seen or "value" not in attrs:
                            raise ValueError("Duplicate or non-value collection metadata")
                        q = attrs["value"]
                        struct.pack_into("<I", b, q + 8, 0xffffffff)
                        b[q + 15] = 0x12
                        struct.pack_into("<I", b, q + 16, 0xffffffff if FLAGS[key] else 0)
                        seen.add(key)
            depth += 1
        elif kind == 0x103:
            depth -= 1
            if pool[u32(b, off + 20)] == "application":
                insert_before = off
    if insert_before is None:
        raise ValueError("Application element not found")
    nodes = bytearray()
    for key, value in FLAGS.items():
        if key in seen:
            continue
        attr_name = struct.pack("<IIIHBBI", ns, name_key, index(key), 8, 0, 3, index(key))
        attr_value = struct.pack("<IIIHBBI", ns, value_key, 0xffffffff, 8, 0, 0x12, 0xffffffff if value else 0)
        nodes += struct.pack("<HHIII", 0x102, 16, 76, 0, 0xffffffff)
        nodes += struct.pack("<IIHHHHHH", 0xffffffff, tag_index, 20, 20, 2, 0, 0, 0)
        nodes += attr_name + attr_value
        nodes += struct.pack("<HHIIIII", 0x103, 16, 24, 0, 0xffffffff, 0xffffffff, tag_index)
    new_pool = pool_with_appended_strings(b, p, additions)
    result = bytearray(b[:u16(b, 2)])
    for off, kind, _, size in parts:
        if off == insert_before:
            result += nodes
        result += new_pool if kind == 1 else b[off:off + size]
    struct.pack_into("<I", result, 4, len(result))
    before, after = manifest(original), manifest(result)
    def unrelated(rows):
        return [row for row in rows if not (row["name"] == "meta-data" and row["attrs"].get("android:name") in FLAGS)]
    if unrelated(before) != unrelated(after):
        raise ValueError("Unrelated manifest content changed")
    actual = {row["attrs"]["android:name"]: row["attrs"].get("android:value") for row in after
              if row["name"] == "meta-data" and row["attrs"].get("android:name") in FLAGS}
    if actual != FLAGS:
        raise ValueError("Collection flags do not match the requested values")
    return bytes(result)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_manifest", type=Path)
    parser.add_argument("--overlay", type=Path, required=True)
    args = parser.parse_args()
    original = args.source_manifest.read_bytes()
    result = prepare(original)
    args.overlay.mkdir(parents=True, exist_ok=True)
    (args.overlay / "AndroidManifest.xml").write_bytes(result)
    report = {"source_sha256": hashlib.sha256(original).hexdigest(), "output_sha256": hashlib.sha256(result).hexdigest(),
              "flags": FLAGS, "other_manifest_content_preserved": True, "runtime_not_yet_verified": True}
    (args.overlay.parent / "privacy-metadata-report.json").write_text(json.dumps(report, indent=2))
    print(json.dumps(report))


if __name__ == "__main__":
    main()
