#!/usr/bin/env python3
"""Record the existing local Android frame stream without issuing device input."""
import argparse
import hashlib
import json
import subprocess
import time
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--name", required=True)
parser.add_argument("--max-seconds", type=int, default=3600)
args = parser.parse_args()
if not args.name.replace("-", "").replace("_", "").isalnum():
    raise SystemExit("Invalid recording name")
if not 1 <= args.max_seconds <= 7200:
    raise SystemExit("Invalid duration")
base = Path(__file__).resolve().parent
stream = base / "stream"
out = base / "recordings"
out.mkdir(exist_ok=True)
stop = out / (args.name + ".stop")
video = out / (args.name + ".mp4")
manifest = out / (args.name + ".frames.jsonl")
if video.exists() or manifest.exists():
    raise SystemExit("Refusing to overwrite a recording")
process = subprocess.Popen([
    "ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "image2pipe",
    "-framerate", "2", "-vcodec", "png", "-i", "pipe:0", "-an",
    "-c:v", "libx264", "-preset", "veryfast", "-crf", "26",
    "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(video)
], stdin=subprocess.PIPE)
started = time.monotonic()
count = 0
try:
    with manifest.open("x") as log:
        while time.monotonic() - started < args.max_seconds and not stop.exists():
            tick = time.monotonic()
            status = json.loads((stream / "status.json").read_text())
            now = int(time.time() * 1000)
            if status.get("online") and now - status["updatedAt"] < 15000:
                frame = (stream / "frame.png").read_bytes()
                process.stdin.write(frame)
                log.write(json.dumps({"index": count, "recorded_at_ms": now,
                    "frame_at_ms": status["updatedAt"],
                    "sha256": hashlib.sha256(frame).hexdigest()}) + "\n")
                log.flush()
                count += 1
            time.sleep(max(0, .5 - (time.monotonic() - tick)))
finally:
    process.stdin.close()
    code = process.wait(timeout=30)
    print(json.dumps({"video": str(video), "frames": count, "code": code,
        "elapsed_seconds": round(time.monotonic() - started, 2)}), flush=True)
