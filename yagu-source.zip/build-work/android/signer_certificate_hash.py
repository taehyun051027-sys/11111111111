#!/usr/bin/env python3
"""Derive the existing Android Signature.hashCode value from a public certificate.

This utility accepts public DER certificate bytes or a signed APK's public PKCS7
certificate block. It never accepts or opens a private keystore/password. APK
extraction needs the cryptography Python package; DER input uses only stdlib.
"""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path


def signature_hash(der):
    value = 1
    for byte in der:
        value = (31 * value + (byte if byte < 128 else byte - 256)) & 0xffffffff
    return value if value < 0x80000000 else value - 0x100000000


def public_certificates(path):
    if path.suffix.lower() == ".der":
        return [path.read_bytes()]
    if path.suffix.lower() != ".apk":
        raise ValueError("Input must be a public .der certificate or signed .apk")
    from cryptography.hazmat.primitives.serialization import Encoding, pkcs7
    result = []
    with zipfile.ZipFile(path) as archive:
        blocks = [name for name in archive.namelist()
                  if name.upper().startswith("META-INF/") and name.upper().endswith((".RSA", ".DSA", ".EC"))]
        for name in blocks:
            result.extend(c.public_bytes(Encoding.DER) for c in pkcs7.load_der_pkcs7_certificates(archive.read(name)))
    if not result:
        raise ValueError("No v1 public signing certificate found; use an exported public DER certificate")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("public_input", type=Path)
    parser.add_argument("--expected-sha256", help="Optional exact public certificate fingerprint")
    args = parser.parse_args()
    records = []
    for der in public_certificates(args.public_input):
        digest = hashlib.sha256(der).hexdigest()
        if args.expected_sha256 and digest != args.expected_sha256.lower():
            raise ValueError("Public certificate fingerprint does not match the expected signer")
        value = signature_hash(der)
        records.append({"certificate_sha256": digest, "certificate_bytes": len(der),
                        "android_signature_hashCode_signed": value,
                        "android_signature_hashCode_hex": f"0x{value & 0xffffffff:08x}"})
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
