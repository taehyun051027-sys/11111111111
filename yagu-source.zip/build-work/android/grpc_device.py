"""Official emulator-controller client for the temporary private dev device.

Run in the emulator's process namespace. Generated protobuf modules come from
that installed emulator's own lib/emulator_controller.proto. This class exposes
only framebuffer, tap/swipe/back and speaker capture, never arbitrary shell.
"""
from pathlib import Path
import sys,time
BASE=Path(__file__).resolve().parent
sys.path[:0]=[str(BASE/'grpc-python'),str(BASE/'grpc-generated')]
import grpc
import emulator_controller_pb2 as pb
import emulator_controller_pb2_grpc as rpc

class GrpcDevice:
    def __init__(self,port=8554,token=None):
        if not isinstance(port,int) or not 1024<=port<65536:raise ValueError('Invalid local controller port')
        self.channel=grpc.insecure_channel(f'127.0.0.1:{port}',options=[('grpc.max_receive_message_length',5000000)])
        self.stub=rpc.EmulatorControllerStub(self.channel)
        self.metadata=(('authorization','Bearer '+token),) if token else ()
        self.width=800;self.height=480

    def screenshot(self):
        frame=self.stub.getScreenshot(pb.ImageFormat(format=pb.ImageFormat.PNG),metadata=self.metadata,timeout=5)
        if not frame.image.startswith(b'\x89PNG'):raise ValueError('Controller returned no PNG')
        self.width=frame.format.width or frame.width
        self.height=frame.format.height or frame.height
        return {'png':frame.image,'width':self.width,'height':self.height,
                'timestamp':frame.timestampUs//1000 if frame.timestampUs else int(time.time()*1000)}

    def point(self,x,y,pressure):
        if type(x)is not int or type(y)is not int or not(0<=x<self.width and 0<=y<self.height):raise ValueError('Touch outside display')
        self.stub.sendTouch(pb.TouchEvent(touches=[pb.Touch(x=x,y=y,identifier=0,pressure=pressure)]),metadata=self.metadata,timeout=3)

    def input(self,cmd):
        kind=cmd.get('kind')
        if kind=='key' and cmd.get('key')=='back':
            self.stub.sendKey(pb.KeyboardEvent(key='GoBack',eventType=pb.KeyboardEvent.keypress),metadata=self.metadata,timeout=3);return
        if kind not in ('tap','swipe'):raise ValueError('Unsupported input')
        x,y=cmd['x'],cmd['y']
        self.point(x,y,1)
        try:
            if kind=='tap':time.sleep(.06)
            else:
                duration=cmd['duration']
                if type(duration)is not int or not 50<=duration<=2000:raise ValueError('Invalid swipe duration')
                x2,y2=cmd['x2'],cmd['y2']
                if type(x2)is not int or type(y2)is not int or not(0<=x2<self.width and 0<=y2<self.height):raise ValueError('Swipe outside display')
                count=max(2,min(40,duration//25));start=time.monotonic()
                for i in range(1,count+1):
                    delay=start+duration/1000*i/count-time.monotonic()
                    if delay>0:time.sleep(delay)
                    x=round(cmd['x']+(x2-cmd['x'])*i/count);y=round(cmd['y']+(y2-cmd['y'])*i/count)
                    self.point(x,y,1)
        finally:self.point(x,y,0)

    def audio(self):
        fmt=pb.AudioFormat(samplingRate=24000,channels=pb.AudioFormat.Mono,format=pb.AudioFormat.AUD_FMT_S16,mode=pb.AudioFormat.MODE_REAL_TIME)
        for packet in self.stub.streamAudio(fmt,metadata=self.metadata):
            if packet.audio:yield {'pcm':packet.audio,'timestamp':packet.timestamp//1000,
                                  'rate':packet.format.samplingRate or 24000,'channels':1}

    def close(self):self.channel.close()
