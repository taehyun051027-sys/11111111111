#!/usr/bin/env python3
"""Check the concrete stale-PID regression with in-memory controller doubles."""
from pathlib import Path
from types import SimpleNamespace
import os
import sys
import tempfile
import time
from grpc_bridge_driver import BridgeGrpcDriver


class Device:
    created = []
    def __init__(self, port, token):
        self.token, self.closed = token, False
        Device.created.append(self)
    def close(self):
        self.closed = True


sys.modules['grpc_device'] = SimpleNamespace(GrpcDevice=Device)
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    log = root / 'child.log'
    path = root / 'pid_16.ini'
    log.write_text(f'INFO | Advertising in: {path}\n')
    path.write_text('grpc.token=old-test-token\n')
    started = time.time_ns()
    os.utime(path, ns=(started - 1000000000, started - 1000000000))
    driver = BridgeGrpcDriver(8554, root, 16, emulator_log=log, child_started_ns=started)
    try:
        driver._connect()
        raise AssertionError('Stale same-PID file was accepted')
    except RuntimeError:
        pass
    assert not Device.created
    path.write_text('grpc.token=fresh-test-token\n')
    os.utime(path, ns=(started + 1, started + 1))
    first = driver._connect()
    assert first.token == 'fresh-test-token'
    assert driver._connect() is first
    path.write_text('grpc.token=rotated-test-token\n')
    os.utime(path, ns=(started + 2, started + 2))
    second = driver._connect()
    assert second is not first and first.closed
    class Unauthorized(Exception):
        def code(self):
            return SimpleNamespace(name='UNAUTHENTICATED')
    driver._rpc_failed(Unauthorized())
    assert second.closed and driver.device is None
    assert driver._connect() is not second
    log.write_text(f'INFO | Advertising in: {root / "pid_17.ini"}\n')
    try:
        driver._connect()
        raise AssertionError('Wrong-PID advertised file was accepted')
    except RuntimeError:
        pass
    driver.close()
print('PASS: stale PID rejected, exact current path selected, file rotation refreshed, auth failure invalidated, wrong PID rejected; no network')
