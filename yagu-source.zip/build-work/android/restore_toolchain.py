#!/usr/bin/env python3
"""Restore the pinned official Android toolchain used by the guarded test AVD.

Downloads use the process's normal HTTPS proxy and certificate trust. The
published Google repository SHA-1 values are checked before extraction; the
local record additionally stores SHA-256 for each archive. No SDK executable
or guest app is launched by this helper.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path, PurePosixPath
from urllib.request import urlopen
import hashlib
import json
import os
import stat
import zipfile
import argparse

BASE = Path(__file__).resolve().parent
DOWNLOADS = BASE / "downloads"
SDK = BASE / "sdk"
ARTIFACTS = (
    ("emulator37.2.13", "emulator-linux_x64-16740729.zip", 349658551,
     "f41f9e31eb5ca64926603c03265c50bbc0ff4172", "", ""),
    ("platform-tools37.0.1", "platform-tools_r37.0.1-linux.zip", 9054187,
     "477254aa5f903c15cf51001717bdf347fb6b53e0", "", ""),
    ("build-tools35.0.0", "build-tools_r35_linux.zip", 61958799,
     "2cfaa0bbb2336e9ec18ed3ecea84fa2e2af607bc", "", ""),
    ("api24-armv7-r7", "armeabi-v7a-24_r07.zip", 283677512,
     "3454546b4eed2d6c3dd06d47757d6da9f4176033", "sys-img/android/",
     "system-images/android-24/default"),
)
LEGACY_ARTIFACT = (
    "emulator32.1.14", "emulator-linux_x64-10330179.zip", 270178945,
    "e08f3acf9900810e877fbc7f816a9dad99889f5c1d18bd78d214fea59d359e17", "", "",
)


def hashes(path):
    sha1, sha256 = hashlib.sha1(), hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            sha1.update(data)
            sha256.update(data)
    return sha1.hexdigest(), sha256.hexdigest()


def restore(item):
    name, filename, size, expected_checksum, prefix, destination = item
    target = DOWNLOADS / filename
    url = "https://dl.google.com/android/repository/" + prefix + filename
    if not target.exists():
        partial = target.with_suffix(target.suffix + ".part")
        with urlopen(url, timeout=60) as response, partial.open("wb") as stream:
            while chunk := response.read(1024 * 1024):
                stream.write(chunk)
        partial.replace(target)
    actual_sha1, actual_sha256 = hashes(target)
    actual_checksum = actual_sha256 if len(expected_checksum) == 64 else actual_sha1
    if target.stat().st_size != size or actual_checksum != expected_checksum:
        raise ValueError(f"Official archive integrity mismatch: {filename}")
    output = SDK / destination
    output.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target) as archive:
        for entry in archive.infolist():
            relative = PurePosixPath(entry.filename)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError("Unexpected archive path")
            mode = entry.external_attr >> 16
            if stat.S_ISLNK(mode):
                link = archive.read(entry).decode("utf-8")
                link_path = output / entry.filename
                if not (link_path.parent / link).resolve().is_relative_to(output.resolve()):
                    raise ValueError("Archive symlink leaves toolchain directory")
                link_path.parent.mkdir(parents=True, exist_ok=True)
                link_path.unlink(missing_ok=True)
                link_path.symlink_to(link)
            else:
                extracted = Path(archive.extract(entry, output))
                if mode:
                    os.chmod(extracted, stat.S_IMODE(mode))
    record = {"name": name, "url": url, "bytes": size,
              "sha1": actual_sha1, "sha256": actual_sha256,
              "destination": str(output)}
    print(json.dumps(record), flush=True)
    return record


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--legacy", action="store_true", help="Restore official32.1.14 separately, before applying the reviewed renderer compatibility repair")
    args = parser.parse_args()
    artifacts = (LEGACY_ARTIFACT,) if args.legacy else ARTIFACTS
    if args.legacy:
        SDK = BASE / "emulator32"
    DOWNLOADS.mkdir(parents=True, exist_ok=True)
    SDK.mkdir(parents=True, exist_ok=True)
    if not args.legacy:
        (SDK / "platforms").mkdir(exist_ok=True)
    with ThreadPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(restore, artifacts))
    record_name = "legacy-toolchain-recovery.json" if args.legacy else "toolchain-recovery.json"
    (BASE / record_name).write_text(json.dumps(records, indent=2) + "\n")
