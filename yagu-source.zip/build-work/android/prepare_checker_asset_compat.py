#!/usr/bin/env python3
"""Repair a bundled checker asset filename mismatch without changing policy.

The original SDK opens 20140120.omg, but this exact APK bundles 20140212.omg.
Copy only those already-present bytes to the expected filename. No checker,
checksum, validation branch, remote response, account, or license is fabricated.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

APK_SHA256 = '2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484'
ASSET_SHA256 = 'cadb7ba03c14fea6ee37af569c3632cf720963a706222af61ac1605418bfbf80'
SOURCE = 'assets/20140212.omg'
TARGET = 'assets/20140120.omg'


def prepare(apk, overlay, report_path):
    original = apk.read_bytes()
    if hashlib.sha256(original).hexdigest() != APK_SHA256:
        raise ValueError('Unsupported original APK fingerprint')
    with zipfile.ZipFile(apk) as archive:
        if TARGET in archive.namelist():
            raise ValueError('Expected missing filename is already present; refusing to guess')
        asset = archive.read(SOURCE)
    if hashlib.sha256(asset).hexdigest() != ASSET_SHA256:
        raise ValueError('Bundled checker asset fingerprint mismatch')
    document = ET.fromstring(base64.b64decode(asset))
    items = [element.text or '' for element in document.iter('item')]
    checksums = [element.text or '' for element in document.iter('jhs')]
    # This is the original SDK's existing format/checksum, not a new policy.
    policy_checksum = hashlib.md5(';'.join(items).encode('utf-8')).hexdigest()
    if document.tag != 'nexus2' or len(items) != 265 or checksums != [policy_checksum]:
        raise ValueError('Original bundled policy does not pass its existing checksum')
    target = overlay / TARGET
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_bytes() != asset:
        raise ValueError('Refusing to replace a different existing compatibility asset')
    target.write_bytes(asset)
    assert target.read_bytes() == asset
    report = {
        'source_apk_sha256': APK_SHA256,
        'source_entry': SOURCE, 'target_entry': TARGET,
        'source_asset_sha256': ASSET_SHA256, 'target_asset_sha256': ASSET_SHA256,
        'bytes': len(asset), 'original_policy_items': len(items),
        'existing_policy_checksum_valid': True, 'byte_for_byte_copy': True,
        'policy_content_changed': False, 'dex_or_native_code_changed': False,
        'checker_parser_checksum_comparisons_and_failure_branches_preserved': True,
        'normal_trigger': 'Original Retry button invokes checker with froyo; unavailable remote configuration uses its original local asset fallback.',
        'runtime_verified': False,
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    if hashlib.sha256(apk.read_bytes()).hexdigest() != APK_SHA256:
        raise ValueError('Original APK changed unexpectedly')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('apk', type=Path)
    parser.add_argument('--overlay', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(prepare(args.apk, args.overlay, args.report), indent=2))
