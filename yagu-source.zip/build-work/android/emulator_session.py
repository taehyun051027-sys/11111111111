#!/usr/bin/env python3
"""Keep a fresh test emulator and adb in one tool process namespace.

Newline JSON commands: status; adb with argument array; screenshot with path;
stop. This is a local verification harness, not part of the APK.
"""
import json
import argparse
import os
import subprocess
import sys
import threading
import time
from urllib.parse import urlparse
from pathlib import Path
from publisher_proxy import PublisherProxy, ClosedLoopbackDns

BASE = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--avd", default="Yagu_API30_ARM64")
parser.add_argument("--machine", choices=("ranchu", "virt"), default="virt")
parser.add_argument("--emulator-root", type=Path, default=BASE / "sdk/emulator")
parser.add_argument("--legacy-emulator", action="store_true")
parser.add_argument("--arch", choices=("arm64", "arm"), default="arm64")
parser.add_argument("--gpu", choices=("software", "swiftshader_indirect", "guest", "host"), default="software",
                    help="Official emulator renderer mode; emulator37 software uses its matching ANGLE libraries")
parser.add_argument("--bridge-dir", type=Path, help="Publish real emulator frames and consume bounded touch input from shared files")
parser.add_argument("--bridge-interval", type=float, default=0.25, help="Minimum pause between frame captures; capture cost adds latency")
parser.add_argument("--bridge-package", default="com.taehyun.yagu")
parser.add_argument("--writable-system", action="store_true", help="Official disposable-AVD system overlay for managed test CA provisioning")
parser.add_argument("--enable-audio", action="store_true", help="Allow the emulator's real audio backend and optional controller capture")
parser.add_argument("--grpc-port", type=int, default=0, help="Optional localhost token-authenticated official emulator controller")
args = parser.parse_args()
avd_name = args.avd
audio_enabled = args.enable_audio
ADB = BASE / "sdk/platform-tools/adb"
SERIAL = "emulator-5560"
env = os.environ.copy()
emu_root = args.emulator_root.resolve()
gles_directory = "lib64/gles_angle" if args.gpu == "software" else "lib64/gles_swiftshader"
env.update(ANDROID_AVD_HOME=str(BASE / "avd"), ANDROID_SDK_ROOT=str(BASE / "sdk"), ANDROID_HOME=str(BASE / "sdk"), ANDROID_EMULATOR_LAUNCHER_DIR=str(emu_root),
           LD_LIBRARY_PATH=":".join(str(emu_root / p) for p in ("lib64", gles_directory, "lib64/vulkan")))
adb_lock = threading.Lock()
bridge_stop = threading.Event()
bridge_driver = None
grpc_recent_success = 0.0
grpc_touch_enabled = False
publisher_proxy = None
native_proxy_guard = None
dns_sink = None


def adb(args, timeout=15):
    with adb_lock:
        result = subprocess.run([str(ADB), "-s", SERIAL, *args], stdin=subprocess.DEVNULL, capture_output=True, timeout=min(timeout, 60), env=env)
    return {"code": result.returncode, "stdout": result.stdout.decode("utf-8", "replace")[-12000:], "stderr": result.stderr.decode("utf-8", "replace")[-6000:]}


def capture_png():
    global grpc_recent_success
    if bridge_driver is not None:
        try:
            png = bridge_driver.screenshot()
            if not png.startswith(b"\x89PNG\r\n\x1a\n"):
                raise ValueError("Controller returned no PNG")
            grpc_recent_success = time.monotonic()
            return png
        except Exception:
            # Boot-time controller availability must not block ordinary adb.
            grpc_recent_success = 0.0
    with adb_lock:
        result = subprocess.run([str(ADB), "-s", SERIAL, "exec-out", "screencap", "-p"], stdin=subprocess.DEVNULL, capture_output=True, env=env, timeout=30)
    if result.returncode or not result.stdout.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("Screenshot capture failed")
    return result.stdout


def atomic_write(path, data):
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_bytes(data)
    tmp.replace(path)


def run_bridge(directory, interval, package_name):
    """File protocol intentionally exposes touch only, never arbitrary adb/shell."""
    directory = directory.resolve()
    commands = directory / "commands"
    acks = directory / "acks"
    commands.mkdir(parents=True, exist_ok=True)
    acks.mkdir(exist_ok=True)
    width, height = 800, 480
    last_input_seconds = None
    def status(online, note, updated_at=0, frame_seconds=None):
        audio_state = bridge_driver.audio_status() if bridge_driver is not None and audio_enabled else {"audio": False}
        atomic_write(directory / "status.json", json.dumps({
            "online": online, "updatedAt": updated_at, "width": width, "height": height,
            "packageName": package_name, "note": note, "frameSeconds": frame_seconds,
            "inputSeconds": last_input_seconds, "transport": "grpc" if time.monotonic() - grpc_recent_success < 10 else "adb",
            "networkPolicy": "deny-all-external",
            **audio_state,
        }, ensure_ascii=False).encode())
    status(False, "Waiting for a real Android frame")
    while not bridge_stop.is_set():
        # One queue is shared with a single remote controller; bounded catch-up
        # prevents stale gestures from running after the client disconnects.
        for path in sorted(commands.glob("*.json"))[:16]:
            started = time.monotonic()
            try:
                if path.is_symlink() or path.stat().st_size > 4096:
                    raise ValueError("Input file must be a regular JSON file smaller than 4KB")
                command = json.loads(path.read_text())
                created_at = command.get("createdAt", path.stat().st_mtime * 1000)
                if not isinstance(created_at, (int, float)) or not 0 <= time.time() * 1000 - created_at <= 15000:
                    raise ValueError("Input expired or has an invalid timestamp")
                def point(x_name, y_name):
                    x, y = command.get(x_name), command.get(y_name)
                    if type(x) not in (int, float) or type(y) not in (int, float) or not 0 <= x < width or not 0 <= y < height:
                        raise ValueError("Coordinates outside the current Android frame")
                    return str(int(x)), str(int(y))
                kind = command.get("kind")
                if kind == "tap":
                    action = ["shell", "input", "tap", *point("x", "y")]
                elif kind == "swipe":
                    duration = command.get("duration", 250)
                    if type(duration) not in (int, float) or not 50 <= duration <= 2000:
                        raise ValueError("Swipe duration must be between 50 and 2000 milliseconds")
                    action = ["shell", "input", "swipe", *point("x", "y"), *point("x2", "y2"), str(round(duration))]
                elif kind == "key" and command.get("key") == "back":
                    action = ["shell", "input", "keyevent", "4"]
                else:
                    raise ValueError("Only tap, swipe and the Android back key are accepted")
                if bridge_driver is not None and grpc_touch_enabled and time.monotonic() - grpc_recent_success < 10:
                    normalized = {"kind": kind}
                    if kind == "key":
                        normalized["key"] = "back"
                    else:
                        normalized.update(x=int(command["x"]), y=int(command["y"]))
                        if kind == "swipe":
                            normalized.update(x2=int(command["x2"]), y2=int(command["y2"]), duration=round(duration))
                    bridge_driver.input(normalized)
                else:
                    result = adb(action, timeout=20)
                    if result["code"] != 0:
                        raise ValueError(result["stderr"] or "Android rejected input")
                last_input_seconds = round(time.monotonic() - started, 3)
                ack = {"ok": True, "completedAt": int(time.time() * 1000), "inputSeconds": last_input_seconds}
            except Exception as error:
                ack = {"ok": False, "completedAt": int(time.time() * 1000), "error": str(error)}
            atomic_write(acks / path.name, json.dumps(ack).encode())
            path.unlink(missing_ok=True)
        # Keep local acknowledgment storage bounded during long dev sessions.
        for old in sorted(acks.glob("*.json"), key=lambda p: p.stat().st_mtime)[:-128]:
            old.unlink(missing_ok=True)
        try:
            started = time.monotonic()
            png = capture_png()
            width, height = int.from_bytes(png[16:20], "big"), int.from_bytes(png[20:24], "big")
            atomic_write(directory / "frame.png", png)
            status(True, "Live Android emulator; software rendering and delayed video", int(time.time() * 1000), round(time.monotonic() - started, 3))
        except Exception as error:
            status(False, str(error))
        bridge_stop.wait(max(0.05, interval))
    status(False, "Android stream stopped")


subprocess.run([str(ADB), "start-server"], env=env, check=True, capture_output=True, timeout=15)
publisher_proxy = PublisherProxy(env.get("HTTP_PROXY", env.get("http_proxy", "")), allowed_hosts=())
native_proxy_guard = PublisherProxy(local_tunnel_port=publisher_proxy.port)
dns_sink = ClosedLoopbackDns()
log_path = BASE / "emulator-session.log"
log = log_path.open("w")
binary = "qemu-system-aarch64-headless" if args.arch == "arm64" else "qemu-system-armel-headless"
command = [str(args.emulator_root.resolve() / "qemu/linux-x86_64" / binary), "-avd", args.avd, "-no-window", "-no-boot-anim", "-no-snapshot", "-accel", "off", "-gpu", args.gpu]
command += ["-http-proxy", "http://127.0.0.1:" + str(native_proxy_guard.port), "-dns-server", dns_sink.address]
if not audio_enabled:
    command.append("-no-audio")
if args.writable_system:
    command.append("-writable-system")
if args.grpc_port:
    if not 1024 <= args.grpc_port < 65536:
        raise ValueError("Invalid local controller port")
    grpc_runtime = BASE / "grpc-runtime"
    grpc_runtime.mkdir(mode=0o700, exist_ok=True)
    grpc_runtime.chmod(0o700)
    env["XDG_RUNTIME_DIR"] = str(grpc_runtime)
    command += ["-grpc", str(args.grpc_port), "-grpc-use-token"]
if not args.legacy_emulator:
    command.append("-no-metrics")
else:
    command += ["-feature", "-Vulkan"]
command += ["-port", "5560", "-qemu", "-machine", "type=" + args.machine]
child_started_ns = time.time_ns()
qemu = subprocess.Popen(command, env=env, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT)
print(json.dumps({"event": "started", "pid": qemu.pid, "serial": SERIAL}), flush=True)
if args.grpc_port:
    from grpc_bridge_driver import BridgeGrpcDriver
    bridge_driver = BridgeGrpcDriver(args.grpc_port, grpc_runtime, qemu.pid,
                                    emulator_log=log_path, child_started_ns=child_started_ns)
    if args.bridge_dir and audio_enabled:
        bridge_driver.start_audio(args.bridge_dir, bridge_stop)
bridge_thread = None
if args.bridge_dir:
    bridge_thread = threading.Thread(target=run_bridge, args=(args.bridge_dir, args.bridge_interval, args.bridge_package), daemon=True)
    bridge_thread.start()
try:
    for line in sys.stdin:
        try:
            request = json.loads(line)
            op = request.get("op")
            if op == "status":
                result = {"qemu_exit": qemu.poll(), "device": adb(["get-state"])}
                if result["device"]["code"] == 0:
                    result["boot_completed"] = adb(["shell", "getprop", "sys.boot_completed"])
                    result["abis"] = adb(["shell", "getprop", "ro.product.cpu.abilist"])
            elif op == "adb":
                adb_args = request.get("args")
                if not isinstance(adb_args, list) or not all(isinstance(x, str) for x in adb_args):
                    raise ValueError("adb args must be a string array")
                result = adb(adb_args, request.get("timeout", 30))
            elif op == "screenshot":
                path = Path(request["path"]).resolve()
                if BASE not in path.parents:
                    raise ValueError("Screenshot must stay in the local Android work directory")
                path.parent.mkdir(parents=True, exist_ok=True)
                png = capture_png()
                path.write_bytes(png)
                result = {"path": str(path), "bytes": len(png)}
            elif op == "proxy_info":
                proxy = urlparse(env.get("HTTP_PROXY", env.get("http_proxy", "")))
                result = {"scheme": proxy.scheme, "host": proxy.hostname, "port": proxy.port, "credentials_present": bool(proxy.username or proxy.password)}
            elif op == "configure_filtered_proxy":
                result = adb(["shell", "settings", "put", "global", "http_proxy", "10.0.2.2:" + str(publisher_proxy.port)])
                result["default_deny_proxy_configured"] = result["code"] == 0
            elif op == "network_status":
                result = {"policy": "deny-all-external", "publisher": publisher_proxy.snapshot(),
                          "native_guard": native_proxy_guard.snapshot(),
                          "dns": {"address": dns_sink.address, "verified_closed": dns_sink.verified_closed}}
            elif op == "clipboard":
                text = request.get("text")
                if bridge_driver is None or not isinstance(text, str) or len(text.encode("utf-8")) > 1024:
                    raise ValueError("A local controller and at most 1024 UTF-8 bytes are required")
                bridge_driver.set_clipboard(text)
                result = {"clipboard_set": True, "utf8_bytes": len(text.encode("utf-8"))}
            elif op == "grpc_input_probe":
                if bridge_driver is None:
                    raise ValueError("Local emulator controller is not enabled")
                bridge_driver.input(request.get("input"))
                result = {"probe_sent": True, "regular_bridge_touch_enabled": grpc_touch_enabled}
            elif op == "enable_grpc_input":
                if bridge_driver is None or request.get("mapping_verified") is not True:
                    raise ValueError("Verify a real screenshot-coordinate input first")
                grpc_touch_enabled = True
                result = {"grpc_touch_enabled": True}
            elif op == "stop":
                print(json.dumps({"event": "stopping"}), flush=True)
                break
            else:
                raise ValueError("Unknown operation")
            print(json.dumps({"op": op, "result": result}), flush=True)
        except Exception as error:
            print(json.dumps({"error": type(error).__name__, "message": str(error)}), flush=True)
finally:
    bridge_stop.set()
    if bridge_driver is not None:
        bridge_driver.close()
    if bridge_thread:
        bridge_thread.join(timeout=35)
    qemu.terminate()
    try:
        qemu.wait(timeout=10)
    except subprocess.TimeoutExpired:
        qemu.kill()
        qemu.wait(timeout=10)
    subprocess.run([str(ADB), "kill-server"], env=env, capture_output=True, timeout=10)
    native_proxy_guard.close()
    publisher_proxy.close()
    dns_sink.close()
    log.close()
    # A tool namespace can reuse the same small PID after restart. Clean only
    # this terminated instance's own stale lock, after wait() confirms exit.
    lock = BASE / "avd" / (avd_name + ".avd") / "hardware-qemu.ini.lock"
    try:
        if lock.read_bytes().rstrip(b"\0\n ") == str(qemu.pid).encode():
            lock.unlink()
    except FileNotFoundError:
        pass
