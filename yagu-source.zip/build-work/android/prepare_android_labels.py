#!/usr/bin/env python3
"""Prepare a renamed compiled resource table; does not build or sign an APK.

Output is only resources.arsc for the exact analyzed input. All original strings
stay in place; a new global string is appended and only app_label*/app_name*
resource references are redirected. In-game logos/text are separate assets.
"""
import argparse
import hashlib
import json
import struct
import zipfile
from pathlib import Path

from apk_android_inspect import EXPECTED_SHA256, chunks, resources, u16, u32


def encode_length(value):
    if value < 0x80:
        return bytes([value])
    if value > 0x7fff:
        raise ValueError("Resource string is too long")
    return bytes([(value >> 8) | 0x80, value & 255])


def rename_table(original, title):
    if not title or "\0" in title:
        raise ValueError("Title must be nonempty and contain no NUL")
    b = bytearray(original)
    rows = resources(b)
    targets = [r for r in rows if r["type"] == "string" and r["key"].startswith(("app_label", "app_name"))]
    if not targets:
        raise ValueError("No Android app title resource targets")
    pools = [(p, hs, size) for p, kind, hs, size in chunks(b, u16(b, 2), len(b)) if kind == 1]
    if len(pools) != 1:
        raise ValueError("Expected one top-level resource string pool")
    p, header_size, old_size = pools[0]
    count, styles, flags, start, style_start = struct.unpack_from("<IIIII", b, p + 8)
    if header_size != 28 or styles or style_start or not flags & 256:
        raise ValueError("Only observed unstyled UTF-8 resource pools are supported")
    if start != header_size + 4 * count:
        raise ValueError("Unexpected global string offset layout")
    for row in targets:
        if row["value_type"] != 3:
            raise ValueError("Indirect app title resource requires separate handling")
        struct.pack_into("<I", b, row["value_data_offset"], count)
    old_payload = bytes(b[p + start:p + old_size])
    utf8 = title.encode("utf-8")
    encoded = encode_length(len(title.encode("utf-16le")) // 2) + encode_length(len(utf8)) + utf8 + b"\0"
    payload = old_payload + encoded
    payload += b"\0" * ((-len(payload)) % 4)
    offset_table = bytes(b[p + header_size:p + start]) + struct.pack("<I", len(old_payload))
    new_start = header_size + len(offset_table)
    pool = struct.pack("<HHIIIIII", 1, header_size, new_start + len(payload), count + 1, 0, flags & ~1, new_start, 0) + offset_table + payload
    result = bytearray(b[:p] + pool + b[p + old_size:])
    struct.pack_into("<I", result, 4, len(result))
    after = resources(result)
    if len(after) != len(rows):
        raise ValueError("Resource count changed")
    changes = []
    for before, updated in zip(rows, after):
        is_target = before["type"] == "string" and before["key"].startswith(("app_label", "app_name"))
        if (before["id"], before["key"], before["language"], before["region"]) != (updated["id"], updated["key"], updated["language"], updated["region"]):
            raise ValueError("Resource identity changed")
        if updated["value"] != (title if is_target else before["value"]):
            raise ValueError("Unexpected resource value change")
        if is_target:
            changes.append({"id": before["id"], "key": before["key"], "language": before["language"], "region": before["region"], "before": before["value"], "after": title})
    return bytes(result), changes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("apk", type=Path)
    parser.add_argument("--output", type=Path, required=True, help="Output resources.arsc, not an installable APK")
    parser.add_argument("--title", default="야구")
    args = parser.parse_args()
    if args.output.resolve() == args.apk.resolve():
        raise ValueError("Refusing to overwrite the source APK")
    raw = args.apk.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    if sha != EXPECTED_SHA256:
        raise ValueError("APK fingerprint does not match the analyzed build")
    with zipfile.ZipFile(args.apk) as archive:
        original = archive.read("resources.arsc")
    result, changes = rename_table(original, args.title)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(result)
    print(json.dumps({"output": str(args.output.resolve()), "changed_label_entries": len(changes),
                      "original_sha256": hashlib.sha256(original).hexdigest(), "output_sha256": hashlib.sha256(result).hexdigest(),
                      "title": args.title, "apk_built_or_signed": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
