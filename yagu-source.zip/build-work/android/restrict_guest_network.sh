#!/system/bin/sh
# Restrict this disposable test guest. App checks and TLS remain intact.
set -eu
YAGU_PROXY_PORT="${1:?local proxy port required}"
case "$YAGU_PROXY_PORT" in *[!0-9]*|'') exit 2;; esac
[ "$YAGU_PROXY_PORT" -ge 1024 ]
[ "$YAGU_PROXY_PORT" -le 65535 ]
[ "$(id -u)" = 0 ]
# Install once per boot; fail closed if a chain already exists.
iptables -w -N YAGU_EGRESS
iptables -w -A YAGU_EGRESS -o lo -j RETURN
iptables -w -A YAGU_EGRESS -d 10.0.2.2 -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
iptables -w -A YAGU_EGRESS -p tcp -d 10.0.2.2 --dport "$YAGU_PROXY_PORT" -j RETURN
iptables -w -A YAGU_EGRESS -j REJECT
iptables -w -I OUTPUT 1 -j YAGU_EGRESS
ip6tables -w -N YAGU_EGRESS
ip6tables -w -A YAGU_EGRESS -o lo -j RETURN
ip6tables -w -A YAGU_EGRESS -j REJECT
ip6tables -w -I OUTPUT 1 -j YAGU_EGRESS
iptables -w -S YAGU_EGRESS
ip6tables -w -S YAGU_EGRESS
