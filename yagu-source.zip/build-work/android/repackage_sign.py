#!/usr/bin/env python3
"""Repackage an exact APK with reviewed overlays, align, sign and verify.

Signing keys/passwords are caller-owned private local files. This script never
prints their contents and never copies them into output artifacts. Successful
packaging proves package integrity only, not gameplay correctness.
"""
import argparse
import hashlib
import json
import os
import re
import struct
import subprocess
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

EXPECTED_SHA256 = "2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484"


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def signature_entry(name):
    upper = name.upper()
    return upper == "META-INF/MANIFEST.MF" or (upper.startswith("META-INF/") and upper.endswith((".SF", ".RSA", ".DSA", ".EC"))) or name == "stamp-cert-sha256"


def acceptable_overlay(name):
    parts = PurePosixPath(name).parts
    if not parts or name.startswith("/") or any(p in ("", ".", "..") or p.startswith(".") for p in parts):
        return False
    if name in ("AndroidManifest.xml", "resources.arsc") or re.fullmatch(r"classes(?:[2-9][0-9]*)?\.dex", name):
        return True
    if len(parts) > 1 and parts[0] in ("assets", "res"):
        return True
    return len(parts) == 3 and parts[0] == "lib" and parts[1] in ("arm64-v8a", "armeabi-v7a") and parts[2].endswith(".so")


def validate_library(name, data):
    if not name.startswith("lib/") or not name.endswith(".so"):
        return
    if data[:4] != b"\x7fELF" or data[5] != 1:
        raise ValueError(f"Expected little-endian ELF: {name}")
    cls, machine = data[4], struct.unpack_from("<H", data, 18)[0]
    expected = (2, 183) if name.split("/")[1] == "arm64-v8a" else (1, 40)
    if (cls, machine) != expected:
        raise ValueError(f"Native library ABI mismatch: {name}")


def run(command, log_path=None):
    result = subprocess.run([str(x) for x in command], text=True, capture_output=True)
    output = result.stdout + result.stderr
    if log_path:
        Path(log_path).write_text(output)
    if result.returncode:
        # Commands contain password file references, never password values.
        raise RuntimeError(f"{Path(str(command[0])).name} failed ({result.returncode}):\n{output[-6000:]}")
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("--overlay", type=Path, action="append", required=True, help="Apply in listed order; later overlays win")
    parser.add_argument("--build-tools", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--keystore", type=Path)
    parser.add_argument("--password-file", type=Path)
    parser.add_argument("--key-alias", default="yagu-local")
    parser.add_argument("--unsigned-only", action="store_true")
    parser.add_argument("--expected-package", default="com.taehyun.yagu")
    args = parser.parse_args()
    if args.output.resolve() == args.source.resolve():
        raise ValueError("Refusing to overwrite original APK")
    if args.output.exists():
        raise ValueError("Output already exists; select a new candidate path")
    if sha256(args.source.read_bytes()) != EXPECTED_SHA256:
        raise ValueError("Source APK does not match the analyzed fingerprint")
    if not args.unsigned_only:
        if not args.keystore or not args.password_file or not args.keystore.is_file() or not args.password_file.is_file():
            raise ValueError("A private local test keystore and password file are required")
        for secret in (args.keystore, args.password_file):
            if secret.stat().st_mode & 0o077:
                raise ValueError("Signing files must be private (chmod 600)")
    overlays, provenance = {}, []
    for root in args.overlay:
        root = root.resolve(strict=True)
        if not root.is_dir():
            raise ValueError("Overlay must be a directory")
        for file in sorted(root.rglob("*")):
            if file.is_symlink():
                raise ValueError("Overlay symlinks are not allowed")
            if not file.is_file():
                continue
            name = file.relative_to(root).as_posix()
            if not acceptable_overlay(name) or signature_entry(name):
                raise ValueError(f"Unexpected overlay entry: {name}")
            data = file.read_bytes()
            validate_library(name, data)
            overlays[name] = data
            provenance.append({"entry": name, "source": str(file), "size_bytes": len(data), "sha256": sha256(data)})
    if "AndroidManifest.xml" not in overlays or "resources.arsc" not in overlays:
        raise ValueError("The reviewed side-by-side manifest and resources are required")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    log_dir = args.output.parent / (args.output.stem + "-verification")
    log_dir.mkdir(exist_ok=False)
    tools = args.build_tools.resolve()
    with tempfile.TemporaryDirectory(prefix="yagu-package-", dir=args.output.parent) as temp:
        temp = Path(temp)
        unsigned, aligned = temp / "unsigned.apk", temp / "aligned.apk"
        with zipfile.ZipFile(args.source) as source, zipfile.ZipFile(unsigned, "w", allowZip64=False) as output:
            infos = source.infolist()
            if len({x.filename for x in infos}) != len(infos):
                raise ValueError("Duplicate ZIP entries in source")
            if source.testzip() is not None:
                raise ValueError("Source ZIP CRC failure")
            written = set()
            for info in infos:
                name = info.filename
                if signature_entry(name):
                    continue
                data = overlays.get(name, source.read(name))
                validate_library(name, data)
                replacement = zipfile.ZipInfo(name, info.date_time)
                replacement.compress_type = zipfile.ZIP_STORED if name == "resources.arsc" else info.compress_type
                replacement.external_attr = info.external_attr
                replacement.create_system = info.create_system
                # Do not carry old ZIP alignment/signing extra fields.
                output.writestr(replacement, data)
                written.add(name)
            for name, data in sorted(overlays.items()):
                if name in written:
                    continue
                replacement = zipfile.ZipInfo(name)
                replacement.compress_type = zipfile.ZIP_STORED if name == "resources.arsc" else zipfile.ZIP_DEFLATED
                replacement.external_attr = 0o100644 << 16
                output.writestr(replacement, data)
        run([tools / "zipalign", "-P", "16", "-f", "4", unsigned, aligned], log_dir / "alignment-build.txt")
        run([tools / "zipalign", "-c", "-P", "16", "4", aligned], log_dir / "alignment-check.txt")
        if args.unsigned_only:
            args.output.write_bytes(aligned.read_bytes())
        else:
            run([tools / "apksigner", "sign", "--ks", args.keystore.resolve(), "--ks-key-alias", args.key_alias,
                 "--ks-pass", "file:" + str(args.password_file.resolve()),
                 "--min-sdk-version", "19", "--v1-signing-enabled", "true", "--v2-signing-enabled", "true", "--v3-signing-enabled", "true",
                 "--v4-signing-enabled", "false", "--out", args.output.resolve(), aligned], log_dir / "signing.txt")
            run([tools / "apksigner", "verify", "--min-sdk-version", "19", "--verbose", "--print-certs", args.output.resolve()], log_dir / "signature-verification.txt")
            run([tools / "zipalign", "-c", "-P", "16", "4", args.output.resolve()], log_dir / "signed-alignment-check.txt")
    with zipfile.ZipFile(args.output) as final:
        if final.testzip() is not None:
            raise ValueError("Final ZIP CRC failure")
        for name, data in overlays.items():
            if final.read(name) != data:
                raise ValueError(f"Overlay changed in final APK: {name}")
    badging = run([tools / "aapt2", "dump", "badging", args.output.resolve()], log_dir / "badging.txt")
    if f"package: name='{args.expected_package}'" not in badging:
        raise ValueError("Unexpected final package name")
    report = {"artifact_kind": "unsigned_candidate" if args.unsigned_only else "signed_test_candidate",
              "apk": str(args.output.resolve()), "size_bytes": args.output.stat().st_size, "sha256": sha256(args.output.read_bytes()),
              "source_sha256": EXPECTED_SHA256, "package": args.expected_package, "overlay_entries": provenance,
              "signature_verified": not args.unsigned_only, "zip_alignment_verified": True, "zip_crc_verified": True,
              "runtime_and_gameplay": "Not established by this packaging step", "logs": str(log_dir.resolve())}
    (log_dir / "package_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "overlay_entries"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
