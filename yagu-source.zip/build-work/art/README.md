# 야구 — original art and stock black uniforms

## Current visual scope

Overlay **2.1-stock-black** supersedes the earlier generated uniform and shared
face/hair experiments. Those images are not packaged. All15 clubs, including
Pumas and both My Player roles, use the shipped black uniforms: batter/pitcher
level_0/color_0 and defender/black. Original player images, skin, hair, crowds,
stadiums, backgrounds, skeletons and animations are retained byte-for-byte.

New art is restricted to the14 requested opponent crests and the previously
requested 야구 title/launcher identity. The Pumas crest is preserved. Original
menu/control positions and title animation bounds remain unchanged.

## Exact identities

| ID | Name | Uniform |
|---:|---|---|
|0|알파|Original black0|
|1|베타|Original black0|
|2|감마|Original black0|
|3|델타|Original black0|
|4|대구 푸마즈|Original black0|
|5|엡실론|Original black0|
|6|제타|Original black0|
|7|에타|Original black0|
|8|세타|Original black0|
|9|요타|Original black0|
|10|입실론|Original black0|
|11|파이|Original black0|
|12|카이|Original black0|
|13|프사이|Original black0|
|14|오메가|Original black0|

NPCs are numbered1..310 in ascending original RFID order. My Player1000/1100
are excluded. Native name resolution covers existing saved-name overrides.

## Packaged resources

The merged overlay has53 unique entries: name/menu tables, original uniform
mapping tables with the18 observed clothing color fields set to0 for all15
clubs, the extended opponent crest atlas, the title logo and six launcher icon
densities. The text-only brand delta preserves original layout fields.

The crest atlas retains its original1024×1024 pixels and55 frames, appending15
slots in a1024×2048 texture. Pumas does not use its appended slot. Opponents use
frame55+team. Only14 new logos are selected.

There are **zero** overlay files below assets/bat/, assets/pit/,
assets/defender/ or assets/stadium/. This is an explicit build assertion.
No extended uniform palettes10..24 are needed. Uniform selection includes
Pumas; the exception for its original crest is separate.

## Native contract and verification

GetUniformPal selects0 for clothing layers3,4,6,9,10,12,14,15,16,19,20,22,24,
25,26,27,29,30 of every valid team0..14. Original costume/head appearance uses
the base style. GameRun selects the original black garment paths. Invalid
teams/parts and nonclothing components retain the original fallback.
Layer2 and the separate equipment selector additionally choose shipped black bat/glove appearances; pitcher ball components and real item/ability fields stay unchanged. Menu6,408 and live2,052 instruction cases verify the stock equipment path scope. Actual appearance still requires the corresponding candidate runtime check.

The source APK is read-only and SHA256-locked to
2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484.

The four used generated sources are crests, extra_crests, title_logo and
launcher_icon. Other historical source illustrations are not used by the packer.

Reproduce with build_art_overlay.py into a fresh base directory (47entries),
make_brand_delta.py into a fresh text directory (12entries), then
assemble_art_overlay.py with both manifests. Six text entries replace base
entries, producing53. The assembler checks every input filename, length and
SHA256 and rejects player/stadium replacements. The complete current inventory
is docs/art/art_overlay_manifest.json.

Static checks establish table/atlas bounds, protected resource preservation
and availability of shipped assets. They do not establish device rendering,
full-game completion or a playable web deployment. Runtime evidence is separate.
