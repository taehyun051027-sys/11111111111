#!/usr/bin/env python3
"""Pack AI-generated game art into observed native atlases, and apply identity tables.

This performs export conditioning (crop, resample, alpha mask, atlas packing), not
procedural illustration or recoloring. Original APK is read-only and hash-gated.
"""
from __future__ import annotations
import argparse,hashlib,io,json,struct,sys,zipfile,shutil
from pathlib import Path
import numpy as np
from scipy.ndimage import distance_transform_edt,label,binary_dilation
from PIL import Image,ImageOps

BASE=Path(__file__).resolve().parents[1]
WORK=BASE.parents[1]
sys.path.insert(0,str(WORK/'analysis/data/tools'))
from zt1_codec import RecordTable,StringTable,pack_zt1,unpack_zt1
EXPECTED='2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484'
TEAM_NAMES=['알파','베타','감마','델타',None,'엡실론','제타','에타','세타','요타','입실론','파이','카이','프사이','오메가']
LOCALES=['assets/data','assets/global_language/eng','assets/global_language/jap','assets/global_language/china_cn','assets/global_language/china_tw','assets/global_language/spn']
LANGS=['kor','eng','jap','cha_CN','cha_TW','spn']
TWOWAY={'kor':('투타겸업','나만의 투타겸업 선수'),'eng':('Two-way','My Two-way mode'),'jap':('二刀流','二刀流モード'),'cha_CN':('投打兼修','我的投打兼修'),'cha_TW':('投打雙修','我的投打雙修'),'spn':('Doble rol','Modo Doble rol')}
PHRASES={'kor':['나만의 타자','나만의타자'],'eng':['My Batter'],'jap':['オリジナル打者'],'cha_CN':['我的击球员'],'cha_TW':['我的擊球員'],'spn':['Mi Bateador']}
UNIFORM_LAYERS={3,4,6,9,10,12,14,15,16,19,20,22,24,25,26,27,29,30}
PLAYER_IDS=list(range(1,181))+list(range(400,520))+list(range(800,805))+list(range(810,815))
PLAYER_NAMES={pid:str(i+1) for i,pid in enumerate(PLAYER_IDS)}
SOURCES={
 'crests':'exec-39b59d50-f993-478d-8ebe-a2505357e183.png',
 'extra_crests':'exec-fe54b891-e1e7-4728-8b8e-720c3c972258.png',
 'blue':'exec-ee59aff4-f6a5-4df4-b6bd-b404690597ef.png',
 'crimson':'exec-1c75d6f0-c298-4ff9-98f6-5fb222e59dd8.png',
 'emerald':'exec-b79ff469-f594-4da3-a4dd-b4f0a3b48706.png',
 'violet':'exec-5b87d0d3-96b4-489d-9a41-e3ff489d8ccd.png',
 'gold':'exec-09fffb93-9ee7-44d6-bcb6-865022069d59.png',
 'cyan':'exec-d02a548d-cf6a-45e7-b9fd-82adb54d2648.png',
 'graphite':'exec-413e96a6-77a3-4e2a-a390-17b5c31e6699.png',
 'navy':'exec-eec7a531-958b-4c18-968e-9c364e7e2fbb.png',
 'silver':'exec-acdb7daf-8254-4f92-b4eb-40abae8e0794.png',
 'coral':'exec-adebce81-337a-400a-9b14-69e29bb47761.png',
 'faces':'exec-c8e684ef-07d0-4199-8ef5-a2ef6a9ea6e3.png',
 'defender0':'exec-7ee8b576-0083-48f5-9521-e888cf522cbf.png',
 'defender1':'exec-74e5beba-d61c-4a5c-94fb-9b927ba90078.png',
 'title_logo':'exec-6c2a45d9-89e2-4a64-85f9-241aa280ce21.png',
 'launcher_icon':'exec-5856e856-c912-4c70-a1de-fe2707ca8a7a.png',
}
PALETTES={0:('blue','blue'),1:('crimson','crimson'),2:('emerald','emerald'),3:('violet','violet'),5:('gold','gold'),6:('cyan','cyan'),7:('graphite','graphite'),8:('navy','navy'),9:('silver','silver'),10:('coral','coral'),11:('blue','crimson'),12:('violet','graphite'),13:('gold','emerald'),14:('blue','navy')}
CREST_BOX={0:('crests',(10,5,209,200)),1:('crests',(210,8,402,200)),2:('crests',(410,7,591,195)),3:('crests',(601,5,790,200)),5:('crests',(792,3,988,200)),6:('crests',(992,3,1194,201)),7:('crests',(1194,3,1372,204)),8:('crests',(1377,5,1552,196)),9:('crests',(4,198,209,395)),10:('extra_crests',(54,55,672,695)),11:('crests',(1347,201,1554,387)),12:('extra_crests',(771,21,1400,703)),13:('extra_crests',(1520,31,2097,694)),14:('crests',(1390,391,1578,583))}

def sha(b):return hashlib.sha256(b).hexdigest()
def png(img):
 buf=io.BytesIO();img.save(buf,format='PNG',optimize=True);return buf.getvalue()
def pzc_rects(b):
 if b[:4]!=b'!PZC':raise ValueError('PZC magic')
 io_,fo,ao=struct.unpack_from('<III',b,12);count=struct.unpack_from('<I',b,io_+12)[0];start=fo-count*28
 return [struct.unpack_from('<4H',b,start+i*28) for i in range(count)]
def fit(img,size,pad=0):
 bb=img.getchannel('A').getbbox()
 if not bb:return Image.new('RGBA',size)
 img=img.crop(bb);img.thumbnail((size[0]-2*pad,size[1]-2*pad),Image.Resampling.LANCZOS)
 out=Image.new('RGBA',size);out.alpha_composite(img,((size[0]-img.width)//2,(size[1]-img.height)//2));return out

def condition(generated,original,rects):
 """Use only generated RGB; original silhouette is the animation export mask.
 Fill generation's transparent holes by nearest opaque generated sample per frame.
 """
 a=np.array(original.convert('RGBA'));g=np.array(generated.resize(original.size,Image.Resampling.LANCZOS).convert('RGBA'))
 out=np.zeros_like(a);covered=np.zeros(a.shape[:2],dtype=bool);missing=0;total=0;empty_frames=0
 whole_good=g[:,:,3]>160
 if not np.any(whole_good):raise ValueError('Generated component is empty')
 _,whole_indices=distance_transform_edt(~whole_good,return_indices=True)
 whole_filled=g[whole_indices[0],whole_indices[1],:3]
 for x,y,w,h in rects:
  if not w or not h:continue
  if x+w>a.shape[1] or y+h>a.shape[0]:raise ValueError('PZC outside image')
  o=a[y:y+h,x:x+w];q=g[y:y+h,x:x+w].copy();mask=o[:,:,3]>0
  good=q[:,:,3]>160
  if np.any(good):
   missing+=int(np.sum(mask&~good));total+=int(np.sum(mask))
   _,indices=distance_transform_edt(~good,return_indices=True)
   q[:,:,:3]=q[indices[0],indices[1],:3]
  else:
   # Tiny export slots may land in generator padding. Extend generated
   # component colour samples into the exact original frame mask.
   empty_frames+=1;missing+=int(np.sum(mask));total+=int(np.sum(mask))
   q[:,:,:3]=whole_filled[y:y+h,x:x+w]
  q[:,:,3]=o[:,:,3];q[~mask]=0
  # Overlapping PZC source rectangles share a texture; same full image samples.
  target=out[y:y+h,x:x+w];target[mask]=q[mask]
  covered[y:y+h,x:x+w]|=mask
 if np.any((a[:,:,3]>0)&~covered):
  # Some atlases have decorative unused pixels outside all PZC source rectangles.
  # They remain transparent, because no frame can consume them.
  pass
 return Image.fromarray(out,'RGBA'),dict(mask_pixels=total,generated_hole_pixels=missing,hole_fraction=round(missing/max(total,1),6),empty_generated_frames_filled=empty_frames)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--apk',type=Path,default=WORK/'upload/baseball-superstars-2013-1-2-9.apk');ap.add_argument('--out',type=Path,default=BASE/'overlay');args=ap.parse_args()
 if sha(args.apk.read_bytes())!=EXPECTED:raise ValueError('APK SHA mismatch')
 if args.out.exists():raise FileExistsError('Use a fresh output directory')
 args.out.mkdir(parents=True)
 (BASE/'generated').mkdir(exist_ok=True)
 source_images={};provenance={}
 for k,name in SOURCES.items():
  local=BASE/'generated'/f'{k}.png'
  if not local.exists():shutil.copyfile(WORK/'generated_images'/name,local)
  source_images[k]=Image.open(local).convert('RGBA');provenance[k]={'file':str(local),'sha256':sha(local.read_bytes()),'generation_file':name,'dimensions':list(source_images[k].size)}
 z=zipfile.ZipFile(args.apk);report={'version':1,'source_apk_sha256':EXPECTED,'runtime_verified':False,'files':[],'teams':[],'player_numbers':PLAYER_NAMES,'generated_sources':provenance,'export_conditioning':[],'ui_changes':[],'preserved_team_id':4,'preserved_my_player_ids':[1000,1100]}
 def put(path,data,kind):
  p=args.out/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
  report['files'].append({'path':path,'bytes':len(data),'sha256':sha(data),'kind':kind})
 def put_png(path,img,kind):put(path,png(img),kind)
 # Name tables in all localizations.
 for locale,lang in zip(LOCALES,LANGS):
  path=f'{locale}/StrCOMMON_BB2013.zt1';src=unpack_zt1(z.read(path));t=StringTable.parse(src)
  changes={i:v for i,v in enumerate(TEAM_NAMES) if v is not None};changes[330]=TWOWAY[lang][0];changes[426]=TWOWAY[lang][1]
  changes[24]={'kor':'유니버셜 리그','eng':'Universal League','jap':'ユニバーサルリーグ','cha_CN':'宇宙联赛','cha_TW':'宇宙聯賽','spn':'Liga Universal'}[lang]
  raw=t.replace(changes);assert StringTable.parse(raw).strings[4]==t.strings[4]
  put(path,pack_zt1(raw),'localized team, top-league and two-way names')
  report['ui_changes'].append({'path':path,'indices':sorted(changes),'old_330':t.strings[330].decode('utf8').rstrip('\0'),'new_330':changes[330]})
 roster=[f'{p}/{n}.zt1' for p in LOCALES for n in ['XlsBATTER_DATA','XlsPITCHER_DATA']]+['assets/data/XlsACE_BAT_DATA.zt1','assets/data/XlsACE_PIT_DATA.zt1']
 for path in roster:
  t=RecordTable.parse(unpack_zt1(z.read(path)));out=bytearray(t.raw);allowed=set()
  for r in range(t.row_count):
   pid=struct.unpack_from('<H',t.row(r))[0]
   if pid in (1000,1100):continue
   name=PLAYER_NAMES[pid].encode('ascii');w=t.widths[1];start=t.data_start+r*t.row_stride+t.offsets[1]
   assert len(name)<w;out[start:start+w]=name+b'\0'*(w-len(name));allowed.update(range(start,start+w))
  assert all(a==b or i in allowed for i,(a,b) in enumerate(zip(t.raw,out)))
  put(path,pack_zt1(bytes(out)),'decimal player names1..310')
 # Menu entry fields are fixed width; replace only the My Batter phrases.
 for lang in LANGS:
  for stem in ['XlsMainmenu','XlsRaiseYearUI']:
   path=f'assets/ui_text/{stem}_{lang}.zt1';t=RecordTable.parse(unpack_zt1(z.read(path)));out=bytearray(t.raw);updates=[]
   for r in range(t.row_count):
    for c,typ in enumerate(t.types):
     if typ<11:continue
     w=t.widths[c];start=t.data_start+r*t.row_stride+t.offsets[c];old=bytes(out[start:start+w]).split(b'\0',1)[0]
     try:s=old.decode('utf8')
     except UnicodeDecodeError:continue
     new=s
     for phrase in PHRASES[lang]:new=new.replace(phrase,TWOWAY[lang][0])
     if new!=s:
      b=new.encode('utf8')
      if len(b)>=w:raise ValueError(f'Text field overflow {path} row{r} width{w}: {new}')
      out[start:start+w]=b+b'\0'*(w-len(b));updates.append({'row':r,'column':c,'old':s,'new':new,'field_bytes':w})
   if updates:put(path,pack_zt1(bytes(out)),'two-way menu entry');report['ui_changes'].append({'path':path,'fields':updates})
 # Live emblem table and uniform palette tables. Preserve Pumas row byte for byte.
 for stem in ['Xlsteam_emblem_info','XlsBatterTeamUniformColorCombi','XlsPitcherTeamUniformColorCombi']:
  raw=z.read(f'assets/data/{stem}.dat');t=RecordTable.parse(raw);out=bytearray(raw)
  for team in range(15):
   if team==4:continue
   if stem=='Xlsteam_emblem_info':
    vals=[55+team,-128,-128,-128,0]
    for c,v in enumerate(vals):out[t.data_start+team*t.row_stride+t.offsets[c]]=v&255
   else:
    for c in UNIFORM_LAYERS:out[t.data_start+team*t.row_stride+t.offsets[c]]=10+team
  assert RecordTable.parse(bytes(out)).row(4)==t.row(4)
  for ext,data in [('dat',bytes(out)),('zt1',pack_zt1(bytes(out)))]:put(f'assets/data/{stem}.{ext}',data,'native consumed team art mapping')
 # Append new crest frames, retaining all original Pumas-compatible frames and pixels.
 path='assets/ui/CC_Team_Symbol_Parts.png';original=Image.open(io.BytesIO(z.read(path))).convert('RGBA');canvas=Image.new('RGBA',(1024,2048));canvas.paste(original,(0,0))
 pzc=bytearray(z.read(path[:-4]+'.pzc'));io_,fo,ao=struct.unpack_from('<III',pzc,12);old_ic=struct.unpack_from('<I',pzc,io_+12)[0];old_fc=struct.unpack_from('<I',pzc,fo+12)[0]
 assert(old_ic,old_fc)==(61,55);new_images=bytearray();new_frames=bytearray();frame_template=bytes(pzc[fo+16:fo+60]);assert struct.unpack_from('<I',frame_template)[0]==1
 for team in range(15):
  x=(team%8)*128+8;y=1024+(team//8)*128+8
  if team in CREST_BOX:
   key,box=CREST_BOX[team];cut=source_images[key].crop(box)
   if team==9:
    a=np.array(cut);labels,_=label(a[:,:,3]>180);areas=np.bincount(labels.ravel());areas[0]=0;keep=binary_dilation(labels==areas.argmax(),iterations=1);a[~keep]=0;cut=Image.fromarray(a)
   badge=fit(cut,(112,112),1);canvas.alpha_composite(badge,(x,y))
  vals=[x,y,112,112,0,0,0,0,0,0,112,112,112,112];new_images+=struct.pack('<14H',*vals)
  f=bytearray(frame_template);struct.pack_into('<I',f,4,old_ic+team);struct.pack_into('<hh',f,8,-56,-56);new_frames+=f
 imgsec=bytearray(pzc[io_:fo]);frmsec=bytearray(pzc[fo:ao]);struct.pack_into('<II',imgsec,8,len(imgsec)+len(new_images),old_ic+15);struct.pack_into('<II',frmsec,8,len(frmsec)+len(new_frames),old_fc+15)
 head=bytearray(pzc[:io_]);struct.pack_into('<II',head,16,fo+len(new_images),ao+len(new_images)+len(new_frames));newpzc=bytes(head+imgsec+new_images+frmsec+new_frames+pzc[ao:]);assert len(pzc_rects(newpzc))==76
 assert canvas.crop((0,0,1024,1024)).tobytes()==original.tobytes()
 put_png(path,canvas,'appended generated opponent crests');put(path[:-4]+'.pzc',newpzc,'appended15 image/frame slots; original55 frames retained')
 # All new uniform textures use original frame/animation metadata and joint bounds.
 layout=json.loads((BASE/'uniform_reference_slots.json').read_text());templates={k:source_images[k].resize((layout['width'],layout['height']),Image.Resampling.LANCZOS) for k in {x for p in PALETTES.values() for x in p}}
 conditioned={}
 for palette,sheet in templates.items():
  for slot in layout['slots']:
   path=slot['path'];orig=Image.open(io.BytesIO(z.read(path))).convert('RGBA');bounds=(slot['x'],slot['y'],slot['x']+slot['w'],slot['y']+slot['h']);crop=sheet.crop(bounds)
   original_pzc=z.read(path[:-4]+'.pzc');new,metric=condition(crop,orig,pzc_rects(original_pzc));conditioned[(palette,path)]=new
   report['export_conditioning'].append({'type':'uniform','palette':palette,'source':path,**metric})
 for team,(body,helmet) in PALETTES.items():
  for slot in layout['slots']:
   path=slot['path'];part=Path(path).name;role=path.split('/')[1];palette=helmet if ('helmat' in part or part=='pitcher_hat.png') else body
   out=f'assets/{role}/level_0/color_{10+team}/{part}'
   put_png(out,conditioned[(palette,path)],'generated opponent uniform component');put(out[:-4]+'.pzc',z.read(path[:-4]+'.pzc'),'unaltered skeletal animation metadata')
  report['teams'].append({'native_team_id':team,'name':TEAM_NAMES[team],'body_palette':body,'helmet_palette':helmet,'uniform_palette_id':10+team,'crest_frame':55+team,'defender_folder':f'defender/team_{team}'})
 # Shared face/skin components: regenerate faces without modifying skeletons.
 layout=json.loads((BASE/'faces_reference_slots.json').read_text());sheet=source_images['faces'].resize((layout['width'],layout['height']),Image.Resampling.LANCZOS)
 for slot in layout['slots']:
  path=slot['path'];orig=Image.open(io.BytesIO(z.read(path))).convert('RGBA');crop=sheet.crop((slot['x'],slot['y'],slot['x']+slot['w'],slot['y']+slot['h']));pzc_=z.read(path[:-4]+'.pzc');new,metric=condition(crop,orig,pzc_rects(pzc_))
  put_png(path,new,'generated shared face/hair/skin component');report['export_conditioning'].append({'type':'face','source':path,**metric})
 # New per-team defender folders, all6consumed layered paths. Original folders unchanged.
 dconditioned={};dmetadata={}
 for g in range(2):
  layout=json.loads((BASE/f'defender_reference_{g}_slots.json').read_text());sheet=source_images[f'defender{g}'].resize((layout['width'],layout['height']),Image.Resampling.LANCZOS)
  for slot in layout['slots']:
   path=slot['path'];orig=Image.open(io.BytesIO(z.read(path))).convert('RGBA');crop=sheet.crop((slot['x'],slot['y'],slot['x']+slot['w'],slot['y']+slot['h']));pzc_=z.read(path[:-4]+'.pzc');new,metric=condition(crop,orig,pzc_rects(pzc_));key=(slot['variant'],slot['part']);dconditioned[key]=new;dmetadata[key]=pzc_
   report['export_conditioning'].append({'type':'defender','palette':slot['variant'],'source':path,**metric})
 for team,(body,helmet) in PALETTES.items():
  for part in ['head','body','calves','stripes','arm','leg']:
   key=(helmet if part=='head' else body,part);path=f'assets/defender/team_{team}/{part}.png';put_png(path,dconditioned[key],'generated opponent defender component');put(path[:-4]+'.pzc',dmetadata[key],'unaltered defender animation metadata')
 # Title logo is rect9 Korean and rect14 English of actual title_back atlas.
 path='assets/title/title_back.png';title=Image.open(io.BytesIO(z.read(path))).convert('RGBA');rects=pzc_rects(z.read(path[:-4]+'.pzc'))
 for idx in [9,14]:
  x,y,w,h=rects[idx];title.paste((0,0,0,0),(x,y,x+w,y+h));title.alpha_composite(fit(source_images['title_logo'],(w,h)),(x,y))
 put_png(path,title,'야구 title logo in both original title frame bounds')
 for path in ['res/2H.png','res/yj.png','res/8p.png','res/9X.png','res/-t.png','res/2c.png']:
  size=Image.open(io.BytesIO(z.read(path))).size;put_png(path,ImageOps.fit(source_images['launcher_icon'],size,method=Image.Resampling.LANCZOS),'야구 launcher icon density variant')
 # Static validation checks exact metadata and sprite rectangle boundaries.
 checked=0
 for item in report['files']:
  path=item['path'];p=args.out/path
  if path.endswith('.pzc'):
   pngpath=p.with_suffix('.png');assert pngpath.exists(),str(pngpath);im=Image.open(pngpath)
   for x,y,w,h in pzc_rects(p.read_bytes()):assert x+w<=im.width and y+h<=im.height,(path,x,y,w,h,im.size)
   checked+=1
  elif path.endswith('.zt1'):
   raw=unpack_zt1(p.read_bytes());StringTable.parse(raw) if raw.startswith(b'GST') else RecordTable.parse(raw)
 assert sha(args.apk.read_bytes())==EXPECTED
 report['validation']={'source_unchanged':True,'pzc_png_pairs_checked':checked,'all_rects_within_textures':True,'pumas_original_crest_pixels_preserved':True,'pumas_mapping_rows_preserved':True,'pumas_original_uniform_and_defender_folders_unmodified':True,'my_player_ids_not_renamed':True,'unique_decimal_player_names':len(set(PLAYER_NAMES.values())),'player_name_range':['1','310'],'runtime_verified':False}
 report['limitations']=['Pixel/frame bounds are verified statically; actual animation appearance needs device verification.','Shared regenerated face/hair resources also affect any player using those default resources; this is not a unique portrait for every roster entry.','Some costume/hair/equipment resources remain original where runtime selects a separate resource outside the new team uniform hooks.','Generated RGB was cropped/resampled and clipped to original source alpha geometry; nearest generated opaque samples fill export holes, never original RGB.']
 report['overlay_file_count']=len(report['files']);(BASE/'art_overlay_manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 (BASE/'team_and_player_identity.json').write_text(json.dumps({'teams':TEAM_NAMES,'preserved_team_id':4,'players':PLAYER_NAMES,'preserved_player_ids':[1000,1100]},ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({'overlay':str(args.out),'files':len(report['files']),'pzc_pairs':checked,'validation':report['validation']},ensure_ascii=False))
if __name__=='__main__':main()
