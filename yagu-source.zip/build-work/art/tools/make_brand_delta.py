"""Create a small, hash-gated text delta over artwork overlay v1.1.

Only the original main-frame title string and start-game hint change. No image,
font, menu geometry, art atlas, animation or other table row is rewritten.
Apply this directory after overlay-v1 when packaging the local APK.
"""
import argparse
import hashlib
import json
from pathlib import Path
import zipfile

from zt1_codec import RecordTable, StringTable, pack_zt1, unpack_zt1

WORK = Path(__file__).resolve().parents[3]
ART = Path(__file__).resolve().parents[1]
SOURCE_SHA256 = '2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484'
LOCALES = {
    'kor': ('assets/data', '투타겸업 또는 나만의 투수로 진행합니다'),
    'eng': ('assets/global_language/eng', 'Play Two-way or My Pitcher.'),
    'jap': ('assets/global_language/jap', '二刀流/オリジナル投手を育成します。'),
    'cha_CN': ('assets/global_language/china_cn', '进行投打兼修或我的投手。'),
    'cha_TW': ('assets/global_language/china_tw', '進行投打雙修或我的投手。'),
    'spn': ('assets/global_language/spn', 'Juega Doble rol o Mi Lanzador.'),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--apk', type=Path, default=WORK / 'upload/baseball-superstars-2013-1-2-9.apk')
    p.add_argument('--base-overlay', type=Path, default=ART / 'overlay-v1')
    p.add_argument('--out', type=Path, default=ART / 'overlay-v1.2-delta')
    p.add_argument('--manifest', type=Path, default=ART / 'brand_delta_v1.2.json')
    args = p.parse_args()
    if sha(args.apk.read_bytes()) != SOURCE_SHA256:
        raise SystemExit('Unsupported source APK SHA256')
    manifest = {'version': '1.2', 'type': 'text-only delta', 'apply_after': 'overlay-v1',
                'source_apk_sha256': SOURCE_SHA256, 'entries': [],
                'images_changed': 0, 'layout_or_style_fields_changed': 0}

    with zipfile.ZipFile(args.apk) as apk:
        def source(path):
            local = args.base_overlay / path
            return local.read_bytes() if local.is_file() else apk.read(path)

        def write(path, before, raw, changes):
            after = pack_zt1(raw)
            assert unpack_zt1(after) == raw
            target = args.out / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(after)
            manifest['entries'].append({'path': path, 'bytes': len(after),
                                        'input_sha256': sha(before), 'sha256': sha(after),
                                        'decoded_sha256': sha(raw), 'changes': changes})

        for language, (common_directory, hint) in LOCALES.items():
            path = f'assets/ui_text/XlsMainframe_{language}.zt1'
            before = source(path)
            raw = unpack_zt1(before)
            table = RecordTable.parse(raw)
            if table.row_count != 48 or len(table.types) != 9 or table.types[8] < 11:
                raise ValueError('Unexpected original main-frame table schema')
            row, column = 19, 8
            start = table.data_start + row * table.row_stride + table.offsets[column]
            width = table.widths[column]
            old = raw[start:start + width].split(b'\0', 1)[0].decode('utf-8')
            replacement = '야구'.encode('utf-8')
            if len(replacement) >= width:
                raise ValueError('Header string does not fit its original cell')
            result = bytearray(raw)
            result[start:start + width] = replacement + b'\0' * (width - len(replacement))
            assert result[:start] == raw[:start]
            assert result[start + width:] == raw[start + width:]
            parsed = RecordTable.parse(bytes(result))
            assert (parsed.types, parsed.row_count, parsed.row_stride) == (
                table.types, table.row_count, table.row_stride)
            write(path, before, bytes(result), [{'row': row, 'column': column,
                                               'old': old, 'new': '야구',
                                               'field_width': width, 'byte_offset': start}])

            path = f'{common_directory}/StrCOMMON_BB2013.zt1'
            before = source(path)
            table = StringTable.parse(unpack_zt1(before))
            old = table.strings[136].rstrip(b'\0').decode('utf-8')
            result = table.replace({136: hint})
            after_table = StringTable.parse(result)
            assert all(a == b for index, (a, b) in enumerate(zip(table.strings, after_table.strings))
                       if index != 136)
            write(path, before, result, [{'string_index': 136, 'old': old, 'new': hint}])

    manifest['entries'].sort(key=lambda item: item['path'])
    manifest['entry_count'] = len(manifest['entries'])
    manifest['total_bytes'] = sum(item['bytes'] for item in manifest['entries'])
    # Deterministic digest over entry paths and their binary content hashes.
    manifest['content_sha256'] = sha('\n'.join(
        f"{item['path']} {item['sha256']}" for item in manifest['entries']).encode('utf-8'))
    args.manifest.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: manifest[key] for key in
                      ('version', 'entry_count', 'total_bytes', 'content_sha256')}, indent=2))


if __name__ == '__main__':
    main()
