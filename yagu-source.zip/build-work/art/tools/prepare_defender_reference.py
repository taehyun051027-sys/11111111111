from PIL import Image
from pathlib import Path
import json,zipfile,io
root=Path('build-work/art')
z=zipfile.ZipFile('upload/baseball-superstars-2013-1-2-9.apk')
variants=[('blue','blue'),('crimson','red'),('emerald','green'),('violet','violet'),('gold','yellow'),('cyan','blue'),('graphite','black'),('navy','navy_blue'),('silver','gray'),('coral','orange')]
parts=[('head',8,8),('body',280,8),('calves',360,8),('stripes',408,8),('leg',280,152),('arm',8,280)]
for g in range(2):
 canvas=Image.new('RGBA',(1584,848))
 slots=[]
 for i,(variant,folder) in enumerate(variants[g*5:g*5+5]):
  ox=(i%3)*528;oy=(i//3)*424
  for part,x,y in parts:
   path=f'assets/defender/{folder}/{part}.png';img=Image.open(io.BytesIO(z.read(path))).convert('RGBA')
   canvas.alpha_composite(img,(ox+x,oy+y))
   slots.append(dict(path=path,part=part,variant=variant,x=ox+x,y=oy+y,w=img.width,h=img.height,native_w=img.width,native_h=img.height))
 canvas.save(root/'reference'/f'defender_reference_{g}.png')
 (root/f'defender_reference_{g}_slots.json').write_text(json.dumps(dict(width=canvas.width,height=canvas.height,slots=slots),indent=2))
