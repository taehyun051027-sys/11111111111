"""Merge reviewed logo/identity and text overlays with strict provenance checks."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True)
    parser.add_argument('--base-manifest', type=Path, required=True)
    parser.add_argument('--brand', type=Path, required=True)
    parser.add_argument('--brand-manifest', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--manifest', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError('Select a fresh output directory')
    base = json.loads(args.base_manifest.read_text())
    brand = json.loads(args.brand_manifest.read_text())
    merged = {}
    for directory, rows in ((args.base, base['files']), (args.brand, brand['entries'])):
        actual = {p.relative_to(directory).as_posix() for p in directory.rglob('*') if p.is_file()}
        assert actual == {row['path'] for row in rows}
        for row in rows:
            path = directory / row['path']
            assert not path.is_symlink()
            assert path.stat().st_size == row['bytes']
            assert hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256']
            destination = args.out / row['path']
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, destination)
            merged[row['path']] = dict(row)
    preserved = ('assets/bat/', 'assets/pit/', 'assets/defender/', 'assets/stadium/')
    assert not any(path.startswith(preserved) for path in merged)
    report = dict(base)
    report.update(version='2.1-stock-black', files=[merged[k] for k in sorted(merged)],
                  base_file_count=len(base['files']), brand_file_count=len(brand['entries']),
                  overlay_file_count=len(merged), brand_content_sha256=brand.get('content_sha256'))
    args.manifest.parent.mkdir(parents=True, exist_ok=True)
    args.manifest.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'version': report['version'], 'files': len(merged),
                      'player_and_stadium_images_replaced': 0}))


if __name__ == '__main__':
    main()
