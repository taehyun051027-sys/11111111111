"""Strict, dependency-free codecs for the observed Baseball 2013 .zt1 tables.

Only formats demonstrated in the supplied APK are supported. This module does
not modify an APK, a save, or an installed app.
"""
from __future__ import annotations

from dataclasses import dataclass
import struct
import zlib


def unpack_zt1(blob: bytes, max_size: int = 8 * 1024 * 1024) -> bytes:
    if len(blob) < 10:
        raise ValueError("Truncated ZT1 container")
    packed_size, raw_size = struct.unpack_from("<II", blob)
    if packed_size != len(blob) or raw_size > max_size:
        raise ValueError("ZT1 length mismatch or excessive declared size")
    inflater = zlib.decompressobj()
    raw = inflater.decompress(blob[8:], raw_size + 1)
    if len(raw) != raw_size or not inflater.eof or inflater.unused_data or inflater.unconsumed_tail:
        raise ValueError("ZT1 zlib stream/decoded length mismatch")
    return raw


def pack_zt1(raw: bytes) -> bytes:
    compressed = zlib.compress(raw, 9)
    return struct.pack("<II", len(compressed) + 8, len(raw)) + compressed


@dataclass(frozen=True)
class StringTable:
    prefix: bytes
    strings: tuple[bytes, ...]

    @classmethod
    def parse(cls, raw: bytes) -> "StringTable":
        if len(raw) < 10 or raw[:6] != b"GST\x02\x01\x00":
            raise ValueError("Expected observed GST2/encoding1 format")
        count = struct.unpack_from("<H", raw, 6)[0]
        base = 8 + 2 * (count + 1)
        if base > len(raw):
            raise ValueError("Truncated GST2 offset table")
        offsets = struct.unpack_from("<" + "H" * (count + 1), raw, 8)
        if offsets[0] != base or offsets[-1] != len(raw):
            raise ValueError("GST2 boundary mismatch")
        if any(a >= b for a, b in zip(offsets, offsets[1:])):
            raise ValueError("GST2 offsets must be strictly increasing")
        strings = tuple(raw[a:b] for a, b in zip(offsets, offsets[1:]))
        if any(not s.endswith(b"\0") for s in strings):
            raise ValueError("GST2 entry lacks a terminator")
        return cls(raw[:8], strings)

    def replace(self, changes: dict[int, str]) -> bytes:
        entries = list(self.strings)
        for index, value in changes.items():
            if not 0 <= index < len(entries) or "\0" in value:
                raise ValueError("Invalid GST2 string replacement")
            entries[index] = value.encode("utf-8") + b"\0"
        position = 8 + 2 * (len(entries) + 1)
        offsets = [position]
        for entry in entries:
            position += len(entry)
            offsets.append(position)
        if position > 65535:
            raise ValueError("GST2 16-bit offset capacity exceeded")
        raw = self.prefix + struct.pack("<" + "H" * len(offsets), *offsets) + b"".join(entries)
        check = self.parse(raw)
        for i, entry in enumerate(self.strings):
            if i not in changes and check.strings[i] != entry:
                raise AssertionError("An unrelated string changed")
        return raw


@dataclass(frozen=True)
class RecordTable:
    raw: bytes
    format_version: int
    row_stride: int
    row_count: int
    types: tuple[int, ...]
    widths: tuple[int, ...]
    offsets: tuple[int, ...]
    data_start: int

    @classmethod
    def parse(cls, raw: bytes) -> "RecordTable":
        if len(raw) < 10 or raw[:3] != b"GXL" or raw[3] not in (1, 2):
            raise ValueError("Expected GXL1 or GXL2")
        version = raw[3]
        header_size = 12 if version == 2 else 10
        if len(raw) < header_size:
            raise ValueError("Truncated GXL header")
        if version == 2 and raw[4:6] != b"\x01\x00":
            raise ValueError("Unsupported GXL2 encoding flag")
        stride, columns, count = struct.unpack_from("<HHH", raw, 6 if version == 2 else 4)
        types = tuple(raw[header_size:header_size + columns])
        if len(types) != columns or not stride or not columns:
            raise ValueError("Invalid GXL schema")
        widths = []
        offsets = []
        for kind in types:
            offsets.append(sum(widths))
            if kind in (0, 1):
                widths.append(1)
            elif kind in (2, 3):
                widths.append(2)
            elif kind == 4:
                widths.append(4)
            elif kind >= 11:
                widths.append(kind - 10)
            else:
                # Type 10 occurs in mission tables but its semantics are not
                # established. Reject it; never silently guess a field size.
                raise ValueError(f"Unsupported GXL type {kind}")
        data_start = header_size + columns
        if sum(widths) != stride or len(raw) != data_start + stride * count:
            raise ValueError("GXL schema size does not match the payload")
        return cls(raw, version, stride, count, types, tuple(widths), tuple(offsets), data_start)

    def row(self, row_index: int) -> bytes:
        if not 0 <= row_index < self.row_count:
            raise IndexError(row_index)
        start = self.data_start + row_index * self.row_stride
        return self.raw[start:start + self.row_stride]

    def numeric_name_overlay(self, preserved_ids: set[int]) -> tuple[bytes, list[int]]:
        if self.types[:2] not in ((3, 27), (3, 19)):
            raise ValueError("Unexpected player ID/name columns")
        output = bytearray(self.raw)
        changed = []
        width = self.widths[1]
        allowed = set()
        for row_index in range(self.row_count):
            row = self.row(row_index)
            player_id = struct.unpack_from("<H", row)[0]
            if player_id in preserved_ids:
                continue
            value = f"{player_id:04d}".encode("ascii")
            if len(value) >= width:
                raise ValueError("Numeric name would overflow name field")
            start = self.data_start + row_index * self.row_stride + self.offsets[1]
            output[start:start + width] = value + b"\0" * (width - len(value))
            allowed.update(range(start, start + width))
            changed.append(player_id)
        if any(a != b and i not in allowed for i, (a, b) in enumerate(zip(self.raw, output))):
            raise AssertionError("A non-name player field changed")
        parsed = self.parse(bytes(output))
        if parsed.row_count != self.row_count or parsed.row_stride != self.row_stride:
            raise AssertionError("Player schema changed")
        return bytes(output), changed
