"""Hash-gated, read-only original ELF inspection for world/career design."""
from pathlib import Path
import argparse
import bisect
import hashlib
import io
import json
import re
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'analysis/native/tools'), str(ROOT / 'recovery/apk_data/python')]
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_ARCH_ARM, CS_MODE_ARM, CS_MODE_THUMB

EXPECTED = {'arm64-v8a': '83fd7f2d689e304b05d77c35885dc95e9b518b0b577a71cda5f2fadad81f78a5',
            'armeabi-v7a': '71e99eaa3733002c466d04205d2ebfadf1285d72acf21e286500ad203d28b960'}


class Original:
    def __init__(self, abi='arm64-v8a'):
        self.abi = abi
        self.is64 = abi == 'arm64-v8a'
        self.raw = (ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so').read_bytes()
        self.sha = hashlib.sha256(self.raw).hexdigest()
        if self.sha != EXPECTED[abi]: raise ValueError('Unexpected original library')
        self.elf = ELFFile(io.BytesIO(self.raw))
        syms = list(self.elf.get_section_by_name('.dynsym').iter_symbols())
        names = subprocess.run(['c++filt'], input='\n'.join(s.name for s in syms),
                               text=True, capture_output=True, check=True).stdout.splitlines()
        self.functions = {n: {'address': s['st_value'] & ~int(not self.is64),
                             'size': s['st_size'], 'mangled': s.name}
                          for s, n in zip(syms, names)
                          if s['st_value'] and s['st_info']['type'] == 'STT_FUNC'}
        self.labels = {s['st_value'] & ~int(not self.is64): n for s, n in zip(syms, names) if s['st_value']}
        self.plt = {}
        start = self.elf.get_section_by_name('.plt')['sh_addr']
        rels = self.elf.get_section_by_name('.rela.plt' if self.is64 else '.rel.plt')
        for i, rel in enumerate(rels.iter_relocations()):
            self.plt[start + 32 + i * 16] = names[rel['r_info_sym']]
            self.labels[start + 32 + i * 16] = '[PLT] ' + names[rel['r_info_sym']]
        self.cs = Cs(CS_ARCH_ARM64, CS_MODE_ARM) if self.is64 else Cs(CS_ARCH_ARM, CS_MODE_THUMB)

    def read(self, address, size):
        for seg in self.elf.iter_segments():
            if seg['p_type'] == 'PT_LOAD' and seg['p_vaddr'] <= address < seg['p_vaddr'] + seg['p_filesz']:
                offset = seg['p_offset'] + address - seg['p_vaddr']
                if address + size > seg['p_vaddr'] + seg['p_filesz']: raise ValueError('Cross-segment read')
                return self.raw[offset:offset + size]
        raise ValueError('Unmapped address ' + hex(address))

    def dump(self, name):
        item = self.functions[name]
        lines = ['\n### ' + name + ' ' + hex(item['address']) + ' ' + str(item['size'])]
        for ins in self.cs.disasm(self.read(item['address'], item['size']), item['address']):
            annotation = ''
            if ins.mnemonic in ('b', 'b.w', 'bl', 'blx') and ins.op_str.startswith('#'):
                target = int(ins.op_str[1:], 16)
                if target in self.labels: annotation = ' ; ' + self.labels[target]
            lines.append(f'{ins.address:08x}: {ins.bytes.hex():8s} {ins.mnemonic:7s} {ins.op_str}{annotation}')
        return '\n'.join(lines)

    def callers(self, pattern):
        targets = {v['address']: k for k, v in self.functions.items() if re.search(pattern, k)}
        targets.update({k: v for k, v in self.plt.items() if re.search(pattern, v)})
        found = []
        if self.is64:
            sec = self.elf.get_section_by_name('.text')
            data, base = sec.data(), sec['sh_addr']
            funcs = sorted((v['address'], v['size'], k) for k, v in self.functions.items())
            starts = [f[0] for f in funcs]
            for offset in range(0, len(data) - 3, 4):
                word = struct.unpack_from('<I', data, offset)[0]
                if word & 0x7c000000 != 0x14000000: continue
                imm = word & 0x3ffffff
                if imm & 0x2000000: imm -= 0x4000000
                pc = base + offset
                target = pc + (imm << 2)
                if target not in targets: continue
                j = bisect.bisect_right(starts, pc) - 1
                fn = funcs[j][2] if j >= 0 and pc < funcs[j][0] + funcs[j][1] else '?'
                found.append({'caller': fn, 'site': hex(pc), 'target': targets[target], 'target_address': hex(target)})
        else:
            seen = set()
            for name, item in self.functions.items():
                if item['address'] in seen: continue
                seen.add(item['address'])
                for ins in self.cs.disasm(self.read(item['address'], item['size']), item['address']):
                    if ins.mnemonic not in ('b', 'b.w', 'bl', 'blx') or not ins.op_str.startswith('#'): continue
                    target = int(ins.op_str[1:], 16)
                    if target in targets:
                        found.append({'caller': name, 'site': hex(ins.address), 'target': targets[target], 'target_address': hex(target)})
        return found


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--abi', choices=list(EXPECTED), default='arm64-v8a')
    parser.add_argument('--match')
    parser.add_argument('--callers')
    parser.add_argument('--out', type=Path)
    args = parser.parse_args()
    original = Original(args.abi)
    if args.callers: output = json.dumps(original.callers(args.callers), indent=2) + '\n'
    else: output = '\n'.join(original.dump(name) for name in original.functions if re.search(args.match or '.', name)) + '\n'
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(output)
        print(args.out, len(output), 'characters')
    else: print(output)
