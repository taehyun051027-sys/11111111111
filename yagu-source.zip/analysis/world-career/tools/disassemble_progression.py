"""Read-only original career progression audit; no APK execution or edits."""
from pathlib import Path
import sys,io,json,subprocess,hashlib
ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'recovery/apk_data/python'))
from elftools.elf.elffile import ELFFile
from capstone import Cs,CS_ARCH_ARM64,CS_ARCH_ARM,CS_MODE_ARM,CS_MODE_THUMB

EXPECTED={'arm64-v8a':'83fd7f2d689e304b05d77c35885dc95e9b518b0b577a71cda5f2fadad81f78a5',
          'armeabi-v7a':'71e99eaa3733002c466d04205d2ebfadf1285d72acf21e286500ad203d28b960'}
KEYS=('CBBGDataMgr::ProcRetire','CBBGDataMgr::GetPastRaise',
      'CBBGRaisePlayerRun::DoProcessEndYear','CBBGRaisePlayerRun::DoProcessNextYear',
      'CBBGRaisePlayerRun::DoProcRetirePlayerContinueCheck',
      'CBBGRaisePlayerRun::INIT_HANDLER_MSTATE_RAISE_PLAYER_RETIRE',
      'CBBGRaisePlayerRun::EVENT_HANDLER_MSTATE_RAISE_PLAYER_RETIRE',
      'CBBGRaisePlayerRun::INIT_HANDLER_MSTATE_RAISE_PLAYER_ENDING',
      'CBBGRaisePlayerRun::EVENT_HANDLER_MSTATE_RAISE_PLAYER_ENDING',
      'CBBGRaiseMode::SeasonClear','CBBGRaiseMode::IsEndingFlag',
      'CBBGLeagueMode::Season','CBBGLeagueMode::GetSeasonYear','CBBGLeagueMode::SetSeasonYear',
      'CBBGLeagueMode::CubGameClear','CBBGLeagueMode::GetCubGameCnt','CBBGLeagueMode::SetCubGameCnt',
      'CBBGModeData::GetTotalPostSeason1St','CBBGModeData::GetTotalPostSeasonMVP',
      'CBBGModeData::SetPostseasonRanking','CBBGModeData::SetPostSeasonMVP')

for abi in EXPECTED:
    raw=(ROOT/'analysis/native/lib'/abi/'libgameDSO.so').read_bytes()
    assert hashlib.sha256(raw).hexdigest()==EXPECTED[abi]
    elf=ELFFile(io.BytesIO(raw));is64=abi=='arm64-v8a'
    syms=list(elf.get_section_by_name('.dynsym').iter_symbols())
    names=subprocess.run(['c++filt'],input='\n'.join(s.name for s in syms),text=True,capture_output=True,check=True).stdout.splitlines()
    named={s.name:n for s,n in zip(syms,names)}
    labels={int(s['st_value'])&~(not is64):n for s,n in zip(syms,names) if s['st_value']}
    plt=elf.get_section_by_name('.plt')['sh_addr']
    rel=elf.get_section_by_name('.rela.plt' if is64 else '.rel.plt')
    for i,r in enumerate(rel.iter_relocations()):labels[plt+32+i*16]='[PLT] '+names[r['r_info_sym']]
    def read(va,size):
        for seg in elf.iter_segments():
            if seg['p_type']=='PT_LOAD' and seg['p_vaddr']<=va<seg['p_vaddr']+seg['p_filesz']:
                off=seg['p_offset']+va-seg['p_vaddr'];return raw[off:off+size]
        raise ValueError(hex(va))
    cs=Cs(CS_ARCH_ARM64,CS_MODE_ARM) if is64 else Cs(CS_ARCH_ARM,CS_MODE_THUMB)
    lines=[];manifest=[];seen=set()
    for s,n in zip(syms,names):
        va=int(s['st_value'])&~(not is64);size=int(s['st_size'])
        if not va or not size or va in seen or not any(n.startswith(k) for k in KEYS):continue
        seen.add(va);manifest.append({'name':n,'address':hex(va),'size':size})
        lines.append(f'\n### {n} {va:#x} {size}')
        for insn in cs.disasm(read(va,size),va):
            extra=''
            if insn.mnemonic in ('bl','blx','b','b.w') and insn.op_str.startswith('#'):
                try:target=int(insn.op_str[1:],16);extra=' ; '+labels[target] if target in labels else ''
                except ValueError:pass
            lines.append(f'{insn.address:08x}: {insn.bytes.hex():8s} {insn.mnemonic:7s} {insn.op_str}{extra}')
    out=ROOT/'analysis/world-career'
    (out/(abi+'.txt')).write_text('\n'.join(lines)+'\n')
    (out/(abi+'-symbols.json')).write_text(json.dumps(manifest,indent=2)+'\n')
    print(abi,len(manifest),'functions',len(lines),'lines')
