# World / career handoff — read-only findings

Status: original native and APK data inspection, 2026-11-19. The finite level250 and pure1400 policy is integrated into candidate7 and has passed7,820 original-consumer cases across both ABIs after the six honor metrics were added. The original long-year/storage boundaries below remain unresolved. Original APK SHA256 is `2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484`; all disassembly tools reject different original gameDSO hashes.

## World design constraint

Preserve the actual original game, controls, layout and 9-inning baseball flow. Team4 is Daegu Pumas. The other nine league teams are 알파, 베타, 감마, 델타, 엡실론, 제타, 에타, 세타, 요타; the five world teams are 입실론, 파이, 카이, 프사이, 오메가. Only the owned My actors (RFID1000/1100 with actual roster/save ownership) have tagged Unbounded state. An elite-world policy must give other players finite legitimate abilities and keep actual game score/outs finite.

Latest direction: retain original stadium/background/character artwork; replace opposing club logos and make every team's uniform, including Pumas/My Player, full black. The stadium inventory below is consumption evidence only. No new stadium illustration is authorized or applied.

## Universal is not sufficient for elite rosters

`CBBGPlayerData::GetLevel()` (A64 `0x587a44`, Thumb `0x37bf98`) reads the stored unsigned byte at actor+`0x16`. In modes3/4 it derives original team IDs from BAT RFID `(id-1)/12` and PIT `(id-400)/8`. It deliberately skips all Option boosts for the own team. Main-league opponents use stored level plus the Option boost; world teams10..14 use the Option level as their level. Thus forcing league kind9 does **not** automatically strengthen Pumas teammates or regular opponents at career creation.

Original roster tables have BAT base levels1..10 and PIT2..8 at column4/offset22. They retain four distinct pure abilities at offsets24,26,28,30. `SetDefaultPlayer` resets replacement players to level1 (`0x58d284`, `0x58d2f4`), so a one-time save mutation alone would not cover later replacement paths.

`SetRaiseTeamAddLv(bool careerIsBat,bool actorIsBat,int team,int value)` clamps its byte to0..250 (`0x590e30`; calls at `0x590e8c`, `0x590ec4`, `0x590f00`). Its BAT-career arrays use Option+`0x230`, stride15; PIT-career main-league arrays use Option+`0x112`, stride10. World teams use the former arrays in either career. The getter does not add another clamp. Returning250 from the original NPC level consumer is safer than adding250 to base levels, which can produce251..260.

World Cup entry sets world-team levels from original A64 table `0x7a1b28`: `[5,10,25,40,60,85,110,140,180,230]`. Kind9 therefore gives world teams230 when `INIT_HANDLER_MSTATE_RAISE_PLAYER_CUB_GAME` runs (`0x493b04`→`0x493b54`→two setter calls). Initial mode setup seeds only teams10..14 with table element0, value5 (`0x4a078c`..`0x4a080c`). Regular opponents' later-season boosts depend on league and promotion result; Pumas is excluded.

`GetStatus` (`0x5885d0`) computes ordinary, non-My/non-HOF ability as pure ability + level×(grade+3), then applies existing items/skills and finite clamps. The main cap is signed16 value3500 at A64 `0x29307e`; some passive branches use cap2100 (`0x834`). This is materially different from My's compatibility adapter10000 and tagged Unbounded behavior. A finite elite policy should preserve original arithmetic and these bounds unless separately audited.

**Implemented/verified:** exact first15-team active-roster pointer policy, level250, and integrated pure1400; both ABIs pass7,820 original-consumer cases. Original grade and skill fields are preserved. The grade nibble has no semantic setter clamp and only two direct growth/prediction consumers, so no arbitrary higher grade is selected. Remaining NPC skill-level changes require a separate consumer audit. Unrelated modes and copied actors retain original behavior. `CBBGStatic::GetPlayerSkillLv` includes league-dependent table `[0,1,2,3,3,3,4,4,4,5]` at `0x28e264`; the observed normal Universal NPC skill value is5, not an established universal safe10. No independent club-facility tier was found in the inspected symbols/strings; training levels, world-map open flags, spring camps and team average level are distinct original systems.

Evidence: `elite-a64.txt`, `elite-callers-a64.json`, `expansion-a64.txt`, `expansion-callers-a64.json`, `league-a64.txt`.

## Career continuation and bounds

Retirement is optional in the inspected path. `DoProcessNextYear` (`0x4a1bc4`) schedules retirement state0x7b at year10 and every five years from15. `EVENT_HANDLER_MSTATE_RAISE_PLAYER_RETIRE` (`0x49d4fc`) checks `GetSltTalkIdx`: choice0 continues to next-season state0x4d; nonzero goes to ending0x7c. `r_event_6_txt.zt1` explicitly contains continue-playing and retire choices. `DoProcRetirePlayerContinueCheck` copies skill/trait progression for a continued/new player; its name alone is not a forced-age-limit predicate. Do not suppress the user's existing retirement choice.

Concrete long-career risks remain:

| Original storage / consumer | Confirmed boundary |
|---|---|
| League year at league+0xe2 | Getter loads unsigned16. Setter's API is **signed char** and narrows before clamping0..9999. |
| `SeasonClear` | Reads year, sign-extends low byte, increments, clears0xee-byte league object, calls signed-char setter. Original transition127→128 becomes negative then0. |
| Pennant ranks at mode+0x15 |32-byte array inferred directly from adjacent postseason array and totals loop32. Setter writes `base+year` without bounds checking. At index32 it overwrites postseason rank0. |
| Postseason ranks at mode+0x35 | Totals loop32; setter has unchecked `base+year` byte write. |
| Personal past records at save+0x830 | BAT stride24 / PIT32; getter clamps every index≥9 to9. `PostSeasonClear` shifts older slots for year≥9 and writes new records. This is bounded history, not unlimited season storage. |
| Cumulative original record analyzer | Limits number of past-record slots to10 and sums finite narrow fields. |

A64/Thumb exact methods: `SeasonClear` `0x3659e0`/`0x215274`; `SetSeasonYear` `0x365a88`/`0x2152d6`; `SetPenntraceRanking` `0x4a4450`/`0x2e3e14`; `SetPostseasonRanking` `0x4a3ee0`/`0x2e3aea`. History setters, award masks and year-dependent event consumers need a coordinated adapter before claiming indefinite seasons. Simply bypassing retirement or widening only the year setter is insufficient.

Evidence: `arm64-v8a.txt`, `armeabi-v7a.txt`, `year-limits-a64.txt`, `year-consumers-a64.json`. No practical forced final season has yet been established.

## Stadium asset consumption

`LoadTexMaker` A64`0x520574` / Thumb`0x3380c0` checks postseason first (playoff atlas, random frame0/1), then World Cup (cup atlas, frame0), then regular home team. Regular resource is0xd63+homeTeam and frame comes from `XlsStadium[column0,row=homeTeam]`. League kind and uniform style do not select the stadium.

| Home team ID | Atlas basename | Frame |
|---:|---|---:|
|0|bat_public_stadium_01_02|0|
|1|bat_public_stadium_01_02|1|
|2|bat_public_stadium_03_07_09|0|
|3|bat_public_stadium_04_05_06|0|
|4 Pumas|bat_public_stadium_04_05_06|1|
|5|bat_public_stadium_04_05_06|2|
|6|bat_public_stadium_03_07_09|1|
|7|bat_public_stadium_08_10|0|
|8|bat_public_stadium_03_07_09|2|
|9|bat_public_stadium_08_10|1|

All paths have prefix `assets/stadium/` and paired `.png`/`.pzc`. Regular and playoff PNGs are1024×1024; cup is1024×512; shared ground1024×256; defense2048×2048. Shared crowd `stadium_ppl` is256×256 with five104×56 source images and15 animation frames. Texture-maker allocation remains2048×2048. Keep original PNG dimensions, alpha/UV bounds, PZC component transforms and frame indices for any new illustration; the original panorama uses repeated/stretched components, so replacing only a loose concept picture would not cover the game.

Exact rectangles, source hashes and frame-section bytes are in `stadium/stadium_inventory.json`; native resource table evidence is `stadium/native_path_table.json`. Extracted original image inputs stay in analysis scratch and are not a public standalone deliverable. Existing in-game commentator methods and sound assets were identified but no additional broadcast presentation layer has been established.
