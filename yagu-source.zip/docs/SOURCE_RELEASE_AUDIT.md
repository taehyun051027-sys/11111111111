# 공개 소스·문서 감사

감사일:2026-11-19. 대상은 현재 candidate7 작업 트리와 `build-work/release/package_project.py`의 읽기 전용 파일 선택 결과다. 이 문서는 최종 ZIP 생성·업로드·9이닝 완료를 확인하는 보고서가 아니다. 최종 압축 파일의 정확한 목록과 해시는 패키징 보고서가 별도로 기록한다.

## 현재 사실 기준

| 항목 | 감사 기준 |
| --- | --- |
| 원본 APK | SHA256 `2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484` |
| 현재 공유 C | SUPER·장비 강화·타격 보호·지갑·지갑UI까지 `55718d9ceb7b6544221f59c99cc969b11f6f5919f73e923d7504dc7356bf9959`; 후속 SP·팀/멘탈 표시와 최종 해시는 별도 고정 |
| 검증 후보 APK | `yagu-unbounded-dev.apk`,59,320,719바이트, SHA256 `e4adc5805bbc09911917b9e5f8349f6b35f01e539e4f551f7358c6450efc0e28`; 전체9이닝 미검증 |
| 후속 소스 타입 상태 | 선수 스키마4/51필드; 개인 기록 스키마4/40지표=33 Unbounded+7 zero; 실행 APK 버전과 분리 |
| 수상6종 | 정규·포스트시즌·컵의 우승/MVP 이벤트 조건 구현; 전용 누적 횟수 UI 발견 여부와 별개 |
| 시상식 본인 성과 | 소유 현재·과거 성과의∞/ERA0 표시; MVP 고정 보상·연말 금액·실제 시상 저장은 보존 |
| 유한 세계 | 정확한 활성15팀 NPC만 레벨250·순수1400; 원본 공식·등급·스킬·상한 유지 |
| 리소스 |2.1-stock-black,53개 고유 파일,2,382,750바이트, 사용 생성 소스4장 |
| 실기 증거 버전 | checkpoint4의 커리어·첫 HR, 이어 e4adc 후보의 실제 투타 경기와7이닝21K·5회초 HR; 전체9이닝은 아직 미확인 |
| 실기 환경 | 공식32.1.14/API24 ARMv7, 호스트 렌더러 호환 수정, APK 원본 Cocos 유지 |
| 웹 | 실제 APK 프레임·입력·PCM 스트림; 현재 플레이 URL 없음 |

실행 중인 한국어 후보에서 `강화 Lv1`, 구단 `팀 Lv25`, My 멘탈 비교3500이 관찰됐다. 강화는 후속51필드 구조와 소비·표시 모듈에서 처리하고4,908건 명령 검증을 마쳤다. 나머지 소유 팀/능력 표시는 별도 통합·검증 대상이다. 태그 개수와 한 화면의∞만으로 모든 소비자·표시가 완성됐다고 결론 내리지 않는다.2·7회초 무홈런 종료 관찰도 기록하며 전타석 홈런을 통과로 표시하지 않는다.

## 수정한 오래된 설명

| 이전 설명 | 수정한 내용 |
| --- | --- |
| 현재 소스가 candidate4이며 실제 메뉴까지만 확인됨 | candidate7 구현 범위와 checkpoint4의 첫 실제 홈런·투수 화면 증거를 별도 기재 |
|43개 능력,33개 기록 및 이전46/39 후보 | 후속 소스51개 선수 필드·40개 기록(33∞·7 zero), 실행 후보와 별도 표기 |
| 로컬 순위는 전부 원래 유한 값 | 타입 비교·본인 표시·타격8/투구7 탐색 구현, 미감사 소비자는 별도 제한 |
|17개 생성 그림·1,408개 리소스 | 사용된4개 생성 소스·53파일 계층; 이전 생성 선수/유니폼 그림 제외 |
| Pumas 유니폼은 보존 | Pumas 로고 보존, 유니폼·장비는 내 선수 포함 모든 팀 원본 검정 선택 |
| 공용 얼굴·수비수·상대별 유니폼을 새 그림으로 교체 | 현재 원본 캐릭터·경기장 리소스 유지, 로고·제목·아이콘만 새 그림 |
| 엘리트 NPC는 조사 중, pure1400은 미통합 | level250+pure1400 공유 소스 통합, 원본 소비자7,820건 확인 |
| 공식37에서 게임 검증 진행 중 |37 EGL 설정 실패 기록,32 호스트 렌더러 호환 복구 후 실제 첫 경기 관찰 |
| 실제 게임 소리는 캡처되지 않음 | 장치의 실제 비영 PCM 캡처 확인, 최신 배포 브라우저 경로는 별도 미검증 |
| 파일명 호환 후 오프라인 진행은 미확인 | 외부 연결 기본 차단 상태에서 checkpoint4 커리어·첫 경기 관찰 |
| 원화 재생성은 두 도구 뒤 수동 병합 | assembler와 두 입력 매니페스트를 명시,47+12−6=53 확인 |

갱신 파일: README, BUILD, COVERAGE, CURRENT_SCOPE, IMPLEMENTATION, WEB_SNAPSHOT, 원화 README, ELITE_WORLD_POLICY, WORLD_CAREER_DESIGN/FINDINGS. 과거 runtime_observations와 candidate3/4 보고서는 이력으로 보존하며 현재 보고서로 가는 안내를 추가했다.

## 공개 포함 기준

| 범주 | 필요한 선택 내용 |
| --- | --- |
| 루트 | README.md, BUILD.md, build.py, requirements.txt, requirements-art.txt 및 저장소 제외 규칙 |
| 네이티브 | 현재 `.py/.c/.h/.inc` 소스, 대응 검사기, 지도·범위 문서와 선택한 검증 JSON |
| 필수 C 조각 | 수상·시상식·SUPER·장비·타격 보호·자원·표시 `.inc`, `elite_world_policy.h` 및 실제 quoted include 전체 |
| 데이터 검증 | `analysis/data/tools/zt1_codec.py`; 엘리트 검사기가 이 경로를 import함 |
| Android 빌드 | 식별자·메타데이터·기존 검사 자산 호환·서명/검증 스크립트, 공개 인증서 해시 계산기 |
| Android 실행 소스 | emulator_session, gRPC 브리지/장치 클라이언트, 기본 차단 프록시·장치 경계 코드와 테스트, 계약 문서·공개 요약 보고서 |
| 공개 인증서 | `yagu-local-public-certificate.der` 한 파일만 명시 선택하고 X.509 DER로 파싱 |
| 리소스 내보내기 | build_art_overlay, make_brand_delta, assemble_art_overlay, zt1_codec 및 매니페스트 |
| 새 생성 소스 | crests.png, extra_crests.png, title_logo.png, launcher_icon.png 네 파일만 |
| 리소스 ZIP | 매니페스트와 정확히 일치하는 `overlays/art/`53파일 및 병합 매니페스트 |
| 웹 | 지정한 최신 Sites 소스의 client.html, package.json, CLIENT_CONTRACT, worker/scripts/tests, 검증된 비밀 없는 hosting.json |
| 문서 | 최신 범위·세계/커리어·원본 검정 외형·서명/재현성·실기 증거와 버전이 표시된 과거 기록 |

`yagu-original-art.zip`이라는 이름은 새로 생성한4개 소스 그림을 뜻한다. 원본 게임의 전체 원화 추출 묶음을 뜻하지 않는다. 리소스 ZIP의 파생 아틀라스는 실제 요청 변경에 필요한 오버레이이며 원본 APK를 따로 제공하지 않는다.

## 제외 기준

원본 APK, 원본/수정 `.so`, ELF·오브젝트·컴파일 출력, SDK·컴파일러·에뮬레이터 바이너리, Python/Node 의존성 디렉터리, 개인키·키스토어·비밀번호 파일·서비스 토큰·에뮬레이터 발견 파일, AVD·게임 저장·장치 덤프, 스트림 화면·음성·입력/확인 큐는 소스 ZIP에서 제외한다. 서명 APK는 소스와 구분된 별도 설치 결과물이다.

실행 입력 기록인 `intro-gated-actions.json`, `nickname-gated-actions.json`, `gameplay_candidate7_trace.json`과 현재 사용하지 않는 `prepare_defender_reference.py`도 선택에서 제외했다. 실제 경기 증거는 별도의 공개 요약으로 남긴다. 폴더 전체를 재귀 복사하지 않고 폴더별 확장자·정확한 파일명 규칙으로 선택한다. 새 파일이 추가되면 목록을 다시 감사한다.

## 패키저와 공개 입력 검사

패키저는 심볼릭 링크·중복 경로·절대 경로·`..`·역슬래시 경로를 거부한다. `.der` 확장자 전체를 허용하지 않고 공개 인증서 한 파일만 읽어 파싱한다. 원화의 길이·SHA256·정확한 파일 집합을 검사하고, ZIP을 만든 뒤 CRC·파일명·각 파일 해시를 다시 읽어 확인한다. 현재 정책의 보호 경로 아래 선수·경기장 교체 파일이0개인 것도 확인했다.

읽기 전용 감사는 패키저가 선택한 공개 입력만 검사했다. 개인키 PEM, GitHub/OpenAI/AWS 자격 증명 형태, 긴 리터럴 Bearer, JWT 패턴에서 발견된 값은 없었다. 공개 DER은 인증서로 정상 파싱됐다. 결과와 선택 당시의 파일 수·바이트 수는 [source_selection_audit.json](source_selection_audit.json)에 있다. 검사 결과에 민감한 문자열 자체를 기록하지 않는다.

`build-work/release/audit_public_sources.py`는 같은 선택 함수를 사용해 금지 경로·서명 URL·호스팅 메타데이터의 자격 증명 키와 실제 C quoted include의 포함 여부도 검사한다. 현재 감사는234개 파일을 읽었고 모든 실제 include가 포함됐으며 발견 사항은0건이었다. 작업 트리와 최종 ZIP을 고정한 뒤 다시 실행해야 한다.

```sh
python3 build-work/release/audit_public_sources.py \
  --source-root "$PWD" \
  --web-root /workspace/sites/yagu-play/.sites-checkout \
  --out docs/source_selection_audit.json
```

패턴 검사만으로 가능한 모든 비밀의 부재를 증명하지는 않는다. 디렉터리 경계, 공개 입력 선택과 실제 ZIP 목록을 함께 확인한다. 이 감사는 아직 생성하지 않은 최종 ZIP의 해시나 최종 게임 성공을 대신하지 않는다.

## 배포 전 남은 확인

최종 소스·후보 APK·원화·웹 파일 해시를 같은 패키징 시점에 고정해야 한다. 현재9이닝·27K·퍼펙트게임·경기 후 저장/재개·웹 전체 경로를 완료로 표시하면 안 된다. ARM64 실기, 전체 시즌/세계대회, 모든 UI/언어, 원본32칸 순위 배열·연차127→128·과거10기록 경계도 별도 제한으로 남긴다.
