#!/usr/bin/env python3
"""Build Yagu from the exact user-supplied APK, reviewed art, and a local key.

No original game binaries or tools are downloaded. Signing secrets are passed
to apksigner by caller-owned file path and are never copied into artifacts.
"""
import argparse
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXPECTED = '2c7792387492b6c3deebb52c162eeb0e147461de1c49e2d148490bec30194484'
ABIS = ('arm64-v8a', 'armeabi-v7a')


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_overlay(directory, entries):
    """Reject stale, missing, changed, extra, or symlinked overlay files."""
    expected = {row['path']: row for row in entries}
    if len(expected) != len(entries):
        raise ValueError('Duplicate overlay manifest paths')
    present = set()
    for path in directory.rglob('*'):
        if path.is_symlink():
            raise ValueError('Overlay symlinks are not allowed')
        if not path.is_file():
            continue
        relative = path.relative_to(directory).as_posix()
        row = expected.get(relative)
        if row is None or path.stat().st_size != row['bytes'] or sha256(path) != row['sha256']:
            raise ValueError('Unexpected overlay content: ' + relative)
        present.add(relative)
    if present != set(expected):
        raise ValueError('Overlay files missing: ' + ', '.join(sorted(set(expected) - present)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apk', type=Path, required=True)
    parser.add_argument('--zig', type=Path, required=True)
    parser.add_argument('--build-tools', type=Path, required=True)
    parser.add_argument('--public-certificate', type=Path, required=True)
    parser.add_argument('--keystore', type=Path, required=True)
    parser.add_argument('--password-file', type=Path, required=True)
    parser.add_argument('--key-alias', default='yagu-local')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    apk = args.apk.resolve(strict=True)
    output = args.output.resolve()
    if output == apk or output.exists():
        raise SystemExit('Select a new output filename; existing APKs are never overwritten')
    if sha256(apk) != EXPECTED:
        raise SystemExit('Source APK fingerprint mismatch')
    art = ROOT / 'overlays/art'
    if not (art / 'assets').is_dir():
        raise SystemExit('Extract yagu-art-overlay.zip into this source directory first')
    art_manifest = json.loads((ROOT / 'docs/art/art_overlay_manifest.json').read_text())
    verify_overlay(art, art_manifest['files'])

    spec = importlib.util.spec_from_file_location(
        'signer_certificate_hash', ROOT / 'build-work/android/signer_certificate_hash.py')
    certificate = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(certificate)
    certificates = certificate.public_certificates(args.public_certificate.resolve(strict=True))
    if len(certificates) != 1:
        raise SystemExit('Exactly one public signing certificate is required')
    der = certificates[0]
    signer_hash = certificate.signature_hash(der)
    env = os.environ.copy()
    env['YAGU_ZIG'] = str(args.zig.resolve(strict=True))
    env['YAGU_CERT_HASH'] = str(signer_hash)
    env['YAGU_ART_OVERLAY'] = str(art / 'assets')
    for path in (args.keystore, args.password_file):
        path.resolve(strict=True)
        if path.stat().st_mode & 0o077:
            raise SystemExit('Signing files must have private permissions (chmod 600)')
    build_tools = args.build_tools.resolve(strict=True)
    for tool in ('zipalign', 'apksigner', 'aapt2'):
        if not (build_tools / tool).is_file():
            raise SystemExit('Missing Android build tool: ' + tool)

    # The archive contains merged v1.2 artwork. Recreate its small text layer
    # and apply it explicitly after artwork, making overlay order reviewable.
    brand = ROOT / 'build/brand-overlay'
    brand.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run([
        sys.executable, str(ROOT / 'build-work/art/tools/make_brand_delta.py'),
        '--apk', str(apk), '--base-overlay', str(art), '--out', str(brand),
        '--manifest', str(ROOT / 'build/brand-delta-report.json'),
    ], cwd=ROOT, check=True)
    brand_manifest = json.loads((ROOT / 'build-work/art/brand_delta_v1.2.json').read_text())
    verify_overlay(brand, brand_manifest['entries'])

    with zipfile.ZipFile(apk) as archive:
        for abi in ABIS:
            destination = ROOT / 'analysis/native/lib' / abi / 'libgameDSO.so'
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(archive.read('lib/' + abi + '/libgameDSO.so'))
    subprocess.run([sys.executable, str(ROOT / 'build-work/native/payload_builder.py')],
                   cwd=ROOT, env=env, check=True)
    native = ROOT / 'build/native-overlay'
    for abi in ABIS:
        destination = native / 'lib' / abi / 'libgameDSO.so'
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / 'build-work/native/integrated/lib' / abi / 'libgameDSO.so', destination)
    identity = ROOT / 'build/identity-overlay'
    subprocess.run([
        sys.executable, str(ROOT / 'build-work/android/prepare_side_by_side.py'),
        str(apk), '--overlay', str(identity),
    ], cwd=ROOT, check=True)
    privacy = ROOT / 'build/privacy-overlay'
    subprocess.run([
        sys.executable, str(ROOT / 'build-work/android/prepare_privacy_metadata.py'),
        str(identity / 'AndroidManifest.xml'), '--overlay', str(privacy),
    ], cwd=ROOT, check=True)
    offline = ROOT / 'build/offline-checker-compat'
    subprocess.run([
        sys.executable, str(ROOT / 'build-work/android/prepare_checker_asset_compat.py'),
        str(apk), '--overlay', str(offline),
        '--report', str(ROOT / 'build/offline-checker-compat-report.json'),
    ], cwd=ROOT, check=True)
    subprocess.run([
        sys.executable, str(ROOT / 'build-work/android/repackage_sign.py'), str(apk),
        '--overlay', str(identity), '--overlay', str(privacy),
        '--overlay', str(art), '--overlay', str(brand), '--overlay', str(offline),
        '--overlay', str(native), '--build-tools', str(build_tools),
        '--keystore', str(args.keystore.resolve()),
        '--password-file', str(args.password_file.resolve()),
        '--key-alias', args.key_alias, '--output', str(output),
    ], cwd=ROOT, check=True)
    actual = certificate.public_certificates(output)
    if len(actual) != 1 or actual[0] != der:
        raise SystemExit('Signed APK certificate differs from configured native signer; do not distribute this output')
    print(json.dumps({
        'apk': str(output), 'sha256': sha256(output),
        'signer_sha256': hashlib.sha256(der).hexdigest(),
        'android_signature_hashCode': signer_hash,
        'art_overlay_version': art_manifest['version'],
        'art_entries': len(art_manifest['files']),
        'brand_delta_entries': len(brand_manifest['entries']),
        'overlay_order': ['identity', 'privacy-metadata', 'merged-art-v1.2',
                          'brand-v1.2', 'existing-checker-asset-alias', 'native'],
        'gameplay_verified_by_this_build': False,
    }, indent=2))


if __name__ == '__main__':
    main()
