"""A refused redirect must not create any request carrying the Site token."""
import importlib.util
import pathlib
import unittest
import urllib.error
import urllib.request

source = pathlib.Path(__file__).resolve().parents[1] / 'scripts/relay_transport.py'
spec = importlib.util.spec_from_file_location('relay_transport', source)
transport = importlib.util.module_from_spec(spec)
spec.loader.exec_module(transport)


class PrivateRelayTransport(unittest.TestCase):
    def test_redirects_never_forward_custom_authorization(self):
        request = urllib.request.Request('https://example.invalid/api/bridge/status',
                                         headers={'OAI-Sites-Authorization': 'Bearer test-only-placeholder'})
        handler = transport.NoSiteRedirects()
        for code in (301, 302, 303, 307, 308):
            for target in ('https://other.invalid/signin', 'http://example.invalid/api/bridge/status',
                           'https://example.invalid/login'):
                with self.subTest(code=code, target=target):
                    with self.assertRaises(urllib.error.HTTPError):
                        handler.redirect_request(request, None, code, 'redirect', {}, target)

    def test_invalid_site_origins_are_rejected_before_io(self):
        for origin in ('http://example.invalid', 'https://', 'https://u:p@example.invalid',
                       'https://example.invalid/?token=x', 'https://example.invalid/#x'):
            with self.subTest(origin=origin):
                with self.assertRaises(ValueError):
                    transport.private_site_opener(origin)

    def test_standard_tls_validation_is_retained(self):
        opener = transport.private_site_opener('https://example.invalid')
        self.assertEqual(sum(isinstance(h, transport.NoSiteRedirects) for h in opener.handlers), 1)
        self.assertEqual(sum(isinstance(h, urllib.request.HTTPSHandler) for h in opener.handlers), 1)


if __name__ == '__main__':
    unittest.main()
