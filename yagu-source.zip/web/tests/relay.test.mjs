import test from 'node:test';
import assert from 'node:assert/strict';
import {makeWorker,inputSchema} from '../worker/relay.js';
class MemoryR2 {
  data=new Map();
  async put(key,value,options={}){this.data.set(key,{bytes:typeof value==='string'?new TextEncoder().encode(value):new Uint8Array(value),...options});}
  async get(key){const o=this.data.get(key);return o?{body:o.bytes,customMetadata:o.customMetadata,json:async()=>JSON.parse(new TextDecoder().decode(o.bytes)),arrayBuffer:async()=>o.bytes.buffer.slice(o.bytes.byteOffset,o.bytes.byteOffset+o.bytes.byteLength)}:null;}
  async delete(key){this.data.delete(key);}
  async list({prefix,limit}){return {objects:[...this.data.keys()].filter(k=>k.startsWith(prefix)).sort().slice(0,limit).map(key=>({key}))};}
}
const origin='https://test.invalid';
const req=(path,method='GET',data,headers={})=>new Request(origin+path,{method,headers,body:data===undefined?undefined:JSON.stringify(data)});
test('input whitelist rejects shell, bounds and unbounded duration',()=>{
 assert.equal(inputSchema({kind:'shell',command:'anything'}),null);
 for(const x of [-1,800,NaN,1.5])assert.equal(inputSchema({kind:'tap',x,y:10}),null);
 assert.equal(inputSchema({kind:'swipe',x:1,y:1,x2:2,y2:2,duration:10000}),null);
 assert.deepEqual(inputSchema({kind:'key',key:'back'}),{kind:'key',key:'back'});
});
test('offline/stale actual emulator forbids queued control',async()=>{
 const BUCKET=new MemoryR2(),worker=makeWorker('<html>stream</html>');
 assert.equal((await worker.fetch(req('/api/input','POST',{kind:'tap',x:1,y:1}),{BUCKET})).status,409);
 await BUCKET.put('session/status.json',JSON.stringify({online:true,updatedAt:Date.now()-20000}));
 assert.equal((await worker.fetch(req('/api/status'),{BUCKET})).status,200);
 assert.equal((await worker.fetch(req('/api/input','POST',{kind:'tap',x:1,y:1}),{BUCKET})).status,409);
});
test('fresh input is delivered once then acknowledged; stale queue discarded',async()=>{
 const BUCKET=new MemoryR2(),worker=makeWorker('screen');
 await BUCKET.put('session/status.json',JSON.stringify({online:true,updatedAt:Date.now()}));
 const accepted=await (await worker.fetch(req('/api/input','POST',{kind:'tap',x:799,y:479}),{BUCKET})).json();
 assert.equal(accepted.accepted,true);
 let commands=await(await worker.fetch(req('/api/bridge/commands'),{BUCKET})).json();
 assert.equal(commands.commands.length,1);assert.equal(commands.commands[0].x,799);
 await worker.fetch(req('/api/bridge/ack','POST',{ids:[accepted.id]}),{BUCKET});
 commands=await(await worker.fetch(req('/api/bridge/commands'),{BUCKET})).json();assert.equal(commands.commands.length,0);
 await BUCKET.put('commands/old.json',JSON.stringify({createdAt:Date.now()-20000}));
 commands=await(await worker.fetch(req('/api/bridge/commands'),{BUCKET})).json();assert.equal(commands.commands.length,0);assert.equal(BUCKET.data.has('commands/old.json'),false);
});
test('cross-site state changes are rejected',async()=>{
 const worker=makeWorker('screen'),BUCKET=new MemoryR2();
 const r=await worker.fetch(req('/api/input','POST',{kind:'key',key:'back'},{Origin:'https://other.invalid'}),{BUCKET});assert.equal(r.status,403);
});
test('actual PNG bytes and capture timestamp survive relay',async()=>{
 const worker=makeWorker('screen'),BUCKET=new MemoryR2(),bytes=new Uint8Array([137,80,78,71,13,10,26,10]);
 const response=await worker.fetch(new Request(origin+'/api/bridge/frame',{method:'PUT',body:bytes,headers:{'X-Frame-Time':'123456789'}}),{BUCKET});assert.equal(response.status,200);
 const frame=await worker.fetch(req('/api/frame'),{BUCKET});assert.deepEqual(new Uint8Array(await frame.arrayBuffer()),bytes);assert.equal(frame.headers.get('X-Frame-Time'),'123456789');
});
test('speaker PCM remains exact, cursor avoids replay, storage stays bounded',async()=>{
 const worker=makeWorker('screen'),BUCKET=new MemoryR2(),base=Date.now()-2000;
 const bytes=new Uint8Array([0,128,255,127,0,0,123,42]);
 for(let i=0;i<10;i++){
  const response=await worker.fetch(new Request(origin+'/api/bridge/audio/'+(base+i*100),{method:'PUT',body:bytes}),{BUCKET});
  assert.equal(response.status,200);
 }
 const initial=await(await worker.fetch(req('/api/audio'),{BUCKET})).json();
 assert.equal(initial.chunks.length,2);
 assert.deepEqual(new Uint8Array(Buffer.from(initial.chunks[0].pcm,'base64')),bytes);
 assert.equal(initial.rate,24000);assert.equal(initial.channels,1);
 assert.equal([...BUCKET.data.keys()].filter(k=>k.startsWith('audio/')).length,8);
 const next=await(await worker.fetch(req('/api/audio?after='+initial.chunks.at(-1).id),{BUCKET})).json();
 assert.equal(next.chunks.length,0);
});
test('audio rejects stale timestamps and malformed PCM without inventing sound',async()=>{
 const worker=makeWorker('screen'),BUCKET=new MemoryR2();
 for(const [id,bytes] of [[String(Date.now()-10000),new Uint8Array(2)],[String(Date.now()),new Uint8Array(3)],[String(Date.now()),new Uint8Array(48002)]]){
  const response=await worker.fetch(new Request(origin+'/api/bridge/audio/'+id,{method:'PUT',body:bytes}),{BUCKET});assert.equal(response.status,400);
 }
 const empty=await(await worker.fetch(req('/api/audio'),{BUCKET})).json();assert.deepEqual(empty.chunks,[]);
});
