import test from 'node:test';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';

test('private Site relay refuses credential-bearing redirects and invalid origins', () => {
  execFileSync('python', [fileURLToPath(new URL('./relay_transport_test.py', import.meta.url))], {stdio:'pipe'});
});
