# Actual APK streaming client

`client.html` is a self-contained browser receiver and touch client. It contains
no game rules, recreated menu, simulated screen, score display, or APK emulator.
Every displayed game pixel must come from the live Android framebuffer endpoint.

The original Android screen occupies the main viewport. Connection chrome is
small and disappears in fullscreen. No external assets or JavaScript packages
are required.

## API

- `GET /api/status`: JSON `{online, updatedAt, width, height, packageName, note}`.
  `updatedAt` is Unix epoch milliseconds (ISO timestamps also parse). `packageName`
  is shown as the **session target**, because the bridge does not assert foreground
  activity. A server may add fields without affecting the client.
- `GET /api/frame?t=<cache-buster>`: `image/png`, `image/jpeg`, or `image/webp`.
  Return `Cache-Control: no-store` and `X-Frame-Time: <capture epoch milliseconds>`.
  The status timestamp is a fallback. Images without a usable capture timestamp
  cannot enable input. The client polls at200ms after each completed transfer,
  with no overlapping frame requests.
- `POST /api/input`: JSON tap, swipe, or Android Back, same-origin credentials.
  Return a JSON acknowledgment, e.g. `{accepted:true,id:"..."}`. A successful
  response is presented as transport acceptance, not proof of game execution.

Examples:

```json
{"kind":"tap","x":400,"y":240}
{"kind":"swipe","x":150,"y":240,"x2":550,"y2":240,"duration":350}
{"kind":"key","key":"back"}
```

Coordinates are intrinsic decoded-frame pixels. Letterboxing is excluded.
Swipes are clamped to80–1500ms, within the bridge's50–2000ms contract. Multitouch,
secondary mouse buttons, cancelled pointers, and release outside the image do
not send commands. Only one input HTTP request is outstanding at a time.

Input requires all of: status.online, a successfully decoded real frame, frame
age at most15seconds, active reception, and no pending input request. A status
response alone never enables game input. Stale images are dimmed and labeled.
Speaker audio is optional and disabled until the Android bridge reports actual
recent captured packets with `audio: true`. It is not a synthetic game soundtrack.
Software-rendering/transport latency is disclosed briefly.

## Optional original speaker audio

`GET /api/audio?after=<last-id>` returns `{rate:24000,channels:1,chunks:[]}`.
Each chunk has a 13-digit capture-completion epoch-millisecond `id` and `pcm`,
base64 signed16LE mono audio, at most48,000bytes. The initial request uses0
and receives at most the two most recent chunks; cursors prevent replay.
The server retains at most eight chunks, and the receiver drops old sound.
The browser starts Web Audio only from the user's speaker-button gesture.
Muting, pausing and hiding the tab stop scheduled buffers. No microphone
permission is requested. Original game UI pixels are unaffected.

The local bridge file contract is `stream/audio/<id>.pcm`, preferably500ms
(24,000bytes) per atomic file. The remote uploader accepts only fresh,
bounded files. Unchanged real screen pixels are republished with their current
capture timestamp at least every2.5seconds, so an idle menu remains interactive. It reports cloud audio availability only after successful
uploads. Instruction/protocol tests are separate from actual emulator audio
capture and browser listening, which must be reported independently.

## Verification

Run:

```sh
node tests/client-input.test.mjs
```

Tests cover letterbox/scaled coordinate mapping, invalid geometry, gesture
classification/cancellation, duration bounds, timestamp forms, freshness,
offline/pause gating, and JavaScript parsing. Browser QA against the actual
stream remains the parent session's responsibility; avoid simultaneous input
while the Android agent is testing the device.

For browser QA, `window.__YAGU_STREAM_DIAGNOSTICS__()` returns only connection
state, dimensions, capture time, pause/input state and intended package name.
It cannot inject game state or fabricate a screenshot.

The host must enforce private access, input validation/rate limits, and fresh
capture metadata. Deployment and emulator lifecycle are deliberately outside
this client. The source is ready for the parent Worker to serve at `/`.
