import http from 'node:http';
import {readFile,writeFile,rename,mkdir,readdir} from 'node:fs/promises';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {inputSchema} from '../worker/relay.js';
const root=path.resolve(import.meta.dirname,'..');
const stream=process.env.YAGU_STREAM_DIR||'/workspace/scratch/b308293898a9/build-work/android/stream';
const args=process.argv.slice(2);
const argValue=(key,fallback)=>{const i=args.indexOf(key);return i>=0&&args[i+1]?args[i+1]:fallback;};
const reply=(res,status,data,type='application/json')=>{res.writeHead(status,{'Content-Type':type,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(type==='application/json'?JSON.stringify(data):data);};
const status=async()=>{try{const s=JSON.parse(await readFile(path.join(stream,'status.json'),'utf8'));return {...s,online:s.online===true&&Date.now()-s.updatedAt<15000};}catch{return {online:false,updatedAt:0,width:800,height:480,packageName:null,note:'Android 실행 세션 연결 대기 중'};}};
http.createServer(async(req,res)=>{
 try {
  const url=new URL(req.url,'http://localhost'),p=url.pathname;
  if(p==='/'&&req.method==='GET')return reply(res,200,await readFile(path.join(root,'client.html')),'text/html; charset=utf-8');
  if(p==='/favicon.ico')return reply(res,204,'','text/plain');
  if(p==='/api/status')return reply(res,200,await status());
  if(p==='/api/audio'&&req.method==='GET'){
   const after=url.searchParams.get('after')||'0';
   if(after!=='0'&&!/^\d{13}$/.test(after))return reply(res,400,{error:'invalid_audio_cursor'});
   let names=[];
   try{names=(await readdir(path.join(stream,'audio'))).filter(n=>/^\d{13}\.pcm$/.test(n)&&Number(n.slice(0,13))>Number(after)&&Date.now()-Number(n.slice(0,13))>=0&&Date.now()-Number(n.slice(0,13))<6000).sort().slice(-8);}catch{}
   if(after==='0')names=names.slice(-2);
   const chunks=[];
   for(const name of names){try{const bytes=await readFile(path.join(stream,'audio',name));if(bytes.length>=2&&bytes.length<=48000&&bytes.length%2===0)chunks.push({id:name.slice(0,13),pcm:bytes.toString('base64')});}catch{}}
   return reply(res,200,{rate:24000,channels:1,chunks});
  }
  if(p==='/api/frame'){
   const s=await status();const bytes=await readFile(path.join(stream,'frame.png'));
   res.setHeader('X-Frame-Time',String(s.updatedAt||0));return reply(res,200,bytes,'image/png');
  }
  if(p==='/api/input'&&req.method==='POST'){
   if(req.headers['sec-fetch-site']==='cross-site')return reply(res,403,{error:'origin_mismatch'});
   const s=await status();if(!s.online)return reply(res,409,{error:'session_offline'});
   let raw='';for await(const b of req){raw+=b;if(raw.length>4096)return reply(res,413,{error:'too_large'});}
   const cmd=inputSchema(JSON.parse(raw));if(!cmd)return reply(res,400,{error:'invalid_input'});
   const id=Date.now()+'-'+randomUUID(),folder=path.join(stream,'commands');await mkdir(folder,{recursive:true});
   const f=path.join(folder,id+'.json');await writeFile(f+'.tmp',JSON.stringify({...cmd,id,createdAt:Date.now()}));await rename(f+'.tmp',f);
   return reply(res,202,{accepted:true,id});
  }
  reply(res,404,{error:'not_found'});
 }catch{reply(res,503,{error:'stream_unavailable'});}
}).listen(Number(argValue('--port',process.env.PORT||3000)),argValue('--host','0.0.0.0'),()=>console.log('Yagu actual APK dev stream ready'));
