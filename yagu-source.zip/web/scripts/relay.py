#!/usr/bin/env python3
"""Bridge actual emulator files to the owner-private Site; secret arrives on stdin.

No Android commands beyond the validated touch/back protocol are accepted.
The process does not persist, print, or send the Site token elsewhere.
"""
import json, sys, time, threading, urllib.request, urllib.error, hashlib, re
from pathlib import Path

tty_state=None
if sys.stdin.isatty():
    import termios
    tty_state=termios.tcgetattr(sys.stdin.fileno())
    hidden=termios.tcgetattr(sys.stdin.fileno());hidden[3]&=~termios.ECHO
    termios.tcsetattr(sys.stdin.fileno(),termios.TCSANOW,hidden)
print('Ready for relay JSON on stdin (input is hidden).', flush=True)
try:config=json.loads(sys.stdin.readline())
finally:
    if tty_state is not None:termios.tcsetattr(sys.stdin.fileno(),termios.TCSANOW,tty_state)
origin=config['url'].rstrip('/')
if not origin.startswith('https://'):raise ValueError('HTTPS required')
token=config.pop('token')
root=Path(config['stream_directory']).resolve()
for name in ['commands','acks']:(root/name).mkdir(parents=True,exist_ok=True)
stop=threading.Event()
audio_last_uploaded=0

def request(route,method='GET',body=None,extra=None):
    headers={'OAI-Sites-Authorization':'Bearer '+token,**(extra or {})}
    if isinstance(body,dict):body=json.dumps(body).encode();headers['Content-Type']='application/json'
    req=urllib.request.Request(origin+route,data=body,method=method,headers=headers)
    with urllib.request.urlopen(req,timeout=12) as res:
        return json.loads(res.read()) if res.headers.get('Content-Type','').startswith('application/json') else None

def command_loop():
    error_last=0
    seen=set()
    while not stop.is_set():
        try:
            result=request('/api/bridge/commands')
            ids=[]
            for cmd in result.get('commands',[]):
                ident=cmd['id']
                if not isinstance(ident,str) or '/' in ident or len(ident)>60:continue
                if ident not in seen:
                    f=root/'commands'/(ident+'.json');tmp=f.with_suffix('.tmp')
                    tmp.write_text(json.dumps(cmd));tmp.replace(f);seen.add(ident)
                ids.append(ident)
            if ids:request('/api/bridge/ack','POST',{'ids':ids})
            if len(seen)>2000:seen=set(list(seen)[-500:])
        except Exception as e:
            if time.time()-error_last>15:print(json.dumps({'event':'command_relay_error','kind':type(e).__name__}),flush=True);error_last=time.time()
        stop.wait(.35)

thread=threading.Thread(target=command_loop,daemon=True);thread.start()
def audio_loop():
    global audio_last_uploaded
    last_id=0;error_last=0
    while not stop.is_set():
        try:
            paths=sorted((root/'audio').glob('*.pcm'))[-8:]
            for path in paths:
                if path.is_symlink() or not re.fullmatch(r'\d{13}',path.stem):continue
                ident=int(path.stem)
                if ident<=last_id:continue
                if not 0<=time.time()*1000-ident<5000:continue
                if not 2<=path.stat().st_size<=48000 or path.stat().st_size%2:continue
                request('/api/bridge/audio/'+path.stem,'PUT',path.read_bytes(),{'Content-Type':'application/octet-stream'})
                last_id=ident;audio_last_uploaded=time.time()
        except Exception as e:
            if time.time()-error_last>15:print(json.dumps({'event':'audio_relay_error','kind':type(e).__name__}),flush=True);error_last=time.time()
        stop.wait(.2)

audio_thread=threading.Thread(target=audio_loop,daemon=True);audio_thread.start()
last_frame=None;last_frame_upload=0;last_status=0;error_last=0
try:
    while not stop.is_set():
        try:
            s=json.loads((root/'status.json').read_text())
            s['audio']=s.get('audio') is True and time.time()-audio_last_uploaded<3
            frame=(root/'frame.png').read_bytes()
            digest=hashlib.sha256(frame).hexdigest()
            if digest!=last_frame or time.time()-last_frame_upload>2.5:
                request('/api/bridge/frame','PUT',frame,{'Content-Type':'image/png','X-Frame-Time':str(s['updatedAt'])})
                last_frame=digest;last_frame_upload=time.time()
            request('/api/bridge/status','PUT',s)
            if not last_status:print(json.dumps({'event':'live','package':s.get('packageName'),'width':s.get('width'),'height':s.get('height')}),flush=True)
            last_status=time.time()
        except Exception as e:
            if time.time()-error_last>15:print(json.dumps({'event':'frame_relay_error','kind':type(e).__name__}),flush=True);error_last=time.time()
        stop.wait(.2)
except KeyboardInterrupt:
    stop.set()
