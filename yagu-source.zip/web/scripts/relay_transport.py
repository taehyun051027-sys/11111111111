"""Thread-local persistent HTTPS, normal proxy/TLS, one private Site origin.

urllib's default handler deliberately closes every HTTP/1.1 connection. This
handler retains one connection per relay thread so frame/status/input/audio do
not share a connection or repeat CONNECT/TLS for every packet. ProxyHandler is
unchanged; TLS still uses Python's normal verified default context.
"""
import http.client
import ssl
import threading
import urllib.error
import urllib.parse
import urllib.request


class NoSiteRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # urllib would otherwise copy the custom authorization header to the
        # redirected request. A private API should answer directly; login or
        # cross-origin redirects must stop before forwarding its credential.
        raise urllib.error.HTTPError(req.full_url, code, 'Site API redirect refused', headers, fp)


def _origin(url):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.fragment:
        raise ValueError('Expected the configured HTTPS Site origin')
    return parsed.scheme, parsed.hostname.lower(), parsed.port or 443


class PersistentSiteHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, origin):
        super().__init__(context=ssl.create_default_context())
        self.origin = _origin(origin)
        self.local = threading.local()

    def https_request(self, req):
        if _origin(req.full_url) != self.origin:
            raise ValueError('Site API origin mismatch')
        return self.do_request_(req)

    def close_current_thread(self):
        connection = getattr(self.local, 'connection', None)
        if connection is not None:
            connection.close()
        self.local.connection = None
        self.local.key = None

    def https_open(self, req):
        if _origin(req.full_url) != self.origin:
            raise ValueError('Site API origin mismatch')
        # The standard ProxyHandler has already selected the normal proxy and
        # tunnel destination. Proxy credentials stay on CONNECT, as in urllib.
        headers = dict(req.unredirected_hdrs)
        headers.update({k: v for k, v in req.headers.items() if k not in headers})
        headers = {name.title(): value for name, value in headers.items()}
        headers.pop('Connection', None)
        tunnel_headers = {}
        if req._tunnel_host and 'Proxy-Authorization' in headers:
            tunnel_headers['Proxy-Authorization'] = headers.pop('Proxy-Authorization')
        key = (req.host, req._tunnel_host, tuple(tunnel_headers.items()))
        connection = getattr(self.local, 'connection', None)
        if connection is None or getattr(self.local, 'key', None) != key:
            self.close_current_thread()
            connection = http.client.HTTPSConnection(req.host, timeout=req.timeout, context=self._context)
            if req._tunnel_host:
                connection.set_tunnel(req._tunnel_host, headers=tunnel_headers)
            self.local.connection, self.local.key = connection, key
        connection.timeout = req.timeout
        if connection.sock is not None:
            connection.sock.settimeout(req.timeout)
        try:
            connection.request(req.get_method(), req.selector, req.data, headers,
                               encode_chunked=req.has_header('Transfer-encoding'))
            response = connection.getresponse()
        except Exception:
            self.close_current_thread()
            raise
        response.url = req.full_url
        response.msg = response.reason
        return response

    def https_response(self, req, response):
        if 200 <= response.status < 300:
            return response
        # Drain small errors to keep an already established TLS connection
        # usable after an expired audio packet. Never follow any redirect.
        try:
            response.read(65537)
            complete = response.isclosed()
        except Exception:
            complete = False
        finally:
            response.close()
        if not complete or 300 <= response.status < 400:
            self.close_current_thread()
        raise urllib.error.HTTPError(req.full_url, response.status,
                                     'Site API request refused', response.headers, None)


def private_site_opener(origin):
    parsed = urllib.parse.urlsplit(origin)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError('Expected the configured HTTPS Site URL without credentials or query')
    if parsed.path not in ('', '/'):
        raise ValueError('Expected the Site root URL')
    return urllib.request.build_opener(NoSiteRedirects(), PersistentSiteHTTPSHandler(origin))
