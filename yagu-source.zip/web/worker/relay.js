// Owner-private Android screen/input relay. The Site dispatch access boundary
// authenticates browser users and service callers; no credential is in this file.
const headers = {'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'};
const json = (data, status=200) => new Response(JSON.stringify(data), {status,headers:{...headers,'Content-Type':'application/json; charset=utf-8'}});
const MAX_AGE = 15000;
function inputSchema(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
  const coord = (v, max) => Number.isInteger(v) && v >= 0 && v < max;
  if (raw.kind === 'key' && raw.key === 'back') return {kind:'key',key:'back'};
  if (!coord(raw.x,800) || !coord(raw.y,480)) return null;
  if (raw.kind === 'tap') return {kind:'tap',x:raw.x,y:raw.y};
  if (raw.kind === 'swipe' && coord(raw.x2,800) && coord(raw.y2,480) && Number.isInteger(raw.duration) && raw.duration >= 50 && raw.duration <= 2000)
    return {kind:'swipe',x:raw.x,y:raw.y,x2:raw.x2,y2:raw.y2,duration:raw.duration};
  return null;
}
async function boundedJson(request, limit=4096) {
  const text=await request.text();
  if (text.length>limit) throw new Error('request_too_large');
  return JSON.parse(text);
}
async function readStatus(bucket) {
  const object=await bucket.get('session/status.json');
  if (!object) return {online:false,updatedAt:0,width:800,height:480,packageName:null,note:'Android 실행 세션이 연결되지 않았습니다.'};
  const s=await object.json();
  return {...s,online:s.online === true && Date.now()-s.updatedAt<MAX_AGE};
}
function audioId(value) {
  return typeof value==='string' && /^\d{13}$/.test(value) && Number(value)<=Date.now()+1000;
}
function audioBase64(bytes) {
  let binary='';
  for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  return btoa(binary);
}
async function audioIndex(bucket) {
  const object=await bucket.get('session/audio-index.json');
  const value=object?await object.json():[];
  return Array.isArray(value)?value.filter(audioId).sort():[];
}
export function makeWorker(html) {
  return {async fetch(request, env) {
    const url=new URL(request.url), p=url.pathname, method=request.method;
    if (method!=='GET' && method!=='HEAD') {
      const origin=request.headers.get('Origin');
      if (origin && origin!==url.origin) return json({error:'origin_mismatch'},403);
    }
    if (p==='/' && method==='GET') return new Response(html,{headers:{...headers,'Content-Type':'text/html; charset=utf-8'}});
    if(p==='/favicon.ico') return new Response(null,{status:204,headers});
    if (!p.startsWith('/api/')) return json({error:'not_found'},404);
    const bucket=env.BUCKET;
    if (!bucket) return json({error:'storage_unavailable'},503);
    try {
      if(p==='/api/status' && method==='GET') return json(await readStatus(bucket));
      if(p==='/api/audio' && method==='GET') {
        const after=url.searchParams.get('after')||'0';
        if(after!=='0'&&!audioId(after))return json({error:'invalid_audio_cursor'},400);
        let ids=(await audioIndex(bucket)).filter(id=>Number(id)>Number(after)&&Date.now()-Number(id)<6000);
        // Starting reception should not replay seconds of old sound.
        if(after==='0')ids=ids.slice(-2);
        const chunks=[];
        for(const id of ids) {
          const object=await bucket.get('audio/'+id+'.pcm');
          if(object)chunks.push({id,pcm:audioBase64(new Uint8Array(await object.arrayBuffer()))});
        }
        return json({rate:24000,channels:1,chunks});
      }
      if(p==='/api/frame' && method==='GET') {
        const object=await bucket.get('session/frame.png');
        if(!object) return json({error:'frame_unavailable'},503);
        return new Response(object.body,{headers:{...headers,'Content-Type':'image/png','X-Frame-Time':object.customMetadata?.updatedAt||'0'}});
      }
      if(p==='/api/input' && method==='POST') {
        const status=await readStatus(bucket);
        if(!status.online) return json({error:'session_offline'},409);
        const command=inputSchema(await boundedJson(request));
        if(!command) return json({error:'invalid_input'},400);
        const id=String(Date.now()).padStart(13,'0')+'-'+crypto.randomUUID();
        await bucket.put('commands/'+id+'.json',JSON.stringify({...command,id,createdAt:Date.now()}),{httpMetadata:{contentType:'application/json'}});
        return json({accepted:true,id},202);
      }
      // Requests below are made by the relay process using documented Site
      // service authorization. The private Site boundary is preserved.
      if(p==='/api/bridge/status' && method==='PUT') {
        const s=await boundedJson(request);
        if(s.width!==800 || s.height!==480 || !Number.isFinite(s.updatedAt) || typeof s.online!=='boolean') return json({error:'invalid_status'},400);
        const sanitized={online:s.online,updatedAt:s.updatedAt,width:800,height:480,packageName:typeof s.packageName==='string'?s.packageName.slice(0,120):null,note:typeof s.note==='string'?s.note.slice(0,400):'',frameSeconds:Math.max(0,Number(s.frameSeconds)||0),inputSeconds:Math.max(0,Number(s.inputSeconds)||0),audio:s.audio===true};
        await bucket.put('session/status.json',JSON.stringify(sanitized));return json({ok:true});
      }
      if(p.startsWith('/api/bridge/audio/') && method==='PUT') {
        const id=p.slice('/api/bridge/audio/'.length);
        if(!audioId(id)||Date.now()-Number(id)>6000)return json({error:'invalid_audio_time'},400);
        const bytes=await request.arrayBuffer();
        if(bytes.byteLength<2||bytes.byteLength>48000||bytes.byteLength%2)return json({error:'invalid_audio_pcm'},400);
        const previous=await audioIndex(bucket);
        await bucket.put('audio/'+id+'.pcm',bytes,{httpMetadata:{contentType:'application/octet-stream'}});
        const keep=[...new Set([...previous,id])].sort().slice(-8);
        await bucket.put('session/audio-index.json',JSON.stringify(keep));
        for(const old of previous)if(!keep.includes(old))await bucket.delete('audio/'+old+'.pcm');
        return json({ok:true});
      }
      if(p==='/api/bridge/frame' && method==='PUT') {
        const bytes=await request.arrayBuffer();
        const b=new Uint8Array(bytes);
        if(bytes.byteLength>2200000 || b[0]!==137 || b[1]!==80 || b[2]!==78 || b[3]!==71) return json({error:'invalid_png'},400);
        const updatedAt=Number(request.headers.get('X-Frame-Time'));
        if(!Number.isFinite(updatedAt))return json({error:'invalid_frame_time'},400);
        await bucket.put('session/frame.png',bytes,{httpMetadata:{contentType:'image/png'},customMetadata:{updatedAt:String(updatedAt)}});
        return json({ok:true});
      }
      if(p==='/api/bridge/commands' && method==='GET') {
        const list=await bucket.list({prefix:'commands/',limit:30});
        const commands=[];
        for(const meta of list.objects) {
          const obj=await bucket.get(meta.key);if(!obj)continue;
          const cmd=await obj.json();
          if(Date.now()-cmd.createdAt>MAX_AGE) await bucket.delete(meta.key);
          else commands.push(cmd);
        }
        return json({commands});
      }
      if(p==='/api/bridge/ack' && method==='POST') {
        const body=await boundedJson(request);
        if(!Array.isArray(body.ids)||body.ids.length>30||!body.ids.every(id=>/^\d{13}-[a-f0-9-]{36}$/.test(id)))return json({error:'invalid_ack'},400);
        for(const id of body.ids)await bucket.delete('commands/'+id+'.json');
        return json({ok:true});
      }
      return json({error:'not_found'},404);
    }catch(error){return json({error:error instanceof SyntaxError?'invalid_json':'relay_error'},400);}
  }};
}
export {inputSchema};
